(()=>{
'use strict';
if(window.__ECP_V162_ANDROID_SYNC)return;
window.__ECP_V162_ANDROID_SYNC=true;
window.__ECP_ANDROID_BUILD='1.5.22-android-sync';
window.__ECP_CROSS_PLATFORM_CALLS=true;
window.__ECP_ACCOUNT_RECOVERY=true;
window.__ECP_PERMISSION_RETRY=true;
})();
