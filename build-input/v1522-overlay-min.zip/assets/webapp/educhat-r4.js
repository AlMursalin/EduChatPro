(() => {
  'use strict';
  const paths = {
    home:'<path d="m3 11 9-8 9 8v10h-6v-7H9v7H3V11Z"/>',
    search:'<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/>',
    menu:'<path d="M5 6h14M5 12h14M5 18h14"/>',
    more:'<circle cx="12" cy="4" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="20" r="1"/>',
    settings:'<path d="m9 3 6 0 1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1 1-3Z"/><circle cx="12" cy="12" r="3"/>',
    bookmark:'<path d="M6 3h12v19l-6-5-6 5V3Z"/>',
    moon:'<path d="M19 17A9 9 0 0 1 9 3a9 9 0 1 0 10 14Z"/>',
    check:'<path d="m4 12 5 5L21 5"/>',
    doublecheck:'<path d="m1 12 5 5L18 5m-7 10 2 2L25 5"/>',
    back:'<path d="m14 4-8 8 8 8M6 12h16"/>',
    chevron:'<path d="m9 5 7 7-7 7"/>',
    cloud:'<path d="M6 18a5 5 0 0 1-1-10 7 7 0 0 1 13-1 5 5 0 0 1 0 11H6Z"/>',
    smile:'<circle cx="12" cy="12" r="9"/><path d="M8 14q4 5 8 0M8 8h.01M16 8h.01"/>',
    paperclip:'<path d="m9 16 8-8a3 3 0 0 0-4-4L4 13a5 5 0 0 0 7 7L21 10M8 13l6-6"/>',
    send:'<path d="m3 3 19 9-19 9 4-9-4-9Zm4 9h15"/>',
    trash:'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7"/>',
    sliders:'<path d="M4 6h16M7 12h10M10 18h4"/>',
    at:'<circle cx="11" cy="12" r="4"/><path d="M15 8v8c9 1 8-14-3-14A10 10 0 1 0 18 20"/>',
    megaphone:'<path d="M3 10v6h5l11 5V3L8 10H3Zm5 6 2 6h4l-2-5M8 10v6"/>',
    list:'<path d="M9 5h12M9 12h12M9 19h12M3 4h2v2H3zM3 11h2v2H3zM3 18h2v2H3z"/>',
    flame:'<path d="M12 2c4 6-3 7 3 11 2-2 3-4 3-4 9 14-15 19-13 4 0-4 5-7 7-11Z"/>',
    question:'<circle cx="12" cy="12" r="9"/><path d="M9 9c0-4 7-4 6 0-1 2-3 1-3 5M12 17h.01"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8" cy="8" r="2"/><path d="m3 17 6-5 4 3 4-5 4 7"/>',
    chart:'<path d="M3 12h4v9H3zM10 3h4v18h-4zM17 8h4v13h-4z"/>',
    like:'<path d="M8 21H3V10h5m0 11h10l3-10H14l1-7-3-2-4 8v11Z"/>',
    share:'<path d="m14 3 8 8-8 8v-5C6 13 3 20 3 20c0-12 4-12 11-12V3Z"/>',
    trending:'<path d="m3 18 6-7 4 3 8-10M15 4h6v6"/>',
    trophy:'<path d="M7 3h10v7a5 5 0 0 1-10 0V3Zm0 2H3v3a5 5 0 0 0 5 5m9-8h4v3a5 5 0 0 1-5 5M12 15v6M7 21h10"/>',
    bulb:'<path d="M8 17c0-4-3-4-3-8a7 7 0 0 1 14 0c0 4-3 4-3 8H8Zm1 4h6M12 17v-7"/>',
    ban:'<circle cx="12" cy="12" r="9"/><path d="m6 6 12 12"/>',

    school:'<path d="m2 9 10-5 10 5-10 5-10-5Z"/><path d="M6 11v6c4 3 8 3 12 0v-6M22 9v7"/>',
    chat:'<path d="M21 11a8 8 0 0 1-8 8H5l-3 3V11a8 8 0 0 1 8-8h3a8 8 0 0 1 8 8Z"/><path d="M7 8h9M7 12h6"/>',
    video:'<rect x="3" y="5" width="12" height="14" rx="3"/><path d="m15 10 6-4v12l-6-4"/>',
    mic:'<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2M12 19v3M8 22h8"/>',
    screen:'<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4m-4-11 4-4 4 4M12 6v8"/>',
    record:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>',
    pointer:'<path d="m5 3 14 9-7 1-3 7-4-17Z"/>',
    people:'<circle cx="9" cy="7" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M16 4a3 3 0 0 1 0 6M18 14a5 5 0 0 1 3 5v2"/>',
    headphones:'<path d="M3 14v-3a9 9 0 0 1 18 0v3"/><rect x="3" y="12" width="4" height="9" rx="2"/><rect x="17" y="12" width="4" height="9" rx="2"/>',
    phone:'<path d="M3 15c5-5 13-5 18 0l-2 4-4-2v-3H9v3l-4 2-2-4Z"/>',
    bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
    user:'<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/>',
    shield:'<path d="m12 2 9 4v6c0 5-9 10-9 10S3 17 3 12V6l9-4Z"/><path d="m8 12 3 3 5-6"/>',
    folder:'<path d="M3 6V4h7l2 3h9v13H3V6Z"/>',
    file:'<path d="M5 2h9l5 5v15H5V2Z"/><path d="M14 2v6h5M8 12h8M8 16h8"/>',
    pin:'<path d="m8 3 8 0-1 7 4 4H5l4-4-1-7ZM12 14v8"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>',
    plus:'<path d="M12 4v16M4 12h16"/>',
    refresh:'<path d="M20 7v5h-5M4 17v-5h5M6 6a8 8 0 0 1 14 6M4 12a8 8 0 0 0 14 6"/>',
    volume:'<path d="m3 9 5 0 5-5v16l-5-5H3V9ZM17 8a6 6 0 0 1 0 8M20 5a10 10 0 0 1 0 14"/>'
  };
  window.EduIcons = name => `<svg class="edu-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${paths[name] || paths.file}</svg>`;
})();

;
(() => {
  // Decode and re-encode user photos, limiting dimensions and stripping metadata.
  async function compress(file) {
    if (!['image/jpeg','image/png','image/webp'].includes(file.type) || file.size>10485760)
      throw new Error('Choose a JPG, PNG or WebP image up to 10 MB.');
    const url=URL.createObjectURL(file),img=new Image();
    try {
      await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(new Error('This image could not be read.'));img.src=url;});
      const scale=Math.min(1,640/Math.max(img.naturalWidth,img.naturalHeight));
      const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
      const ctx=canvas.getContext('2d');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
      const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',.82));
      if(!blob||blob.size>1048576)throw new Error('Image could not be compressed below 1 MB.');return blob;
    } finally {URL.revokeObjectURL(url);}
  }
  window.EduImages={compress};
})();

;
(() => {
 'use strict';
 const W=window.EduWorkspace=window.EduWorkspace||{cleanups:[],pending:null};
 W.dispose=()=>{window.EduUI.closeModal();for(const fn of W.cleanups.splice(0)){try{fn();}catch{}}};
 W.rich=value=>window.EduUI.esc(value||'').replace(/\*\*([^]+?)\*\*/g,'<strong>$1</strong>').replace(/==([^]+?)==/g,'<mark>$1</mark>').replace(/((?:https?:\/\/|www\.)[^\s<]+)/gi,m=>{const h=/^www\./i.test(m)?'https://'+m:m;return '<a class="ws-link" href="'+h+'" target="_blank" rel="noopener noreferrer">'+m+'</a>'});
 W.icon=(name)=>window.EduIcons(name);
 W.run=(fn)=>async(...args)=>{try{return await fn(...args);}catch(e){window.EduUI.toast(window.EduUI.errorText(e),'error');}};
 W.data=r=>{if(r.error)throw r.error;return r.data;};
 W.time=v=>v?new Intl.DateTimeFormat(undefined,{hour:'numeric',minute:'2-digit'}).format(new Date(v)):'';
 W.date=v=>new Intl.DateTimeFormat(undefined,{dateStyle:'medium'}).format(new Date(v));
 W.avatar=(name,path=null,bucket='avatars',extra='')=>`<span class="ws-avatar ${extra}">${path?`<img alt="${window.EduUI.attr(name||'Profile')}" data-photo="${window.EduUI.attr(path)}" data-bucket="${bucket}" loading="lazy">`:window.EduUI.esc((name||'?').trim().slice(0,1).toUpperCase())}</span>`;
 const photoCache=new Map();
 W.photos=async(root,sb)=>{const {data}=await sb.auth.getSession();const user=data.session?.user.id;if(!user)return;await Promise.all([...root.querySelectorAll('[data-photo]')].map(async img=>{const photo=img.dataset.photo,bucket=img.dataset.bucket||'avatars',identity=`${user}|${bucket}|${photo}`;if(!photo||img.dataset.photoLoaded===identity&&img.src)return;try{const url=await window.EduPhotos.get(sb,user,bucket,photo);if(img.isConnected&&img.dataset.photo===photo){img.src=url;img.dataset.photoLoaded=identity;}}catch{img.alt=img.alt||'Profile';}}));};
 W.patchChildren=(container,html,keyAttr='data-render-key')=>{const t=document.createElement('template');t.innerHTML=html;const desired=[...t.content.children],existing=new Map([...container.children].map(n=>[n.getAttribute(keyAttr),n]).filter(([k])=>k));const keep=new Set();for(const fresh of desired){const key=fresh.getAttribute(keyAttr),old=key?existing.get(key):null,stamp=fresh.getAttribute('data-render-stamp');let node=fresh;if(old&&old.getAttribute('data-render-stamp')===stamp){node=old;keep.add(old);}else if(old){old.replaceWith(fresh);keep.add(fresh);}else{keep.add(fresh);}container.appendChild(node);}for(const node of [...container.children])if(!keep.has(node))node.remove();};
 W.button=(icon,label,attrs='',className='ws-icon-btn')=>`<button class="${className}" title="${label}" aria-label="${label}" ${attrs}>${W.icon(icon)}</button>`;
 W.watch=(sb,tables,callback)=>{const timers=new Map(),channel=sb.channel('workspace-'+crypto.randomUUID());for(const table of tables)channel.on('postgres_changes',{event:'*',schema:'public',table},payload=>{clearTimeout(timers.get(table));timers.set(table,setTimeout(()=>Promise.resolve(callback({table,payload})).catch(e=>window.EduUI.toast(e.message,'error')),80));});channel.subscribe();W.cleanups.push(()=>{for(const timer of timers.values())clearTimeout(timer);sb.removeChannel(channel);});return channel;};
 W.upload=async(sb,bucket,prefix,file)=>{
  if(!file.size||file.size>10485760)throw new Error('Choose a file between 1 byte and 10 MB.');
  let upload=file,mime=file.type||({pdf:'application/pdf',zip:'application/zip',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}[file.name.split('.').pop().toLowerCase()]);
  if(mime?.startsWith('image/')){upload=await window.EduImages.compress(file);mime='image/jpeg';}
  const allowed=['image/jpeg','image/png','image/webp','application/pdf','application/zip','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','audio/webm','audio/ogg','audio/mp4','video/mp4','video/webm','video/quicktime'];
  mime=mime?.split(';')[0];if(!allowed.includes(mime))throw new Error('This file type is not supported.');
  const path=prefix+'/'+crypto.randomUUID()+'/'+window.EduUI.safeName(file.name);W.data(await sb.storage.from(bucket).upload(path,upload,{contentType:mime}));return {attachment_path:path,attachment_name:file.name,attachment_mime:mime};
 };
 W.attachment=(m,bucket)=>{if(!m.attachment_path&&m.image_path)m={...m,attachment_path:m.image_path,attachment_name:'Post media',attachment_mime:/\.(mp4|webm|mov)$/i.test(m.image_path)?'video/mp4':'image/jpeg'},bucket='forum-images';else if(m.attachment_path&&!m.attachment_mime)m={...m,attachment_name:m.file_name||'Attachment',attachment_mime:m.mime_type||'application/octet-stream'},bucket=m.thread_id?'direct-files':'group-files';if(!m.attachment_path)return '';const mime=m.attachment_mime||m.mime_type||'application/octet-stream',name=m.attachment_name||m.file_name||'Attachment',image=mime.startsWith('image/'),video=mime.startsWith('video/'),audio=mime.startsWith('audio/');const preview=image?`<img class="ws-inline-media ws-inline-image" alt="${window.EduUI.attr(name)}" data-photo="${window.EduUI.attr(m.attachment_path)}" data-bucket="${bucket}" loading="lazy" decoding="async">`:video?'<div class="ws-inline-video-wrap"><video class="ws-inline-media ws-inline-video" muted playsinline preload="metadata"></video><span class="ws-inline-video-play" aria-hidden="true">▶</span></div>':audio?'<audio controls preload="metadata"></audio>':W.icon('file');const actions=(image||video)?`<details class="ws-media-more"><summary aria-label="Media actions" title="Media actions">⋮</summary><div class="ws-media-more-menu"><button class="ws-file-download" type="button">Download</button></div></details>`:audio?'':`<div class="ws-file-actions"><button class="ws-file-open">${window.EduUI.esc(name||'Open attachment')}</button><button class="ws-file-download" type="button">Download</button></div>`;return `<div class="ws-attachment ${image||video?'ws-media-attachment':''}" data-file-path="${window.EduUI.attr(m.attachment_path)}" data-file-bucket="${bucket}" data-file-name="${window.EduUI.attr(name)}" data-file-mime="${window.EduUI.attr(mime)}">${preview}${actions}</div>`;};
 W.openMediaViewer=({url,mime,name='Media',download})=>{const log=document.querySelector('#message-log,#dm-log,#chat-log,.ws-message-log,.chat-log'),top=log?.scrollTop??0,d=document.createElement('dialog');d.className='ecp-full-media-viewer';const video=mime.startsWith('video/');d.innerHTML=`<div class="ecp-media-top"><button type="button" class="ecp-media-back" aria-label="Back">‹</button><strong>${window.EduUI.esc(name)}</strong><details class="ecp-media-more"><summary aria-label="Media actions">⋮</summary><div><button type="button" data-viewer-download>Download</button></div></details></div><div class="ecp-media-stage">${video?`<video src="${window.EduUI.attr(url)}" controls autoplay playsinline></video>`:`<img src="${window.EduUI.attr(url)}" alt="${window.EduUI.attr(name)}">`}</div>`;document.body.append(d);let restored=false;const restore=()=>{if(restored)return;restored=true;const media=d.querySelector('video');try{media?.pause()}catch{};requestAnimationFrame(()=>{if(log?.isConnected)log.scrollTop=top;});};d.querySelector('.ecp-media-back').onclick=()=>d.close();d.oncancel=e=>{e.preventDefault();d.close()};d.onclose=()=>{restore();d.remove()};d.querySelector('[data-viewer-download]').onclick=async()=>{try{await download?.();d.querySelector('.ecp-media-more')?.removeAttribute('open');}catch(e){window.EduUI.toast(window.EduUI.errorText(e),'error')}};d.showModal();return d;};
 W.files=(root,sb)=>{for(const el of root.querySelectorAll('[data-file-path]')){const mime=el.dataset.fileMime||'',name=el.dataset.fileName||'Attachment',bucket=el.dataset.fileBucket,path=el.dataset.filePath,image=mime.startsWith('image/'),video=mime.startsWith('video/'),audio=mime.startsWith('audio/');const download=async()=>{const data=W.data(await sb.storage.from(bucket).download(path));window.EduUI.download(name,data,mime||data.type||'application/octet-stream');};const openMedia=async()=>{let preview=el.querySelector('img,video'),url=preview?.currentSrc||preview?.src||'';if(!url){const link=W.data(await sb.storage.from(bucket).createSignedUrl(path,1800));url=link.signedUrl;}W.openMediaViewer({url,mime,name,download});};const open=el.querySelector('.ws-file-open');if(open&&!open.dataset.bound){open.dataset.bound='1';open.onclick=W.run(async()=>{if(image||video)return openMedia();const link=W.data(await sb.storage.from(bucket).createSignedUrl(path,600));window.open(link.signedUrl,'_blank','noopener,noreferrer');});}const dl=el.querySelector('.ws-file-download');if(dl&&!dl.dataset.bound){dl.dataset.bound='1';dl.addEventListener('click',W.run(async e=>{e.preventDefault();e.stopPropagation();await download();el.querySelector('.ws-media-more')?.removeAttribute('open');}));}const preview=el.querySelector('img.ws-inline-media,video.ws-inline-media');if(preview&&!preview.dataset.previewBound){preview.dataset.previewBound='1';preview.tabIndex=0;preview.setAttribute('role','button');preview.setAttribute('aria-label','Open '+name+' full screen');preview.onclick=e=>{e.preventDefault();openMedia().catch(err=>window.EduUI.toast(window.EduUI.errorText(err),'error'));};preview.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();preview.click();}};}const media=el.querySelector('audio,video');if(media&&!media.dataset.mediaLoaded){media.dataset.mediaLoaded='1';const assign=async(preserve=false)=>{const t=preserve?media.currentTime:0,paused=media.paused,r=await sb.storage.from(bucket).createSignedUrl(path,1800);if(!r.error&&media.isConnected){media.src=r.data.signedUrl;if(preserve&&t>0){media.addEventListener('loadedmetadata',()=>{try{media.currentTime=t;if(!paused&&!video)media.play().catch(()=>{});}catch{}},{once:true});}}};assign(false);media.addEventListener('error',()=>{if(media.dataset.mediaRefreshing)return;media.dataset.mediaRefreshing='1';assign(true).finally(()=>setTimeout(()=>delete media.dataset.mediaRefreshing,1000));});}}};
 W.shell=(c)=>{
  const {S,U,navigate}=c;const links=[['chats','chat','Chats'],['groups','people','Groups'],['meetings','video','Calls'],['contacts','user','Contacts'],['saved','bookmark','Saved'],['forum','home','Forum'],['notifications','bell','Notifications'],['profile','settings','Settings']];if(c.isAdmin())links.push(['admin','shield','Admin']);
  document.querySelector('#app').innerHTML=`<div class="ws-shell"><aside class="ws-rail"><a class="ws-logo" href="#" aria-label="EduChat home">${W.icon('school')}<small>EC</small></a><nav>${links.map(([id,icon,title])=>`<button data-nav="${id}" title="${title}" aria-label="${title}">${W.icon(icon)}<span>${title}</span></button>`).join('')}</nav><button class="ws-account" title="Your profile">${W.avatar(S.profile?.full_name,S.profile?.avatar_path)}<i></i></button></aside><div class="ws-main"><header class="ws-topbar">${W.button('menu','Toggle sidebar','id="ws-menu"')}<b>Edu Chat Pro</b><span class="spacer"></span>${W.button('bell','Notifications','data-nav="notifications"')}${W.button('moon','Toggle dark mode','id="ws-theme"')}<button class="ws-user" title="Profile">${W.avatar(S.profile?.full_name,S.profile?.avatar_path)}</button><button class="ws-signout">Sign out</button></header><main id="page" class="ws-page"></main></div></div>`;
  U.qa('[data-nav]').forEach(b=>b.onclick=()=>{W.inboxFilter=b.dataset.nav==='chats'?'direct':null;return navigate(b.dataset.nav);});U.q('.ws-logo').onclick=e=>{e.preventDefault();navigate('chats');};U.q('.ws-account').onclick=U.q('.ws-user').onclick=()=>navigate('profile');U.q('.ws-signout').onclick=W.run(()=>c.sb.auth.signOut());
  U.q('#ws-menu').onclick=()=>document.querySelector('.ws-shell').classList.toggle('rail-expanded');
  let dark=false;try{dark=(localStorage.getItem('educhat-theme')||localStorage.getItem('ecp-theme'))==='dark';}catch{}document.body.classList.toggle('ws-dark',dark);document.documentElement.dataset.theme=dark?'dark':'light';
  U.q('#ws-theme').onclick=()=>{const next=!document.body.classList.contains('ws-dark');document.body.classList.toggle('ws-dark',next);document.documentElement.dataset.theme=next?'dark':'light';try{localStorage.setItem('educhat-theme',next?'dark':'light');localStorage.setItem('ecp-theme',next?'dark':'light');}catch{}window.dispatchEvent(new CustomEvent('edu-theme',{detail:{theme:next?'dark':'light'}}));};W.photos(document.querySelector('.ws-shell'),c.sb);
 };
 W.openChat=(c,kind,id)=>{W.pending={kind,id};return c.navigate(kind==='group'?'groups':'people');};
})();

;
(() => {
 'use strict';const W=window.EduWorkspace;
 W.chat=async(c,initial='all')=>{
  const {sb,S,U}=c,root=U.q('#page');let closed=false,threads=[],selected=null,filter=initial==='groups'?'group':initial==='direct'?'direct':'all',view=initial==='saved'?'saved':'all',search='',offset=0,messages=[],messageSearch='',messageOffset=0,profiles={},receipts=[],reactions=[],generation=0,listGeneration=0,attached=null,recorder=null,recordStream=null,recordChunks=[],voicePanel=null,voiceTimer=null,voiceRaf=0,voiceAudioCtx=null,voiceCancelled=false,pollBusy=false,messageRequest=0,lastListQuery='',mentionTargets=new Map(),mentionPeople=null,mentionGroup='';
  const myId=S.user.id,run=W.run;const localKey=(name)=>`ecp-${name}:${myId}`;const msgCacheKey=item=>`ecp-chat-v150:${myId}:${item.kind}:${item.id}`;const readMsgCache=item=>{try{return JSON.parse(localStorage.getItem(msgCacheKey(item))||'null')}catch{return null}};const saveMsgCache=item=>{try{const keep=messages.slice(-100);localStorage.setItem(msgCacheKey(item),JSON.stringify({messages:keep,profiles,receipts,reactions,t:Date.now()}))}catch{}};const readLocal=name=>{try{return JSON.parse(localStorage.getItem(localKey(name))||'[]')}catch{return[]}};const writeLocal=(name,value)=>{try{localStorage.setItem(localKey(name),JSON.stringify(value))}catch{}};const hasLocal=(name,value)=>readLocal(name).includes(value);const setLocal=(name,value,on)=>{const next=new Set(readLocal(name));on?next.add(value):next.delete(value);writeLocal(name,[...next]);};const threadKey=item=>`${item.kind}:${item.id}`;const blockState=async peer=>{let mine=hasLocal('blocked-users',peer),theirs=false;try{const [a,b]=await Promise.all([sb.from('user_blocks').select('blocked_id').eq('blocker_id',myId).eq('blocked_id',peer).maybeSingle(),sb.from('user_blocks').select('blocker_id').eq('blocker_id',peer).eq('blocked_id',myId).maybeSingle()]);if(!a.error)mine=!!a.data;if(!b.error)theirs=!!b.data;}catch{}return {mine,theirs,blocked:mine||theirs};};const setBlocked=async(peer,on)=>{setLocal('blocked-users',peer,on);try{const q=on?await sb.from('user_blocks').upsert({blocker_id:myId,blocked_id:peer}):await sb.from('user_blocks').delete().eq('blocker_id',myId).eq('blocked_id',peer);if(q.error&&!/user_blocks/i.test(q.error.message||''))throw q.error;}catch{}};const stopVoiceVisuals=()=>{if(voiceTimer){clearInterval(voiceTimer);voiceTimer=null;}if(voiceRaf){cancelAnimationFrame(voiceRaf);voiceRaf=0;}try{voiceAudioCtx?.close()}catch{}voiceAudioCtx=null;voicePanel?.remove();voicePanel=null;U.q('#ws-send')?.classList.remove('voice-recording-active');U.q('#voice-record')?.classList.remove('recording');};W.cleanups.push(()=>{closed=true;generation++;voiceCancelled=true;if(recorder?.state==='recording')recorder.stop();recordStream?.getTracks().forEach(t=>t.stop());stopVoiceVisuals();});
  root.className='content workspace-v3 ws-page ws-chat-page';root.innerHTML=`<div class="ws-inbox"><section class="ws-chat-list"><div class="ws-list-heading"><h1>Chats</h1><span class="spacer"></span>${W.button('search','Search people and groups','id="focus-search"')}${W.button('plus','New conversation','id="new-chat"','ws-icon-btn blue')}</div><div class="ws-tabs" id="inbox-tabs"><button data-filter="all" class="active">All</button><button data-filter="group">Groups</button><button data-view="unread">Unread</button><button data-view="favorite">Favorites</button></div><div class="ws-chat-search">${W.icon('search')}<input id="chat-search" placeholder="Search chats, groups, people…" aria-label="Search chats, groups, people">${W.button('sliders','Filter individual chats','id="direct-filter"')}</div><div class="ws-thread-scroll"><div id="people-results" aria-live="polite" aria-label="People search results"></div><div id="thread-list"></div><button id="thread-more" class="ws-more">Load more conversations</button></div></section><section class="ws-conversation"><div class="ws-chat-empty">${W.icon('chat')}<h2>Your conversations</h2><p>Choose a chat or group to start messaging.</p></div></section><aside class="ws-chat-details"><div class="ws-chat-empty">${W.icon('people')}<p>Conversation details appear here.</p></div></aside></div>`;
  const conv=U.q('.ws-conversation',root),details=U.q('.ws-chat-details',root),detailsWidthKey=localKey('details-width');try{const w=Number(localStorage.getItem(detailsWidthKey));if(w>=240&&w<=560)root.style.setProperty('--ws-details-width',w+'px')}catch{}
  function toggleDetails(force){const open=force===undefined?root.classList.contains('details-hidden'):!!force;if(open){root.classList.remove('details-hidden');root.classList.add('details-open')}else{root.classList.remove('details-open');root.classList.add('details-hidden')}}
  function bindDetailsResize(){const bar=U.q('#details-resizer',details);if(!bar)return;let startX=0,startW=0;bar.onpointerdown=e=>{if(matchMedia('(max-width:800px)').matches)return;startX=e.clientX;startW=details.getBoundingClientRect().width;bar.setPointerCapture?.(e.pointerId);root.classList.add('details-resizing');e.preventDefault()};bar.onpointermove=e=>{if(!bar.hasPointerCapture?.(e.pointerId))return;const next=Math.max(240,Math.min(560,startW+(startX-e.clientX)));root.style.setProperty('--ws-details-width',next+'px')};bar.onpointerup=e=>{if(bar.hasPointerCapture?.(e.pointerId))bar.releasePointerCapture?.(e.pointerId);root.classList.remove('details-resizing');const next=Math.round(details.getBoundingClientRect().width);try{localStorage.setItem(detailsWidthKey,String(next))}catch{}};bar.onpointercancel=bar.onpointerup;}
  function activateTabs(){U.qa('#inbox-tabs button',root).forEach(b=>b.classList.toggle('active',b.dataset.view?view===b.dataset.view:view==='all'&&filter===b.dataset.filter));U.q('#direct-filter').classList.toggle('active',filter==='direct');}
  async function loadList(append=false){
   const ticket=++listGeneration,key=JSON.stringify([search,filter,view]),count=!append&&key===lastListQuery?Math.max(1,Math.ceil(offset/60)):1,args={search_text:search,kind_filter:filter,view_filter:view==='saved'?'all':view};let data=[];for(let page=0;page<count;page++){const batch=W.data(await sb.rpc('chat_inbox',{...args,page_offset:append?offset:page*60}));if(closed||ticket!==listGeneration)return;data.push(...batch);if(batch.length<60)break;}lastListQuery=key;if(closed||ticket!==listGeneration)return;
   data=data.filter(t=>!hasLocal('hidden-chats',threadKey(t)));if(!append){threads=[];offset=0;}threads.push(...data);offset+=data.length;
   U.q('#thread-more',root).hidden=data.length===0||data.length%60!==0;const list=U.q('#thread-list',root);
   const html=threads.length?threads.map(t=>{const stamp=U.attr(JSON.stringify([t.name,t.avatar_path,t.description,t.preview,t.last_at,Number(t.unread)||0,!!t.pinned,selected?.id===t.id]));return `<div class="ws-thread-wrap" data-render-key="thread:${U.attr(t.kind)}:${U.attr(t.id)}" data-render-stamp="${stamp}"><button class="ws-thread ${selected?.id===t.id?'selected':''}" data-thread="${t.id}" data-kind="${t.kind}">${W.avatar(t.name,t.avatar_path,t.kind==='group'?'group-images':'avatars',t.kind==='group'?'group-avatar':'')}<span class="ws-thread-copy"><span class="ws-thread-title"><b>${U.esc(t.name)}${t.kind==='direct'?window.EduPresence.badge(t.peer_id):''}</b><time>${W.time(t.last_at)}</time></span><span class="ws-thread-description">${U.esc(t.description||'')}</span><span class="ws-thread-preview">${U.esc(t.preview||'Start a conversation')}<span class="spacer"></span>${Number(t.unread)?`<i class="ws-unread">${Number(t.unread)>99?'99+':t.unread}</i>`:''}</span></span></button><button class="ws-thread-pin ${t.pinned?'pinned':''}" data-pin-thread="${t.id}" data-pin-kind="${t.kind}" title="${t.pinned?'Unpin':'Pin'} conversation" aria-label="${t.pinned?'Unpin':'Pin'} conversation">${W.icon('pin')}</button></div>`;}).join(''):'<div class="ws-empty" data-render-key="empty" data-render-stamp="empty">No conversations match this filter.</div>';
   W.patchChildren(list,html);
   U.qa('[data-thread]',list).forEach(b=>b.onclick=run(()=>select(threads.find(t=>t.id===b.dataset.thread&&t.kind===b.dataset.kind))));U.qa('[data-pin-thread]',list).forEach(b=>b.onclick=run(async()=>{const t=threads.find(x=>x.id===b.dataset.pinThread&&x.kind===b.dataset.pinKind);if(!t)return;W.data(await sb.from('chat_preferences').upsert({kind:t.kind,thread_id:t.id,user_id:myId,favorite:!!t.favorite,pinned:!t.pinned}));t.pinned=!t.pinned;await loadList();}));W.photos(list,sb);activateTabs();
  }
  async function peopleSearch(query){const target=U.q('#people-results',root);if(!query.trim()){target.innerHTML='';return;}const raw=query.trim(),clean=raw.replace(/^@/,'').replace(/[%_,()]/g,'').slice(0,60);if(!clean){target.innerHTML='';return;}let result=await sb.rpc('search_public_profiles',{search_text:clean,max_results:20});if(result.error)result=await sb.from('profiles').select('id,full_name,avatar_path,public_id').eq('status','active').neq('id',myId).or(`full_name.ilike.%${clean}%,public_id.ilike.%${clean}%`).order('full_name').limit(20);const people=W.data(result);if(closed||query!==search)return;target.innerHTML=`<h4 class="ws-section-label">People</h4>${people.length?'':'<p class="ws-search-empty">No matching people found.</p>'}`+people.map(p=>`<button class="ws-thread ws-person-result" data-person="${p.id}">${W.avatar(p.full_name,p.avatar_path)}<span class="ws-person-copy"><b>${U.esc(p.full_name)}</b>${window.EduPresence.badge(p.id)}${p.public_id?`<small>@${U.esc(p.public_id)}</small>`:''}</span>${W.icon('plus')}</button>`).join('');U.qa('[data-person]',target).forEach(b=>b.onclick=run(()=>startDirect(b.dataset.person)));W.photos(target,sb);}
  async function startDirect(id){const thread=W.data(await sb.rpc('start_direct_chat',{other_user:id}));search='';U.q('#chat-search').value='';U.q('#people-results',root).innerHTML='';filter='all';view='all';await loadList();let item=threads.find(t=>t.id===thread);if(!item){const p=W.data(await sb.from('profiles').select('id,full_name,avatar_path').eq('id',id).single());item={id:thread,kind:'direct',peer_id:id,name:p.full_name,avatar_path:p.avatar_path};}await select(item);}
  const searchLater=U.debounce(run(async()=>{if(closed)return;await Promise.all([loadList(),peopleSearch(search)]);}),250);U.q('#chat-search').oninput=e=>{search=e.target.value;listGeneration++;U.q('#people-results',root).innerHTML='';U.q('.ws-thread-scroll',root).scrollTop=0;searchLater();};
  U.q('#focus-search').onclick=()=>U.q('#chat-search').focus();U.q('#new-chat').onclick=()=>{const r=U.modal({title:'New conversation',body:'<p>Find a person or create a class group.</p>',actions:'<button class="btn primary" id="find-person">Find a person</button>'+'<button class="btn" id="create-chat-group">Create group</button>'+'<button class="btn" data-close>Close</button>'});U.q('#find-person',r).onclick=()=>{U.closeModal();U.q('#chat-search').focus();U.q('#people-results').innerHTML='<p class="ws-empty">Type a person’s name above, then select them to start a private chat.</p>';};U.q('#create-chat-group',r)?.addEventListener('click',run(async()=>{const values=await U.promptBox({title:'Create group',fields:[{label:'Group name',max:120},{label:'Description',type:'textarea',required:false,max:2000}],submit:'Create'});if(!values)return;const g=W.data(await sb.from('groups').insert({name:values[0],description:values[1],created_by:myId}).select().single());filter='group';view='all';search='';U.q('#chat-search').value='';await loadList();await select({...g,kind:'group',avatar_path:g.image_path});}));};
  U.q('#direct-filter').onclick=run(async()=>{filter=filter==='direct'?'all':'direct';view='all';await loadList();});
  U.qa('#inbox-tabs button').forEach(b=>b.onclick=run(async()=>{if(b.dataset.view)view=b.dataset.view;else{filter=b.dataset.filter;view='all';}await loadList();}));U.q('#thread-more').onclick=run(()=>loadList(true));
  async function select(item){if(!item)return;if(recorder?.state==='recording')recorder.stop();selected=item;messageSearch='';messageOffset=0;messages=[];attached=null;mentionTargets.clear();mentionPeople=null;mentionGroup='';window.EduChatScroll?.reset?.();const ticket=++generation;root.classList.add('conversation-open');
   conv.innerHTML=`<header class="ws-conversation-header">${W.button('back','Back to chats','id="back-chats"','ws-icon-btn mobile-only')}${W.avatar(item.name,item.avatar_path,item.kind==='group'?'group-images':'avatars')}<div class="ws-heading-copy"><h2>${U.esc(item.name)}</h2><p id="chat-subtitle">${U.esc(item.description||'Direct conversation')}</p></div><span class="spacer"></span>${W.button('search','Search messages','id="message-search-toggle"')}${W.button('video','Start video call','id="chat-video"')}${W.button('phone','Start audio call','id="chat-audio"')}${item.kind==='group'?W.button('megaphone','Group announcements','id="group-announcements"'):''}${W.button('more','Conversation menu','id="show-details"','ws-icon-btn ws-more-visible')}</header><div class="ws-message-search" hidden><input id="message-search" placeholder="Search messages in this conversation…" aria-label="Search messages">${W.button('close','Clear message search','id="close-message-search"')}</div><div class="ws-message-log" id="message-log"><button class="ws-more" id="older-messages">Load older messages</button><div id="message-content"></div></div><form class="ws-composer" id="ws-send"><div id="attachment-preview" hidden></div><div class="ws-composer-row">${W.button('smile','Insert emoji','type="button" id="insert-emoji"')}${W.button('paperclip','Attach a file or photo','type="button" id="attach-file"')}<input id="chat-file" type="file" hidden><textarea id="message-input" rows="1" maxlength="4000" placeholder="Type a message…" title="Mention someone with @Full Name" aria-label="Message"></textarea>${W.button('mic','Record voice message','type="button" id="voice-record"')}<button class="ws-icon-btn blue send" type="submit" aria-label="Send message">${W.icon('send')}</button></div><div id="mention-suggestions" class="ws-mention-suggestions" hidden></div></form>`;
   S.group=item.kind==='group'?item:null;S.direct=item.kind==='direct'?item.peer_id:null;const cachedChat=readMsgCache(item);if(cachedChat?.messages?.length){messages=cachedChat.messages;profiles=cachedChat.profiles||{};receipts=cachedChat.receipts||[];reactions=cachedChat.reactions||[];messageOffset=messages.length;paintMessages();requestAnimationFrame(()=>{const l=U.q('#message-log');if(l)l.scrollTop=l.scrollHeight});}const blockInfo=item.kind==='direct'?await blockState(item.peer_id):{mine:false,theirs:false,blocked:false},blocked=blockInfo.blocked;const canSend=!blocked&&(item.kind==='direct'||item.allow_member_messaging||c.isAdmin());const groupLocked=item.kind==='group'&&!item.allow_member_messaging&&!c.isAdmin();U.q('#message-input').disabled=blocked;U.q('#message-input').readOnly=groupLocked;U.q('#ws-send button[type="submit"]').disabled=blocked;U.q('#attach-file').disabled=U.q('#voice-record').disabled=blocked;if(!canSend)U.q('#message-input').placeholder=blocked?(blockInfo.theirs?'This member has blocked this conversation.':'This member is blocked. Unblock from the 3-dot menu to message.'):'Group messaging is paused by an administrator.';
   U.q('#back-chats').onclick=()=>root.classList.remove('conversation-open');U.q('#show-details').onclick=()=>conversationMenu();const toggleFromProfile=()=>toggleDetails();U.q('.ws-heading-copy',conv)?.addEventListener('click',toggleFromProfile);U.q('.ws-conversation-header>.ws-avatar',conv)?.addEventListener('click',toggleFromProfile);
   U.q('#message-search-toggle').onclick=()=>{U.q('.ws-message-search').hidden=false;U.q('#message-search').focus();};U.q('#close-message-search').onclick=run(async()=>{messageSearch='';messages=[];U.q('#message-search').value='';U.q('.ws-message-search').hidden=true;await loadMessages(false);});
   U.q('#message-search').oninput=U.debounce(run(async e=>{messageSearch=e.target.value;messages=[];await loadMessages(false);}),250);
   U.q('#older-messages').onclick=run(()=>loadMessages(true));U.q('#message-log').onscroll=U.debounce(()=>markSeen().catch(()=>{}),200);
   U.q('#group-announcements')?.addEventListener('click',run(async()=>{const group=selected,rows=W.data(await sb.from('group_messages').select('*').eq('group_id',group.id).eq('is_announcement',true).order('created_at',{ascending:false}).limit(100)),allowed=c.can('announcements.create')||group.created_by===myId,r=U.modal({title:'Group announcements',body:rows.map(m=>`<article class="ws-card"><p>${U.esc(m.body)}</p><small>${U.fmtDate(m.created_at)}</small></article>`).join('')||'<p>No announcements yet.</p>',actions:`${allowed?'<button class="btn primary" id="new-announcement">Post announcement</button>':''}<button class="btn" data-close>Close</button>`});U.q('#new-announcement',r)?.addEventListener('click',run(async()=>{const values=await U.promptBox({title:'Post announcement',fields:[{label:'Announcement',type:'textarea',max:4000}],submit:'Post'});if(!values?.[0]?.trim())return;W.data(await sb.from('group_messages').insert({group_id:group.id,sender_id:myId,body:values[0].trim(),is_announcement:true}));if(selected?.id===group.id)await loadMessages(false,true);}));}));
   U.q('#insert-emoji').onclick=()=>{const input=U.q('#message-input'),r=U.modal({title:'Choose emoji',body:`<div class="ws-emoji-options">${['😊','👍','❤️','🎉','📚','✅','👋','😂','🙏','😮','💡','👏','🔥','🤝','💯','⭐','🤔','😢','😍','🎓','📌','✨','🙌','💪'].map(e=>`<button type="button" data-pick-emoji="${e}">${e}</button>`).join('')}</div>`});U.qa('[data-pick-emoji]',r).forEach(b=>b.onclick=()=>{input.setRangeText(b.dataset.pickEmoji,input.selectionStart,input.selectionEnd,'end');U.closeModal();input.focus();});};U.q('#attach-file').onclick=()=>U.q('#chat-file').click();U.q('#chat-file').onchange=e=>{attached=e.target.files[0]||null;showAttachment();};
   U.q('#message-input').onpaste=e=>{const file=[...(e.clipboardData?.files||[])].find(f=>/^(image|video)\//.test(f.type));if(file){e.preventDefault();attached=file;showAttachment();U.toast('Pasted media is ready to send.','ok');}};U.q('#message-input').oninput=U.debounce(()=>mentionSuggestions().catch(()=>{}),100);U.q('#message-input').onkeydown=e=>{const mb=U.q('#mention-suggestions');if(e.key==='Escape'&&mb)mb.hidden=true;if(e.key==='Enter'&&!e.shiftKey){if(mb&&!mb.hidden&&mb.querySelector('[data-mention-id]')){e.preventDefault();mb.querySelector('[data-mention-id]').click();return;}e.preventDefault();U.q('#ws-send').requestSubmit();}};U.q('#ws-send').onsubmit=run(send);
   U.q('#voice-record').onclick=run(async()=>{
    if(recorder?.state==='recording'){voicePanel?.querySelector('[data-voice-done]')?.focus();return;}
    if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)throw new Error('Voice recording requires HTTPS and a supported browser.');
    recordStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    if(closed||ticket!==generation){recordStream.getTracks().forEach(t=>t.stop());return;}
    recordChunks=[];voiceCancelled=false;
    const mimeType=['audio/webm;codecs=opus','audio/ogg;codecs=opus','audio/mp4','audio/webm'].find(t=>MediaRecorder.isTypeSupported?.(t));
    try{recorder=new MediaRecorder(recordStream,mimeType?{mimeType}:undefined);}catch(e){recordStream.getTracks().forEach(t=>t.stop());throw e;}
    const recordingStarted=Date.now(),activeRecorder=recorder,activeStream=recordStream,chunks=recordChunks,form=U.q('#ws-send'),row=U.q('.ws-composer-row',form);
    stopVoiceVisuals();
    voicePanel=document.createElement('div');voicePanel.className='ws-voice-recording';voicePanel.innerHTML=`<button type="button" class="ws-voice-cancel" data-voice-cancel aria-label="Cancel voice recording">×</button><div class="ws-voice-live"><span class="ws-voice-pulse">${W.icon('mic')}</span><div class="ws-voice-wave" aria-label="Live microphone level">${Array.from({length:22},()=>'<i></i>').join('')}</div><strong class="ws-voice-time" data-voice-time>00:00</strong></div><button type="button" class="ws-voice-done" data-voice-done aria-label="Done recording">✓ Done</button>`;
    row.parentNode.insertBefore(voicePanel,row);form.classList.add('voice-recording-active');U.q('#voice-record').classList.add('recording');
    const timerEl=voicePanel.querySelector('[data-voice-time]'),bars=[...voicePanel.querySelectorAll('.ws-voice-wave i')];
    const updateClock=()=>{const sec=Math.floor(Math.min(120000,Date.now()-recordingStarted)/1000);timerEl.textContent=String(Math.floor(sec/60)).padStart(2,'0')+':'+String(sec%60).padStart(2,'0')};updateClock();voiceTimer=setInterval(updateClock,250);
    try{const C=window.AudioContext||window.webkitAudioContext;if(C){voiceAudioCtx=new C();const analyser=voiceAudioCtx.createAnalyser();analyser.fftSize=256;analyser.smoothingTimeConstant=.72;voiceAudioCtx.createMediaStreamSource(recordStream).connect(analyser);const data=new Uint8Array(analyser.frequencyBinCount);const animate=()=>{if(!voicePanel?.isConnected)return;analyser.getByteFrequencyData(data);for(let i=0;i<bars.length;i++){const start=Math.floor(i*data.length/bars.length),end=Math.max(start+1,Math.floor((i+1)*data.length/bars.length));let sum=0;for(let j=start;j<end;j++)sum+=data[j];const level=sum/(end-start)/255;bars[i].style.transform=`scaleY(${Math.max(.18,Math.min(1,.18+level*1.55))})`;}voiceRaf=requestAnimationFrame(animate)};animate();}}
    catch{}
    const finish=(cancel=false)=>{voiceCancelled=cancel;if(activeRecorder.state==='recording')activeRecorder.stop();};
    voicePanel.querySelector('[data-voice-cancel]').onclick=()=>finish(true);voicePanel.querySelector('[data-voice-done]').onclick=()=>finish(false);
    recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
    const timeout=setTimeout(()=>{if(activeRecorder.state==='recording')finish(false);},120000);
    recorder.onstop=()=>{clearTimeout(timeout);activeStream.getTracks().forEach(t=>t.stop());stopVoiceVisuals();if(closed||ticket!==generation||voiceCancelled){recordChunks=[];return;}const mime=(activeRecorder.mimeType||mimeType||'audio/webm').split(';')[0],ext=mime==='audio/mp4'?'.m4a':mime==='audio/ogg'?'.ogg':'.webm';attached=new File(chunks,['voice-',Date.now(),ext].join(''),{type:mime});attached.durationMs=Math.min(120000,Date.now()-recordingStarted);showAttachment();U.toast('Voice recording ready. Press Send to share it.','ok');};
    recorder.start(250);
    W.cleanups.push(()=>clearTimeout(timeout));
   });
   U.q('#chat-video').onclick=run(()=>call(false));U.q('#chat-audio').onclick=run(()=>call(true));
   await Promise.all([loadMessages(false),renderDetails()]);applyChatBackground();W.photos(conv,sb);if(ticket===generation){const ret=W.returnChat;if(ret&&((ret.id&&ret.kind===selected.kind&&ret.id===selected.id)||(ret.peer&&selected.kind==='direct'&&ret.peer===selected.peer_id))){W.returnChat=null;requestAnimationFrame(()=>{const l=U.q('#message-log');if(l)l.scrollTop=Math.max(0,Math.min(Number(ret.scrollTop)||0,Math.max(0,l.scrollHeight-l.clientHeight)));});}await loadList();if(W.pendingPanel){const target=W.pendingPanel;W.pendingPanel=null;root.classList.remove('details-hidden');root.classList.add('details-open');await panel(target);}}
  }
  async function getGroupMentionPeople(){
   if(!selected||selected.kind!=='group')return [];
   if(mentionPeople&&mentionGroup===selected.id)return mentionPeople;
   const members=W.data(await sb.from('group_members').select('user_id').eq('group_id',selected.id).limit(200)),map=await c.namesFor(members.map(x=>x.user_id));
   mentionGroup=selected.id;mentionPeople=members.map(x=>map[x.user_id]).filter(x=>x?.id!==myId&&x?.full_name).sort((a,b)=>a.full_name.localeCompare(b.full_name));return mentionPeople;
  }
  async function mentionSuggestions(){
   const input=U.q('#message-input'),box=U.q('#mention-suggestions');if(!input||!box||!selected||selected.kind!=='group'){if(box){box.hidden=true;box.innerHTML='';}return;}
   const pos=input.selectionStart??input.value.length,before=input.value.slice(0,pos),match=before.match(/(?:^|\s)@([^@\n]{0,50})$/);if(!match){box.hidden=true;box.innerHTML='';return;}
   const query=(match[1]||'').trim().toLowerCase(),people=(await getGroupMentionPeople()).filter(p=>!query||p.full_name.toLowerCase().includes(query)).slice(0,8);
   if(!people.length){box.hidden=true;box.innerHTML='';return;}
   box.innerHTML=people.map((p,i)=>`<button type="button" data-mention-id="${U.attr(p.id)}" data-mention-name="${U.attr(p.full_name)}" ${i===0?'data-mention-active="1"':''}>${W.avatar(p.full_name,p.avatar_path)}<span><b>${U.esc(p.full_name)}</b><small>Mention in this group</small></span></button>`).join('');box.hidden=false;W.photos(box,sb);
   U.qa('[data-mention-id]',box).forEach(b=>b.onclick=()=>{const name=b.dataset.mentionName,start=pos-match[0].length+(match[0].startsWith(' ')?1:0),prefix=input.value.slice(0,start),suffix=input.value.slice(pos);input.value=`${prefix}@${name} ${suffix}`;mentionTargets.set(name.toLowerCase(),b.dataset.mentionId);const cursor=(prefix+'@'+name+' ').length;input.setSelectionRange(cursor,cursor);box.hidden=true;input.focus();});
  }
  function showAttachment(){const p=U.q('#attachment-preview');p.hidden=!attached;p.innerHTML=attached?`${W.icon('file')} ${U.esc(attached.name)} <button type="button" id="remove-attachment" aria-label="Remove attachment">×</button>`:'';U.q('#remove-attachment')?.addEventListener('click',()=>{attached=null;showAttachment();});}
  async function send(e){e.preventDefault();const input=U.q('#message-input'),button=U.q('#ws-send button[type="submit"]'),item=selected,ticket=generation;const body=input.value.trim();if(button.disabled||(!body&&!attached))return;window.EduChatScroll?.beginSend?.();const mentionSnapshot=[...mentionTargets.entries()].filter(([name])=>body.toLowerCase().includes('@'+name)).map(([,id])=>id);button.disabled=true;let file,inserted=false;
   try{let sentId=null;if(attached)await c.sendAttachment(item,attached,body);else{const row={body,sender_id:myId};row[item.kind==='group'?'group_id':'thread_id']=item.id;const added=W.data(await sb.from(item.kind==='group'?'group_messages':'direct_messages').insert(row).select('id').single());sentId=added?.id;}inserted=true;if(body.includes('@'))notifyMentions(item,body,sentId,mentionSnapshot).catch(()=>{});mentionTargets.clear();if(ticket!==generation||closed)return;input.value='';attached=null;showAttachment();messageSearch='';U.q('#message-search').value='';U.q('.ws-message-search').hidden=true;await loadMessages(false,true);await loadList();}
   catch(e){if(file&&!inserted)await sb.storage.from('chat-files').remove([file.attachment_path]);throw e;}finally{if(button.isConnected)button.disabled=false;}
  }
  async function notifyMentions(item,body,messageId,selectedIds=[]){
   const names=(body.match(/@[\p{L}\p{N} ._-]{2,80}/gu)||[]).map(x=>x.slice(1).trim().toLowerCase()).filter(Boolean);if(!names.length&&!selectedIds.length)return;let ids=[...selectedIds];
   if(item.kind==='group'){const members=W.data(await sb.from('group_members').select('user_id').eq('group_id',item.id)),memberSet=new Set(members.map(x=>x.user_id));ids=ids.filter(id=>memberSet.has(id));if(names.length){const map=await c.namesFor(members.map(x=>x.user_id));ids.push(...members.filter(m=>names.some(n=>(map[m.user_id]?.full_name||'').toLowerCase().startsWith(n))).map(m=>m.user_id));}}
   else{const p=W.data(await sb.from('profiles').select('id,full_name').eq('id',item.peer_id).single());if(names.some(n=>(p.full_name||'').toLowerCase().startsWith(n)))ids.push(p.id);}
   ids=[...new Set(ids.filter(id=>id&&id!==myId))];if(!ids.length)return;const rpc=await sb.rpc('notify_chat_mentions',{target_users:ids,chat_kind:item.kind,chat_id:item.id,message_id:messageId||null});if(rpc.error)await sb.from('notifications').insert(ids.map(id=>({user_id:id,kind:'mention',title:`${S.profile?.full_name||'Someone'} mentioned you`,resource_id:item.id,target_kind:item.kind,target_id:item.id})));
  }
  async function loadMessages(older=false,forceBottom=false){if(!selected||closed)return;const item=selected,ticket=generation,request=++messageRequest;const scroll=U.q('#message-log'),height=scroll.scrollHeight,top=scroll.scrollTop,wasBottom=height-scroll.clientHeight-top<100;
   const table=item.kind==='group'?'group_messages':'direct_messages',key=item.kind==='group'?'group_id':'thread_id';let data=[];
   if(!older&&!messageSearch&&messages.length){
     const newest=messages[messages.length-1],qnew=sb.from(table).select('*').eq(key,item.id).gte('created_at',newest.created_at).order('created_at',{ascending:true}).order('id',{ascending:true}).limit(100);
     data=W.data(await qnew);if(closed||ticket!==generation||request!==messageRequest)return;
     if(data.length){const map=new Map(messages.map(m=>[m.id,m]));for(const m of data)map.set(m.id,m);messages=[...map.values()].sort((a,b)=>new Date(a.created_at)-new Date(b.created_at)||String(a.id).localeCompare(String(b.id)));}
     messageOffset=messages.length;
   }else{
     let query=sb.from(table).select('*').eq(key,item.id);if(messageSearch)query=query.ilike('body','%'+messageSearch+'%');
     const start=older?messageOffset:0,size=older?50:Math.max(50,messages.length||0),batch=W.data(await query.order('created_at',{ascending:false}).order('id',{ascending:false}).range(start,start+size-1));if(closed||ticket!==generation||request!==messageRequest)return;
     data=batch;if(!older){messages=batch.reverse();messageOffset=batch.length;}else{messages=[...batch.reverse(),...messages];messageOffset+=batch.length;}
   }
   const ids=messages.map(m=>m.sender_id);receipts=W.data(await sb.from('chat_receipts').select('*').eq('kind',item.kind).eq('thread_id',item.id));const needed=[...new Set([...ids,...receipts.map(r=>r.user_id)])].filter(id=>!profiles[id]);if(needed.length)Object.assign(profiles,await c.namesFor(needed));
   if(closed||ticket!==generation||request!==messageRequest)return;const enriched=await c.hydrateAttachments(messages);if(closed||ticket!==generation||request!==messageRequest)return;messages=enriched;reactions=messages.length?W.data(await sb.from('chat_reactions').select('*').eq('kind',item.kind).eq('thread_id',item.id).in('message_id',messages.map(m=>m.id))):[];if(closed||ticket!==generation||request!==messageRequest)return;
   saveMsgCache(item);U.q('#older-messages').hidden=!older&&messages.length<50?true:(older?data.length<50:false);paintMessages();if(older)scroll.scrollTop=scroll.scrollHeight-height+top;else if(wasBottom||(forceBottom&&(window.EduChatScroll?.shouldFollow?.()??true)))scroll.scrollTop=scroll.scrollHeight;await markSeen();
  }
  function paintMessages(){const box=U.q('#message-content');let day='';const html=messages.length?messages.map(m=>{
   const mine=m.sender_id===myId,name=profiles[m.sender_id]?.full_name||'Member',seen=receipts.filter(r=>r.user_id!==m.sender_id&&new Date(r.last_read_at)>=new Date(m.created_at)),mySeen=seen.some(r=>r.user_id!==myId),date=W.date(m.created_at);let sep='';if(date!==day){day=date;sep=`<div class="ws-day" data-render-key="day:${U.attr(date)}" data-render-stamp="${U.attr(date)}"><span>${date}</span></div>`;}
   const rr=reactions.filter(r=>r.message_id===m.id),emojis=[...new Set(rr.map(r=>r.emoji))],pinned=hasLocal('pinned-messages',`${selected.kind}:${selected.id}:${m.id}`),stamp=U.attr(JSON.stringify([m.body,m.edited_at,m.attachment_path,m.attachment_name,m.attachment_mime,m.is_announcement,name,profiles[m.sender_id]?.avatar_path,pinned,mySeen,rr.map(r=>[r.user_id,r.emoji]).sort(),seen.map(r=>[r.user_id,r.last_read_at]).sort()]));return sep+`<article class="ws-message ${mine?'mine':''}" data-message="${m.id}" data-render-key="msg:${U.attr(m.id)}" data-render-stamp="${stamp}">${!mine?W.avatar(name,profiles[m.sender_id]?.avatar_path):''}<div class="ws-message-stack"><div class="ws-bubble">${!mine?`<b class="ws-sender">${U.esc(name)}</b>${window.EduPresence.badge(m.sender_id)}`:''}<div class="ws-message-body">${m.is_announcement?'<strong class="ws-announcement-label">Announcement</strong>':''}${pinned?'<span class="ws-pinned-mark">📌</span>':''}${W.rich(m.body)}</div>${W.attachment(m,'chat-files')}<div class="ws-message-stamp"><time>${W.time(m.created_at)}</time>${m.edited_at?'<span class="ws-edited">Edited</span>':''}${mine?`<span class="ws-ticks ${mySeen?'seen':''}" title="${mySeen?'Seen':'Sent'}">${W.icon(mySeen?'doublecheck':'check')}</span>`:''}<button class="ws-message-menu" title="Message actions" aria-label="Message actions" data-message-menu="${m.id}">⋯</button></div></div><div class="ws-message-reactions">${emojis.map(emoji=>`<button data-react="${m.id}" data-emoji="${emoji}" class="${rr.some(r=>r.user_id===myId&&r.emoji===emoji)?'selected':''}">${emoji} ${rr.filter(r=>r.emoji===emoji).length}</button>`).join('')}</div>${selected.kind==='group'&&seen.length?`<div class="ws-seen-people" aria-label="Seen by ${U.attr(seen.map(r=>profiles[r.user_id]?.full_name||'Member').join(', '))}">${seen.slice(0,8).map(r=>`<span title="Seen by ${U.attr(profiles[r.user_id]?.full_name||'Member')}">${W.avatar(profiles[r.user_id]?.full_name,profiles[r.user_id]?.avatar_path)}</span>`).join('')}${seen.length>8?`<small>+${seen.length-8}</small>`:''}</div>`:''}</div></article>`;
   }).join(''):'<div class="ws-empty" data-render-key="empty" data-render-stamp="'+(messageSearch?'search':'empty')+'">'+(messageSearch?'No matching messages.':'Say hello to start this conversation.')+'</div>';
   W.patchChildren(box,html);W.photos(box,sb);W.files(box,sb);c.linkGroupInvites(box);U.qa('[data-react]',box).forEach(b=>b.onclick=run(()=>react(b.dataset.react,b.dataset.emoji)));U.qa('[data-message-menu]',box).forEach(b=>b.onclick=()=>messageMenu(messages.find(m=>m.id===b.dataset.messageMenu)));
  }
  async function react(id,emoji){if(!id||String(id).startsWith('local-')){U.toast('Wait for this message to finish sending.','error');return;}const mine=reactions.find(r=>r.message_id===id&&r.user_id===myId);if(mine?.emoji===emoji)W.data(await sb.from('chat_reactions').delete().eq('kind',selected.kind).eq('message_id',id).eq('user_id',myId));else W.data(await sb.from('chat_reactions').upsert({kind:selected.kind,thread_id:selected.id,message_id:id,user_id:myId,emoji}));await loadMessages(false);}
  async function copyMessage(m){
   if(m.body?.trim())await U.copy(m.body);else if(m.attachment_path){const bucket=m.thread_id?'direct-files':'group-files',mime=m.attachment_mime||m.mime_type||'';const blob=W.data(await sb.storage.from(bucket).download(m.attachment_path));if(mime.startsWith('image/')&&navigator.clipboard?.write&&window.ClipboardItem){await navigator.clipboard.write([new ClipboardItem({[blob.type||'image/png']:blob})]);U.toast('Image copied.','ok');}else U.toast('This attachment can be downloaded from the message.','ok');}
  }
  function captureMessageViewport(){const log=U.q('#message-log');if(!log)return null;const box=U.q('#message-content'),rect=log.getBoundingClientRect(),anchor=box?U.qa('[data-message]',box).find(el=>el.getBoundingClientRect().bottom>rect.top+1):null;return {top:log.scrollTop,atBottom:log.scrollHeight-log.clientHeight-log.scrollTop<100,anchorId:anchor?.dataset.message||'',anchorOffset:anchor?anchor.getBoundingClientRect().top-rect.top:0};}
  function restoreMessageViewport(view){if(!view)return;requestAnimationFrame(()=>{const log=U.q('#message-log');if(!log)return;if(view.atBottom){log.scrollTop=log.scrollHeight;return;}const anchor=view.anchorId?U.q(`[data-message="${view.anchorId}"]`,log):null;if(anchor){const rect=log.getBoundingClientRect(),now=anchor.getBoundingClientRect().top-rect.top;log.scrollTop+=now-view.anchorOffset;}else log.scrollTop=Math.max(0,view.top);});}
  async function editMessage(m,view){if(!m||m.sender_id!==myId)return;const values=await U.promptBox({title:'Edit message',fields:[{label:'Message',type:'textarea',value:m.body||'',max:4000}],submit:'Save'});restoreMessageViewport(view);if(!values)return;const body=(values[0]||'').trim();if(!body){U.toast('Message cannot be empty.','error');return;}if(body===String(m.body||'').trim())return;const table=selected.kind==='group'?'group_messages':'direct_messages',updated=W.data(await sb.from(table).update({body}).eq('id',m.id).eq('sender_id',myId).select('*').single());const i=messages.findIndex(x=>x.id===m.id);if(i>=0)messages[i]={...messages[i],...updated};paintMessages();saveMsgCache(selected);restoreMessageViewport(view);await loadList();}
  function messageMenu(m){if(!m)return;const key=`${selected.kind}:${selected.id}:${m.id}`,pinned=hasLocal('pinned-messages',key),view=captureMessageViewport(),mine=m.sender_id===myId;const r=U.modal({title:'Message actions',body:`<div class="ws-emoji-options">${['👍','❤️','🎉','😂','🙏','😮'].map(e=>`<button data-emoji="${e}">${e}</button>`).join('')}</div>`,actions:`<button class="btn" id="quote-msg">Reply</button><button class="btn" id="copy-msg">Copy</button>${mine?'<button class="btn" id="edit-msg">Edit</button>':''}<button class="btn" id="pin-msg">${pinned?'Unpin':'Pin'} message</button><button class="btn" id="save-msg">Save</button>${mine||selected.kind==='group'&&c.can('groups.manage')?'<button class="btn danger" id="delete-msg">Unsend for everyone</button>':''}<button class="btn" data-close>Close</button>`});requestAnimationFrame(()=>restoreMessageViewport(view));U.qa('[data-emoji]',r).forEach(b=>b.onclick=run(async()=>{await react(m.id,b.dataset.emoji);U.closeModal();restoreMessageViewport(view);}));U.q('#quote-msg',r).onclick=()=>{U.q('#message-input').value='↪ '+(m.body||'Attachment').slice(0,250)+'\n';U.closeModal();restoreMessageViewport(view);U.q('#message-input').focus();};U.q('#copy-msg',r).onclick=run(async()=>{await copyMessage(m);U.closeModal();restoreMessageViewport(view);});U.q('#edit-msg',r)?.addEventListener('click',run(async()=>{U.closeModal();restoreMessageViewport(view);await editMessage(m,view);}));U.q('#pin-msg',r).onclick=()=>{setLocal('pinned-messages',key,!pinned);U.closeModal();paintMessages();restoreMessageViewport(view);};U.q('#save-msg',r).onclick=run(async()=>{W.data(await sb.from('saved_messages').upsert({kind:selected.kind,thread_id:selected.id,message_id:m.id,user_id:myId}));U.toast('Message saved.','ok');U.closeModal();restoreMessageViewport(view);});U.q('#delete-msg',r)?.addEventListener('click',run(async()=>{U.closeModal();restoreMessageViewport(view);if(!await U.confirmBox('Unsend message','Remove this message for everyone in this conversation?','Unsend')){restoreMessageViewport(view);return;}const table=selected.kind==='group'?'group_messages':'direct_messages',removed=W.data(await sb.from(table).delete().eq('id',m.id).select('id'));if(!removed?.length)throw new Error('Message could not be unsent.');messages=messages.filter(x=>x.id!==m.id);reactions=reactions.filter(x=>x.message_id!==m.id);setLocal('pinned-messages',key,false);paintMessages();saveMsgCache(selected);restoreMessageViewport(view);await loadList();}));}

  function applyChatBackground(){if(!selected)return;const key=localKey(`chat-bg:${threadKey(selected)}`),log=U.q('#message-log');if(!log)return;let cfg={};try{cfg=JSON.parse(localStorage.getItem(key)||'{}')}catch{};const opacity=Math.max(0,Math.min(1,Number(cfg.opacity??.35))),dark=document.documentElement.dataset.theme==='dark';log.style.setProperty('--chat-user-bg',cfg.image?`url("${cfg.image}")`:'none');log.style.setProperty('--chat-user-overlay',dark?`rgba(12,24,36,${opacity})`:`rgba(237,243,249,${opacity})`);log.classList.toggle('has-user-bg',!!cfg.image);}
  async function backgroundSettings(){const key=localKey(`chat-bg:${threadKey(selected)}`);let cfg={opacity:.35};try{cfg={...cfg,...JSON.parse(localStorage.getItem(key)||'{}')}}catch{}const r=U.modal({title:'Chat background',body:`<label class="field">Choose local picture<input id="chat-bg-file" type="file" accept="image/*"></label><label class="field">Transparency <input id="chat-bg-opacity" type="range" min="0" max="0.9" step="0.05" value="${Number(cfg.opacity??.35)}"></label><p class="hint">This background stays only on this browser/device.</p>`,actions:'<button class="btn danger" id="remove-chat-bg">Remove</button><button class="btn" data-close>Close</button><button class="btn primary" id="save-chat-bg">Save</button>'});U.q('#save-chat-bg',r).onclick=async()=>{const f=U.q('#chat-bg-file',r).files[0],opacity=Number(U.q('#chat-bg-opacity',r).value);if(f){if(f.size>2*1024*1024){U.toast('Choose a background under 2 MB.','error');return}cfg.image=await new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.onerror=rej;fr.readAsDataURL(f)});}cfg.opacity=opacity;try{localStorage.setItem(key,JSON.stringify(cfg))}catch{U.toast('This picture is too large for local storage.','error');return}U.closeModal();applyChatBackground();};U.q('#remove-chat-bg',r).onclick=()=>{localStorage.removeItem(key);U.closeModal();applyChatBackground();};}
  async function conversationMenu(){if(!selected)return;const key=threadKey(selected),muted=hasLocal('muted-chats',key),blockInfo=selected.kind==='direct'?await blockState(selected.peer_id):{mine:false,theirs:false,blocked:false},blocked=blockInfo.mine;const actions=[`<button class="btn" id="open-details">Conversation details</button>`,`<button class="btn" id="pin-conversation">${selected.pinned?'Unpin':'Pin'} chat</button>`,`<button class="btn" id="mute-conversation">${muted?'Unmute':'Mute'} ${selected.kind==='group'?'group':'chat'}</button>`,`<button class="btn" id="chat-background">Chat background</button>`];if(selected.kind==='direct')actions.push(`<button class="btn ${blocked?'':'danger'}" id="block-member">${blocked?'Unblock member':'Block member'}</button>`);if(selected.kind==='group')actions.push('<button class="btn" id="create-group-poll">Create Poll</button><button class="btn" id="group-invite-menu">Group invite link</button><button class="btn danger" id="leave-group">Leave / exit group</button>');actions.push('<button class="btn danger" id="delete-conversation">Delete conversation from this device</button>');const r=U.modal({title:'Conversation options',body:`<div class="stack">${actions.join('')}</div>`,actions:'<button class="btn" data-close>Close</button>'});U.q('#open-details',r).onclick=()=>{U.closeModal();toggleDetails(true);};U.q('#pin-conversation',r).onclick=run(async()=>{W.data(await sb.from('chat_preferences').upsert({kind:selected.kind,thread_id:selected.id,user_id:myId,favorite:!!selected.favorite,pinned:!selected.pinned}));selected.pinned=!selected.pinned;U.closeModal();await loadList();});U.q('#mute-conversation',r).onclick=()=>{setLocal('muted-chats',key,!muted);U.closeModal();U.toast(muted?'Conversation unmuted.':'Conversation muted on this device.','ok');};U.q('#chat-background',r).onclick=()=>{U.closeModal();backgroundSettings();};U.q('#block-member',r)?.addEventListener('click',run(async()=>{await setBlocked(selected.peer_id,!blocked);U.closeModal();await select(selected);}));U.q('#create-group-poll',r)?.addEventListener('click',()=>{U.closeModal();if(typeof window.EduOpenGroupPollComposer==='function')window.EduOpenGroupPollComposer();else U.toast('Poll tools are still loading. Please try again.','error');});U.q('#group-invite-menu',r)?.addEventListener('click',run(async()=>{U.closeModal();const g=W.data(await sb.from('groups').select('*').eq('id',selected.id).single());await c.shareGroupInvite?.(g);}));U.q('#leave-group',r)?.addEventListener('click',run(async()=>{if(!await U.confirmBox('Leave group','Leave this group? You will need another invitation to join again.','Leave'))return;W.data(await sb.from('group_members').delete().eq('group_id',selected.id).eq('user_id',myId));U.closeModal();selected=null;root.classList.remove('conversation-open');await loadList();}));U.q('#delete-conversation',r).onclick=async()=>{if(!await U.confirmBox('Delete conversation','Hide this conversation and its local view on this device? Messages for other members are not deleted.','Delete'))return;setLocal('hidden-chats',key,true);U.closeModal();selected=null;root.classList.remove('conversation-open');await loadList();};}
  let marking=false;async function markSeen(){if(marking||closed||!selected||!messages.length||messageSearch||document.visibilityState!=='visible'||!document.hasFocus())return;const log=U.q('#message-log');if(!log||log.scrollHeight-log.clientHeight-log.scrollTop>100)return;const newest=messages[messages.length-1],mine=receipts.find(r=>r.user_id===myId);if(mine&&new Date(mine.last_read_at)>=new Date(newest.created_at))return;marking=true;try{W.data(await sb.rpc('mark_chat_read',{k:selected.kind,t:selected.id,message:newest.id}));receipts=receipts.filter(r=>r.user_id!==myId);receipts.push({user_id:myId,last_read_at:newest.created_at});await loadList();}finally{marking=false;}}
  const onFocus=()=>markSeen().catch(()=>{});window.addEventListener('focus',onFocus);document.addEventListener('visibilitychange',onFocus);W.cleanups.push(()=>{window.removeEventListener('focus',onFocus);document.removeEventListener('visibilitychange',onFocus);});
  async function updateConversationPresence(item=selected,count=null){if(!item||closed)return;const subtitle=U.q('#chat-subtitle');if(!subtitle)return;if(item.kind==='group'){subtitle.textContent=`${item.description||'Group conversation'}${count==null?'':' · '+count+' members'}`;return;}try{let result=await sb.rpc('ecp_presence_list',{targets:[item.peer_id]}),row=Array.isArray(result.data)?result.data[0]:result.data;if(result.error||!row){const fallback=await sb.from('profiles').select('last_active_at,last_seen_visible,public_id').eq('id',item.peer_id).maybeSingle();if(fallback.error)throw fallback.error;row=fallback.data;}if(closed||selected?.id!==item.id||!subtitle.isConnected)return;subtitle.dataset.presenceUser=item.peer_id;window.EduPresence.seed?.(item.peer_id,row);subtitle.textContent=window.EduPresence.label(row);}catch{subtitle.textContent='Last seen unavailable';}}
  async function renderDetails(){if(!selected)return;const item=selected,ticket=generation;let count=2;if(item.kind==='group'){const result=await sb.from('group_members').select('*',{count:'exact',head:true}).eq('group_id',item.id);if(result.error)throw result.error;count=result.count;}if(closed||ticket!==generation)return;
   await updateConversationPresence(item,count);if(closed||ticket!==generation)return;let publicId='';if(item.kind==='direct'){try{const r=await sb.rpc('ecp_presence_list',{targets:[item.peer_id]}),row=Array.isArray(r.data)?r.data[0]:r.data;publicId=row?.public_id||''}catch{}}
   details.innerHTML=`<div class="ws-details-resizer" id="details-resizer" role="separator" aria-label="Resize conversation details" aria-orientation="vertical"></div>${W.button('close','Close details','id="close-details"')}<div class="ws-details-profile">${W.avatar(item.name,item.avatar_path,item.kind==='group'?'group-images':'avatars')}<h2>${U.esc(item.name)}</h2>${publicId?`<p class="ws-public-id">@${U.esc(publicId)}</p>`:''}<p>${U.esc(item.description||'Private conversation')}</p><p>${item.kind==='group'?count+' members':'Only you and '+U.esc(item.name)}</p></div><div class="ws-details-nav">${[['chat','Chat'],['pin','Pinned'],['bookmark','Saved Messages'],['file','Files'],['people','Members'],['video','Meetings'],...(item.kind==='group'?[['cloud','Google Drive']]:[]),['settings','Settings']].map(([icon,label])=>`<button data-panel="${label}" class="${label==='Chat'?'active':''}">${W.icon(icon)}${label}${W.icon('chevron')}</button>`).join('')}</div><div id="details-panel"></div>`;
   U.q('#close-details').onclick=()=>toggleDetails(false);U.qa('[data-panel]',details).forEach(b=>b.onclick=run(()=>panel(b.dataset.panel)));bindDetailsResize();W.photos(details,sb);
  }
  async function panel(name){U.qa('[data-panel]',details).forEach(b=>b.classList.toggle('active',b.dataset.panel===name));const out=U.q('#details-panel'),active=U.qa('[data-panel]',details).find(b=>b.dataset.panel===name);if(active)active.insertAdjacentElement('afterend',out);out.innerHTML='';if(name==='Chat')return;if(name==='Pinned'){const keys=new Set(readLocal('pinned-messages')),rows=messages.filter(m=>keys.has(`${selected.kind}:${selected.id}:${m.id}`));out.innerHTML=rows.length?rows.map(m=>`<div class="card"><b>📌 ${U.esc(profiles[m.sender_id]?.full_name||'Message')}</b><p>${W.rich(m.body||m.attachment_name||m.file_name||'Attachment')}</p></div>`).join(''):'<p>No pinned messages in this chat.</p>';return;}
   if(name==='Saved Messages'){
    const saved=W.data(await sb.from('saved_messages').select('message_id').eq('user_id',myId).eq('kind',selected.kind).eq('thread_id',selected.id));
    const ids=[...new Set((saved||[]).map(x=>x.message_id).filter(Boolean))];
    if(!ids.length){out.innerHTML='<p class="ws-saved-empty">No saved messages in this conversation.</p>';return;}
    const table=selected.kind==='group'?'group_messages':'direct_messages';
    let rows=W.data(await sb.from(table).select('*').in('id',ids).order('created_at',{ascending:false}));
    rows=await c.hydrateAttachments(rows);
    const names=await c.namesFor([...new Set((rows||[]).map(x=>x.sender_id).filter(Boolean))]);
    const now=new Date(),todayKey=now.toDateString(),yesterdayKey=new Date(now.getFullYear(),now.getMonth(),now.getDate()-1).toDateString();
    const labelFor=d=>d.toDateString()===todayKey?'Today':d.toDateString()===yesterdayKey?'Yesterday':d.toLocaleDateString([], {year:'numeric',month:'short',day:'numeric'});
    const groups=[];let last='';for(const m of rows||[]){const d=new Date(m.created_at),label=labelFor(d);if(label!==last){groups.push({label,rows:[]});last=label;}groups[groups.length-1].rows.push(m);}
    out.innerHTML=groups.map(g=>`<section class="ws-saved-message-group"><h4>${U.esc(g.label)}</h4>${g.rows.map(m=>`<article class="ws-saved-message" data-saved-message="${m.id}"><div class="ws-saved-message-head"><b>${U.esc(names[m.sender_id]?.full_name||'Member')}</b><time>${U.esc(new Date(m.created_at).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'}))}</time></div><p>${W.rich(m.body||m.attachment_name||m.file_name||'Attachment')}</p>${(m.attachment_name||m.file_name)?`<small>${U.esc(m.attachment_name||m.file_name)}</small>`:''}<button class="text-btn danger-text" data-unsave-message="${m.id}">Unsave</button></article>`).join('')}</section>`).join('');
    U.qa('[data-unsave-message]',out).forEach(b=>b.onclick=run(async()=>{W.data(await sb.from('saved_messages').delete().eq('user_id',myId).eq('kind',selected.kind).eq('thread_id',selected.id).eq('message_id',b.dataset.unsaveMessage));await panel('Saved Messages');}));
    return;
   }
   if(name==='Files'){let off=0;const load=async()=>{const data=W.data(await sb.from(selected.kind==='group'?'group_messages':'direct_messages').select('*').eq(selected.kind==='group'?'group_id':'thread_id',selected.id).not('attachment_path','is',null).order('created_at',{ascending:false}).range(off,off+29));out.innerHTML=data.map(m=>W.attachment(m,'chat-files')).join('')||'<p>No shared attachments.</p>';out.insertAdjacentHTML('beforeend','<button class="btn small" id="files-more">Next attachments</button>');U.q('#files-more',out).disabled=data.length<30;U.q('#files-more',out).onclick=run(async()=>{off+=30;await load();});W.files(out,sb);W.photos(out,sb);};await load();if(selected.kind==='group'){out.insertAdjacentHTML('beforeend','<button class="btn small" id="group-files-open">Group file manager</button>');U.q('#group-files-open').onclick=run(()=>legacyPanel('files'));}return;}
   if(name==='Members'){if(selected.kind==='group'){await legacyPanel('members');return;}const people=await c.namesFor([myId,selected.peer_id]);out.innerHTML=Object.values(people).map(p=>`<div class="ws-member">${W.avatar(p.full_name,p.avatar_path)}<span>${U.esc(p.full_name)}${window.EduPresence.badge(p.id)}</span></div>`).join('');W.photos(out,sb);return;}
   if(name==='Meetings'){if(selected.kind==='group'){await legacyPanel('meetings');return;}out.innerHTML='<button class="btn primary" id="details-call">Start video meeting</button>';U.q('#details-call').onclick=run(()=>call(false));return;}
   if(name==='Google Drive'){await legacyPanel('drive');return;}
   if(name==='Settings'){out.innerHTML=`<label class="ws-setting"><input id="favorite-chat" type="checkbox" ${selected.favorite?'checked':''}>Favorite conversation</label><label class="ws-setting"><input id="pin-chat" type="checkbox" ${selected.pinned?'checked':''}>Pin conversation</label>`;for(const [id,key]of[['favorite-chat','favorite'],['pin-chat','pinned']])U.q('#'+id,out).onchange=run(async e=>{const value=e.target.checked;W.data(await sb.from('chat_preferences').upsert({kind:selected.kind,thread_id:selected.id,user_id:myId,favorite:!!selected.favorite,pinned:!!selected.pinned,[key]:value}));selected[key]=value;await loadList();});if(selected.kind==='group'){out.insertAdjacentHTML('beforeend','<button class="btn" id="group-settings-open">Group settings</button>');U.q('#group-settings-open').onclick=run(()=>legacyPanel('settings'));}}
  }
  async function legacyPanel(tab){const g=W.data(await sb.from('groups').select('*').eq('id',selected.id).single());U.q('#details-panel').innerHTML='<div id="group-body"></div>';await c.groupPanel(g,tab);}
  async function call(audio){await c.startCall(selected,audio);}
  const refresh=async change=>{if(pollBusy||closed)return;pollBusy=true;try{const table=change?.table,p=change?.payload||{},row=p.new&&Object.keys(p.new).length?p.new:p.old||{},event=p.eventType||'';if(table==='group_members'&&selected?.kind==='group'&&row.group_id===selected.id){mentionPeople=null;mentionGroup='';}
   if(table==='group_messages'||table==='direct_messages'){const kind=table==='group_messages'?'group':'direct',threadId=row[kind==='group'?'group_id':'thread_id'];if(selected?.kind===kind&&selected.id===threadId&&row.id){const log=U.q('#message-log'),atBottom=log&&log.scrollHeight-log.clientHeight-log.scrollTop<100;if(event==='DELETE')messages=messages.filter(m=>m.id!==row.id);else{let hydrated=(await c.hydrateAttachments([row]))[0]||row;if(!profiles[hydrated.sender_id])Object.assign(profiles,await c.namesFor([hydrated.sender_id]));const map=new Map(messages.map(m=>[m.id,m]));map.set(hydrated.id,{...(map.get(hydrated.id)||{}),...hydrated});messages=[...map.values()].sort((a,b)=>new Date(a.created_at)-new Date(b.created_at)||String(a.id).localeCompare(String(b.id)));messageOffset=Math.max(messageOffset,messages.length);}paintMessages();saveMsgCache(selected);if(atBottom&&log)requestAnimationFrame(()=>{log.scrollTop=log.scrollHeight;markSeen().catch(()=>{});});}await loadList();return;}
   if(table==='chat_receipts'){if(selected&&row.kind===selected.kind&&row.thread_id===selected.id){receipts=receipts.filter(r=>!(r.user_id===row.user_id));if(event!=='DELETE')receipts.push(row);paintMessages();saveMsgCache(selected);}return;}
   if(table==='chat_reactions'){if(selected&&row.kind===selected.kind&&row.thread_id===selected.id){reactions=reactions.filter(r=>!(r.message_id===row.message_id&&r.user_id===row.user_id));if(event!=='DELETE')reactions.push(row);paintMessages();saveMsgCache(selected);}return;}
   if(table==='profiles'&&row.id){
    const threadProfile=threads.find(t=>t.kind==='direct'&&t.peer_id===row.id),before=profiles[row.id]||{},oldAvatar=before.avatar_path??threadProfile?.avatar_path??null,oldName=before.full_name??threadProfile?.name??null;
    profiles[row.id]={...before,...row};
    const avatarChanged=Object.prototype.hasOwnProperty.call(row,'avatar_path')&&row.avatar_path!==oldAvatar,nameChanged=Object.prototype.hasOwnProperty.call(row,'full_name')&&row.full_name!==oldName;
    if(selected?.kind==='direct'&&selected.peer_id===row.id){
      if(nameChanged&&row.full_name){selected.name=row.full_name;const h=U.q('.ws-heading-copy h2',conv);if(h)h.textContent=row.full_name;}
      if(avatarChanged){selected.avatar_path=row.avatar_path||null;const av=U.q('.ws-conversation-header>.ws-avatar',conv);if(av){if(row.avatar_path){let img=U.q('img',av);if(!img){av.textContent='';img=document.createElement('img');av.appendChild(img);}img.alt=selected.name||'Profile';img.dataset.photo=row.avatar_path;img.dataset.bucket='avatars';img.loading='eager';delete img.dataset.photoLoaded;img.removeAttribute('src');W.photos(av,sb);}else av.textContent=(selected.name||'?').trim().slice(0,1).toUpperCase();}}
    }
    if(selected)paintMessages();
    if(avatarChanged||nameChanged)await loadList();
    if(selected?.kind==='direct'&&selected.peer_id===row.id)window.EduPresence.paint?.([row.id]);
    return;
   }
   if(table==='groups'&&selected?.kind==='group'&&row.id===selected.id){selected={...selected,...row,avatar_path:row.image_path??selected.avatar_path};S.group=selected;await renderDetails();}await loadList();
  }finally{pollBusy=false;}};
  W.watch(sb,['group_messages','direct_messages','direct_threads','chat_receipts','chat_preferences','chat_reactions','group_members','profiles'],refresh);
  await loadList();if(W.pending){const pending=W.pending;W.pending=null;let item=threads.find(t=>t.id===pending.id&&t.kind===pending.kind);if(!item&&pending.kind==='group'){const g=W.data(await sb.from('groups').select('*').eq('id',pending.id).single());item={...g,kind:'group',avatar_path:g.image_path};}if(!item&&pending.kind==='direct'){const t=W.data(await sb.from('direct_threads').select('*').eq('id',pending.id).single()),peer=t.user_a===myId?t.user_b:t.user_a,p=W.data(await sb.from('profiles').select('id,full_name,avatar_path').eq('id',peer).single());item={id:t.id,kind:'direct',peer_id:peer,name:p.full_name,avatar_path:p.avatar_path};}if(item)select(item).catch(e=>U.toast(U.errorText(e),'error'));}else if(threads.length&&!matchMedia('(max-width:800px)').matches)select(threads[0]).catch(e=>U.toast(U.errorText(e),'error'));if(initial==='contacts')U.q('#new-chat').click();
 };
})();

;
(() => {
 'use strict';const W=window.EduWorkspace;
 W.forum=async(c,startFilter='all')=>{
  const {sb,S,U}=c,root=U.q('#page');let filter=startFilter,search='',sort='latest',offset=0,posts=[],closed=false,version=0,lastQuery='',forumHasMore=false,forumServerMarker='';W.cleanups.push(()=>{closed=true;});root.className='content workspace-v3 ws-page ws-standard-page';
  root.innerHTML=`<div class="ws-page-heading"><div><h1>Community Forum</h1><p>Share updates, discussions, questions, and announcements with everyone on Edu Chat Pro.</p></div><button id="new-forum-post" class="ws-primary">${W.icon('plus')} New post</button></div><div class="ws-filterbar ws-forum-filters"><div class="ws-tabs">${[['all','list','All Posts'],['popular','flame','Popular'],['question','question','Questions'],['announcement','megaphone','Announcements'],['saved','bookmark','Saved Posts']].map(([f,icon,label])=>`<button data-forum-filter="${f}">${W.icon(icon)}${label}</button>`).join('')}</div><label class="ws-search">${W.icon('search')}<input id="forum-search" placeholder="Search posts, people, or topics…" aria-label="Search posts, people, or topics"></label><select id="forum-sort" aria-label="Sort forum"><option value="latest">Latest</option><option value="popular">Popular</option><option value="oldest">Oldest</option></select></div><div class="ws-forum-layout"><section class="ws-forum-feed"><div class="ws-card ws-post-composer">${W.avatar(S.profile.full_name,S.profile.avatar_path)}<div><button class="ws-composer-prompt" data-compose="discussion">Share something with the community…</button><div class="ws-compose-tools">${[['photo','image','Photo'],['poll','chart','Poll'],['file','paperclip','File'],['question','question','Question']].map(([type,icon,label])=>`<button data-compose="${type}">${W.icon(icon)}${label}</button>`).join('')}</div></div></div><div id="forum-posts"></div><button class="ws-more" id="forum-more">Load more posts</button></section><aside id="forum-sidebar" class="ws-right-column"></aside></div>`;
  const panelsButton=document.createElement('button');panelsButton.className='ws-secondary ws-panels-toggle';panelsButton.textContent='Side panel';panelsButton.setAttribute('aria-expanded','false');root.querySelector('.ws-page-heading').appendChild(panelsButton);panelsButton.onclick=()=>{root.classList.toggle('panels-open');panelsButton.setAttribute('aria-expanded',String(root.classList.contains('panels-open')));};
  const forumCacheKey=`ecp-forum-feed-v158:${S.user.id}`;
  const canCacheForum=()=>filter==='all'&&sort==='latest'&&!search;
  const markerOf=rows=>{let best=null;for(const p of rows||[]){const ts=Date.parse(p.updated_at||p.created_at||0)||0,id=String(p.id||'');if(!best||ts>best.ts||(ts===best.ts&&id>best.id))best={ts,id};}return best?best.ts+':'+best.id:'';};
  const saveForumCache=()=>{if(!canCacheForum())return;try{const keep=posts.slice(0,60);localStorage.setItem(forumCacheKey,JSON.stringify({posts:keep,offset:keep.length,lastQuery,hasMore:forumHasMore,serverMarker:forumServerMarker||markerOf(keep),savedAt:Date.now()}));}catch{}};
  const keyedCard=p=>{const card=postCard(p),stamp=U.attr(JSON.stringify([p.updated_at,p.title,p.body,p.avatar_path,p.reactions,p.comments,p.shares,p.my_reaction,p.saved,p.my_vote,p.poll_counts,p.approval_status]));return card.replace('<article class="ws-card ws-post" data-post="'+p.id+'"','<article class="ws-card ws-post" data-post="'+p.id+'" data-render-key="post:'+U.attr(p.id)+'" data-render-stamp="'+stamp+'"');};
  const renderForumPosts=()=>{const list=U.q('#forum-posts');if(!list)return;const html=posts.length?posts.map(keyedCard).join(''):'<div class="ws-card ws-empty" data-render-key="empty" data-render-stamp="empty">No discussions match this filter. Start a new post or change the search.</div>';W.patchChildren(list,html);U.q('#forum-more').hidden=!forumHasMore;U.qa('[data-forum-filter]').forEach(b=>b.classList.toggle('active',b.dataset.forumFilter===filter));wirePosts(list);W.photos(root,sb);W.files(list,sb);};
  const restoreForumCache=()=>{if(!canCacheForum())return false;try{const saved=JSON.parse(localStorage.getItem(forumCacheKey)||'null');if(!saved||!Array.isArray(saved.posts)||!saved.posts.length)return false;posts=saved.posts;offset=Number(saved.offset)||posts.length;lastQuery=saved.lastQuery||JSON.stringify([search,filter,sort]);forumHasMore=!!saved.hasMore;forumServerMarker=saved.serverMarker||markerOf(posts);renderForumPosts();return true;}catch{return false;}};
  async function readForumServerMarker(){try{const r=await sb.from('forum_posts').select('id,updated_at,created_at').order('updated_at',{ascending:false}).order('id',{ascending:false}).limit(1);if(r.error)return'';return markerOf(r.data||[]);}catch{return'';}}
  async function catchUpForum(){if(!canCacheForum())return;const current=await readForumServerMarker();if(closed)return;if(current&&current!==forumServerMarker){await load();return;}if(current){forumServerMarker=current;saveForumCache();}}
  async function load(append=false){const ticket=++version,key=JSON.stringify([search,filter,sort]),count=!append&&key===lastQuery?Math.max(1,Math.ceil(offset/20)):1,args={search_text:search,filter_name:filter,sort_name:sort};let data=[];for(let page=0;page<count;page++){const batch=W.data(await sb.rpc('forum_feed',{...args,page_offset:append?offset:page*20}));if(closed||ticket!==version)return;data.push(...batch);if(batch.length<20)break;}if(data.length){const status=await sb.from('forum_posts').select('id,approval_status').in('id',data.map(x=>x.id));if(!status.error){const sm=Object.fromEntries((status.data||[]).map(x=>[x.id,x.approval_status||'approved']));data=data.map(x=>({...x,approval_status:sm[x.id]||'approved'})).filter(x=>c.isAdmin()||x.approval_status!=='pending');}}lastQuery=key;if(closed||ticket!==version)return;if(!append){posts=[];offset=0;}posts.push(...data);offset+=data.length;forumHasMore=data.length!==0&&data.length%20===0;renderForumPosts();if(canCacheForum()){forumServerMarker=await readForumServerMarker()||markerOf(posts);saveForumCache();}}
  function postCard(p){const author=p.anonymous?'Anonymous':p.author_name||'Member',role=p.anonymous?'':p.author_role==='super_admin'?'Instructor':p.author_role==='assistant_admin'?'Moderator':'Student',counts=p.poll_counts||{},total=Object.values(counts).reduce((a,b)=>a+Number(b),0);return `<article class="ws-card ws-post" data-post="${p.id}"><header>${W.avatar(author,p.anonymous?null:p.avatar_path)}<div><b>${U.esc(author)}</b>${!p.anonymous?window.EduPresence.badge(p.public_author_id||p.author_id):''}${role?`<span class="ws-role ${role.toLowerCase()}">${role}</span>`:''}<p>${U.fmtDate(p.created_at)}${p.tags?.length?' · '+U.esc(p.tags.join(' · ')):''}${p.approval_status==='pending'?' · Pending approval':''}</p></div><span class="spacer"></span>${W.button('more','Post options',`data-post-menu="${p.id}"`)}</header><h3>${W.icon(p.category==='question'?'question':p.attachment_path?'image':'chat')}${U.esc(p.title)}</h3><div class="ws-post-body">${W.rich(p.body)}</div>${W.attachment(p,'forum-media')}${p.category==='poll'&&p.poll_options?`<div class="ws-poll">${p.poll_options.map((option,i)=>`<button data-vote="${p.id}" data-choice="${i}" class="${p.my_vote===i?'chosen':''}" style="--vote:${total?Math.round(Number(counts[i]||0)/total*100):0}%"><span>${U.esc(option)}</span><b>${counts[i]||0} ${p.my_vote===i?'✓':''}</b></button>`).join('')}<small>${total} votes · Select an option to vote or change your vote</small></div>`:''}<div class="ws-post-counts"><button type="button" class="ws-reaction-count" data-reactors="${p.id}" ${Number(p.reactions)?'':'disabled'}>${Number(p.reactions)?'👍 ❤️ 🎉 ':''}${p.reactions||0} reactions</button><span class="spacer"></span><button data-comment="${p.id}">${p.comments||0} comments</button><span>${p.shares||0} shares</span></div><footer><button data-like="${p.id}" class="${p.my_reaction?'active':''}">${W.icon('like')}${p.my_reaction||'Like'}</button><button data-comment="${p.id}">${W.icon('chat')}Comment</button><button data-share="${p.id}">${W.icon('share')}Share</button><button data-save-post="${p.id}" class="${p.saved?'active':''}">${W.icon('bookmark')}${p.saved?'Saved':'Save'}</button></footer></article>`;}
  function patchForumPost(p){const list=U.q('#forum-posts'),old=list?.querySelector(`[data-post="${p.id}"]`);if(!old)return;const t=document.createElement('template');t.innerHTML=keyedCard(p).trim();const fresh=t.content.firstElementChild;if(!fresh)return;old.replaceWith(fresh);wirePosts(fresh);W.photos(fresh,sb);W.files(fresh,sb);saveForumCache();}
  async function refreshForumReactions(postId){const p=posts.find(x=>x.id===postId);if(!p)return;const r=await sb.from('forum_reactions').select('user_id,emoji,reaction').eq('post_id',postId);if(r.error)return;const rows=r.data||[];p.reactions=rows.length;const mine=rows.find(x=>x.user_id===S.user.id);p.my_reaction=mine?.emoji||mine?.reaction||null;patchForumPost(p);}
  async function refreshForumComments(postId){const p=posts.find(x=>x.id===postId);if(!p)return;const r=await sb.from('forum_comments').select('id',{count:'exact',head:true}).eq('post_id',postId);if(r.error)return;p.comments=Number(r.count||0);patchForumPost(p);}
  async function refreshForumVotes(postId){const p=posts.find(x=>x.id===postId);if(!p)return;const r=await sb.from('forum_votes').select('user_id,choice').eq('post_id',postId);if(r.error)return;const counts={};let mine=null;for(const v of r.data||[]){counts[v.choice]=(counts[v.choice]||0)+1;if(v.user_id===S.user.id)mine=Number(v.choice);}p.poll_counts=counts;p.my_vote=mine;patchForumPost(p);}
  async function refreshForumShares(postId){const p=posts.find(x=>x.id===postId);if(!p)return;const r=await sb.from('forum_shares').select('post_id',{count:'exact',head:true}).eq('post_id',postId);if(r.error)return;p.shares=Number(r.count||0);patchForumPost(p);}
  async function showReactors(postId){
   let result=await sb.from('forum_reactions').select('post_id,user_id,emoji,reaction,created_at').eq('post_id',postId).order('created_at',{ascending:false});
   if(result.error)result=await sb.from('forum_reactions').select('post_id,user_id,emoji,reaction').eq('post_id',postId);
   const rows=W.data(result)||[],people=await c.namesFor(rows.map(x=>x.user_id));
   const body=rows.length?`<div class="ws-fb-reactor-list">${rows.map(x=>{const person=people[x.user_id]||{full_name:'Member'};return `<div class="ws-fb-reactor-row">${W.avatar(person.full_name,person.avatar_path)}<b>${U.esc(person.full_name||'Member')}</b><span>${U.esc(x.emoji||({like:'👍',love:'❤️',celebrate:'🎉',laugh:'😂',pray:'🙏',wow:'😮'})[x.reaction]||'👍')}</span></div>`}).join('')}</div>`:'<p>No reactions yet.</p>';
   const modal=U.modal({title:`Reactions (${rows.length})`,body,wide:false});W.photos(modal,sb);
  }
  function wirePosts(list){U.qa('[data-reactors]',list).forEach(b=>b.onclick=W.run(()=>showReactors(b.dataset.reactors)));U.qa('[data-like]',list).forEach(b=>b.onclick=W.run(async()=>{const p=posts.find(x=>x.id===b.dataset.like);if(!p)return;if(p.my_reaction)W.data(await sb.from('forum_reactions').delete().eq('post_id',p.id).eq('user_id',S.user.id));else W.data(await sb.from('forum_reactions').upsert({post_id:p.id,user_id:S.user.id,emoji:'👍'}));await refreshForumReactions(p.id);}));U.qa('[data-comment]',list).forEach(b=>b.onclick=W.run(()=>comments(posts.find(x=>x.id===b.dataset.comment))));U.qa('[data-share]',list).forEach(b=>b.onclick=W.run(async()=>{const p=posts.find(x=>x.id===b.dataset.share);if(!p)return;const url=new URL(location.href);url.search='';url.hash='';url.searchParams.set('post',p.id);await U.copy(url.href);W.data(await sb.from('forum_shares').upsert({post_id:p.id,user_id:S.user.id}));await refreshForumShares(p.id);}));U.qa('[data-save-post]',list).forEach(b=>b.onclick=W.run(async()=>{const p=posts.find(x=>x.id===b.dataset.savePost);if(!p)return;if(p.saved)W.data(await sb.from('forum_saved').delete().eq('post_id',p.id).eq('user_id',S.user.id));else W.data(await sb.from('forum_saved').upsert({post_id:p.id,user_id:S.user.id}));p.saved=!p.saved;patchForumPost(p);}));U.qa('[data-vote]',list).forEach(b=>b.onclick=W.run(async()=>{W.data(await sb.rpc('vote_forum',{p:b.dataset.vote,option_index:Number(b.dataset.choice)}));await refreshForumVotes(b.dataset.vote);}));U.qa('[data-post-menu]',list).forEach(b=>b.onclick=()=>postMenu(posts.find(p=>p.id===b.dataset.postMenu)));}
  async function compose(type='discussion',existing=null){let id=existing?.id||null,attachment=null,stored=existing?.attachment_path?{attachment_path:existing.attachment_path,attachment_name:existing.attachment_name,attachment_mime:existing.attachment_mime}:null;const category=existing?.category||(type==='question'||type==='poll'?type:'discussion');const r=U.modal({title:existing?'Edit post':'New community post',wide:true,closeOnBackdrop:false,body:`<form id="forum-compose"><label class="field">Title<input id="post-title" class="input" maxlength="160" value="${U.attr(existing?.title||'')}" required></label><label class="field">Description</label><div class="ws-format-tools"><button type="button" data-format="**" aria-label="Bold selected text"><strong>B</strong> Bold</button><button type="button" data-format="==" aria-label="Highlight selected text"><mark>Highlight</mark></button></div><label class="field"><textarea id="post-body" class="textarea" maxlength="10000" required>${U.esc(existing?.body||'')}</textarea></label><div class="ws-form-row"><label class="field">Category<select id="post-category" class="select"><option value="discussion">Discussion</option><option value="question">Question</option><option value="poll">Poll</option>${c.can('announcements.create')?'<option value="announcement">Announcement</option>':''}</select></label><label class="field">Topics (comma separated)<input id="post-tags" class="input" maxlength="400" value="${U.attr((existing?.tags||[]).join(', '))}" placeholder="webdev, resources"></label></div><label class="field" id="poll-field">Poll options (one per line, 2–6)<textarea id="post-poll" class="textarea" maxlength="726">${U.esc((existing?.poll_options||[]).join('\n'))}</textarea></label><label class="ws-setting"><input id="post-anonymous" type="checkbox" ${existing?.anonymous?'checked':''}>Post anonymously</label><p class="ws-small">Your identity is hidden from other users. Super Admin identification is audited.</p><label class="ws-secondary">${W.icon('paperclip')} ${type==='photo'?'Choose photo':'Attach photo or file'}<input id="post-file" type="file" ${type==='photo'?'accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime"':''} hidden></label><span id="post-file-label">${U.esc(stored?.attachment_name||'')}</span><p id="compose-error" class="danger-text" role="alert"></p></form>`,actions:'<button class="btn" data-close>Cancel</button><button class="btn primary" id="publish-post">Publish</button>'});
   U.qa('[data-format]',r).forEach(b=>b.onclick=()=>{const t=U.q('#post-body',r),a=t.selectionStart,z=t.selectionEnd,token=b.dataset.format,chosen=t.value.slice(a,z)||'text';t.setRangeText(token+chosen+token,a,z,'select');t.focus();t.setSelectionRange(a+token.length,a+token.length+chosen.length);});U.q('#post-category',r).value=category;const pollVisibility=()=>U.q('#poll-field',r).hidden=U.q('#post-category',r).value!=='poll';pollVisibility();U.q('#post-category',r).onchange=pollVisibility;U.q('#post-file',r).onchange=e=>{attachment=e.target.files[0]||null;U.q('#post-file-label',r).textContent=attachment?.name||stored?.attachment_name||'';};
   U.q('#publish-post',r).onclick=async()=>{const form=U.q('#forum-compose',r);if(!form.reportValidity())return;const button=U.q('#publish-post',r);button.disabled=true;U.q('#compose-error',r).textContent='';try{const cat=U.q('#post-category',r).value,options=U.q('#post-poll',r).value.split('\n').map(x=>x.trim()).filter(Boolean),tags=U.q('#post-tags',r).value.split(',').map(x=>x.trim().replace(/^#/, '').slice(0,40)).filter(Boolean);if(tags.length>8)throw new Error('Use up to 8 topics.');if(cat==='poll'&&(options.length<2||options.length>6||options.some(x=>x.length>120)))throw new Error('A poll needs 2–6 options, each up to 120 characters.');
    id=W.data(await sb.rpc('save_post',{post:id,title_text:U.q('#post-title',r).value.trim(),body_text:U.q('#post-body',r).value.trim(),is_anonymous:U.q('#post-anonymous',r).checked}));if(attachment){if(/^(image|video)\//.test(attachment.type)){const path=await c.uploadForumMedia(attachment);try{W.data(await sb.rpc('ec_r4_set_forum_media',{post_input:id,path_input:path}));}catch(error){await sb.storage.from('forum-images').remove([path]);throw error;}stored=null;}else stored=await W.upload(sb,'forum-media',id,attachment);attachment=null;}
    const changedPoll=cat==='poll'&&JSON.stringify(options)!==JSON.stringify(existing?.poll_options);W.data(await sb.rpc('set_forum_details',{p:id,category_name:cat,post_tags:tags,poll_options:changedPoll?options:null,file_path:stored?.attachment_path||null,file_name:stored?.attachment_name||null,file_mime:stored?.attachment_mime||null}));let pending=false;if(!c.isAdmin()&&!existing){const settings=await sb.from('forum_settings').select('require_approval').eq('id',1).maybeSingle();if(!settings.error&&settings.data?.require_approval){const q=await sb.from('forum_posts').update({approval_status:'pending',approved_by:null,approved_at:null}).eq('id',id);if(!q.error)pending=true;}}if(cat==='announcement'&&c.isSuper()){const message=U.q('#post-title',r).value.trim()+': '+U.q('#post-body',r).value.trim().slice(0,350);await sb.rpc('admin_announcement',{message});}U.closeModal();U.toast(pending?'Post sent for admin approval.':'Post published.','ok');await Promise.all([load(),sidebar()]);
   }catch(e){if(!U.q('#compose-error',r)){U.toast(U.errorText(e),'error');return;}U.q('#compose-error',r).textContent=(id?'Post text was saved. Finish the remaining details by retrying: ':'')+U.errorText(e);}finally{button.disabled=false;}};
  }
  async function comments(post,initialReply=null){let off=0,all=[],reply=initialReply;const r=U.modal({title:'Discussion',wide:true,body:`<h3>${U.esc(post.title)}</h3><p class="ws-post-body">${W.rich(post.body)}</p><div id="ws-comments"></div><button id="comments-more" class="ws-more">More comments</button><form id="comment-form" class="ws-comment-form"><p id="reply-to" hidden></p><textarea id="comment-body" class="textarea" maxlength="4000" placeholder="Write a comment…"></textarea><label class="btn">Photo / video<input id="comment-media" type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime"></label><button class="btn primary">Post comment</button></form>`});
   const setReply=(id,names)=>{reply=id||null;const label=U.q('#reply-to',r),input=U.q('#comment-body',r);if(!reply){label.hidden=true;input.placeholder='Write a comment…';return;}const item=all.find(x=>x.id===reply),who=names[item?.author_id]?.full_name||'Member';label.hidden=false;label.innerHTML=`Replying to <b>${U.esc(who)}</b> · <button type="button" class="text-btn" id="cancel-reply">Cancel</button>`;U.q('#cancel-reply',label).onclick=()=>setReply(null,names);input.placeholder=`Reply to ${who}…`;input.focus();};
   const loadComments=async(reset=false)=>{if(reset){all=[];off=0;}const data=W.data(await sb.from('forum_comments').select('*').eq('post_id',post.id).order('created_at').order('id').range(off,off+39));if(!r.isConnected)return;all.push(...data);off+=data.length;const names=await c.namesFor(all.map(x=>x.author_id)),children=new Map();for(const x of all){const k=x.parent_id||'root';if(!children.has(k))children.set(k,[]);children.get(k).push(x);}const render=(x,d=0)=>{const person=names[x.author_id]||{full_name:'Member'},kids=children.get(x.id)||[];return `<article class="ws-comment ${d?'reply':''}" data-comment-id="${x.id}" data-post-id="${post.id}" style="margin-left:${Math.min(d,3)*30}px">${W.avatar(person.full_name,person.avatar_path)}<div><b>${U.esc(person.full_name)}</b>${window.EduPresence.badge(x.author_id)}<time>${W.time(x.created_at)}</time>${d?'<small>Reply</small>':''}<p>${W.rich(x.body)}</p>${W.attachment(x,'forum-media')}<button class="text-btn" data-reply="${x.id}">Reply</button>${x.author_id===S.user.id?`<button class="text-btn" data-edit-comment="${x.id}">Edit</button>`:''}${x.author_id===S.user.id||c.can('forum.moderate')?`<button class="text-btn danger-text" data-delete-comment="${x.id}">Delete</button>`:''}</div></article>${kids.map(k=>render(k,d+1)).join('')}`};const roots=all.filter(x=>!x.parent_id||!all.some(y=>y.id===x.parent_id));U.q('#comments-more',r).hidden=data.length<40;U.q('#ws-comments',r).innerHTML=roots.map(x=>render(x)).join('')||'<p>No comments yet.</p>';W.photos(r,sb);W.files(r,sb);U.qa('[data-reply]',r).forEach(b=>b.onclick=()=>setReply(b.dataset.reply,names));U.qa('[data-delete-comment]',r).forEach(b=>b.onclick=W.run(async()=>{if(!window.confirm('Delete this comment and its replies?'))return;W.data(await sb.from('forum_comments').delete().eq('id',b.dataset.deleteComment));await loadComments(true);await refreshForumComments(post.id);}));U.qa('[data-edit-comment]',r).forEach(b=>b.onclick=W.run(async()=>{const x=all.find(v=>v.id===b.dataset.editComment),body=window.prompt('Edit comment',x.body);if(!body?.trim())return;W.data(await sb.from('forum_comments').update({body:body.trim()}).eq('id',x.id).eq('author_id',S.user.id));await loadComments(true);}));if(reply)setReply(reply,names);};
   U.q('#comments-more',r).onclick=W.run(()=>loadComments());U.q('#comment-form',r).onsubmit=W.run(async e=>{e.preventDefault();const input=U.q('#comment-body',r),picker=U.q('#comment-media',r),button=U.q('#comment-form button',r),file=picker.files[0];if(button.disabled||(!input.value.trim()&&!file))return;button.disabled=true;let path,saved=false;try{if(file)path=await c.uploadForumMedia(file);W.data(await sb.from('forum_comments').insert({post_id:post.id,author_id:S.user.id,parent_id:reply,body:input.value.trim(),...(path?{image_path:path}:{})}));saved=true;input.value='';picker.value='';}catch(error){if(path&&!saved)await sb.storage.from('forum-images').remove([path]);throw error;}finally{button.disabled=false;}reply=null;U.q('#reply-to',r).hidden=true;input.placeholder='Write a comment…';await loadComments(true);await refreshForumComments(post.id);});await loadComments();
  }
  function postMenu(p){const r=U.modal({title:'Post options',body:`<div class="ws-emoji-options">${['👍','❤️','🎉','😂','🙏','😮'].map(e=>`<button data-post-emoji="${e}">${e}</button>`).join('')}</div>`,actions:`${p.mine?'<button class="btn" id="edit-post">Edit</button>':''}${p.mine||c.can('forum.moderate')?'<button class="btn danger" id="delete-post">Delete</button>':''}${p.anonymous&&c.isSuper()?'<button class="btn" id="identify-post">Identify author</button>':''}<button class="btn" id="report-post">Report</button><button class="btn" data-close>Close</button>`});U.qa('[data-post-emoji]',r).forEach(b=>b.onclick=W.run(async()=>{W.data(await sb.from('forum_reactions').upsert({post_id:p.id,user_id:S.user.id,emoji:b.dataset.postEmoji}));U.closeModal();await refreshForumReactions(p.id);}));U.q('#edit-post',r)?.addEventListener('click',()=>compose(p.category,p));U.q('#delete-post',r)?.addEventListener('click',W.run(async()=>{U.closeModal();if(!await U.confirmBox('Delete discussion','Delete this post and its comments?','Delete'))return;W.data(await sb.rpc('delete_post',{post:p.id}));await Promise.all([load(),sidebar()]);}));U.q('#identify-post',r)?.addEventListener('click',W.run(async()=>{const id=W.data(await sb.rpc('identify_post',{post:p.id})),people=await c.namesFor([id]);U.modal({title:'Author — audited lookup',body:`<p>${U.esc(people[id]?.full_name||'Member')}</p><code>${U.esc(id)}</code>`});}));U.q('#report-post',r).onclick=W.run(async()=>{const values=await U.promptBox({title:'Report post',fields:[{label:'Reason',type:'textarea',max:2000}],submit:'Report'});if(!values)return;const result=await sb.from('forum_reports').insert({post_id:p.id,reporter_id:S.user.id,reason:values[0]});if(result.error?.code==='23505'){U.toast('You already reported this post.','ok');return;}W.data(result);U.toast('Report submitted.','ok');});}
  async function sidebar(){const data=W.data(await sb.rpc('forum_sidebar'));if(closed)return;const box=U.q('#forum-sidebar');function rules(list){return list.map(x=>`<div class="ws-rule"><span class="ws-rule-icon">${W.icon(x.icon)}</span><div><b>${U.esc(x.title)}</b><p>${U.esc(x.body)}</p></div></div>`).join('');}function topics(list){return list.map((x,i)=>`<button class="ws-topic" data-topic="${U.attr(x.tag)}"><i>${i+1}</i><span><b>${U.esc(x.tag)}</b><small>${x.posts} posts</small></span><em>#${U.esc(x.tag)}</em></button>`).join('')||'<p class="ws-small">Topics appear when posts include tags.</p>';}function contributors(list){return list.map((p,i)=>`<button class="ws-contributor" data-author="${U.attr(p.full_name)}">${W.avatar(p.full_name,p.avatar_path)}<b>${U.esc(p.full_name)}</b><span>${p.points} points</span><i>${i<3?'♛':''}</i></button>`).join('')||'<p class="ws-small">Contributors appear after publishing.</p>';}
   box.innerHTML=`<button type="button" class="ws-panel-close" id="forum-panel-close" aria-label="Close forum side panel">${W.icon('close')}<span>Close</span></button><section class="ws-card"><header><h3>${W.icon('shield')}Forum Rules</h3><span>${c.isSuper()?'<button class="text-btn" id="forum-edit-rules">Edit</button>':''}<button class="text-btn" data-view-all="rules">View all</button></span></header>${rules((data.rules||[]).slice(0,4))}</section><section class="ws-card"><header><h3>${W.icon('trending')}Trending Topics</h3><button class="text-btn" data-view-all="topics">View all</button></header>${topics((data.topics||[]).slice(0,5))}</section><section class="ws-card"><header><h3>${W.icon('trophy')}Top Contributors</h3><button class="text-btn" data-view-all="contributors">View all</button></header>${contributors((data.contributors||[]).slice(0,3))}<small class="ws-small">10 points per public post. Anonymous posts are excluded.</small></section>`;
   const wire=target=>{U.qa('[data-topic],[data-author]',target).forEach(b=>b.onclick=W.run(async()=>{search=b.dataset.topic||b.dataset.author;U.q('#forum-search').value=search;filter='all';await load();if(target!==box)U.closeModal();}));W.photos(target,sb);};U.q('#forum-panel-close',box)?.addEventListener('click',()=>{root.classList.remove('panels-open');panelsButton.setAttribute('aria-expanded','false');});wire(box);U.q('#forum-edit-rules',box)?.addEventListener('click',W.run(async()=>{const rows=W.data(await sb.from('forum_rules').select('*').order('id')),r=U.modal({title:'Edit forum rules',wide:true,body:rows.map(x=>`<div class="card card-pad" data-rule="${x.id}"><input class="input" data-title value="${U.attr(x.title||'')}"><textarea class="textarea" data-body>${U.esc(x.body||'')}</textarea></div>`).join(''),actions:'<button class="btn" data-close>Cancel</button><button class="btn primary" id="save-forum-rules">Save rules</button>'});U.q('#save-forum-rules',r).onclick=W.run(async()=>{for(const row of U.qa('[data-rule]',r))W.data(await sb.from('forum_rules').update({title:U.q('[data-title]',row).value.trim(),body:U.q('[data-body]',row).value.trim()}).eq('id',row.dataset.rule));U.closeModal();await sidebar();U.toast('Forum rules updated.','ok');});}));U.qa('[data-view-all]',box).forEach(b=>b.onclick=()=>{const key=b.dataset.viewAll,r=U.modal({title:{rules:'Forum rules',topics:'Trending topics',contributors:'Top contributors'}[key],body:({rules,topics,contributors}[key])(data[key]||[]),wide:true});wire(r);});
  }
  U.q('#new-forum-post').onclick=()=>compose();U.qa('[data-compose]').forEach(b=>b.onclick=()=>compose(b.dataset.compose));U.qa('[data-forum-filter]').forEach(b=>b.onclick=W.run(async()=>{filter=b.dataset.forumFilter;await load();}));U.q('#forum-search').oninput=U.debounce(W.run(async e=>{search=e.target.value;await load();}),250);U.q('#forum-sort').onchange=W.run(async e=>{sort=e.target.value;await load();});U.q('#forum-more').onclick=W.run(()=>load(true));W.watch(sb,['forum_posts','forum_comments','forum_reactions','forum_votes','forum_saved','profiles'],async change=>{
    const payload=change?.payload||{},row=payload.new&&Object.keys(payload.new).length?payload.new:payload.old||{},event=payload.eventType||'';
    if(change?.table==='profiles'){if(!row.id)return;const affected=[];for(const p of posts){if(!p.anonymous&&(p.public_author_id===row.id||p.author_id===row.id)){if(Object.prototype.hasOwnProperty.call(row,'avatar_path'))p.avatar_path=row.avatar_path;if(row.full_name)p.author_name=row.full_name;affected.push(p);}}for(const p of affected)patchForumPost(p);return;}
    if(change?.table==='forum_reactions'){if(row.post_id)await refreshForumReactions(row.post_id);return;}
    if(change?.table==='forum_comments'){if(row.post_id)await refreshForumComments(row.post_id);return;}
    if(change?.table==='forum_votes'){if(row.post_id)await refreshForumVotes(row.post_id);return;}
    if(change?.table==='forum_saved'){if(row.user_id===S.user.id&&row.post_id){const p=posts.find(x=>x.id===row.post_id);if(p){p.saved=event!=='DELETE';patchForumPost(p);}}return;}
    if(change?.table==='forum_posts'){if(event==='DELETE'&&row.id){posts=posts.filter(p=>p.id!==row.id);offset=Math.max(0,offset-1);U.q(`#forum-posts [data-post="${row.id}"]`)?.remove();forumServerMarker=await readForumServerMarker();saveForumCache();await sidebar();return;}await load();await sidebar();return;}
  });const restoredForum=restoreForumCache();await Promise.all([restoredForum?catchUpForum():load(),sidebar()]);
  if(W.pendingPost){const id=W.pendingPost;W.pendingPost=null;const p=W.data(await sb.from('forum_posts').select('*').eq('id',id).single());await comments(p);}
 };
 W.saved=async c=>{const {U,sb}=c,root=U.q('#page');root.className='content workspace-v3 ws-page ws-standard-page';let offset=0,closed=false;W.cleanups.push(()=>{closed=true;});root.innerHTML='<div class="ws-page-heading"><div><h1>Saved</h1><p>Your bookmarked messages and community posts.</p></div><button class="ws-primary" id="saved-forum">Saved posts</button></div><div id="saved-chat-list" class="ws-saved-list"></div><button class="ws-more" id="saved-more">Load more messages</button>';const load=async()=>{const rows=W.data(await sb.rpc('saved_chat_messages',{page_offset:offset}));if(closed)return;const list=U.q('#saved-chat-list');if(!offset&&!rows.length)list.innerHTML='<div class="ws-card ws-empty">No saved messages yet.</div>';offset+=rows.length;list.insertAdjacentHTML('beforeend',rows.map(r=>`<article class="ws-card"><h3>${U.esc(r.name)}</h3><p>${U.esc(r.body)}</p><button class="btn" data-open-saved="${r.thread_id}" data-kind="${r.kind}">Open chat</button><button class="btn ghost" data-remove-saved="${r.message_id}" data-kind="${r.kind}">Unsave</button></article>`).join(''));U.q('#saved-more').hidden=rows.length<40;U.qa('[data-open-saved]').forEach(b=>b.onclick=()=>W.openChat(c,b.dataset.kind,b.dataset.openSaved));U.qa('[data-remove-saved]').forEach(b=>b.onclick=W.run(async()=>{W.data(await sb.from('saved_messages').delete().eq('user_id',c.S.user.id).eq('kind',b.dataset.kind).eq('message_id',b.dataset.removeSaved));b.closest('article').remove();}));};U.q('#saved-forum').onclick=()=>{W.dispose();W.forum(c,'saved').catch(e=>U.toast(e.message,'error'));};U.q('#saved-more').onclick=W.run(load);await load();};
})();

;
(() => {
 'use strict';const W=window.EduWorkspace;
 W.notifications=async c=>{
  const {sb,S,U}=c,root=U.q('#page');let filter='all',query='',oldest=false,offset=0,rows=[],closed=false,version=0,lastQuery='';W.cleanups.push(()=>{closed=true;});root.className='content workspace-v3 ws-page ws-standard-page ws-notifications-page';
  root.innerHTML=`<div class="ws-page-heading"><div><h1>Notifications</h1><p>Calls, messages, announcements, and community updates.</p></div><div class="ws-heading-actions"><button class="ws-primary" data-enable-notify>${W.icon('bell')} Enable notifications</button><button class="ws-secondary" id="read-all">${W.icon('check')} Mark all as read</button><button class="ws-secondary danger-text" id="clear-notifications">${W.icon('trash')} Clear</button></div></div><div class="ws-notification-layout"><section class="ws-notification-main"><div class="ws-filterbar"><label class="ws-search">${W.icon('search')}<input id="notification-search" placeholder="Search notifications…"></label><div class="ws-tabs">${[['all','All'],['unread','Unread'],['mentions','@ Mentions'],['system','System']].map(([f,label])=>`<button data-notification-filter="${f}">${label} <span data-count="${f}"></span></button>`).join('')}</div><select id="notification-sort" aria-label="Sort notifications"><option value="newest">Newest first</option><option value="oldest">Oldest first</option></select></div><div class="ws-notification-scroll"><div id="notification-list"></div><button class="ws-more" id="notification-more">Load more</button></div></section><aside class="ws-right-column"><section class="ws-card ws-notify-promo"><div class="ws-bell-art">${W.icon('bell')}</div><h2>Stay in the loop</h2><p>Get notified about important messages, calls, and updates from your classes and communities.</p><button class="ws-primary" data-enable-notify>${W.icon('bell')} Enable notifications</button><p class="ws-small" id="notification-permission"></p></section><section class="ws-card"><h3>Notification types</h3>${[['messages','chat','Messages'],['calls','phone','Calls'],['mentions','at','Mentions'],['community','people','Community'],['system','settings','System']].map(([f,icon,label])=>`<button class="ws-type-row" data-notification-filter="${f}">${W.icon(icon)}${label}<span data-count="${f}">0</span></button>`).join('')}</section></aside></div>`;
  const panelsButton=document.createElement('button');panelsButton.className='ws-secondary ws-panels-toggle';panelsButton.textContent='Side panel';panelsButton.setAttribute('aria-expanded','false');root.querySelector('.ws-page-heading').appendChild(panelsButton);panelsButton.onclick=()=>{root.classList.toggle('panels-open');panelsButton.setAttribute('aria-expanded',String(root.classList.contains('panels-open')));};
  async function load(append=false){const v=++version,key=JSON.stringify([query,filter,oldest]),count=!append&&key===lastQuery?Math.max(1,Math.ceil(offset/40)):1,args={search_text:query,filter_name:filter,oldest_first:oldest};let data=[];for(let page=0;page<count;page++){const batch=W.data(await sb.rpc('notification_feed',{...args,page_offset:append?offset:page*40}));if(closed||v!==version)return;data.push(...batch);if(batch.length<40)break;}lastQuery=key;const counts=W.data(await sb.rpc('notification_counts'));if(closed||v!==version)return;if(!append){rows=[];offset=0;}rows.push(...data);offset+=data.length;U.q('#notification-more').hidden=data.length===0||data.length%40!==0;U.qa('[data-count]',root).forEach(el=>el.textContent=counts[el.dataset.count]||0);U.qa('[data-notification-filter]',root).forEach(b=>b.classList.toggle('active',b.dataset.notificationFilter===filter));const list=U.q('#notification-list');list.innerHTML=rows.length?rows.map(n=>`<article class="ws-notification ${!n.read_at?'unread':''}"><span class="ws-read-dot"></span><span class="ws-notification-icon ${n.category}">${W.icon(({messages:'file',calls:'phone',mentions:'at',community:'smile',system:'megaphone'})[n.category])}</span><div class="ws-notification-copy"><h3>${U.esc(n.title)}</h3><p>${U.esc(n.body||({group_files:'A file was shared in your group.',group_messages:'Open your group conversation.',meetings:'A group meeting is starting.',forum:'Someone replied to your discussion.'}[n.kind])||'An update from EduChat.')}</p></div><time title="${U.attr(U.fmtDate(n.created_at))}">${W.date(n.created_at)===W.date(new Date())?W.time(n.created_at):W.date(n.created_at)}</time><button class="ws-open" data-open-notification="${n.id}">Open</button>${W.button('more','Notification options',`data-notification-menu="${n.id}"`)}</article>`).join(''):'<div class="ws-card ws-empty">You’re all caught up. No notifications match this filter.</div>';U.qa('[data-open-notification]',list).forEach(b=>b.onclick=W.run(()=>open(rows.find(n=>n.id===b.dataset.openNotification))));U.qa('[data-notification-menu]',list).forEach(b=>b.onclick=()=>menu(rows.find(n=>n.id===b.dataset.notificationMenu)));}
  async function read(n,yes=true){W.data(await sb.from('notifications').update({read_at:yes?new Date().toISOString():null}).eq('id',n.id).eq('user_id',S.user.id));}
  async function open(n){if(!n.target_kind){await c.openNotification(n);return;}await read(n);const target=n.target_id||n.resource_id;if(n.target_kind==='group'){await W.openChat(c,'group',target);return;}if(n.target_kind==='direct'){await W.openChat(c,'direct',target);return;}if(n.target_kind==='meeting'){const m=W.data(await sb.from('meetings').select('*').eq('id',target).single());if(m.ended_at)throw new Error('This meeting has ended.');await c.openMeeting(m);await load();return;}if(n.target_kind==='forum'||['forum','community'].includes(n.kind)){W.pendingPost=target;await c.navigate('forum');return;}if(['group_messages','group_files','meetings'].includes(n.kind)){await W.openChat(c,'group',target);return;}await load();U.modal({title:n.title,body:`<p>${U.esc(n.body||'System notification')}</p><p>${U.fmtDate(n.created_at)}</p>`});}
  function menu(n){const r=U.modal({title:'Notification options',body:`<p>${U.esc(n.title)}</p>`,actions:`<button class="btn" id="toggle-read">${n.read_at?'Mark unread':'Mark read'}</button><button class="btn danger" id="remove-notification">Clear notification</button><button class="btn" data-close>Cancel</button>`});U.q('#toggle-read',r).onclick=W.run(async()=>{await read(n,!n.read_at);U.closeModal();await load();});U.q('#remove-notification',r).onclick=W.run(async()=>{W.data(await sb.from('notifications').delete().eq('id',n.id).eq('user_id',S.user.id));U.closeModal();await load();});}
  function permission(){U.q('#notification-permission').textContent='Notification'in window?'Browser permission: '+Notification.permission:'This browser does not support notifications.';}
  U.qa('[data-enable-notify]',root).forEach(b=>b.onclick=W.run(async()=>{await c.enableAlerts();permission();}));U.q('#read-all').onclick=W.run(async()=>{W.data(await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('user_id',S.user.id).is('read_at',null));await load();});
  U.q('#clear-notifications').onclick=()=>{const r=U.modal({title:'Clear notifications',body:'<p>Choose which notifications to remove from your account.</p>',actions:'<button class="btn" id="clear-read">Clear read</button><button class="btn danger" id="clear-all">Clear all</button><button class="btn" data-close>Cancel</button>'});for(const[id,onlyRead]of[['clear-read',true],['clear-all',false]])U.q('#'+id,r).onclick=W.run(async()=>{U.closeModal();if(!await U.confirmBox('Clear notifications',onlyRead?'Remove all read notifications?':'Remove all your notifications?','Clear'))return;let q=sb.from('notifications').delete().eq('user_id',S.user.id);if(onlyRead)q=q.not('read_at','is',null);W.data(await q);await load();});};
  U.qa('[data-notification-filter]',root).forEach(b=>b.onclick=W.run(async()=>{filter=b.dataset.notificationFilter;await load();}));U.q('#notification-search').oninput=U.debounce(W.run(async e=>{query=e.target.value;await load();}),250);U.q('#notification-sort').onchange=W.run(async e=>{oldest=e.target.value==='oldest';await load();});U.q('#notification-more').onclick=W.run(()=>load(true));W.watch(sb,['notifications'],()=>load());permission();await load();
 };
})();

;
(()=>{if(!document.getElementById('ecp-chat-layout-v118')){const style=document.createElement('style');style.id='ecp-chat-layout-v118';style.textContent=":root{--chat-blue:#087aff;--chat-pane:#f7fbff;--chat-other:#edf3f9;--chat-mine:#d1ecff;--chat-border:#e2edf7;--chat-soft:#eef5fb}\n:root[data-theme=dark]{--chat-blue:#56b2ff;--chat-pane:#0c1824;--chat-other:#182a3b;--chat-mine:#123d57;--chat-border:#243d50;--chat-soft:#152536}\n.main>.content.messenger-page{height:calc(100dvh - 52px);padding:0!important;overflow:hidden;display:block!important}\n.messenger-layout{display:grid;grid-template-columns:minmax(280px,350px) minmax(0,1fr);height:100%;min-height:0;background:var(--surface)}\n#conversation-rail{min-width:0;min-height:0;border-right:1px solid var(--chat-border);display:flex;flex-direction:column;background:var(--surface);padding:20px 0 10px}\n.rail-title{display:flex;align-items:center;justify-content:space-between;padding:0 20px 20px}.rail-title h1{font-size:29px;margin:0;color:var(--text)}.rail-title .icon-btn{border-radius:50%;background:#087aff;color:white;width:44px;height:44px;font-size:28px}\n.chat-filters{display:flex;gap:7px;padding:0 16px 18px;overflow-x:auto}.chat-filters button{border:0;background:var(--chat-soft);color:var(--text);font:inherit;font-size:12px;font-weight:700;border-radius:24px;padding:10px 13px;cursor:pointer;white-space:nowrap}.chat-filters button.selected{background:#087aff;color:white;box-shadow:0 4px 12px #087aff24}\n.rail-search{margin:0 16px 15px;display:flex;gap:10px;align-items:center;border-radius:16px;background:var(--chat-soft);padding:12px;color:var(--muted)}.rail-search span{font-size:23px}.rail-search input{font:inherit;font-size:13px;width:100%;border:0;outline:0;background:transparent;color:var(--text);min-width:0}\n#conversation-rows{flex:1;overflow-y:auto;min-height:0}.conversation{position:relative;margin:0 7px;border-bottom:1px solid var(--chat-border);border-radius:12px}.conversation.selected{background:color-mix(in srgb,var(--chat-blue) 12%,var(--surface));border-left:3px solid var(--chat-blue)}.conversation-main{border:0;display:flex;gap:12px;width:100%;padding:17px 12px 25px;background:transparent;text-align:left;cursor:pointer;color:var(--text);align-items:center}.conversation .avatar{width:52px;height:52px;min-width:52px;border-radius:50%;overflow:hidden;background:var(--chat-soft)}.conversation .avatar img{height:100%;width:100%;object-fit:cover}.conversation .avatar .ui-icon{width:28px;height:28px}.conversation-copy{display:grid;gap:7px;min-width:0;flex:1}.conversation-copy strong{font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.conversation-copy>span{font-size:13px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.conversation-end{align-self:flex-start;display:grid;justify-items:end;gap:12px;font-size:10px;color:var(--muted);white-space:nowrap}.unread-dot{width:11px;height:11px;border-radius:50%;background:#087aff}.conversation-pin{position:absolute;right:16px;bottom:7px;border:0;background:transparent;color:var(--muted);cursor:pointer;padding:2px 5px}.conversation-pin.pinned{color:var(--chat-blue)}.rail-empty{text-align:center;padding:30px 15px;color:var(--muted)}\n#conversation-pane{min-width:0;min-height:0;display:flex;flex-direction:column;overflow:hidden;background:var(--chat-pane)}.choose-conversation{margin:auto;text-align:center;padding:25px;color:var(--muted)}.choose-conversation img{width:80px;height:80px}.choose-conversation h1{color:var(--text);font-size:26px}.direct-heading{padding:17px 22px;margin:0!important;background:var(--surface);border-bottom:1px solid var(--chat-border);min-height:80px;gap:12px}.direct-heading h2{font-size:22px;margin:0}.direct-heading .avatar{width:52px;height:52px}.direct-heading .btn{border:0;background:var(--chat-soft);border-radius:16px}.direct-heading .muted{font-size:13px}.direct-heading #dm-back{display:none}\n#conversation-pane .chat-panel{flex:1;min-height:0;display:flex;flex-direction:column;border:0;border-radius:0;background:transparent;padding:0;margin:0;box-shadow:none}\n.chat-workspace .chat-log,#conversation-pane .chat-log{flex:1;min-height:0;border:0!important;border-radius:22px!important;padding:18px 20px!important;background-color:var(--chat-pane)!important;background-image:url('data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22220%22%20height%3D%22220%22%20viewBox%3D%220%200%20220%20220%22%20fill%3D%22none%22%20stroke%3D%22%2353b7e5%22%20stroke-opacity%3D%22.075%22%20stroke-width%3D%222%22%3E%3Cg%20transform%3D%22translate%2815%2018%29%20rotate%28-12%29%22%3E%3Crect%20width%3D%2226%22%20height%3D%2221%22%20rx%3D%228%22%2F%3E%3Cpath%20d%3D%22M6%2020v7l8-7M7%209h12M7%2014h8%22%2F%3E%3C%2Fg%3E%3Cg%20transform%3D%22translate%28116%2033%29%20rotate%2818%29%22%3E%3Cpath%20d%3D%22m0%2013%2033-13-11%2034-6-16zM16%2018%2033%200%22%2F%3E%3C%2Fg%3E%3Cg%20transform%3D%22translate%2861%20101%29%22%3E%3Ccircle%20cx%3D%2214%22%20cy%3D%2214%22%20r%3D%2215%22%2F%3E%3Cpath%20d%3D%22M8%2011h1m10%200h1M7%2018q7%208%2014%200%22%2F%3E%3C%2Fg%3E%3Cg%20transform%3D%22translate%28161%20131%29%20rotate%2812%29%22%3E%3Cpath%20d%3D%22M0%200h22v28H0zM4%207h14M4%2013h14M4%2019h9%22%2F%3E%3C%2Fg%3E%3Cg%20transform%3D%22translate%288%20171%29%20rotate%28-14%29%22%3E%3Cpath%20d%3D%22m0%209%2017-8%2017%208-17%208zM7%2013v9q10%209%2020%200v-9M34%209v16%22%2F%3E%3C%2Fg%3E%3Cpath%20d%3D%22m187%2028%203%206%207%201-5%205%201%207-6-4-6%204%201-7-5-5%207-1zM119%20190h13m-7-6v12M46%2058h6m-3-3v6%22%2F%3E%3C%2Fsvg%3E%0A')!important;background-size:220px!important;gap:17px!important;overflow-y:auto}\n.chat-workspace .message-row,#conversation-pane .message-row{position:relative;max-width:86%;gap:12px;align-items:flex-start;margin:0;flex-shrink:0}.chat-workspace .message-row .avatar,#conversation-pane .message-row .avatar{width:40px;height:40px;min-width:40px;overflow:hidden;border:3px solid var(--surface);box-shadow:0 2px 6px #1020400a}.chat-workspace .message,#conversation-pane .message{padding:11px 15px!important;border-radius:5px 20px 20px 20px!important;background:var(--chat-other)!important;box-shadow:0 2px 5px #16344b08;color:var(--text);min-width:110px;font-size:15px;font-weight:500;line-height:1.55;max-width:100%}.chat-workspace .message.mine,#conversation-pane .message.mine{background:var(--chat-mine)!important;border-radius:20px 5px 20px 20px!important}.chat-workspace .message .meta,#conversation-pane .message .meta{display:flex;gap:14px;align-items:center;margin-bottom:5px;font-size:11px;color:var(--muted)}.message .meta strong{color:var(--chat-blue);font-size:12px}.message .meta time{font-weight:500;white-space:nowrap}.message .bodytext{white-space:pre-wrap;overflow-wrap:anywhere}.message .danger-text{font-size:10px;opacity:.55;padding:3px 0}.message:hover .danger-text{opacity:1}\n.new-day{margin-top:36px!important}.new-day:before{content:attr(data-day);position:absolute;top:-33px;left:0;white-space:nowrap;border-radius:22px;background:var(--chat-soft);color:var(--muted);padding:4px 12px;font-size:10px}.new-day.mine:before{left:auto;right:0}\n.chat-reactions{display:flex;gap:5px;margin-top:7px;flex-wrap:wrap}.chat-reactions button{border:1px solid var(--chat-border);background:var(--surface);color:var(--text);border-radius:20px;padding:3px 8px;font-size:12px;cursor:pointer}.chat-reactions button:not(.has-reactions){opacity:0;transition:opacity .15s}.message:hover .chat-reactions button,.message:focus-within .chat-reactions button{opacity:1}.chat-reactions button.selected{border-color:var(--chat-blue);color:var(--chat-blue)}\n.chat-workspace .composer,#conversation-pane .composer{margin:0!important;background:var(--surface);padding:12px;border-radius:24px;border:1px solid var(--chat-border);flex-shrink:0}.composer .row{display:flex!important;align-items:center;gap:8px!important}.chat-workspace .composer .input,#conversation-pane .composer .input{background:var(--chat-soft)!important;border:0!important;box-shadow:none!important;height:46px!important;font-size:14px;font-weight:500;border-radius:28px;flex:1;min-width:60px}.composer .btn{height:44px;white-space:nowrap}.composer .attach-button,.composer .emoji-toggle,.composer .voice-button{width:44px!important;min-width:38px;border-radius:50%!important;border:0!important;background:var(--chat-soft)!important;padding:0!important;font-size:22px}.composer .btn.primary{background:#008e98!important;border-radius:25px!important;border:0!important;color:white!important;padding:10px 22px!important}#dm-form .btn.primary{background:#087aff!important}#dm-form .voice-button{order:8}#dm-form .btn.primary{order:9}#dm-form .emoji-toggle{order:0}#dm-attach{order:1}#dm-text{order:2}\n.chat-workspace #group-body{min-height:0;flex:1;display:flex;flex-direction:column}.chat-workspace #group-body.group-conversation{display:grid;grid-template-columns:minmax(0,1fr) 285px;gap:12px}.group-conversation>.chat-panel{min-height:0;margin:0;display:flex;flex-direction:column;padding:0!important;border:0;background:transparent;box-shadow:none}.group-info{padding:17px;overflow-y:auto;min-height:0;border-radius:22px;border:1px solid var(--chat-border);box-shadow:none;background:var(--surface);font-size:13px}.group-info header,.info-section-title{display:flex;align-items:center;justify-content:space-between;gap:8px}.group-info header strong{font-size:16px}.group-info h3{font-size:15px;margin:0}.group-info-title{display:flex;align-items:center;gap:12px;margin:20px 0 12px}.group-info-title>.avatar{width:62px;height:62px;flex-shrink:0;border:1px solid var(--chat-border);overflow:hidden}.group-info .avatar img{width:100%;height:100%;object-fit:cover}.group-info p{color:var(--muted);line-height:1.6}.group-info section{border-top:1px solid var(--chat-border);padding-top:17px;margin-top:17px}.info-member{display:flex;gap:10px;align-items:center;margin-top:13px}.info-member>span:last-child{display:grid;gap:4px}.info-member small{color:var(--muted)}.info-member .avatar{width:37px;height:37px}#info-media-list{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;margin-top:14px}.media-thumb{min-width:0;overflow:hidden;background:var(--chat-soft);color:var(--text);border:0;border-radius:10px;padding:5px;cursor:pointer}.media-thumb img{width:100%;height:54px;object-fit:cover;border-radius:7px}.media-thumb small{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-size:8px}.next-meeting{display:flex;gap:9px;align-items:center;background:var(--chat-soft);border-radius:14px;padding:12px;font-size:11px}.next-meeting>span{display:grid;flex:1;min-width:0}.next-meeting strong{overflow:hidden;text-overflow:ellipsis}.group-hero{border:1px solid var(--chat-border);box-shadow:none!important}.group-hero-icon img{border-radius:50%}.group-hero-icon{border-radius:50%!important}.chat-workspace>#group-tabs{border-color:var(--chat-border)!important}.chat-workspace #older-messages,#dm-older{align-self:center;font-size:10px;margin:3px!important;padding:3px 12px;min-height:20px;height:24px}.media-content img,.media-content video{max-height:220px}.shared-image{border-radius:12px}\n@media(min-width:1400px){.messenger-layout{grid-template-columns:390px minmax(0,1fr)}.chat-workspace #group-body.group-conversation{grid-template-columns:minmax(0,1fr) 315px}}\n@media(max-width:1100px){.group-info{display:none!important}.chat-workspace #group-body.group-conversation{display:flex}.messenger-layout{grid-template-columns:290px minmax(0,1fr)}.chat-workspace .message-row,#conversation-pane .message-row{max-width:93%}.composer #announce{font-size:11px;padding:5px 10px}}\n@media(max-width:760px){.messenger-layout{display:flex}.messenger-page #conversation-rail{width:100%;border:0}.messenger-page.direct-workspace #conversation-rail{display:none}.messenger-page:not(.direct-workspace) #conversation-pane{display:none}#conversation-pane{width:100%}.direct-heading #dm-back{display:block}.direct-heading{padding:10px}.direct-heading h2{font-size:17px}.chat-workspace .chat-log,#conversation-pane .chat-log{padding:12px 8px!important}.message-row .avatar{width:30px!important;height:30px!important;min-width:30px!important}.chat-workspace .message,#conversation-pane .message{font-size:14px;padding:8px 10px!important}.chat-reactions button:not(.has-reactions){opacity:.5}.composer .btn.primary{padding:8px 12px!important}.composer .btn.primary .ui-icon{margin:0}.composer .row{gap:4px!important}.composer .attach-button,.composer .emoji-toggle,.composer .voice-button{width:32px!important;min-width:30px;font-size:19px}.main>.content.messenger-page{height:calc(100dvh - 116px)}.chat-workspace .composer{padding:7px}.group-hero .body{display:block!important}}\n\n/* Deterministic viewport sizing and reference layout refinements. */\nhtml,body{font-family:\"Segoe UI\",Arial,sans-serif;font-weight:500;line-height:1.5}\nbutton,input,textarea,select{font-family:inherit}\n.shell>.main>.workspace-top{box-sizing:border-box;height:58px;min-height:58px;flex:0 0 58px;padding:8px 18px}\n.shell>.main>.content.messenger-page{height:auto!important;flex:1;min-height:0;padding:0!important;overflow:hidden!important}\n.messenger-layout{width:100%;max-width:100%;min-width:0;grid-template-columns:minmax(290px,360px) minmax(0,1fr)}\n#conversation-rail .rail-title h1{display:block;font-size:29px;line-height:1.2;font-weight:750;letter-spacing:-.7px}\n#conversation-rail button{font-family:inherit;text-transform:none;letter-spacing:normal}\n#conversation-rail .conversation-main{font-weight:500;text-align:left;min-width:0}\n#conversation-rail .conversation-copy{overflow:hidden;min-width:0}\n#conversation-rail .conversation-copy strong{font-size:16px;font-weight:750;display:block;max-width:100%}\n#conversation-rail .conversation-copy>span{display:block;width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500;line-height:1.5;max-height:1.5em}\n#conversation-rail .conversation-end time{font-weight:500;font-size:11px}\n#conversation-rail .rail-search input{font-weight:500;line-height:1.4;height:23px;padding:0}\n#conversation-rail .rail-search input::placeholder{font-weight:500}\n.chat-filters button{min-height:38px;padding:9px 14px;font-size:12px;font-weight:650;flex-shrink:0}\n.chat-workspace .group-hero .body{display:grid;grid-template-columns:minmax(130px,1fr) auto;gap:3px 24px}\n.chat-workspace .group-hero h1{font-size:22px;font-weight:750;letter-spacing:-.35px}\n.chat-workspace .group-hero p{font-size:13px;font-weight:500}\n.chat-workspace #group-member-count{font-size:12px;font-weight:500}\n.chat-workspace>#group-tabs{min-height:42px}\n.chat-workspace>#group-tabs button{font-size:13px;font-weight:650;min-height:40px}\n.chat-workspace #group-body.group-conversation{display:grid!important;grid-template-columns:minmax(0,1fr) 300px;grid-template-rows:minmax(0,1fr) auto;gap:12px;overflow:hidden}\n.group-conversation>.chat-panel{grid-column:1;grid-row:1;min-width:0;overflow:hidden;border:1px solid var(--chat-border)!important;border-radius:24px;padding:5px!important;background:var(--surface)}\n.group-conversation>.group-info{grid-column:2;grid-row:1;min-width:0;overflow:auto;padding:18px;border-radius:23px;align-self:stretch}\n.group-conversation>.composer{grid-column:1/-1;grid-row:2;min-width:0;margin:0!important;padding:10px 12px!important;border-radius:25px}\n.group-info .group-info-title{display:flex;gap:13px;align-items:center}\n.group-info .group-info-title>div{min-width:0}.group-info h3{font-size:15px;font-weight:750;line-height:1.4;overflow-wrap:anywhere}\n.group-info header strong{font-size:16px;font-weight:750}.group-info .muted,.group-info p,.info-member small{font-weight:500;font-size:13px;line-height:1.6}.group-info .info-member strong{font-size:12px;font-weight:650;overflow-wrap:anywhere}.group-info .info-member>span:last-child{min-width:0}.group-info .info-member .avatar{flex-shrink:0}.info-section-title .text-btn{font-size:11px;font-weight:600;color:var(--inbox-action)}\n.chat-workspace .chat-log,#conversation-pane .chat-log{height:auto!important;min-height:0;flex:1;overflow:auto!important}\n.chat-workspace .message .meta,#conversation-pane .message .meta{color:var(--muted);font-size:11px;font-weight:500}.chat-workspace .message .meta strong,#conversation-pane .message .meta strong{color:var(--chat-blue);font-size:12px;font-weight:700}\n.chat-workspace .message .bodytext,.chat-workspace .message>div:not(.meta):not(.chat-reactions),#conversation-pane .message .bodytext{font-size:15px;font-weight:500;line-height:1.6;overflow-wrap:anywhere}\n.chat-workspace .composer .input,#conversation-pane .composer .input{font-weight:500;font-size:14px}.composer .input::placeholder{font-weight:500}.composer .btn{font-weight:650}.chat-workspace .chat-empty h2{font-size:27px;font-weight:750}.chat-workspace .chat-empty p{font-size:14px;font-weight:500}\n.direct-heading .body h2{font-size:21px;font-weight:750;letter-spacing:-.4px}.direct-heading .body span{font-weight:500;font-size:13px}#conversation-pane .direct-heading{flex:0 0 auto}#conversation-pane>.chat-panel{min-height:0;overflow:hidden}#conversation-pane .composer{margin:10px 12px!important}\n@media(min-width:1500px){.messenger-layout{grid-template-columns:400px minmax(0,1fr)}.chat-workspace #group-body.group-conversation{grid-template-columns:minmax(0,1fr) 330px}.group-info{padding:20px!important}}\n@media(max-width:1100px){.chat-workspace #group-body.group-conversation{grid-template-columns:minmax(0,1fr)!important}.group-conversation>.group-info{display:none!important}.group-conversation>.composer{grid-column:1}.messenger-layout{grid-template-columns:290px minmax(0,1fr)}}\n@media(max-width:760px){.messenger-layout{display:flex}.shell>.main>.workspace-top{height:52px;min-height:52px;flex-basis:52px;padding:6px 10px}.chat-workspace .group-hero .body{display:block}.chat-workspace .group-hero h1{font-size:18px}.chat-workspace>#group-tabs button{font-size:10px}.chat-workspace #group-body.group-conversation{gap:7px}.group-conversation>.composer{padding:6px!important}.direct-heading .body h2{font-size:17px}.group-conversation .composer .row{flex-wrap:wrap}.chat-workspace .chat-empty h2{font-size:22px}}\n";document.head.appendChild(style)}})();

(() => {

'use strict';

if(window.__ECP_BOOT)window.__ECP_BOOT.started=true;

const U=window.EduUI;

const CFG=window.EDUCHAT_CONFIG||{};

let sb=null;

const S={user:null,profile:null,role:'student',permissions:new Set(),page:'groups',group:null,direct:null,channel:null,notificationChannel:null,activeTimer:null};

window.__ECP_STATE=S;

let qrLoginRun=0;

const PERMS=['groups.manage','members.manage','files.manage','meetings.create','forum.moderate','announcements.create','attendance.read'];

const isAdmin=()=>S.role==='super_admin'||S.role==='assistant_admin';

const isSuper=()=>S.role==='super_admin';

const can=p=>isSuper()||S.permissions.has(p);

const app=()=>U.q('#app');

const boot=()=>U.q('#boot');

function showApp(){if(window.__ECP_BOOT)window.__ECP_BOOT.ready=true;const b=document.getElementById('boot');const a=document.getElementById('app');b?.classList.add('hidden');a?.classList.remove('hidden')}

function failScreen(message,detail='') {
  if(window.__ECP_BOOT)window.__ECP_BOOT.ready=true;
  const esc=v=>String(v??'').replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
  document.getElementById('boot')?.classList.add('hidden');
  const a=document.getElementById('app');if(!a)return;a.classList.remove('hidden');
  a.innerHTML=`<div class="auth-panel" style="min-height:100vh"><div class="card card-pad" style="max-width:720px"><h1>Edu Chat Pro could not start</h1><p>${esc(message)}</p>${detail?`<pre class="diag">${esc(detail)}</pre>`:''}<p class="hint">Reload once after replacing all site files. If this message remains, check the failed asset shown above.</p><button class="btn primary" onclick="location.reload()">Retry</button></div></div>`;
}

function must(result,msg='Operation failed'){if(result.error)throw Object.assign(new Error(result.error.message||msg),{code:result.error.code});return result.data}

function pageHead(title,sub='',actions=''){return `<div class="page-head"><div><h1>${U.esc(title)}</h1>${sub?`<p>${U.esc(sub)}</p>`:''}</div><div class="spacer"></div>${actions}</div>`}

function initials(n){return String(n||'U').trim().charAt(0).toUpperCase()||'U'}

function profileMap(rows){return Object.fromEntries((rows||[]).map(x=>[x.id,x]))}

function lastSeenClock(value){if(!value)return'';const d=new Date(value);if(Number.isNaN(d.getTime()))return'';const old=Math.abs(Date.now()-d.getTime())>=86400000;return old?d.toLocaleString([],{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}):d.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'});}
function lastSeenAgo(value){if(!value)return'unknown';const ms=Math.max(0,Date.now()-new Date(value).getTime()),sec=Math.floor(ms/1000);if(sec<60)return'just now';const min=Math.floor(sec/60);if(min<60)return`${min} min ago`;const hr=Math.floor(min/60);if(hr<24)return`${hr} hr${hr===1?'':'s'} ago`;const day=Math.floor(hr/24);if(day<7)return`${day} day${day===1?'':'s'} ago`;return U.fmtDate(value);}
function presenceLabel(profile,role='student'){return window.EduPresence.label(profile)}

const avatarCache=new Map();

async function namesFor(ids){ids=[...new Set(ids.filter(Boolean))];if(!ids.length)return{};let result=await sb.rpc('ecp_presence_list',{targets:ids});if(result.error)result=await sb.rpc('get_profiles_presence',{targets:ids});if(result.error)result=await sb.from('profiles').select('id,full_name,avatar_path,last_active_at,last_seen_visible,public_id').in('id',ids);if(result.error)result=await sb.from('profiles').select('id,full_name,avatar_path').in('id',ids);if(result.error)return{};return profileMap(result.data)}

function avatarHtml(p,size=''){const name=p?.full_name||'User',path=p?.avatar_path||'';return `<span class="avatar ${U.attr(size)}" ${path?`data-avatar-path="${U.attr(path)}"`:''}>${U.esc(initials(name))}</span>`}

async function signedAvatar(path){return path?window.EduPhotos.get(sb,S.user.id,'avatars',path):null}



async function hydrateAvatars(root=document){await Promise.all(U.qa('[data-avatar-path]',root).map(async el=>{if(el.dataset.avatarLoaded==='1'||el.dataset.avatarPending==='1')return;el.dataset.avatarPending='1';try{const url=await signedAvatar(el.dataset.avatarPath);if(!url||!el.isConnected)return;const img=new Image();img.alt='Profile photo';img.decoding='async';img.onload=()=>{if(el.isConnected){el.textContent='';el.append(img);el.dataset.avatarLoaded='1'}el.dataset.avatarPending=''};img.onerror=()=>{el.dataset.avatarPending=''};img.src=url}catch{el.dataset.avatarPending=''}}))}



async function compressAvatar(file){if(!file.type.startsWith('image/'))throw new Error('Choose an image file.');if(file.size>10*1024*1024)throw new Error('Choose an image under 10 MB.');let source,width,height,cleanup=()=>{};if('createImageBitmap'in window){source=await createImageBitmap(file);width=source.width;height=source.height;cleanup=()=>source.close?.()}else{const url=URL.createObjectURL(file);source=await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(new Error('Could not read image.'));img.src=url});width=source.naturalWidth;height=source.naturalHeight;cleanup=()=>URL.revokeObjectURL(url)}const max=720,scale=Math.min(1,max/Math.max(width,height)),w=Math.max(1,Math.round(width*scale)),h=Math.max(1,Math.round(height*scale));const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;canvas.getContext('2d').drawImage(source,0,0,w,h);cleanup();const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('Could not process image.')),'image/jpeg',.82));if(blob.size>1024*1024)throw new Error('The processed photo is still too large. Choose a smaller image.');return blob}

function groupImage(g){return g.image_path?`<img data-group-photo="${U.attr(g.image_path)}" alt="Group photo" loading="lazy">`:U.icon('groups')}

async function hydrateGroupImages(root){await Promise.all(U.qa('[data-group-photo]',root).map(async img=>{if(img.src)return;try{const url=await window.EduPhotos.get(sb,S.user.id,'group-images',img.dataset.groupPhoto);if(img.isConnected){img.decoding='async';img.src=url}}catch{}}))}



async function has(p){if(isSuper())return true;if(S.role==='assistant_admin')return S.permissions.has(p);return false}

function cleanupChannel(){S.pageRefresh=null;S.alertsRefresh=null;S.meetingRefresh=null;if(S.channel){sb.removeChannel(S.channel).catch(()=>{});S.channel=null}}



async function init(){

  try{

    if(!U)throw new Error('utils.js did not load.');
    if(!CFG.SUPABASE_URL||!CFG.SUPABASE_PUBLISHABLE_KEY)throw new Error('Supabase URL/key are missing from config.js.');

    // Do not let a slow third-party CDN keep the splash screen visible forever.
    if(!window.supabase?.createClient){
      if(window.__ecpSupabaseReady)await U.timeout(window.__ecpSupabaseReady,5200,'Supabase library connection timed out.');
    }
    if(!window.supabase?.createClient)throw new Error('Supabase browser library did not load.');

    sb=window.supabase.createClient(CFG.SUPABASE_URL,CFG.SUPABASE_PUBLISHABLE_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});

    sb.auth.onAuthStateChange((event,session)=>setTimeout(()=>authChanged(event,session),0));

    // getSession is normally instant because it reads the local session. A hard
    // timeout prevents a browser/storage issue from trapping the user on splash.
    const {data,error}=await U.timeout(sb.auth.getSession(),2500,'Session check timed out.');window.eduCleanAddress?.();if(error)throw error;

    if(!data.session && U.routeInvite() && !window.EDU_ENTRY?.login){location.replace('guest.html?invite='+encodeURIComponent(U.routeInvite()));return;}

    if(data.session)await enter(data.session.user);else {renderAuth();showApp();}

  }catch(e){console.error(e);failScreen('Startup failed.',U.errorText(e));}

}

function recoveryPending(){try{return !!window.EDU_ENTRY?.recovery||sessionStorage.getItem('ecp-account-recovery')==='1'}catch{return !!window.EDU_ENTRY?.recovery}}
function clearRecoveryPending(){try{sessionStorage.removeItem('ecp-account-recovery')}catch{}if(window.EDU_ENTRY)window.EDU_ENTRY.recovery=false}

async function authChanged(event,session){

  if(session&&(event==='PASSWORD_RECOVERY'||recoveryPending())){renderPasswordRecovery();showApp();return}

  if(!session){leaveSession();if(!recoveryPending())clearRecoveryPending();renderAuth();showApp();return}

  if(!S.user||S.user.id!==session.user.id)await enter(session.user);

}

function leaveSession(){window.EduPresence.stop();window.EduWorkspace.dispose();stopDesignRail();window.EduPhotos.clear();mediaUrls.clear();document.querySelector('.permission-banner')?.remove();S.stopNotifications?.();S.stopNotifications=null;avatarCache.clear();document.querySelector('.incoming-call')?.remove();S.direct=null;cleanupChannel();if(S.notificationChannel){sb.removeChannel(S.notificationChannel).catch(()=>{});S.notificationChannel=null}clearInterval(S.activeTimer);Object.assign(S,{user:null,profile:null,role:'student',permissions:new Set(),group:null});}



function renderAuth(tab='login'){

  qrLoginRun++;

  if(window.EDU_ENTRY?.groupInvite)sessionStorage.setItem('ecp-group-invite',window.EDU_ENTRY.groupInvite);

  app().innerHTML=`<div class="auth-shell"><section class="auth-art"><img class="brand-mark" src="ecp-logo.png" alt="Edu Chat Pro"><h1>Learn, talk,<br>meet together.</h1><p>Edu Chat Pro brings WhatsApp-style group communication, files, public discussion and Google-Meet-inspired calls into one learning space.</p></section><section class="auth-panel"><div class="card auth-card"><div class="row" style="margin-bottom:18px"><img class="brand-mark auth-form-logo" src="ecp-logo.png?v=20260923-logo" alt="Edu Chat Pro logo" width="56" height="56"><div><strong style="font-size:20px">Edu Chat Pro</strong><div class="tiny muted">Educational communication</div></div></div><div class="auth-tabs"><button data-tab="login" class="${tab==='login'?'active':''}">Sign in</button><button data-tab="signup" class="${tab==='signup'?'active':''}">Create account</button></div><div id="auth-form"></div></div></section></div>`;

  U.qa('[data-tab]',app()).forEach(b=>b.onclick=()=>renderAuth(b.dataset.tab));

  const f=U.q('#auth-form',app());

  if(tab==='signup')f.innerHTML=`<form id="signup"><div class="field"><label>Full name</label><input class="input" name="name" maxlength="100" required></div><div class="field"><label>Email</label><input class="input" name="email" type="email" required></div><div class="field"><label>Password</label><input class="input" name="password" type="password" minlength="8" required></div><button class="btn primary" style="width:100%">Create account</button><p class="hint">A verification email may be sent depending on your Supabase Auth settings.</p></form>`;

  else f.innerHTML=`<form id="login"><div class="field"><label>Email</label><input class="input" name="email" type="email" autocomplete="email" required></div><div class="field"><label>Password</label><input class="input" name="password" type="password" autocomplete="current-password" required></div><button class="btn primary" style="width:100%">Sign in</button><button type="button" class="btn ghost" style="width:100%;margin-top:9px" id="forgot">Forgot password / User ID?</button><div class="auth-divider"><span>or</span></div><button type="button" class="btn qr-auth-link-btn" id="qr-auth-link"><span class="qr-icon">▦</span> Sign in with mobile QR</button><p class="hint" style="text-align:center;margin-bottom:0">Already signed in on the Edu Chat Pro mobile app? Scan the QR code to sign in here without typing your email or password.</p></form>`;

  U.q('#signup',f)?.addEventListener('submit',async e=>{e.preventDefault();const b=e.submitter;U.setBusy(b,true);try{const d=new FormData(e.target);const signupEmail=String(d.get('email')).trim().toLowerCase();const {data,error}=await sb.auth.signUp({email:signupEmail,password:d.get('password'),options:{data:{full_name:d.get('name')},emailRedirectTo:CFG.PUBLIC_WEB_URL||location.origin}});if(error)throw error;try{localStorage.setItem('ecp-onboarding-pending:'+signupEmail,'1')}catch{}U.toast(data.session?'Account created. Complete your profile setup next.':'Check your email to verify your account. Your profile setup will continue after sign-in.','ok');if(!data.session)renderAuth('login')}catch(x){U.toast(U.errorText(x),'error')}finally{U.setBusy(b,false)}});

  U.q('#login',f)?.addEventListener('submit',async e=>{e.preventDefault();const b=e.submitter;U.setBusy(b,true);try{clearRecoveryPending();const d=new FormData(e.target);const {error}=await sb.auth.signInWithPassword({email:String(d.get('email')).trim(),password:d.get('password')});if(error)throw error}catch(x){U.toast(U.errorText(x),'error')}finally{U.setBusy(b,false)}});

  U.q('#forgot',f)?.addEventListener('click',async()=>{const v=await U.promptBox({title:'Recover account',fields:[{label:'Account email',type:'email'}],submit:'Send recovery email'});if(!v)return;const email=String(v[0]||'').trim().toLowerCase();if(!email){U.toast('Enter the email used for this account.','error');return}try{const {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:CFG.PUBLIC_WEB_URL||location.origin});if(error)throw error;U.toast('If this email belongs to an account, a recovery email has been sent. Open that link to reset your password and view or change your User ID.','ok')}catch(e){U.toast(U.errorText(e),'error')}});

  U.q('#qr-auth-link',f)?.addEventListener('click',startQrWebLogin);

  const guestCode=U.routeInvite();if(guestCode){const guest=document.createElement('a');guest.className='btn primary';guest.style.marginTop='12px';guest.textContent='Join meeting as guest';guest.href='guest.html?invite='+encodeURIComponent(guestCode);f.appendChild(guest);}

}



let qrEndpoint='qr-auth-link';
let qrLibraryPromise=null;
function ensureQrLibrary(){
  if(window.QRCode)return Promise.resolve(window.QRCode);
  if(!qrLibraryPromise)qrLibraryPromise=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';script.async=true;script.onload=()=>window.QRCode?resolve(window.QRCode):reject(new Error('QR renderer did not load.'));script.onerror=()=>reject(new Error('QR renderer did not load.'));document.head.appendChild(script)}).catch(e=>{qrLibraryPromise=null;throw e});
  return qrLibraryPromise;
}

async function qrRequest(body){let result=await sb.functions.invoke(qrEndpoint,{body});if(result.error?.context?.status===404&&body.action==='create'){qrEndpoint='qr-login';result=await sb.functions.invoke(qrEndpoint,{body})}return result}

async function startQrWebLogin(){

  const button=U.q('#qr-auth-link'); if(button)U.setBusy(button,true,'Creating QR…');

  const run=++qrLoginRun;

  try{

    const qrReady=ensureQrLibrary().catch(()=>null);
    const created=await qrRequest({action:'create'});

    if(created.error)throw created.error;

    const d=created.data||{};

    if(!d.session_id||!d.secret)throw new Error('QR login service returned an incomplete response.');

    const payload=JSON.stringify({type:'educhat_web_login',version:1,session_id:d.session_id,secret:d.secret,origin:CFG.PUBLIC_WEB_URL||location.origin});

    const r=U.modal({title:'Sign in with your phone',body:`<div class="qr-auth-link-panel"><div id="qr-code" class="qr-code"></div><p><strong>On your phone:</strong> open Edu Chat Pro → Profile → Scan web login QR.</p><p class="hint">For your security this code expires in about 2 minutes and works only once.</p><div id="qr-status" class="qr-status">Waiting for scan…</div></div>`,actions:`<button class="btn ghost" data-close-qr>Cancel</button>`,closeOnBackdrop:false});

    U.q('[data-close-qr]',r).onclick=()=>{qrLoginRun++;U.closeModal()};

    const box=U.q('#qr-code',r);

    await qrReady;
    if(window.QRCode){new window.QRCode(box,{text:payload,width:224,height:224,colorDark:'#111827',colorLight:'#ffffff',correctLevel:window.QRCode.CorrectLevel.M});}
    else box.innerHTML='<div class="meet-error">QR renderer did not load. Check your internet/CDN access and try again.</div>';

    const status=U.q('#qr-status',r);

    const deadline=d.expires_at?new Date(d.expires_at).getTime():Date.now()+120000;

    while(run===qrLoginRun && Date.now()<deadline && !!U.q('#qr-status',r)){

      await U.sleep(1500);

      if(run!==qrLoginRun||!U.q('#qr-status',r))return;

      const polled=await qrRequest({action:'poll',session_id:d.session_id,secret:d.secret});

      if(polled.error){const msg=await (async()=>{try{return (await polled.error.context?.clone?.().json())?.error||U.errorText(polled.error)}catch{return U.errorText(polled.error)}})();if(/expired/i.test(msg)){status.textContent='QR code expired. Close this window and create a new one.';status.classList.add('error');return}status.textContent='Connection issue: '+msg+' — retrying…';continue;}

      if(polled.data?.status==='approved'&&polled.data?.token_hash){

        status.textContent='Approved on phone. Signing you in…';status.classList.add('ok');

        const verified=await sb.auth.verifyOtp({type:'magiclink',token_hash:polled.data.token_hash});

        if(verified.error)throw verified.error;

        qrRequest({action:'complete',session_id:d.session_id,secret:d.secret}).catch(()=>{});qrLoginRun++;U.closeModal();U.toast('Signed in from your mobile app.','ok');return;

      }

    }

    if(run===qrLoginRun&&status){status.textContent='QR code expired. Close this window and create a new one.';status.classList.add('error');}

  }catch(e){U.toast(`QR login: ${U.errorText(e)}`,'error')}

  finally{if(button&&document.body.contains(button))U.setBusy(button,false)}

}



async function renderPasswordRecovery(){
  app().innerHTML=`<div class="auth-panel" style="min-height:100vh"><div class="card auth-card"><h1>Recover your account</h1><p class="hint">Verifying your recovery link…</p></div></div>`;
  try{
    const userResult=await sb.auth.getUser(),user=userResult.data?.user;if(userResult.error||!user)throw userResult.error||new Error('Recovery session expired. Request a new recovery email.');window.eduCleanAddress?.();
    let profile=null;try{const r=await sb.rpc('my_profile');if(!r.error)profile=r.data}catch{}
    if(!profile)try{const r=await sb.from('profiles').select('public_id,full_name').eq('id',user.id).maybeSingle();if(!r.error)profile=r.data}catch{}
    const currentId=normalizePublicId(profile?.public_id||'');
    app().innerHTML=`<div class="auth-panel" style="min-height:100vh"><div class="card auth-card"><div class="row" style="margin-bottom:16px"><img class="brand-mark auth-form-logo" src="ecp-logo.png" alt="Edu Chat Pro logo" width="52" height="52"><div><h1 style="margin:0">Account recovery</h1><div class="tiny muted">Verified recovery session</div></div></div><p class="hint">You can set a new password and confirm or change your unique User ID. Your email is shown only so you can confirm which account you are recovering.</p><div class="field"><label>Account email</label><input class="input" value="${U.attr(user.email||'')}" readonly aria-readonly="true"></div><form id="recover"><div class="field"><label>User ID</label><div style="display:flex;align-items:center;gap:8px"><span class="code">@</span><input id="recover-public-id" class="input" name="public_id" maxlength="24" value="${U.attr(currentId)}" autocomplete="off" autocapitalize="none" spellcheck="false" required></div><p id="recover-id-status" class="hint">4–24 characters · starts with a letter · letters, numbers and _ only.</p></div><div class="field"><label>New password</label><input class="input" type="password" name="password" minlength="8" autocomplete="new-password" required></div><div class="field"><label>Confirm new password</label><input class="input" type="password" name="confirm_password" minlength="8" autocomplete="new-password" required></div><p id="recover-error" class="danger-text"></p><button class="btn primary" style="width:100%" id="recover-submit">Update User ID & password</button><button type="button" class="btn ghost" style="width:100%;margin-top:9px" id="recover-cancel">Cancel recovery</button></form></div></div>`;
    const input=U.q('#recover-public-id'),status=U.q('#recover-id-status'),form=U.q('#recover'),err=U.q('#recover-error');let availability=true,token=0;
    const checkId=U.debounce(async()=>{const run=++token,id=normalizePublicId(input.value);status.classList.remove('danger-text');if(!/^[a-z][a-z0-9_]{3,23}$/.test(id)){availability=false;status.textContent='Use 4–24 characters, start with a letter, and use only letters, numbers or _.';status.classList.add('danger-text');return}if(id===currentId){availability=true;status.textContent=currentId?'✓ This is your current User ID.':'✓ User ID format is valid.';return}const ok=await publicIdAvailable(id);if(run!==token)return;availability=ok;status.textContent=ok===null?'Availability will be checked when you save.':ok?'✓ Available':'Taken — choose another User ID.';status.classList.toggle('danger-text',ok===false)},220);input.oninput=checkId;checkId();
    U.q('#recover-cancel').onclick=async()=>{clearRecoveryPending();try{await sb.auth.signOut()}catch{}renderAuth('login');showApp()};
    form.onsubmit=async e=>{e.preventDefault();const b=U.q('#recover-submit');U.setBusy(b,true,'Updating…');err.textContent='';try{const d=new FormData(form),id=normalizePublicId(d.get('public_id')),password=String(d.get('password')||''),confirm=String(d.get('confirm_password')||'');if(!/^[a-z][a-z0-9_]{3,23}$/.test(id))throw new Error('Enter a valid User ID.');if(password.length<8)throw new Error('Password must be at least 8 characters.');if(password!==confirm)throw new Error('The two passwords do not match.');if(id!==currentId){const ok=await publicIdAvailable(id);if(ok===false)throw new Error('That User ID is already taken. Choose another one.');if(ok===null)throw new Error('Could not verify User ID availability. Check your connection and try again.')}const passwordResult=await sb.auth.updateUser({password});if(passwordResult.error)throw passwordResult.error;let idError=null;if(id!==currentId){const idResult=await sb.rpc('set_my_public_id',{new_id:id});if(idResult.error)idError=idResult.error}clearRecoveryPending();const refreshed=(await sb.auth.getUser()).data?.user;if(idError){U.toast('Password updated, but the User ID could not be changed: '+U.errorText(idError),'error')}else U.toast(`Account recovered. Password updated${id?` and User ID set to @${id}`:''}.`,'ok');if(refreshed)await enter(refreshed);else{renderAuth('login');showApp()}}catch(x){err.textContent=U.errorText(x)}finally{if(b?.isConnected)U.setBusy(b,false)}};
  }catch(x){clearRecoveryPending();app().innerHTML=`<div class="auth-panel" style="min-height:100vh"><div class="card auth-card"><h1>Recovery link unavailable</h1><p class="danger-text">${U.esc(U.errorText(x))}</p><button class="btn primary" id="recovery-back">Back to sign in</button></div></div>`;U.q('#recovery-back').onclick=()=>{renderAuth('login');showApp()}}
}



async function enter(user){

  S.user=user;

  try{

    // Identity data should never block the whole application indefinitely.
    // We allow a short network window, then continue with safe defaults and
    // refresh the identity in the background when the connection recovers.
    const fallbackProfile={
      full_name:user?.user_metadata?.full_name||user?.user_metadata?.name||user?.email?.split('@')[0]||'Student',
      avatar_path:user?.user_metadata?.avatar_path||''
    };
    let identityTimedOut=false;
    try{
      const [profileResult,role]=await U.timeout(Promise.all([
        sb.rpc('my_profile'),
        sb.from('user_roles').select('role').eq('user_id',user.id).maybeSingle()
      ]),2400,'Profile loading timed out.');
      S.profile=must(profileResult)||fallbackProfile;
      if(role.error)throw role.error;S.role=role.data?.role||'student';
    }catch(e){
      identityTimedOut=/timed out/i.test(U.errorText(e));
      if(!identityTimedOut)throw e;
      console.warn('Continuing with cached/default identity while profile loads:',e);
      S.profile=fallbackProfile;S.role='student';
    }

    S.permissions=new Set();
    if(S.role==='assistant_admin'){
      try{
        const permissionResult=await U.timeout(sb.from('assistant_admin_permissions').select('permission').eq('user_id',user.id),1800,'Permission loading timed out.');
        if(!permissionResult.error)(permissionResult.data||[]).forEach(x=>S.permissions.add(x.permission));
      }catch(e){console.warn('Permission loading delayed:',e)}
    }

    renderShell();showApp();setupNotifications().catch(e=>console.warn('Notification setup:',e));clearInterval(S.activeTimer);window.EduPresence.start(sb,S.user.id);setTimeout(()=>startWelcomeSetup().catch(e=>{console.warn('Welcome setup:',e);offerWebPermissions();ensurePublicUserId().catch(()=>{})}),420);

    // If profile loading was temporarily slow, refresh state after the UI is
    // already visible. This does not hold the user on the splash screen.
    if(identityTimedOut){
      Promise.all([sb.rpc('my_profile'),sb.from('user_roles').select('role').eq('user_id',user.id).maybeSingle()]).then(([p,r])=>{
        if(!S.user||S.user.id!==user.id)return;
        if(!p.error&&p.data)S.profile=p.data;
        if(!r.error&&r.data?.role)S.role=r.data.role;
      }).catch(()=>{});
    }

    const groupCode=window.EDU_ENTRY?.groupInvite||sessionStorage.getItem('ecp-group-invite');if(groupCode){navigate('groups').then(()=>acceptGroupInvite(groupCode)).catch(e=>U.toast(U.errorText(e),'error'));return;}

    const invite=U.routeInvite();if(invite){setTimeout(()=>joinByInvite(invite),200)}else {
      // Paint the shell immediately; page data can arrive a moment later.
      await navigate('forum').catch(e=>{console.error(e);U.toast(U.errorText(e),'error')});
      const notificationId=window.EDU_ENTRY?.notification||new URLSearchParams(location.search).get('notification');
      if(notificationId){
        sb.from('notifications').select('*').eq('id',notificationId).maybeSingle().then(async result=>{
          if(result.data)await openNotification(result.data);
          if(window.EDU_ENTRY)window.EDU_ENTRY.notification=null;window.eduCleanAddress?.();
        }).catch(()=>{});
      }
    }

  }catch(e){console.error(e);U.toast(U.errorText(e),'error');throw e}

}

async function touchActive(){if(!S.user)return;try{await sb.rpc('touch_active')}catch{}}

function normalizePublicId(value){return String(value||'').trim().toLowerCase().replace(/^@/,'').replace(/[^a-z0-9_]/g,'').slice(0,24)}
function suggestedPublicId(){let base=normalizePublicId((S.profile?.full_name||S.user?.email?.split('@')[0]||'user').replace(/\s+/g,'_'));if(!/^[a-z]/.test(base))base='user_'+base;if(base.length<4)base=(base+'user').slice(0,8);const tail=(S.user?.id||U.uuid()).replace(/-/g,'').slice(0,6);return (base.slice(0,Math.max(4,17-tail.length))+'_'+tail).slice(0,24)}
async function profileExtras(){let r=await sb.rpc('my_profile_extras');if(r.error)return null;const row=Array.isArray(r.data)?r.data[0]:r.data;return row||null}
async function publicIdAvailable(value){const id=normalizePublicId(value);if(!/^[a-z][a-z0-9_]{3,23}$/.test(id))return false;const r=await sb.rpc('public_id_available',{candidate:id});if(r.error)return null;return !!r.data}
async function savePublicId(value){const id=normalizePublicId(value);if(!/^[a-z][a-z0-9_]{3,23}$/.test(id))throw new Error('User ID must be 4–24 characters, start with a letter, and use only letters, numbers or _.');const r=await sb.rpc('set_my_public_id',{new_id:id});if(r.error)throw new Error(r.error.message||'Could not change User ID. Run the included FINAL database SQL once.');const saved=normalizePublicId(r.data||id);S.profile={...S.profile,public_id:saved,public_id_custom:true};return saved}
async function openPublicIdEditor(first=false){const current=S.profile?.public_id||suggestedPublicId();const r=U.modal({title:first?'Your unique User ID':'Change unique User ID',closeOnBackdrop:!first,body:`<p>${first?'A unique User ID has already been reserved for you. Keep it or choose another one.':'People can search for you by this unique ID.'}</p><label class="field">User ID<input id="public-id-edit" class="input" maxlength="24" value="${U.attr(current)}" autocomplete="off"></label><p class="hint">4–24 characters · start with a letter · letters, numbers and _ only.</p><p id="public-id-status" class="hint"></p><p id="public-id-error" class="danger-text"></p>`,actions:`${first?'<button class="btn ghost" id="keep-public-id">Keep default</button>':''}<button class="btn primary" id="save-public-id-edit">Save User ID</button>`});const input=U.q('#public-id-edit',r),status=U.q('#public-id-status',r),err=U.q('#public-id-error',r);let checkToken=0;const check=U.debounce(async()=>{const token=++checkToken,id=normalizePublicId(input.value);err.textContent='';if(!/^[a-z][a-z0-9_]{3,23}$/.test(id)){status.textContent='Use 4–24 valid characters.';return}if(id===normalizePublicId(S.profile?.public_id)){status.textContent='This is your current User ID.';return}const ok=await publicIdAvailable(id);if(token!==checkToken)return;status.textContent=ok===null?'Availability will be checked when you save.':ok?'✓ Available':'Taken — choose another User ID.';status.classList.toggle('danger-text',ok===false)},260);input.oninput=check;check();U.q('#keep-public-id',r)?.addEventListener('click',()=>{try{localStorage.setItem('ecp-user-id-suggestion:'+S.user.id,'1')}catch{}U.closeModal()});U.q('#save-public-id-edit',r).onclick=async()=>{const b=U.q('#save-public-id-edit',r);U.setBusy(b,true);err.textContent='';try{const id=await savePublicId(input.value);try{localStorage.setItem('ecp-user-id-suggestion:'+S.user.id,'1')}catch{}U.closeModal();U.toast(`User ID saved as @${id}.`,'ok');if(!first&&S.page==='profile')await navigate('profile')}catch(e){err.textContent=U.errorText(e)}finally{if(b.isConnected)U.setBusy(b,false)}}}
async function ensurePublicUserId(){if(!S.user)return;let extra=await profileExtras();if(!extra?.public_id){const r=await sb.rpc('ensure_my_public_id');if(!r.error)extra={...(extra||{}),public_id:r.data,public_id_custom:false}}if(extra)S.profile={...S.profile,...extra};if(!S.profile?.public_id)return;let shown=false;try{shown=localStorage.getItem('ecp-user-id-suggestion:'+S.user.id)==='1'}catch{}if(!shown&&!S.profile?.public_id_custom)setTimeout(()=>openPublicIdEditor(true),120)}


function onboardingDoneKey(){return 'ecp-onboarding-complete:'+(S.user?.id||'')}
function onboardingPendingKey(){return 'ecp-onboarding-pending:'+String(S.user?.email||'').trim().toLowerCase()}

async function onboardingState(){
  if(!S.user)return {needed:false};
  try{if(localStorage.getItem(onboardingDoneKey())==='1')return {needed:false,source:'local'}}catch{}
  const state=await sb.rpc('my_onboarding_state');
  if(!state.error){
    const row=Array.isArray(state.data)?state.data[0]:state.data;
    if(row){S.profile={...S.profile,...row};return {needed:!row.onboarding_completed_at,row,source:'database'}}
  }
  // Safe fallback before the optional onboarding SQL has been installed: only
  // accounts created through this browser's sign-up form are treated as new.
  let pending=false;try{pending=localStorage.getItem(onboardingPendingKey())==='1'}catch{}
  return {needed:pending,source:'browser'};
}

async function startWelcomeSetup(){
  if(!S.user)return;
  const state=await onboardingState();
  if(state.needed){await runNewUserOnboarding();return}
  offerWebPermissions();
  await ensurePublicUserId();
}

async function queryDevicePermission(name){
  try{if(!navigator.permissions?.query)return 'unknown';const r=await navigator.permissions.query({name});return r.state||'unknown'}catch{return 'unknown'}
}

async function finishNewUserOnboarding(){
  try{const r=await sb.rpc('complete_my_onboarding');if(r.error&&!['PGRST202','42883'].includes(r.error.code))console.warn('Could not persist onboarding state:',r.error)}catch(e){console.warn(e)}
  try{localStorage.setItem(onboardingDoneKey(),'1');localStorage.removeItem(onboardingPendingKey());localStorage.setItem('ecp-web-permissions-v1','onboarding')}catch{}
}

// Both first-login setup and existing account editing use the same verified save.
async function saveProfileAvatar(file){
 const userId=S.user?.id;if(!userId)throw new Error('Please sign in before changing your photo.');
 const blob=await window.EduCrop(file);if(!blob)return null;
 if(!blob.size)throw new Error('The cropped photo is empty. Please choose the photo again.');
 if(S.user?.id!==userId)throw new Error('Your session changed. Please sign in again.');
 const path=`${userId}/${U.uuid()}.jpg`,old=S.profile?.avatar_path||null;
 const upload=await sb.storage.from('avatars').upload(path,blob,{contentType:'image/jpeg',upsert:false,cacheControl:'31536000'});
 if(upload.error)throw new Error('Photo upload failed: '+U.errorText(upload.error));
 const result=await sb.from('profiles').update({avatar_path:path}).eq('id',userId).select('id,avatar_path').single();
 if(result.error||result.data?.avatar_path!==path){
  // Never remove a photo after an ambiguous network response if it may be saved.
  const check=await sb.from('profiles').select('id,avatar_path').eq('id',userId).maybeSingle();
  if(check.error||check.data?.avatar_path!==path){
   if(!check.error&&check.data)await sb.storage.from('avatars').remove([path]).catch(()=>{});
   throw new Error('The photo could not be saved to your profile: '+(result.error?U.errorText(result.error):'No profile row was updated.'));
  }
 }
 if(S.user?.id!==userId)return null;
 S.profile={...S.profile,avatar_path:path};avatarCache.clear();
 if(old&&old!==path)await sb.storage.from('avatars').remove([old]).catch(()=>{});
 return path;
}
async function onboardingUploadAvatar(file,preview){
 if(!file)return false;
 const path=await saveProfileAvatar(file);if(!path)return false;
 renderShell();
 if(preview){try{preview.src=await signedAvatar(path);preview.hidden=false}catch{}}
 return true;
}

async function runNewUserOnboarding(){
  if(!S.user)return;
  // Reserve a default unique ID first. The user can keep it or change it in step 2.
  try{let extra=await profileExtras();if(!extra?.public_id){const r=await sb.rpc('ensure_my_public_id');if(!r.error)extra={...(extra||{}),public_id:r.data,public_id_custom:false}}if(extra)S.profile={...S.profile,...extra}}catch(e){console.warn('Default User ID:',e)}

  const steps=['Profile photo','Username','Microphone','Camera','Notifications','Screen share','Ready'];
  let index=0,photoReady=!!S.profile?.avatar_path;
  const r=U.modal({title:'Welcome to Edu Chat Pro',closeOnBackdrop:false,wide:true,body:'<div id="onboarding-body"></div>',actions:'<div id="onboarding-actions" class="onboarding-actions"></div>'});
  r.classList.add('onboarding-modal');
  const body=U.q('#onboarding-body',r),actions=U.q('#onboarding-actions',r),title=U.q('h2',r);

  const progress=()=>`<div class="onboarding-progress" aria-label="Setup progress">${steps.map((x,i)=>`<span class="${i<index?'done':i===index?'active':''}" title="${U.attr(x)}">${i<index?'✓':i+1}</span>`).join('')}</div><div class="onboarding-step-label">Step ${index+1} of ${steps.length} · ${U.esc(steps[index])}</div>`;
  const go=n=>{index=Math.max(0,Math.min(steps.length-1,n));paint()};
  const nextButton=(label='Continue')=>`<button class="btn primary" id="onboard-next">${U.esc(label)}</button>`;
  const skipButton=(label='Not now')=>`<button class="btn ghost" id="onboard-skip">${U.esc(label)}</button>`;
  const statusLine=(id,text='')=>`<p class="onboarding-status" id="${id}" role="status">${U.esc(text)}</p>`;

  async function mediaPermission(kind){
    if(!navigator.mediaDevices?.getUserMedia)throw new Error('Camera/microphone access is not supported in this browser.');
    const constraints=kind==='camera'?{video:true,audio:false}:{audio:{echoCancellation:true,noiseSuppression:true},video:false};
    const stream=await navigator.mediaDevices.getUserMedia(constraints);stream.getTracks().forEach(t=>t.stop());return true;
  }

  async function paint(){
    if(!r.isConnected)return;
    title.textContent=index===steps.length-1?'Setup complete':'Set up your new account';
    actions.innerHTML='';

    if(index===0){
      let avatarUrl='';if(S.profile?.avatar_path)try{avatarUrl=await signedAvatar(S.profile.avatar_path)}catch{}
      body.innerHTML=progress()+`<div class="onboarding-center"><div class="onboarding-avatar"><img id="onboard-avatar-preview" ${avatarUrl?`src="${U.attr(avatarUrl)}"`:'hidden'} alt="Profile photo"><span id="onboard-avatar-fallback" ${avatarUrl?'hidden':''}>${U.esc(initials(S.profile?.full_name))}</span></div><h3>Add a profile photo</h3><p>People will recognize you in chats, groups, the forum and meetings.</p><label class="btn primary onboarding-file">Choose profile photo<input id="onboard-photo" type="file" accept="image/jpeg,image/png,image/webp" hidden></label>${statusLine('onboard-photo-status',photoReady?'Profile photo is already set.':'JPG, PNG or WebP · crop and adjust before saving.')}</div>`;
      actions.innerHTML=`${skipButton('Skip photo for now')}${nextButton(photoReady?'Continue':'Continue')}`;
      const input=U.q('#onboard-photo',r),status=U.q('#onboard-photo-status',r),preview=U.q('#onboard-avatar-preview',r),fallback=U.q('#onboard-avatar-fallback',r);
      input.onchange=async()=>{const file=input.files?.[0];if(!file)return;input.disabled=true;status.textContent='Preparing and saving your photo…';try{const saved=await onboardingUploadAvatar(file,preview);if(!saved){status.textContent='Photo selection cancelled. You can choose another photo.';return;}fallback.hidden=true;photoReady=true;status.textContent='✓ Profile photo saved.';status.classList.add('ok')}catch(e){status.textContent=U.errorText(e);status.classList.add('error')}finally{input.disabled=false;input.value=''}};
      U.q('#onboard-skip',r).onclick=()=>go(1);U.q('#onboard-next',r).onclick=()=>go(1);return;
    }

    if(index===1){
      const current=S.profile?.public_id||suggestedPublicId();
      body.innerHTML=progress()+`<div class="onboarding-copy"><h3>Choose your unique username</h3><p>Everyone has a different User ID. People can search and find you using this ID.</p><label class="field">Username / User ID<div class="onboarding-userid"><span>@</span><input id="onboard-userid" class="input" maxlength="24" value="${U.attr(current)}" autocomplete="off" autocapitalize="none" spellcheck="false"></div></label><p class="hint">4–24 characters · starts with a letter · letters, numbers and _ only.</p>${statusLine('onboard-userid-status','Checking availability…')}</div>`;
      actions.innerHTML=nextButton('Save username & continue');
      const input=U.q('#onboard-userid',r),status=U.q('#onboard-userid-status',r),save=U.q('#onboard-next',r);let token=0,available=null;
      const check=U.debounce(async()=>{const t=++token,id=normalizePublicId(input.value);status.classList.remove('ok','error');if(!/^[a-z][a-z0-9_]{3,23}$/.test(id)){available=false;status.textContent='Use 4–24 valid characters.';status.classList.add('error');return}if(id===normalizePublicId(S.profile?.public_id)){available=true;status.textContent='✓ This User ID is reserved for you.';status.classList.add('ok');return}const ok=await publicIdAvailable(id);if(t!==token)return;available=ok;status.textContent=ok===null?'Availability will be checked when you save.':ok?'✓ Available':'Taken — choose another username.';status.classList.toggle('ok',ok===true);status.classList.toggle('error',ok===false)},220);
      input.oninput=check;check();save.onclick=async()=>{U.setBusy(save,true);status.classList.remove('error');try{const id=normalizePublicId(input.value);if(available===false)throw new Error('This username is taken. Choose another one.');const saved=await savePublicId(id);S.profile={...S.profile,public_id:saved,public_id_custom:true};try{localStorage.setItem('ecp-user-id-suggestion:'+S.user.id,'1')}catch{}go(2)}catch(e){status.textContent=U.errorText(e);status.classList.add('error')}finally{if(save.isConnected)U.setBusy(save,false)}};return;
    }

    if(index===2||index===3){
      const kind=index===2?'microphone':'camera',label=index===2?'Microphone':'Camera',icon=index===2?'mic':'camera';
      const state=await queryDevicePermission(kind);
      body.innerHTML=progress()+`<div class="onboarding-permission"><div class="onboarding-permission-icon">${U.icon(icon)}</div><h3>Allow ${label.toLowerCase()} access</h3><p>${kind==='microphone'?'Needed for voice messages, voice calls and meetings.':'Needed when you turn on video in calls and meetings.'}</p><div class="permission-state ${state==='granted'?'granted':state==='denied'?'denied':''}" id="onboard-permission-state">${state==='granted'?'✓ Already allowed':state==='denied'?'Blocked in browser site settings':'Your browser will ask for permission after you press Allow.'}</div><button class="btn primary" id="onboard-allow">Allow ${label}</button>${statusLine('onboard-permission-status')}</div>`;
      actions.innerHTML=`${skipButton()}${nextButton(state==='granted'?'Continue':'Continue')}`;
      const stateEl=U.q('#onboard-permission-state',r),status=U.q('#onboard-permission-status',r),allow=U.q('#onboard-allow',r);
      if(state==='granted')allow.hidden=true;
      allow.onclick=async()=>{allow.disabled=true;status.textContent='Waiting for browser permission…';try{await mediaPermission(kind);stateEl.textContent='✓ Permission allowed';stateEl.className='permission-state granted';status.textContent=`${label} is ready.`;status.classList.add('ok');allow.hidden=true}catch(e){stateEl.textContent='Permission was not allowed';stateEl.className='permission-state denied';status.textContent=U.errorText(e)+' You can enable it later in browser site settings.';status.classList.add('error')}finally{allow.disabled=false}};
      U.q('#onboard-skip',r).onclick=()=>go(index+1);U.q('#onboard-next',r).onclick=()=>go(index+1);return;
    }

    if(index===4){
      const state=('Notification'in window)?Notification.permission:'unsupported';
      body.innerHTML=progress()+`<div class="onboarding-permission"><div class="onboarding-permission-icon">${U.icon('bell')}</div><h3>Turn on notifications</h3><p>Get messages, mentions, announcements and incoming-call alerts.</p><div class="permission-state ${state==='granted'?'granted':state==='denied'?'denied':''}" id="onboard-permission-state">${state==='granted'?'✓ Notifications already allowed':state==='denied'?'Blocked in browser site settings':state==='unsupported'?'Notifications are not supported in this browser':'Press Allow to open the browser permission request.'}</div><button class="btn primary" id="onboard-allow" ${state==='granted'||state==='unsupported'?'hidden':''}>Allow notifications</button>${statusLine('onboard-permission-status')}</div>`;
      actions.innerHTML=`${skipButton()}${nextButton()}`;
      const stateEl=U.q('#onboard-permission-state',r),status=U.q('#onboard-permission-status',r),allow=U.q('#onboard-allow',r);
      allow.onclick=async()=>{allow.disabled=true;status.textContent='Waiting for browser permission…';try{const mode=await window.EduPush.enable(sb,S.user.id);stateEl.textContent='✓ Notifications allowed';stateEl.className='permission-state granted';status.textContent=mode==='push'?'Background push notifications are ready.':'Notifications are ready while Edu Chat Pro is open.';status.classList.add('ok');allow.hidden=true}catch(e){stateEl.textContent='Notifications were not allowed';stateEl.className='permission-state denied';status.textContent=U.errorText(e);status.classList.add('error')}finally{allow.disabled=false}};
      U.q('#onboard-skip',r).onclick=()=>go(5);U.q('#onboard-next',r).onclick=()=>go(5);return;
    }

    if(index===5){
      const supported=!!(navigator.mediaDevices?.getDisplayMedia||navigator.getDisplayMedia);
      body.innerHTML=progress()+`<div class="onboarding-permission"><div class="onboarding-permission-icon">${U.icon('share')}</div><h3>Check screen sharing</h3><p>When you share later, the browser will let you choose <b>Entire Screen</b>, a <b>Window/App</b>, or a <b>Browser Tab</b>. For privacy, browsers ask for screen-share permission each time.</p><div class="permission-state ${supported?'':'denied'}" id="onboard-permission-state">${supported?'Press Test screen share to see the secure browser picker. The preview will stop immediately after the test.':'Screen sharing is not supported on this browser/device.'}</div><button class="btn primary" id="onboard-allow" ${supported?'':'hidden'}>Test screen share</button>${statusLine('onboard-permission-status')}</div>`;
      actions.innerHTML=`${skipButton('Skip test')}${nextButton('Finish setup')}`;
      const status=U.q('#onboard-permission-status',r),stateEl=U.q('#onboard-permission-state',r),allow=U.q('#onboard-allow',r);
      if(allow)allow.onclick=async()=>{allow.disabled=true;status.textContent='Choose a screen, window/app or tab in the browser picker…';try{const getDisplay=navigator.mediaDevices?.getDisplayMedia?.bind(navigator.mediaDevices)||navigator.getDisplayMedia?.bind(navigator);const stream=await getDisplay({video:true,audio:false});stream.getTracks().forEach(t=>t.stop());stateEl.textContent='✓ Screen-share picker works on this device';stateEl.className='permission-state granted';status.textContent='Screen sharing is ready. The browser will ask again whenever you actually share.';status.classList.add('ok')}catch(e){if(e.name==='NotAllowedError'||e.name==='AbortError'){status.textContent='Screen-share test was cancelled. You can allow it later during a meeting.'}else{status.textContent=U.errorText(e);status.classList.add('error')}}finally{allow.disabled=false}};
      U.q('#onboard-skip',r).onclick=()=>go(6);U.q('#onboard-next',r).onclick=()=>go(6);return;
    }

    body.innerHTML=progress()+`<div class="onboarding-center onboarding-finish"><div class="onboarding-done">✓</div><h3>Your account is ready</h3><p>Your profile, username and device permissions can be changed later from Profile or browser site settings.</p><div class="onboarding-summary"><span>${S.profile?.avatar_path?'✓':'○'} Profile photo</span><span>✓ @${U.esc(S.profile?.public_id||'user')}</span><span>✓ Permission setup reviewed</span></div></div>`;
    actions.innerHTML='<button class="btn primary" id="onboard-finish">Start using Edu Chat Pro</button>';
    U.q('#onboard-finish',r).onclick=async()=>{const b=U.q('#onboard-finish',r);U.setBusy(b,true);await finishNewUserOnboarding();U.closeModal();U.toast('Welcome to Edu Chat Pro.','ok')};
  }

  await paint();
}

function renderShell(){

  try{document.documentElement.dataset.theme=localStorage.getItem('ecp-theme')||'light'}catch{document.documentElement.dataset.theme='light'}

  const nav=[['forum','forum','Home'],['groups','groups','Chats'],['saved','file','Saved'],['meetings','meeting','Calls'],['notifications','bell','Alerts'],['profile','user','Profile']];if(isAdmin())nav.push(['admin','shield','Admin']);

  app().innerHTML=`<div class="shell"><nav class="icon-rail" aria-label="Quick navigation"><button class="rail-logo" id="rail-expand-logo" title="Expand sidebar" aria-label="Expand sidebar" aria-controls="site-sidebar" aria-expanded="false"><img src="ecp-logo.png" alt="Edu Chat Pro"></button><div class="rail-links"><button class="rail-button" id="rail-home" data-nav="forum" title="Forum" aria-label="Forum"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 10 12 3l9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z" fill="currentColor" stroke="none"/></svg></button>${[['groups','groups','Groups'],['people','chat','Personal chats'],['meetings','meeting','Calls and meetings'],['notifications','bell','Notifications'],['profile','user','Profile']].map(n=>`<button class="rail-button" data-nav="${n[0]}" title="${n[2]}" aria-label="${n[2]}">${U.icon(n[1])}</button>`).join('')}<button class="rail-button" id="rail-more" title="Expand sidebar" aria-label="Expand sidebar" aria-controls="site-sidebar" aria-expanded="false"><span aria-hidden="true">•••</span></button></div></nav><aside class="sidebar" id="site-sidebar" inert aria-label="Main navigation"><button id="drawer-close" class="btn drawer-close" aria-label="Close navigation">×</button><div class="brand"><img class="brand-mark" src="ecp-logo.png" alt="Edu Chat Pro"><div><div>Edu Chat Pro</div><div class="tiny muted">Connect • Learn • Meet</div></div></div><nav class="nav">${nav.map(n=>`<button data-nav="${n[0]}">${U.icon(n[1])}<span>${n[2]}</span></button>`).join('')}</nav><div class="sidebar-bottom card"><div class="row">${avatarHtml(S.profile)}<div class="sidebar-user"><strong>${U.esc(S.profile?.full_name||'Student')}</strong><div class="tiny muted">${U.esc(S.role.replaceAll('_',' '))}</div></div></div><button class="btn ghost" id="theme-toggle" style="width:100%">☾ Light / Dark mode</button><button id="logout" class="btn ghost" style="width:100%;margin-top:12px">${U.icon('logout')} Sign out</button></div></aside><button class="drawer-backdrop" aria-label="Close navigation" tabindex="-1" hidden></button><main class="main"><header class="workspace-top"><button class="btn icon-btn" id="sidebar-toggle" aria-label="Open navigation" aria-controls="site-sidebar" aria-expanded="false">☰</button><img class="workspace-logo" src="ecp-logo.png" alt="Edu Chat Pro"><button class="workspace-title workspace-breadcrumb" id="workspace-title" type="button" title="Back to groups">Edu Chat Pro</button><form id="inbox-search-form" class="inbox-search" hidden><span aria-hidden="true">⌕</span><input id="inbox-search" type="search" placeholder="Search in this group…" aria-label="Search messages" maxlength="160" autocomplete="off"><button class="text-btn" aria-label="Submit search">Search</button></form><div class="spacer"></div><button class="btn icon-btn" id="header-alerts" aria-label="Notifications">${U.icon('bell')}</button><button class="btn icon-btn" id="theme-mobile-toggle" aria-label="Toggle dark mode">☾</button></header><div id="page" class="content"></div></main><nav class="mobile-nav">${nav.slice(0,5).map(n=>`<button data-nav="${n[0]==='groups'?'chats':n[0]}">${U.icon(n[1])}<span>${n[2]}</span></button>`).join('')}</nav></div>`;

  U.qa('[data-nav]',app()).forEach(b=>b.onclick=()=>{setDrawer(false);const mobileChat=matchMedia('(max-width:800px)').matches&&b.dataset.nav==='groups';navigate(mobileChat?'chats':b.dataset.nav)});U.q('#rail-expand-logo').onclick=()=>setDrawer(true);U.q('#rail-more').onclick=()=>setDrawer(true);U.q('#rail-home').onclick=()=>{setDrawer(false);navigate('forum')};U.q('#sidebar-toggle').onclick=()=>setDrawer(!U.q('.shell').classList.contains('drawer-open'));U.q('.drawer-backdrop').onclick=()=>setDrawer(false);U.q('#drawer-close').onclick=()=>setDrawer(false);U.q('#workspace-title').onclick=()=>navigate(matchMedia('(max-width:800px)').matches?'chats':'groups');U.q('#header-alerts').onclick=()=>navigate('notifications');U.q('#inbox-search-form').onsubmit=e=>{e.preventDefault();searchInbox()};U.q('#theme-toggle').onclick=toggleTheme;U.q('#theme-mobile-toggle').onclick=toggleTheme;U.q('#logout').onclick=async()=>{try{await window.EduPush.unregister(sb,S.user.id);await sb.auth.signOut({scope:'local'})}catch(e){U.toast(U.errorText(e),'error')}};hydrateAvatars(app());

}

function setDrawer(open){const shell=U.q('.shell'),side=U.q('#site-sidebar');if(!shell||!side)return;shell.classList.toggle('drawer-open',open);side.inert=!open;U.q('.main').inert=open;U.q('.icon-rail').inert=open;U.q('#rail-more').setAttribute('aria-expanded',String(open));U.q('#rail-expand-logo').setAttribute('aria-expanded',String(open));U.q('.drawer-backdrop').hidden=!open;U.q('#sidebar-toggle').setAttribute('aria-expanded',String(open));if(open)side.querySelector('button')?.focus();else U.q('#sidebar-toggle').focus()}

document.addEventListener('keydown',e=>{if(e.key==='Escape'&&U.q('.drawer-open'))setDrawer(false)});

function chatLayout(kind=''){if(!kind){stopDesignRail();U.q('#page')?.classList.remove('messenger-page');}const box=U.q('#page');if(!box)return;box.classList.toggle('chat-workspace',!!kind);box.classList.toggle('direct-workspace',kind==='direct');const search=U.q('#inbox-search-form');if(search)search.hidden=!kind;const input=U.q('#inbox-search');if(input){input.value='';input.placeholder=kind==='direct'?'Search this conversation…':'Search in this group…'}const title=U.q('#workspace-title');if(title)title.textContent=kind==='group'?'Groups › '+(S.group?.name||'Chat'):kind==='direct'?'Inbox':'Edu Chat Pro'}

async function searchInbox(){

 const query=U.q('#inbox-search').value.trim(),group=S.group?.id,other=S.direct;if(!query||(!group&&!other))return;

 const r=U.modal({title:'Search messages',wide:true,body:'<div id="search-results" class="stack"></div>',actions:'<button class="btn ghost" data-close>Close</button><button class="btn" id="search-more">Load more</button>'});const results=U.q('#search-results',r),more=U.q('#search-more',r);let offset=0;

 async function load(){U.setBusy(more,true);try{let request=sb.from(group?'group_messages':'direct_messages').select('id,body,sender_id,created_at').ilike('body','%'+query.replace(/[\\%_]/g,c=>'\\'+c)+'%').order('created_at',{ascending:false}).order('id').range(offset,offset+29);if(group)request=request.eq('group_id',group);else request=request.or(`and(sender_id.eq.${S.user.id},recipient_id.eq.${other}),and(sender_id.eq.${other},recipient_id.eq.${S.user.id})`);const rows=must(await request)||[],names=await namesFor(rows.map(m=>m.sender_id));if(!results.isConnected)return;results.insertAdjacentHTML('beforeend',rows.map(m=>`<article class="search-hit"><strong>${U.esc(names[m.sender_id]?.full_name||'Member')}</strong><span class="tiny muted"> · ${U.fmtDate(m.created_at)}</span><p class="bodytext">${U.esc(m.body)}</p></article>`).join(''));if(!offset&&!rows.length)results.textContent='No messages match your search.';offset+=rows.length;more.hidden=rows.length<30}catch(e){U.toast(U.errorText(e),'error')}finally{U.setBusy(more,false)}}more.onclick=load;await load();

}

function toggleTheme(){const theme=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=theme;document.body.classList.toggle('ws-dark',theme==='dark');(()=>{try{localStorage.setItem('ecp-theme',theme);localStorage.setItem('educhat-theme',theme)}catch{}})()}

function workspaceContext(){return {sb,S,U,can,isAdmin,isSuper,presenceLabel,navigate,openMeeting,namesFor,openNotification,enableAlerts:enableWebAlerts,uploadForumMedia,linkGroupInvites,shareGroupInvite,
 sendAttachment:async(item,file,body)=>{if(item.kind==='group')await sendGroupAttachment(item,file,file.durationMs||0,body);else await sendDirectAttachment(item.peer_id,file,file.durationMs||0,body);},
 hydrateAttachments:async(rows)=>{const ids=rows.filter(m=>m.file_id&&!m.attachment_path).map(m=>m.file_id);if(!ids.length)return rows;const files=must(await sb.from('group_files').select('*').in('id',ids));return rows.map(m=>{const f=files.find(f=>f.id===m.file_id);return f?{...m,attachment_path:f.object_path,file_name:f.name,mime_type:f.mime_type}:m;});},
 startCall:async(item,audio)=>{if(item.kind==='group'&&item.allow_member_calls===false&&!isAdmin())throw new Error('Group calling is disabled for members.');S.group=item.kind==='group'?item:null;S.direct=item.kind==='direct'?item.peer_id:null;let m;if(item.kind==='direct'){const id=must(await sb.rpc('start_direct_call',{target:item.peer_id,video:!audio}));m=must(await sb.from('meetings').select('*').eq('id',id).single());}else{m=must(await sb.from('meetings').insert({title:(audio?'Audio: ':'Video: ')+item.name,group_id:item.id,host_id:S.user.id}).select().single());}await openMeeting(m,{autoJoin:true,video:!audio});},
 groupPanel:async(g,tab)=>{S.group=g;if(tab==='files')await groupFiles(g);else if(tab==='members')await groupMembers(g);else if(tab==='meetings')await renderMeetings(g);else if(tab==='drive')await groupDrive(g);else await groupSettings(g);}};}
async function navigate(p){const nav=window.__ECP_NAV||(window.__ECP_NAV={stack:[],ready:false,suppress:false});const current=S.page;if(nav.ready&&!nav.suppress&&current&&current!==p){nav.stack.push(current);if(nav.stack.length>30)nav.stack.shift();}nav.suppress=false;nav.ready=true;window.EduWorkspace.dispose();chatLayout();cleanupChannel();S.page=p;S.group=null;S.direct=null;const box=U.q('#page',app());box.className='content';box.dataset.page=p;U.qa('[data-nav]',app()).forEach(x=>x.classList.toggle('active',x.dataset.nav===p));box.innerHTML='<div class="loading">Loading…</div>';try{const c=workspaceContext();if(p==='groups'||p==='people'||p==='chats')await window.EduWorkspace.chat(c,p==='groups'?'groups':p==='people'?'direct':'all');else if(p==='forum')await window.EduWorkspace.forum(c);else if(p==='saved')await window.EduWorkspace.saved(c);else if(p==='meetings')await renderMeetings();else if(p==='notifications')await window.EduWorkspace.notifications(c);else if(p==='profile')await renderProfile();else if(p==='admin'&&isAdmin())await renderAdmin();else await window.EduWorkspace.chat(c,'all');}catch(e){box.innerHTML=`${pageHead('Could not open this page')}<div class="card card-pad"><p class="danger-text">${U.esc(U.errorText(e))}</p><p>If this mentions a missing database function or column, apply the included REVISION4_DATABASE_UPDATE.sql once.</p><button class="btn" onclick="location.reload()">Reload</button></div>`;console.error(e)}}


async function legacyRenderGroups(){

  chatLayout();

  S.direct=null;

  const box=U.q('#page');const actions='<button class="btn ghost" id="private-chats">'+U.icon('chat')+' Private chats</button>'+(can('groups.manage')?'<button class="btn primary" id="new-group">+ New group</button>':'');box.innerHTML=pageHead('Groups','Your classes, files and group conversations.',actions)+'<div id="group-list" class="grid"></div>';

  U.q('#private-chats').onclick=renderPeople;

  if(can('groups.manage'))U.q('#new-group').onclick=async()=>{const v=await U.promptBox({title:'Create group',fields:[{label:'Group name',max:120},{label:'Description',type:'textarea',required:false,max:2000}],submit:'Create'});if(!v)return;try{const {data,error}=await sb.from('groups').insert({name:v[0],description:v[1],created_by:S.user.id}).select().single();if(error)throw error;U.toast('Group created.','ok');await openGroup(data.id)}catch(e){U.toast(U.errorText(e),'error')}};

  const {data,error}=await sb.from('groups').select('*').order('created_at',{ascending:false});if(error)throw error;

  const list=U.q('#group-list');if(!data?.length){list.innerHTML='<div class="card empty"><div class="big">🏫</div>No groups yet.</div>';return}

  list.innerHTML=data.map(g=>`<button class="card group-card" data-group="${g.id}"><div class="group-cover">${groupImage(g)}</div><div class="card-pad" style="text-align:left"><h3>${U.esc(g.name)}</h3><p>${U.esc(g.description||'No description')}</p><span class="badge ${g.allow_member_messaging?'green':'red'}">Member chat ${g.allow_member_messaging?'on':'off'}</span></div></button>`).join('');

  hydrateGroupImages(list);U.qa('[data-group]',list).forEach(b=>b.onclick=()=>openGroup(b.dataset.group));

}

async function oldOpenGroup(id,tab='chat'){stopDesignRail();U.q('#page')?.classList.remove('messenger-page');

  S.direct=null;

  cleanupChannel();const {data:g,error}=await sb.from('groups').select('*').eq('id',id).single();if(error)throw error;S.group=g;chatLayout(tab==='chat'?'group':'');

  const box=U.q('#page');box.innerHTML=`<button class="btn ghost small" id="back-groups">← Groups</button><div class="group-hero"><div class="group-hero-icon">${groupImage(g)}</div><div class="body"><h1>${U.esc(g.name)}</h1><p>${U.esc(g.description||'Group workspace')}</p><span class="muted" id="group-member-count">Private group</span></div><div class="spacer"></div>${can('groups.manage')||g.created_by===S.user.id?'<button class="btn ghost" id="edit-group">'+U.icon('edit')+' Edit group</button>':''}</div><div class="tabs" id="group-tabs">${[['chat','Chat'],['files','Files'],['members','Members'],['meetings','Meetings'],['drive','Google Drive'],['settings','Settings']].map(x=>`<button data-gtab="${x[0]}" class="${tab===x[0]?'active':''}">${U.icon(({chat:'chat',files:'file',members:'groups',meetings:'meeting',drive:'cloud',settings:'settings'})[x[0]])} ${x[1]}</button>`).join('')}</div><div id="group-body"></div>`;

  sb.from('group_members').select('user_id',{count:'exact',head:true}).eq('group_id',id).then(({count,error})=>{const label=U.q('#group-member-count');if(!error&&label&&S.group?.id===id)label.textContent=`${count} members · Private group`});

  hydrateGroupImages(box);if(can('groups.manage')||g.created_by===S.user.id){const photo=U.q('.group-hero-icon',box);photo.setAttribute('role','button');photo.tabIndex=0;photo.title='Change group photo';photo.onclick=()=>changeWebGroupPhoto(g,tab);photo.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();changeWebGroupPhoto(g,tab)}}}U.q('#back-groups').onclick=()=>navigate(matchMedia('(max-width:800px)').matches?'chats':'groups');U.qa('[data-gtab]').forEach(b=>b.onclick=()=>openGroup(id,b.dataset.gtab));

  U.q('#edit-group')?.addEventListener('click',async()=>{const v=await U.promptBox({title:'Edit group',fields:[{label:'Name',value:g.name,max:120},{label:'Description',type:'textarea',value:g.description,required:false,max:2000}],submit:'Save'});if(!v)return;try{const {error}=await sb.from('groups').update({name:v[0],description:v[1]}).eq('id',g.id);if(error)throw error;U.toast('Group updated.','ok');openGroup(id,tab)}catch(e){U.toast(U.errorText(e),'error')}});

  if(tab==='chat')await groupChat(g);else if(tab==='files')await groupFiles(g);else if(tab==='members')await groupMembers(g);else if(tab==='meetings')await renderMeetings(g);else if(tab==='drive')await groupDrive(g);else await groupSettings(g);

}

async function groupChat(g){

  let messageLimit=30,groupLoadGeneration=0,groupSignature='';

  const body=U.q('#group-body');body.innerHTML=`<div class="card card-pad chat-panel"><button type="button" class="btn ghost small" id="older-messages">Load older messages</button><div id="chat-log" class="chat-log"></div><form id="chat-form" class="composer" style="margin-top:12px"><div class="row"><button type="button" class="btn attach-button" id="chat-attach" aria-label="Attach a file">+</button><input type="file" id="chat-file" hidden><input id="chat-input" class="input" maxlength="4000" placeholder="Write to this group…" ${!g.allow_member_messaging&&!isAdmin()?'disabled':''}><button type="button" class="btn ghost emoji-toggle" id="chat-emoji" aria-label="Choose emoji">☺</button><button class="btn primary" ${!g.allow_member_messaging&&!isAdmin()?'disabled':''}>${U.icon('send')} Send</button>${(can('announcements.create')||g.created_by===S.user.id)?'<button type="button" class="btn ghost" id="announce">Announcement</button>':''}</div></form>${!g.allow_member_messaging&&!isAdmin()?'<p class="hint">Group messaging is currently closed by an administrator.</p>':''}</div>`;

  const load=async()=>{const generation=++groupLoadGeneration;const {data,error}=await sb.from('group_messages').select('*,group_files(*)').eq('group_id',g.id).order('created_at',{ascending:false}).limit(messageLimit);if(error)throw error;const rows=(data||[]).reverse(),names=await namesFor(rows.map(x=>x.sender_id));const log=U.q('#chat-log');if(generation!==groupLoadGeneration||!log||S.group?.id!==g.id)return;const signature=JSON.stringify([rows,names]);if(signature===groupSignature){hydrateChatReactions(log,'group');return}groupSignature=signature;const oldHeight=log.scrollHeight,oldTop=log.scrollTop,atBottom=oldHeight-oldTop-log.clientHeight<100;syncMessages(log,rows.length?rows.map(m=>{const mine=m.sender_id===S.user.id,p=names[m.sender_id]||{full_name:mine?(S.profile?.full_name||'You'):'Member'};return `<div data-message-id="${m.id}" data-created="${m.created_at}" data-stamp="${U.attr(JSON.stringify([m,p]))}" class="message-row ${mine?'mine':''}">${avatarHtml(p)}<div class="message ${mine?'mine':''}"><div class="meta">${messageMeta(p.full_name||'Member',m.created_at,mine)} ${m.is_announcement?'• Announcement':''}</div><div>${U.esc(m.body)}</div>${m.group_files?`<button class="btn attachment" data-attachment="${U.attr(m.group_files.object_path)}" data-mime="${U.attr(m.group_files.mime_type)}">📎 ${U.esc(m.group_files.name)}</button>${mine||can('files.manage')||g.created_by===S.user.id?`<button class="text-btn danger-text" data-remove-attachment="${m.group_files.id}" data-path="${U.attr(m.group_files.object_path)}">Remove file</button>`:''}`:''}${(mine||can('groups.manage'))?`<button class="text-btn danger-text" data-del-msg="${m.id}">Delete</button>`:''}</div></div>`}).join(''):'<div class="empty chat-empty"><div class="chat-art">•••</div><h2>No messages yet</h2><p>Be the first to start the conversation in this group!</p><div class="chat-prompts"><span>💡 Share ideas</span><span>❔ Ask questions</span><span>♧ Learn together</span></div></div>');const older=U.q('#older-messages');if(older)older.hidden=rows.length<messageLimit;await hydrateAvatars(log);

    U.qa('[data-attachment]',log).forEach(b=>{const wrap=document.createElement('div');wrap.innerHTML=mediaMarkup('group-files',b.dataset.attachment,b.dataset.mime||'',b.textContent);b.replaceWith(wrap)});await hydrateMedia(log);linkGroupInvites(log);addDayMarkers(log);hydrateChatReactions(log,S.group?'group':'direct');

    U.qa('[data-remove-attachment]',log).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Remove attachment','Delete this file from the group?','Delete'))return;try{must(await sb.storage.from('group-files').remove([b.dataset.path]));must(await sb.from('group_files').delete().eq('id',b.dataset.removeAttachment));await load()}catch(e){U.toast(U.errorText(e),'error')}});

    log.scrollTop=atBottom?log.scrollHeight:oldTop+(log.scrollHeight-oldHeight);U.qa('[data-del-msg]',log).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Delete message','Delete this message?','Delete'))return;const {error}=await sb.from('group_messages').delete().eq('id',b.dataset.delMsg);if(error)U.toast(U.errorText(error),'error');else load()})};

  await load();

  U.q('#older-messages').onclick=async()=>{messageLimit+=30;try{await load()}catch(e){U.toast(U.errorText(e),'error')}};

  U.q('#chat-emoji').onclick=()=>{const r=U.modal({title:'Choose emoji',body:['😊','👍','❤️','🎉','📚','✅','👋','😂'].map(x=>`<button class="btn emoji-choice">${x}</button>`).join('')});U.qa('.emoji-choice',r).forEach(b=>b.onclick=()=>{U.q('#chat-input').value+=b.textContent;U.closeModal();U.q('#chat-input').focus()})};

  U.q('#chat-attach').onclick=()=>U.q('#chat-file').click();

  U.q('#chat-attach').disabled=!g.allow_member_messaging&&!isAdmin();

  U.q('#chat-file').onchange=async e=>{const file=e.target.files?.[0];if(!file)return;const b=U.q('#chat-attach');b.disabled=true;try{await sendGroupAttachment(g,file);await load()}catch(err){U.toast(U.errorText(err),'error')}finally{b.disabled=false;e.target.value=''}};

  U.q('#chat-form').onsubmit=async e=>{e.preventDefault();const i=U.q('#chat-input'),v=i.value.trim();if(!v)return;const {error}=await sb.from('group_messages').insert({group_id:g.id,sender_id:S.user.id,body:v,is_announcement:false});if(error)U.toast(U.errorText(error),'error');else{i.value='';load()}};

  U.q('#announce')?.addEventListener('click',async()=>{const v=await U.promptBox({title:'Post announcement',fields:[{label:'Announcement',type:'textarea',max:4000}],submit:'Post'});if(!v)return;const {error}=await sb.from('group_messages').insert({group_id:g.id,sender_id:S.user.id,body:v[0],is_announcement:true});if(error)U.toast(U.errorText(error),'error');else load()});

  installGroupInfo(g).catch(()=>{});S.pageRefresh=load;installVoice(U.q('#chat-form'),async(file,duration)=>{await sendGroupAttachment(g,file,duration);await load()});

  S.channel=sb.channel(`group-chat-${g.id}`).on('postgres_changes',{event:'*',schema:'public',table:'group_messages',filter:`group_id=eq.${g.id}`},()=>load()).on('postgres_changes',{event:'*',schema:'public',table:'message_reactions'},()=>{const log=U.q('#chat-log');if(log)hydrateChatReactions(log,'group')}).on('postgres_changes',{event:'*',schema:'public',table:'group_files',filter:`group_id=eq.${g.id}`},()=>{load().catch(()=>{});installGroupInfo(g).catch(()=>{})}).on('postgres_changes',{event:'*',schema:'public',table:'group_members',filter:`group_id=eq.${g.id}`},()=>installGroupInfo(g).catch(()=>{})).subscribe();

}

async function groupFiles(g){

  const body=U.q('#group-body');const allow=isAdmin()||g.allow_member_messaging;body.innerHTML=`<div class="card card-pad"><div class="row wrap"><div><h3 style="margin:0">Group files</h3><div class="hint">PDF, Office, images and ZIP • up to 10 MB each</div></div><div class="spacer"></div>${allow?'<label class="btn primary">Upload file<input id="file-pick" type="file" hidden></label>':''}${can('files.manage')?'<button class="btn danger" id="delete-all-files">Delete all</button>':''}</div><div id="files-list" class="list" style="margin-top:16px"></div></div>`;

  const load=async()=>{const {data,error}=await sb.from('group_files').select('*').eq('group_id',g.id).order('created_at',{ascending:false});if(error)throw error;const names=await namesFor((data||[]).map(x=>x.uploaded_by));const list=U.q('#files-list');list.innerHTML=data?.length?data.map(f=>`<div class="list-item"><div class="avatar">📄</div><div class="body"><h3>${U.esc(f.name)}</h3><p>${U.fmtBytes(f.size_bytes)} • ${U.esc(names[f.uploaded_by]?.full_name||'Member')} • ${U.fmtDate(f.created_at)}</p></div><button class="btn small" data-open-file="${f.id}">Open</button>${can('files.manage')||f.uploaded_by===S.user.id||g.created_by===S.user.id?`<button class="btn danger small" data-del-file="${f.id}">Delete</button>`:''}</div>`).join(''):'<div class="empty">No files uploaded.</div>';U.qa('[data-open-file]',list).forEach(b=>b.onclick=async()=>{const f=data.find(x=>x.id===b.dataset.openFile);const {data:s,error}=await sb.storage.from('group-files').createSignedUrl(f.object_path,300);if(error)U.toast(U.errorText(error),'error');else (()=>{const a=document.createElement('a');a.href=s.signedUrl;a.target='_blank';a.rel='noopener';a.click()})()});U.qa('[data-del-file]',list).forEach(b=>b.onclick=()=>deleteFile(data.find(x=>x.id===b.dataset.delFile),load))};

  async function deleteFile(f,after){if(!await U.confirmBox('Delete file',`Delete ${f.name}?`,'Delete'))return;try{must(await sb.storage.from('group-files').remove([f.object_path]));must(await sb.from('group_files').delete().eq('id',f.id));U.toast('File deleted.','ok');after()}catch(e){U.toast(U.errorText(e),'error')}}

  await load();

  U.q('#file-pick')?.addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;if(f.size>10485760){U.toast('File must be 10 MB or smaller.','error');return}const allowed=['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','image/jpeg','image/png','image/webp','application/zip'];if(!allowed.includes(f.type)){U.toast('This file type is not allowed.','error');return}const path=`${g.id}/${Date.now()}-${U.uuid()}-${U.safeName(f.name)}`;try{const up=await sb.storage.from('group-files').upload(path,f,{contentType:f.type,upsert:false});if(up.error)throw up.error;const meta=await sb.from('group_files').insert({group_id:g.id,uploaded_by:S.user.id,name:U.safeName(f.name),object_path:path,size_bytes:f.size,mime_type:f.type});if(meta.error){await sb.storage.from('group-files').remove([path]);throw meta.error}U.toast('File uploaded.','ok');load()}catch(x){U.toast(U.errorText(x),'error')}finally{e.target.value=''}});

  U.q('#delete-all-files')?.addEventListener('click',async()=>{if(!await U.confirmBox('Delete all group files','This removes every file in this group. This cannot be undone.','Delete all'))return;const {data}=await sb.from('group_files').select('id,object_path').eq('group_id',g.id);if(!data?.length)return;const rm=await sb.storage.from('group-files').remove(data.map(x=>x.object_path));if(rm.error){U.toast(U.errorText(rm.error),'error');return}const del=await sb.from('group_files').delete().eq('group_id',g.id);if(del.error)U.toast(U.errorText(del.error),'error');else{U.toast('All group files deleted.','ok');load()}});

}

async function groupMembers(g){

  const body=U.q('#group-body');body.innerHTML=`<div class="card card-pad"><div class="row wrap"><h3 style="margin:0">Members</h3><div class="spacer"></div>${(can('members.manage')||g.created_by===S.user.id)?'<button class="btn" id="group-invite-link">Invite link</button><button class="btn primary" id="add-member">+ Add member</button>':''}</div><div id="member-list" class="list" style="margin-top:14px"></div></div>`;

  const load=async()=>{const {data,error}=await sb.from('group_members').select('*').eq('group_id',g.id).order('created_at');if(error)throw error;const ids=(data||[]).map(x=>x.user_id),names=await namesFor(ids);const roleResult=ids.length?await sb.from('user_roles').select('user_id,role').in('user_id',ids):{data:[]},roles=Object.fromEntries((roleResult.data||[]).map(x=>[x.user_id,x.role]));const l=U.q('#member-list');l.innerHTML=data?.length?data.map(m=>{const p=names[m.user_id]||{},presence=presenceLabel(p,p.role||roles[m.user_id]||'student');return `<div class="list-item ws-member-presence"><div class="avatar">${U.esc(initials(p.full_name))}</div><div class="body"><h3>${U.esc(p.full_name||'Member')}</h3><p>${p.public_id?`<span class="code">@${U.esc(p.public_id)}</span> • `:''}</p>${window.EduPresence.badge(m.user_id)}<small>Joined ${U.fmtDate(m.created_at)}</small></div>${m.user_id!==S.user.id?`<button class="btn small" data-member-chat="${m.user_id}">Message</button><button class="btn small" data-member-audio="${m.user_id}">Audio call</button><button class="btn small" data-member-video="${m.user_id}">Video call</button>`:''}${(can('members.manage')||g.created_by===S.user.id)&&m.user_id!==g.created_by?`<button class="btn danger small" data-remove="${m.user_id}">Remove</button>`:''}</div>`}).join(''):'<div class="empty">No members.</div>';U.qa('[data-member-audio],[data-member-video]',l).forEach(b=>b.onclick=window.EduWorkspace.run(()=>workspaceContext().startCall({kind:'direct',peer_id:b.dataset.memberAudio||b.dataset.memberVideo},!!b.dataset.memberAudio)));U.qa('[data-member-chat]',l).forEach(b=>b.onclick=()=>openDirectChat(b.dataset.memberChat));U.qa('[data-remove]',l).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Remove member','Remove this user from the group?','Remove'))return;const {error}=await sb.from('group_members').delete().eq('group_id',g.id).eq('user_id',b.dataset.remove);if(error)U.toast(U.errorText(error),'error');else load()})};await load();

  U.q('#group-invite-link')?.addEventListener('click',()=>shareGroupInvite(g));

  U.q('#add-member')?.addEventListener('click',()=>selectGroupMembers(g,load));

}

async function acceptGroupInvite(code){

 try{if(!await U.confirmBox('Join group','Join the group from this invitation using your current account?','Join group'))return;

 const id=must(await sb.rpc('join_group_invite',{code_input:code}));await openGroup(id,'chat');U.toast('You joined the group.','ok');

 }catch(e){U.toast(U.errorText(e),'error')}finally{sessionStorage.removeItem('ecp-group-invite');if(window.EDU_ENTRY)window.EDU_ENTRY.groupInvite=null;}

}

async function shareGroupInvite(g,rotate=false){

 try{const code=must(await sb.rpc('get_group_invite',{group_input:g.id,rotate_input:rotate})),link=new URL('group.html',CFG.PUBLIC_WEB_URL+'/');link.searchParams.set('group_invite',code);

 const r=U.modal({title:'Group invitation link',body:`<p>Share this link in WhatsApp, Messenger or any chat. Valid for 7 days. Recipients sign in to join.</p><input class="input" readonly value="${U.attr(link.href)}">`,actions:'<button class="btn" data-close>Close</button><button class="btn" id="replace-group-link">Replace link</button><button class="btn" id="copy-group-link">Copy</button><button class="btn primary" id="share-group-link">Share</button>'});

 U.q('#copy-group-link',r).onclick=()=>U.copy(link.href);U.q('#replace-group-link',r).onclick=()=>shareGroupInvite(g,true);U.q('#share-group-link',r).onclick=async()=>{try{if(navigator.share)await navigator.share({title:g.name,url:link.href});else await U.copy(link.href)}catch(e){if(e.name!=='AbortError')U.toast(U.errorText(e),'error')}};

 }catch(e){U.toast(U.errorText(e),'error')}

}

async function groupDrive(g){

  const body=U.q('#group-body');const {data,error}=await sb.from('group_drive_links').select('*').eq('group_id',g.id).maybeSingle();if(error)throw error;const url=data?.url||'';body.innerHTML=`<div class="card card-pad"><div class="row"><div class="avatar">☁️</div><div><h2 style="margin:0">Google Drive</h2><p class="muted">Open the Drive folder configured for this group.</p></div></div>${url?`<div class="banner" style="margin-top:15px;word-break:break-all">${U.esc(url)}</div><button class="btn primary" id="open-drive">Open Google Drive</button>`:'<div class="empty">No Google Drive folder has been linked yet.</div>'}${can('groups.manage')?'<button class="btn ghost" id="set-drive">Set / change link</button> <button class="btn danger" id="remove-drive">Remove link</button>':''}</div>`;

  U.q('#open-drive')?.addEventListener('click',()=>window.open(url,'_blank','noopener'));

  U.q('#set-drive')?.addEventListener('click',async()=>{const v=await U.promptBox({title:'Google Drive folder',fields:[{label:'Folder URL',value:url,placeholder:'https://drive.google.com/drive/folders/...'}],submit:'Save'});if(!v)return;if(!U.driveUrl(v[0])){U.toast('Use a Google Drive folder URL.','error');return}const {error}=await sb.from('group_drive_links').update({url:v[0]}).eq('group_id',g.id);if(error)U.toast(U.errorText(error),'error');else groupDrive(g)});

  U.q('#remove-drive')?.addEventListener('click',async()=>{if(!url)return;const {error}=await sb.from('group_drive_links').update({url:null}).eq('group_id',g.id);if(error)U.toast(U.errorText(error),'error');else groupDrive(g)});

}

async function groupSettings(g){

  const body=U.q('#group-body');body.innerHTML=`<div class="card card-pad"><h3>Group settings</h3>${can('groups.manage')||g.created_by===S.user.id?'<button class="btn" id="edit-group-details">Edit name / description</button>':''}${g.created_by!==S.user.id?'<button class="btn danger" id="leave-group">Leave group</button>':''}${can('groups.manage')||g.created_by===S.user.id?'<label class="btn ghost">Change group photo<input id="group-photo" type="file" accept="image/jpeg,image/png,image/webp" hidden></label>':''}<label class="switch"><input id="allow-chat" type="checkbox" ${g.allow_member_messaging?'checked':''} ${isSuper()?'':'disabled'}><span>Allow member texting / files / voice</span></label><p class="hint">Only Super Admin can change this. ON: members can send text/files/voice and start group calls. OFF: members can only read, download files, listen to voice messages and join active calls/meetings; only Admin/Super Admin can send, start group calls or create meetings.</p>${can('groups.manage')?'<hr><button class="btn danger" id="delete-group">Delete group</button>':''}</div>`;

  U.q('#edit-group-details')?.addEventListener('click',window.EduWorkspace.run(async()=>{const v=await U.promptBox({title:'Edit group',fields:[{label:'Name',value:g.name,max:120},{label:'Description',type:'textarea',value:g.description||'',max:2000}],submit:'Save'});if(!v?.[0]?.trim())return;must(await sb.from('groups').update({name:v[0].trim(),description:v[1]?.trim()||''}).eq('id',g.id).select('id').single());await openGroup(g.id,'settings');}));
  U.q('#leave-group')?.addEventListener('click',window.EduWorkspace.run(async()=>{if(!await U.confirmBox('Leave group','Leave this group? You will need an invitation to rejoin.','Leave'))return;must(await sb.from('group_members').delete().eq('group_id',g.id).eq('user_id',S.user.id));await navigate('groups');}));
  U.q('#group-photo')?.addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;let path,saved=false;try{const blob=await window.EduCrop(file);if(!blob)return;path=`${g.id}/${U.uuid()}.jpg`;must(await sb.storage.from('group-images').upload(path,blob,{contentType:'image/jpeg'}));must(await sb.from('groups').update({image_path:path}).eq('id',g.id).select('id,image_path').single());saved=true;if(g.image_path&&g.image_path!==path)await sb.storage.from('group-images').remove([g.image_path]);await openGroup(g.id,'settings')}catch(err){if(path&&!saved)await sb.storage.from('group-images').remove([path]);U.toast(U.errorText(err),'error')}});

  U.q('#allow-chat')?.addEventListener('change',async e=>{if(!isSuper()){e.target.checked=g.allow_member_messaging;U.toast('Only Super Admin can change member texting.','error');return;}const {error}=await sb.from('groups').update({allow_member_messaging:e.target.checked}).eq('id',g.id);if(error){e.target.checked=!e.target.checked;U.toast(U.errorText(error),'error')}else{g.allow_member_messaging=e.target.checked;U.toast('Group messaging setting updated.','ok')}});

  U.q('#delete-group')?.addEventListener('click',async()=>{if(!await U.confirmBox('Delete group','This deletes the group, its messages, file metadata, meetings and links. Delete stored files first if you want their objects removed too.','Delete group'))return;const {error}=await sb.from('groups').delete().eq('id',g.id);if(error)U.toast(U.errorText(error),'error');else navigate('groups')});

}



async function joinByInvite(input){

  const code=U.inviteCode(input);if(!code){U.toast('Invalid meeting invite code or link.','error');return}

  try{const {data,error}=await sb.rpc('join_invite',{code});if(error)throw error;U.clearInvite();const m=must(await sb.from('meetings').select('*').eq('id',data).single());await openMeeting(m,{autoJoin:true})}catch(e){U.toast(U.errorText(e),'error');if(S.page!=='meetings')navigate('meetings')}

}

async function openMeeting(m,opts={}){

  if(m.ended_at){U.toast('This meeting has ended.','error');return}

  if(m.starts_at&&Date.parse(m.starts_at)>Date.now()){U.toast('This meeting starts '+U.fmtDate(m.starts_at),'error');return}

  await window.EduMeeting.open(sb,m,{profile:S.profile,autoJoin:!!opts.autoJoin,onExit:()=>{if(S.direct)openDirectChat(S.direct);else if(S.group)openGroup(S.group.id,'meetings');else navigate('meetings')}});

}

async function renderMeetings(group=null){

 const box=group?U.q('#group-body'):U.q('#page'),allowed=group?isAdmin():can('meetings.create');

 box.innerHTML=`<section class="meetings-hub"><header class="meetings-banner"><div><h1>${group?'Group meetings':'Meetings'}</h1><p>A place to connect and learn, live.</p></div><div class="meetings-art" aria-hidden="true">${U.icon('meeting')}</div></header><div class="meeting-actions">${[['instant','Instant Meeting','Start now','meeting'],['scheduled','Schedule Meeting','Plan ahead','people'],['join','Join with invite','Use code/link','calendar'],['room','Create Room','Custom room','plus']].map(([kind,title,sub,icon])=>`<button class="meeting-action ${kind}" data-create-kind="${kind}" ${kind!=='join'&&!allowed?'disabled title="Meeting creation is restricted by your administrator"':''}>${U.icon(icon)}<strong>${title}</strong><span>${sub} <b aria-hidden="true">→</b></span></button>`).join('')}</div><form id="join-form" class="meeting-join"><span aria-hidden="true">${U.icon('link')}</span><input id="join-code" class="input" required aria-label="Meeting link or invite code" placeholder="Meeting link or invite code…"><button class="btn primary">Join</button></form><div class="row wrap history-heading"><h2>Recent Meetings</h2><div class="spacer"></div><select id="meeting-sort" class="select" aria-label="Meeting order"><option value="newest">Newest first</option><option value="oldest">Oldest first</option></select><button id="clear-history" class="btn ghost small">Clear All</button></div><div class="meeting-filters" role="group" aria-label="Filter meetings">${['all','recurring','scheduled','favorites'].map(f=>`<button class="btn ${f==='all'?'primary':''}" data-filter="${f}" aria-pressed="${f==='all'}">${f[0].toUpperCase()+f.slice(1)}</button>`).join('')}</div><div id="meeting-list" class="list" aria-live="polite"></div></section>`;

 const list=U.q('#meeting-list',box);let filter='all',newest=true,pageCount=1,serial=0;

 const alive=()=>list.isConnected;

 const report=e=>{if(alive())U.toast(U.errorText(e),'error')};

 const load=async()=>{

  const request=++serial,rows=[];let lastSize=0;

  try{

   for(let page=0;page<pageCount;page++){const batch=must(await sb.rpc('mobile_meetings',{group_filter:group?.id||null,list_filter:filter,page_offset:page*30,newest_first:newest}))||[];rows.push(...batch);lastSize=batch.length;if(lastSize<30)break}

   const [hosts,favs]=await Promise.all([namesFor(rows.map(m=>m.host_id)),rows.length?sb.from('meeting_favorites').select('meeting_id').eq('user_id',S.user.id).in('meeting_id',rows.map(m=>m.id)):Promise.resolve({data:[]})]);

   const favorites=new Set((must(favs)||[]).map(f=>f.meeting_id));if(!alive()||request!==serial)return;

   list.innerHTML=rows.length?rows.map(m=>{const future=m.starts_at&&Date.parse(m.starts_at)>Date.now();return `<article class="list-item meeting-entry"><div class="avatar">${U.icon('meeting')}</div><div class="body"><h3>${U.esc(m.title)}</h3><p>${U.esc(m.meeting_kind||'instant')} · Host ${U.esc(hosts[m.host_id]?.full_name||'User')} · ${U.fmtDate(m.starts_at||m.created_at)}${m.repeat_days?' · '+(m.repeat_days===1?'Daily':'Weekly'):''} · ${m.ended_at?'Ended':future?'Scheduled':'Ready'}</p><div class="tiny code meeting-id"><span>${U.esc(m.invite_code)}</span><button class="text-btn" data-copy-id="${U.attr(m.invite_code)}" aria-label="Copy meeting code">⧉</button></div></div><div class="meeting-entry-actions">${!m.ended_at?`<button class="btn primary small" data-join-m="${m.id}" ${future?'disabled title="Available at the scheduled time"':''}>Join</button><button class="btn small" data-invite="${m.id}">Invite</button>`:''}<button class="btn small" data-favorite="${m.id}" aria-label="${favorites.has(m.id)?'Remove from':'Add to'} favorites" aria-pressed="${favorites.has(m.id)}">${favorites.has(m.id)?'★':'☆'}</button>${can('attendance.read')||m.host_id===S.user.id?`<button class="btn small" data-att="${m.id}">${U.icon('chart')} Attendance</button>`:''}<details class="history-menu"><summary aria-label="Meeting actions">⋮</summary><button class="btn danger small" data-hide-meeting="${m.id}">Delete history</button>${!m.ended_at&&(m.host_id===S.user.id||isSuper())?`<button class="btn danger small" data-end="${m.id}">End for everyone</button>`:''}</details></div></article>`}).join(''):`<div class="meeting-empty"><div class="meetings-art">${U.icon('meeting')}</div><h2>${filter==='all'?'No meetings yet':'No '+filter+' meetings'}</h2><p>Start an instant meeting, join with a link<br>or schedule a meeting to see it here.</p>${allowed?'<button class="btn primary" id="empty-start">Start Instant Meeting</button>':''}</div>`;

   U.q('#empty-start',list)?.addEventListener('click',()=>create('instant'));

   U.qa('[data-copy-id]',list).forEach(b=>b.onclick=()=>U.copy(b.dataset.copyId));

   U.qa('[data-invite]',list).forEach(b=>b.onclick=()=>showMeetingInvite(rows.find(m=>m.id===b.dataset.invite)));

   U.qa('[data-join-m]',list).forEach(b=>b.onclick=()=>openMeeting(rows.find(m=>m.id===b.dataset.joinM),{autoJoin:true}).catch(report));

   U.qa('[data-att]',list).forEach(b=>b.onclick=()=>showAttendance(rows.find(m=>m.id===b.dataset.att)));

   U.qa('[data-favorite]',list).forEach(b=>b.onclick=async()=>{b.disabled=true;try{must(await (favorites.has(b.dataset.favorite)?sb.from('meeting_favorites').delete().eq('user_id',S.user.id).eq('meeting_id',b.dataset.favorite):sb.from('meeting_favorites').insert({user_id:S.user.id,meeting_id:b.dataset.favorite})));await load()}catch(e){report(e)}finally{b.disabled=false}});

   U.qa('[data-hide-meeting]',list).forEach(b=>b.onclick=async()=>{try{must(await sb.from('meeting_history_hidden').upsert({user_id:S.user.id,meeting_id:b.dataset.hideMeeting}));await load()}catch(e){report(e)}});

   U.qa('[data-end]',list).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('End meeting','End this meeting for everyone?','End meeting'))return;try{must(await sb.rpc('end_p2p_meeting',{meeting:b.dataset.end}));await load()}catch(e){report(e)}});

   if(lastSize===30){const more=document.createElement('button');more.className='btn ghost';more.textContent='Load more meetings';more.onclick=()=>{pageCount++;load()};list.append(more)}

  }catch(e){if(!alive()||request!==serial)return;list.innerHTML=`<div class="card card-pad"><p>${U.esc(['PGRST202','42883','42P01'].includes(e.code)?'Meeting setup is missing. Apply the supplied Supabase SQL, then retry.':U.errorText(e))}</p><button class="btn" id="retry-meetings">Retry</button></div>`;U.q('#retry-meetings',list).onclick=load}

 };

 const create=kind=>{

  if(kind==='join'){U.q('#join-code',box).focus();return}if(!allowed)return;

  const scheduled=kind==='scheduled',r=U.modal({title:scheduled?'Schedule meeting':kind==='room'?'Create room':'Instant meeting',body:`<form id="meeting-create-form"><div class="field"><label for="meeting-title">Meeting title</label><input id="meeting-title" class="input" required maxlength="120" value="${U.attr(group?group.name+' meeting':scheduled?'Scheduled meeting':kind==='room'?'Meeting room':'Instant meeting')}"></div>${scheduled?'<div class="field"><label for="meeting-starts">Date and time (your local time)</label><input type="datetime-local" class="input" id="meeting-starts" required></div><div class="field"><label for="meeting-repeat">Repeat</label><select id="meeting-repeat" class="select"><option value="0">Does not repeat</option><option value="1">Daily</option><option value="7">Weekly</option></select></div>':''}<p class="hint">Share the meeting link to invite participants.</p><button type="submit" class="btn primary">${scheduled?'Schedule meeting':'Create meeting'}</button></form>`});

  U.q('#meeting-create-form',r).onsubmit=async e=>{e.preventDefault();const title=U.q('#meeting-title',r).value.trim(),date=scheduled?new Date(U.q('#meeting-starts',r).value):null;if(!title)return;if(scheduled&&(!Number.isFinite(date.getTime())||date<=new Date())){U.toast('Choose a future date and time.','error');return}U.setBusy(e.submitter,true);try{const id=must(await sb.rpc('create_mobile_meeting',{title_input:title,group_input:group?.id||null,kind_input:kind,starts_input:date?.toISOString()||null,repeat_input:scheduled?Number(U.q('#meeting-repeat',r).value):0})),m=must(await sb.from('meetings').select('*').eq('id',id).single());U.closeModal();await load();showMeetingInvite(m)}catch(err){report(err)}finally{U.setBusy(e.submitter,false)}};

 };

 U.qa('[data-create-kind]',box).forEach(b=>b.onclick=()=>create(b.dataset.createKind));

 U.qa('[data-filter]',box).forEach(b=>b.onclick=()=>{filter=b.dataset.filter;pageCount=1;U.qa('[data-filter]',box).forEach(x=>{x.classList.toggle('primary',x===b);x.setAttribute('aria-pressed',String(x===b))});load()});

 U.q('#meeting-sort',box).onchange=e=>{newest=e.target.value==='newest';pageCount=1;load()};

 U.q('#join-form',box).onsubmit=async e=>{e.preventDefault();U.setBusy(e.submitter,true);try{await joinByInvite(U.q('#join-code',box).value)}finally{U.setBusy(e.submitter,false)}};

 U.q('#clear-history',box).onclick=async()=>{if(!await U.confirmBox('Clear meeting history','Hide all meeting history for your account? Other participants keep their history and attendance.','Clear All'))return;try{must(await sb.rpc('clear_meeting_history',{group_filter:group?.id||null}));pageCount=1;await load()}catch(e){report(e)}};

 await load();if(!alive())return;

 const refresh=U.debounce(()=>{if(alive())load()},300);

 S.channel=sb.channel(`meetings-web-${group?.id||'mine'}-${Date.now()}`).on('postgres_changes',{event:'*',schema:'public',table:'meetings'},refresh).on('postgres_changes',{event:'*',schema:'public',table:'meeting_favorites',filter:`user_id=eq.${S.user.id}`},refresh).on('postgres_changes',{event:'*',schema:'public',table:'meeting_history_hidden',filter:`user_id=eq.${S.user.id}`},refresh).subscribe();

 S.meetingRefresh=()=>{if(alive())refresh()};

}

async function showMeetingInvite(m){

 const link=new URL('/',CFG.PUBLIC_WEB_URL);link.searchParams.set('invite',m.invite_code);const future=m.starts_at&&Date.parse(m.starts_at)>Date.now();

 const r=U.modal({title:'Meeting invite',body:`<p>${m.allow_guests===false?'Registered participants can use this link to join.':'Participants can join in their browser using this link. Guest access is available when enabled on the server.'}</p>${m.starts_at?`<p>Starts ${U.fmtDate(m.starts_at)}</p>`:''}<div class="field"><label>Invite link</label><input class="input" readonly value="${U.attr(link.href)}"></div><div class="field"><label>Meeting code</label><input class="input" readonly value="${U.attr(m.invite_code)}"></div>`,actions:`<button class="btn ghost" data-close>Close</button><button class="btn" id="copy-invite">Copy link</button><button class="btn" id="share-invite">Share</button>${!future&&!m.ended_at?'<button class="btn primary" id="start-invite">Join now</button>':''}`});

 U.q('#copy-invite',r).onclick=()=>U.copy(link.href);

 U.q('#share-invite',r).onclick=async()=>{try{if(navigator.share)await navigator.share({title:m.title,text:'Join '+m.title,url:link.href});else await U.copy(link.href)}catch(e){if(e.name!=='AbortError')U.toast(U.errorText(e),'error')}};

 U.q('#start-invite',r)?.addEventListener('click',()=>{U.closeModal();openMeeting(m,{autoJoin:true}).catch(e=>U.toast(U.errorText(e),'error'))});

}



async function showAttendance(m){

  try{const {data,error}=await sb.from('meeting_attendance').select('*').eq('meeting_id',m.id).order('joined_at');if(error)throw error;const names=await namesFor((data||[]).map(x=>x.user_id));const rows=(data||[]).map(x=>({name:names[x.user_id]?.full_name||'User',user_id:x.user_id,device:U.shortId(x.connection_id||x.id),joined:U.fmtDate(x.joined_at),left:x.left_at?U.fmtDate(x.left_at):'Still connected / not closed',duration_seconds:x.duration_seconds??(x.left_at?0:'')}));const html=`<div class="table-wrap"><table><thead><tr><th>Name</th><th>User</th><th>Device/session</th><th>Joined</th><th>Left</th><th>Seconds</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${U.esc(x.name)}</td><td><span class="code">${U.esc(U.shortId(x.user_id))}</span></td><td>${U.esc(x.device)}</td><td>${U.esc(x.joined)}</td><td>${U.esc(x.left)}</td><td>${U.esc(x.duration_seconds)}</td></tr>`).join('')}</tbody></table></div><p class="hint">A single account joining from mobile and laptop appears as two device/session attendance rows.</p>`;const r=U.modal({title:`Attendance — ${m.title}`,body:html,wide:true,actions:'<button class="btn ghost" data-close>Close</button><button class="btn primary" id="csv-att">Download CSV</button>'});U.q('#csv-att',r).onclick=()=>U.download(`attendance-${U.safeName(m.title)}.csv`,U.makeCsv(rows,['name','user_id','device','joined','left','duration_seconds']),'text/csv;charset=utf-8')}catch(e){U.toast(U.errorText(e),'error')}

}



async function renderForum(limit=30){const render= S.forumRender=(S.forumRender||0)+1;

 cleanupChannel();

  const box=U.q('#page');if(!U.q('#forum-list',box))box.innerHTML=pageHead('Community Forum','Share an update with everyone on Edu Chat Pro.','<button class="btn primary" id="new-post">+ New post</button>')+'<div id="forum-list" class="stack"></div>';U.q('#new-post').onclick=()=>editPost(null);

  const ownership=await sb.rpc('my_post_ids');const own=ownership.data||[];

  const {data,error}=await sb.from('forum_posts').select('*').order('created_at',{ascending:false}).order('id',{ascending:false}).limit(limit);if(error)throw error;const names=await namesFor((data||[]).map(x=>x.public_author_id));const list=U.q('#forum-list');if(!list||render!==S.forumRender||S.page!=='forum')return;

  syncMessages(list,data?.length?data.map(p=>{const author=names[p.public_author_id]||{full_name:'User'};return `<article data-message-id="${p.id}" data-stamp="${U.attr(JSON.stringify([p,author,own.includes(p.id)]))}" class="card forum-post"><div class="row">${p.anonymous?'<span class="avatar">?</span>':avatarHtml(author)}<div><strong>${p.anonymous?'Anonymous':U.esc(author.full_name||'User')}</strong><div class="tiny muted">${U.fmtDate(p.created_at)}${p.updated_at!==p.created_at?' • edited':''}</div></div><div class="spacer"></div>${p.anonymous&&isSuper()?`<button class="btn small" data-identify="${p.id}">Identify</button>`:''}</div><div class="bodytext social-body">${U.esc(p.body)}</div>${p.image_path?`<img class="forum-image" data-forum-image="${U.attr(p.image_path)}" alt="Post image" loading="lazy" decoding="async">`:''}<div class="reaction-bar" data-reactions="${p.id}"></div><div class="row wrap" style="margin-top:14px"><button class="btn small" data-open-post="${p.id}">${U.icon('chat')} Comments</button><button class="btn ghost small" data-report="${p.id}">Report</button>${own.includes(p.id)?`<button class="btn ghost small" data-edit-post="${p.id}">${U.icon('edit')} Edit</button>`:''}${own.includes(p.id)||can('forum.moderate')?`<button class="btn danger small" data-del-post="${p.id}">Delete</button>`:''}</div></article>`}).join(''):'<div class="card empty">No forum posts yet.</div>');await hydrateAvatars(list);await hydrateSocial(list);if(data?.length===limit){const more=document.createElement('button');more.className='btn ghost';more.textContent='Load older posts';more.onclick=()=>renderForum(limit+30).catch(e=>U.toast(U.errorText(e),'error'));list.appendChild(more)}

  U.qa('[data-open-post]',list).forEach(b=>b.onclick=()=>openPost(data.find(x=>x.id===b.dataset.openPost)));

  U.qa('[data-edit-post]',list).forEach(b=>b.onclick=()=>editPost(data.find(x=>x.id===b.dataset.editPost)));

  U.qa('[data-del-post]',list).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Delete post','Delete this post and its comments?','Delete'))return;const {error}=await sb.rpc('delete_post',{post:b.dataset.delPost});if(error)U.toast(U.errorText(error),'error');else{const post=data.find(p=>p.id===b.dataset.delPost);if(post?.image_path){const removed=await sb.storage.from('forum-images').remove([post.image_path]);if(removed.error)U.toast('Post deleted. Its image could not be removed from storage.','warn')}renderForum()}});

  U.qa('[data-identify]',list).forEach(b=>b.onclick=async()=>{const {data:id,error}=await sb.rpc('identify_post',{post:b.dataset.identify});if(error)U.toast(U.errorText(error),'error');else{const n=await namesFor([id]);U.modal({title:'Anonymous post identity',body:`<p>Account: <strong>${U.esc(n[id]?.full_name||'User')}</strong></p><p class="code">${U.esc(id)}</p><p class="hint">This lookup is logged in the admin audit history.</p>`})}});

  S.channel=sb.channel('forum-updates').on('postgres_changes',{event:'*',schema:'public',table:'forum_reactions'},payload=>{const id=payload.new?.post_id||payload.old?.post_id;U.qa('[data-reactions]').filter(b=>b.dataset.reactions===id).forEach(hydrateReaction)}).on('postgres_changes',{event:'INSERT',schema:'public',table:'forum_comments'},()=>{const form=U.q('#comment-form');if(form&&!U.q('#comment-text')?.value.trim()&&!U.q('#comment-image')?.files?.length){form.dispatchEvent(new Event('refresh-comments'));return}if(form&&!U.q('#comment-refresh')){const b=document.createElement('button');b.id='comment-refresh';b.type='button';b.className='btn ghost';b.textContent='New comments — refresh';form.before(b);b.onclick=()=>form.dispatchEvent(new Event('refresh-comments'))}}).on('postgres_changes',{event:'*',schema:'public',table:'forum_posts'},()=>{clearTimeout(S.forumTimer);S.forumTimer=setTimeout(()=>{if(S.page==='forum')renderForum(limit).catch(e=>U.toast(U.errorText(e),'error'))},350)}).subscribe();

  S.pageRefresh=()=>renderForum(limit);

  U.qa('[data-report]',list).forEach(b=>b.onclick=async()=>{const v=await U.promptBox({title:'Report post',fields:[{label:'Reason',type:'textarea',max:2000}],submit:'Report'});if(!v)return;const {error}=await sb.from('forum_reports').insert({post_id:b.dataset.report,reporter_id:S.user.id,reason:v[0]});if(error)U.toast(U.errorText(error),'error');else U.toast('Report sent to moderators.','ok')});

}

async function editPost(p){

 const r=U.modal({title:p?'Edit post':'Create post',body:`<textarea id="social-body" class="textarea" maxlength="10000" placeholder="What would you like to share?">${U.esc(p?.body||'')}</textarea><label class="btn ghost">📷 Add photo / video<input type="file" id="social-image" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime" hidden></label><img id="social-preview" class="forum-image hidden" alt="Selected image"><label class="switch"><input type="checkbox" id="social-anonymous" ${p?.anonymous?'checked':''}>Post anonymously</label><button class="btn ghost" id="remove-social-image">Remove image</button>`,actions:'<button class="btn ghost" data-close>Cancel</button><button class="btn primary" id="save-social">Post</button>'});

 let selected=null,remove=false,previewUrl=null;

 if(p?.image_path){const preview=U.q('#social-preview',r);sb.storage.from('forum-images').createSignedUrl(p.image_path,300).then(({data:image})=>{if(image&&preview.isConnected&&!selected&&!remove){if(/\.(mp4|webm|mov)$/i.test(p.image_path)){const v=document.createElement('video');v.id='social-preview';v.className='forum-image';v.controls=true;v.src=image.signedUrl;preview.replaceWith(v)}else{preview.src=image.signedUrl;preview.classList.remove('hidden')}}})}

 U.q('#social-image',r).onchange=e=>{selected=e.target.files?.[0]||null;remove=false;if(previewUrl)URL.revokeObjectURL(previewUrl);if(selected){previewUrl=URL.createObjectURL(selected);let img=U.q('#social-preview',r);const node=document.createElement(selected.type.startsWith('video/')?'video':'img');node.id='social-preview';node.className='forum-image';node.src=previewUrl;if(node.tagName==='VIDEO')node.controls=true;img.replaceWith(node)}};

 U.q('#remove-social-image',r).onclick=()=>{selected=null;remove=true;U.q('#social-image',r).value='';U.q('#social-preview',r).classList.add('hidden')};

 U.q('#save-social',r).onclick=async e=>{const body=U.q('#social-body',r).value.trim();if(!body){U.toast('Write a description first.','error');return}let uploaded=null,saved=false;U.setBusy(e.target,true);try{let path=remove?null:p?.image_path||null;if(selected){uploaded=await uploadForumMedia(selected);path=uploaded}let result=await sb.rpc('save_social_post',{post:p?.id||null,body_text:body,is_anonymous:U.q('#social-anonymous',r).checked,image_path_input:path});if(['PGRST202','42883'].includes(result.error?.code)&&!path&&!p?.image_path)result=await sb.rpc('save_post',{post:p?.id||null,title_text:body.slice(0,160),body_text:body,is_anonymous:U.q('#social-anonymous',r).checked});must(result);saved=true;if(p?.image_path&&p.image_path!==path)await sb.storage.from('forum-images').remove([p.image_path]);if(previewUrl)URL.revokeObjectURL(previewUrl);U.closeModal();await renderForum()}catch(err){if(uploaded&&!saved)await sb.storage.from('forum-images').remove([uploaded]);U.toast(U.errorText(err),'error')}finally{U.setBusy(e.target,false)}};

}

async function openPost(p,limit=50){

 try{

 const rows=must(await sb.from('forum_comments').select('*').eq('post_id',p.id).order('created_at',{ascending:false}).limit(limit))||[],names=await namesFor(rows.map(c=>c.author_id));

 const r=U.modal({title:'Discussion',wide:true,body:`<div class="bodytext">${U.esc(p.body)}</div><div id="comments">${rows.reverse().map(c=>`<article class="comment"><div class="row">${avatarHtml(names[c.author_id])}<strong>${U.esc(names[c.author_id]?.full_name||'User')}</strong><span class="tiny muted">${U.fmtDate(c.created_at)}</span></div><p class="bodytext">${U.esc(c.body)}</p>${c.image_path?`<img class="forum-image" data-forum-image="${U.attr(c.image_path)}" alt="Comment image" loading="lazy">`:''}${c.author_id===S.user.id||can('forum.moderate')?`<button class="btn ghost small" data-cdel="${c.id}">Delete</button>`:''}</article>`).join('')||'<p>No comments yet.</p>'}</div>${rows.length===limit?'<button class="btn ghost" id="more-comments">Load older comments</button>':''}<form id="comment-form" class="stack"><textarea id="comment-text" class="textarea" maxlength="4000" placeholder="Write a comment…"></textarea><label class="btn ghost">Add photo / video<input id="comment-image" type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime" hidden></label><div id="comment-preview"></div><button class="btn primary">Send comment</button></form>`});

 hydrateAvatars(r);hydrateSocial(r);let selected=null,previewUrl;

 U.q('#comment-image',r).onchange=e=>{selected=e.target.files?.[0]||null;if(previewUrl)URL.revokeObjectURL(previewUrl);const box=U.q('#comment-preview',r);box.innerHTML='';if(selected){previewUrl=URL.createObjectURL(selected);const img=document.createElement(selected.type.startsWith('video/')?'video':'img');img.src=previewUrl;img.className='forum-image';if(img.tagName==='VIDEO'){img.controls=true;img.preload='metadata'}box.appendChild(img);const b=document.createElement('button');b.type='button';b.className='btn ghost';b.textContent='Remove photo';b.onclick=()=>{selected=null;box.innerHTML='';U.q('#comment-image',r).value=''};box.appendChild(b)}};

 U.q('#comment-form',r).addEventListener('refresh-comments',()=>{if(selected||U.q('#comment-text',r).value.trim()){U.toast('Send your draft before refreshing comments.','ok');return}openPost(p,limit)});

 U.q('#more-comments',r)?.addEventListener('click',()=>openPost(p,limit+50));

 U.q('#comment-form',r).onsubmit=async e=>{e.preventDefault();const body=U.q('#comment-text',r).value.trim();if(!body&&!selected)return;let path,saved=false;U.setBusy(e.submitter,true);try{if(selected){path=await uploadForumMedia(selected)}must(await sb.from('forum_comments').insert({post_id:p.id,author_id:S.user.id,body,...(path?{image_path:path}:{})}));saved=true;await openPost(p,limit)}catch(err){if(path&&!saved)await sb.storage.from('forum-images').remove([path]);U.toast(U.errorText(err),'error')}finally{U.setBusy(e.submitter,false)}};

 U.qa('[data-cdel]',r).forEach(b=>b.onclick=async()=>{try{const c=rows.find(x=>x.id===b.dataset.cdel);must(await sb.from('forum_comments').delete().eq('id',c.id));if(c.image_path)await sb.storage.from('forum-images').remove([c.image_path]);await openPost(p,limit)}catch(e){U.toast(U.errorText(e),'error')}});

 }catch(e){U.toast(U.errorText(e),'error')}

}



async function setupNotifications(){

 S.stopNotifications?.();

 if('Notification' in window)window.EduPush.resume(sb,S.user.id).catch(()=>{});

 if(S.notificationChannel)sb.removeChannel(S.notificationChannel).catch(()=>{});

 const userId=S.user.id,seen=new Set();let since=new Date().toISOString(),fetching=false;

 const accept=n=>{if(S.user?.id!==userId||seen.has(n.id))return;seen.add(n.id);if(seen.size>500)seen.delete(seen.values().next().value);

  if(n.kind==='call_cancel'){S.cancelledCalls??=new Set();S.cancelledCalls.add(n.resource_id);if(S.cancelledCalls.size>200)S.cancelledCalls.delete(S.cancelledCalls.values().next().value);if(S.incoming?.id===n.resource_id)S.incoming.close();window.EduPush.dismiss(n.resource_id);return}

  if(['direct_call_audio','direct_call_video','group_call'].includes(n.kind)&&Date.now()-Date.parse(n.created_at)>60000)return;

  const announcement=/announcement|system|important/i.test(String(n.kind||''));if(announcement){let host=document.querySelector('#ecp-top-announcements');if(!host){host=document.createElement('div');host.id='ecp-top-announcements';host.className='ecp-top-announcements';document.body.append(host);}const banner=document.createElement('div');banner.className='ecp-top-announcement';banner.innerHTML=`<span>${U.icon('bell')}</span><b>${U.esc(n.title||'Announcement')}</b><button type="button" aria-label="Dismiss">×</button>`;banner.querySelector('button').onclick=()=>banner.remove();host.prepend(banner);setTimeout(()=>banner.remove(),12000);}window.EduPush.show(n).catch(()=>{});

  if(['direct_call_audio','direct_call_video','group_call'].includes(n.kind))receiveDirectCall(n);

  // Native Android handles incoming message/call notifications. In-app green message toasts are intentionally suppressed.

  window.dispatchEvent(new Event('edu-alerts-updated'));

 };

 const catchUp=async()=>{if(fetching||S.user?.id!==userId||document.hidden)return;fetching=true;const until=new Date().toISOString();try{let offset=0;for(let page=0;page<5;page++){const rows=must(await sb.from('notifications').select('*').eq('user_id',userId).gte('created_at',since).lte('created_at',until).order('created_at').order('id').range(offset,offset+99))||[];if(S.user?.id!==userId)break;rows.forEach(accept);if(rows.length<100){since=until;break}offset+=100}}catch(e){console.warn('Notification sync:',e.message)}finally{fetching=false}};

 S.notificationChannel=sb.channel(`alerts-${userId}`).on('postgres_changes',{event:'INSERT',schema:'public',table:'notifications',filter:`user_id=eq.${userId}`},p=>accept(p.new)).subscribe(status=>{if(status==='SUBSCRIBED')catchUp()});

 const wake=()=>{if(!document.hidden)catchUp()};document.addEventListener('visibilitychange',wake);window.addEventListener('online',wake);

 S.stopNotifications=()=>{document.removeEventListener('visibilitychange',wake);window.removeEventListener('online',wake);S.incoming?.close();S.cancelledCalls?.clear()};

}

async function enableWebAlerts(){try{const mode=await window.EduPush.enable(sb,S.user.id);U.toast(mode==='push'?'Push notifications enabled.':'Notifications enabled while this website is open.','ok')}catch(e){U.toast(U.errorText(e),'error')}}
async function unusedBrowserAlerts(){try{const mode=await window.EduPush.enable(sb,S.user.id);U.toast(mode==='push'?'Push notifications enabled.':'Notifications enabled while this website is open.','ok')}catch(e){U.toast(U.errorText(e),'error')}}

async function renderNotifications(){

 const box=U.q('#page');box.innerHTML=pageHead('Notifications','Calls, messages, announcements and community updates.','<button class="btn primary" id="alerts-enable">Enable notifications</button><button class="btn ghost" id="mark-all">Mark all read</button><button class="btn ghost" id="clear-alerts">Clear notifications</button>')+'<p class="hint">Allow browser notifications and keep this website open to receive alerts.</p><div id="alerts" class="list"></div>';

 const list=U.q('#alerts',box);let revision=0;

 const load=async()=>{const rev=++revision;try{const rows=must(await sb.from('notifications').select('*').eq('user_id',S.user.id).neq('kind','call_cancel').order('created_at',{ascending:false}).limit(100))||[];if(!list.isConnected||rev!==revision)return;list.innerHTML=rows.length?rows.map(n=>`<div class="list-item ${n.read_at?'':'unread'}"><div class="avatar">${U.icon(n.kind.includes('call')?'phone':'bell')}</div><div class="body"><h3>${U.esc(n.title)}</h3><p>${U.fmtDate(n.created_at)}</p></div>${n.resource_id?`<button class="btn small" data-open-alert="${n.id}">Open</button>`:''}${!n.read_at?`<button class="btn small" data-read="${n.id}">Read</button>`:''}</div>`).join(''):'<div class="card empty">No notifications.</div>';U.qa('[data-open-alert]',list).forEach(b=>b.onclick=()=>openNotification(rows.find(n=>n.id===b.dataset.openAlert)));U.qa('[data-read]',list).forEach(b=>b.onclick=async()=>{try{must(await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('id',b.dataset.read));await load()}catch(e){U.toast(U.errorText(e),'error')}})}catch(e){if(list.isConnected)U.toast(U.errorText(e),'error')}};

 U.q('#alerts-enable',box).onclick=enableWebAlerts;U.q('#clear-alerts',box).onclick=window.EduWorkspace.run(async()=>{if(!await U.confirmBox('Clear notifications','Remove all your notifications?','Clear'))return;must(await sb.from('notifications').delete().eq('user_id',S.user.id));await load();});

 U.q('#mark-all',box).onclick=async()=>{try{must(await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('user_id',S.user.id).is('read_at',null));await load()}catch(e){U.toast(U.errorText(e),'error')}};

 S.alertsRefresh=load;await load();

}



async function renderProfile(){
  S.profile=must(await sb.rpc('my_profile'))||S.profile;try{const extra=await profileExtras();if(extra)S.profile={...S.profile,...extra}}catch{}const p=S.profile,box=U.q('#page');
  let coverPath=p.cover_path||null,lastSeenVisible=p.last_seen_visible!==false;
  box.innerHTML=pageHead('Profile','Your photo and information appear in chats, forum posts and meetings.','<button class="btn ghost" id="invite-app">Invite to Edu Chat Pro</button>')+`<div class="grid two"><div class="card card-pad profile-card-main"><div class="profile-cover ${coverPath?'has-cover':''}" id="profile-cover" ${coverPath?`data-cover-path="${U.attr(coverPath)}"`:''}><label class="profile-cover-edit" title="Change cover photo">${U.icon('photo')} Change cover<input id="profile-cover-file" type="file" accept="image/jpeg,image/png,image/webp" hidden></label></div><div class="profile-content"><div class="profile-avatar-wrap"><label class="avatar-button" title="Change profile photo">${avatarHtml(p,'profile-xl')}<span class="avatar-edit">${U.icon('photo')}</span><input id="profile-photo" type="file" accept="image/*" hidden></label></div><h2 class="profile-name">${U.esc(p.full_name)}</h2><div class="profile-email">${U.esc(S.user.email||'')}</div><p class="hint profile-photo-note">Use a profile picture plus an adjustable cover photo. JPG, PNG or WebP up to 10 MB.</p><div class="field" style="margin-top:20px"><label>Full name</label><input id="prof-name" class="input" maxlength="100" value="${U.attr(p.full_name||'')}"></div><div class="field"><label>Phone (optional)</label><input id="prof-phone" class="input" maxlength="30" value="${U.attr(p.phone||'')}"></div><div class="row wrap"><button class="btn primary" id="save-profile">Save profile</button>${p.avatar_path?'<button class="btn ghost" id="remove-photo">Remove photo</button>':''}${coverPath?'<button class="btn ghost" id="remove-cover">Remove cover</button>':''}</div></div></div><div class="card card-pad"><h3>Account & security</h3><p><b>Public User ID</b><br><span class="code">@${U.esc(p.public_id||'not-set')}</span></p><button class="btn ghost small" id="change-public-id">Change User ID</button><p><b>Account UUID</b><br><span class="code">${U.esc(S.user.id)}</span></p><p><b>Role</b><br>${U.esc(S.role.replaceAll('_',' '))}</p>${isAdmin()?`<label class="switch"><input id="last-seen-visible" type="checkbox" ${lastSeenVisible?'checked':''}><span>Show my last active / last seen</span></label><p class="hint">Only admins can hide their own last seen. Student last seen is always visible.</p>`:'<p class="hint">Your last active / last seen is always visible to other users.</p>'}<button class="btn" id="change-password">Change password</button> <button class="btn ghost" id="enable-notify">Enable browser notifications</button><p class="hint">Passwords are handled by Supabase Auth and are never visible to Edu Chat Pro admins.</p></div></div>`;
  await hydrateAvatars(box);
  if(coverPath){try{const url=await window.EduPhotos.get(sb,S.user.id,'avatars',coverPath),el=U.q('#profile-cover');if(el)el.style.backgroundImage=`url("${url}")`;}catch{}}
  U.q('#invite-app').onclick=async()=>{const url=new URL('/',CFG.PUBLIC_WEB_URL).href;try{if(navigator.share)await navigator.share({title:'Join Edu Chat Pro',url});else await U.copy(url)}catch(e){if(e.name!=='AbortError')U.toast(U.errorText(e),'error')}};
  U.q('#profile-cover-file')?.addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;const input=e.target;input.disabled=true;let path=null;try{const blob=await window.EduCoverCrop(file);if(!blob)return;path=`${S.user.id}/cover-${U.uuid()}.jpg`;must(await sb.storage.from('avatars').upload(path,blob,{contentType:'image/jpeg',upsert:false}));const upd=await sb.from('profiles').update({cover_path:path}).eq('id',S.user.id);if(upd.error){await sb.storage.from('avatars').remove([path]);throw upd.error}if(coverPath)await sb.storage.from('avatars').remove([coverPath]).catch(()=>{});S.profile={...S.profile,cover_path:path};U.toast('Cover photo updated.','ok');await navigate('profile')}catch(err){if(path)await sb.storage.from('avatars').remove([path]).catch(()=>{});U.toast(U.errorText(err),'error')}finally{input.disabled=false}});
  U.q('#remove-cover')?.addEventListener('click',async()=>{if(!await U.confirmBox('Remove cover photo','Remove your current cover photo?','Remove'))return;const old=coverPath;const upd=await sb.from('profiles').update({cover_path:null}).eq('id',S.user.id);if(upd.error){U.toast(U.errorText(upd.error),'error');return}if(old)await sb.storage.from('avatars').remove([old]).catch(()=>{});S.profile={...S.profile,cover_path:null};await navigate('profile')});
  U.q('#profile-photo')?.addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;const input=e.target;input.disabled=true;try{const path=await saveProfileAvatar(file);if(!path)return;U.toast('Profile photo saved.','ok');renderShell();await navigate('profile')}catch(err){U.toast(U.errorText(err),'error')}finally{input.disabled=false;input.value=''}});
  U.q('#remove-photo')?.addEventListener('click',async()=>{if(!await U.confirmBox('Remove profile photo','Remove your current profile picture?','Remove'))return;try{const old=S.profile?.avatar_path;const upd=await sb.from('profiles').update({avatar_path:null}).eq('id',S.user.id).select('id,avatar_path').single();if(upd.error)throw upd.error;if(old)await sb.storage.from('avatars').remove([old]);avatarCache.clear();S.profile={...S.profile,avatar_path:null};U.toast('Profile photo removed.','ok');renderShell();await navigate('profile')}catch(e){U.toast(U.errorText(e),'error')}});
  U.q('#save-profile').onclick=async()=>{const full_name=U.q('#prof-name').value.trim(),phone=U.q('#prof-phone').value.trim()||null;if(!full_name){U.toast('Full name is required.','error');return}const {error}=await sb.from('profiles').update({full_name,phone}).eq('id',S.user.id);if(error)U.toast(U.errorText(error),'error');else{S.profile={...S.profile,full_name,phone};U.toast('Profile saved.','ok');renderShell();navigate('profile')}};
  U.q('#change-public-id')?.addEventListener('click',()=>openPublicIdEditor(false));
  U.q('#last-seen-visible')?.addEventListener('change',async e=>{const wanted=e.target.checked,previous=!wanted;e.target.disabled=true;try{const result=await sb.rpc('set_last_seen_visibility',{show_value:wanted});if(result.error)throw result.error;S.profile={...S.profile,last_seen_visible:wanted};U.toast(wanted?'Last seen is visible.':'Last seen is hidden for your admin account.','ok')}catch(err){e.target.checked=previous;U.toast(U.errorText(err),'error')}finally{e.target.disabled=false}});
  U.q('#change-password').onclick=async()=>{const v=await U.promptBox({title:'Change password',fields:[{label:'New password',type:'password',max:200}],submit:'Update password'});if(!v)return;if(v[0].length<8){U.toast('Use at least 8 characters.','error');return}const {error}=await sb.auth.updateUser({password:v[0]});if(error)U.toast(U.errorText(error),'error');else U.toast('Password changed.','ok')};
  U.q('#enable-notify').onclick=enableWebAlerts;
}


async function renderAdmin(){

  const box=U.q('#page');if(!isAdmin()){box.innerHTML='<div class="card empty">Admin access required.</div>';return}

  if(!isSuper()){

    box.innerHTML=pageHead('Assistant Admin','Your access is controlled by the Super Admin.')+`<div class="card card-pad"><h3>Current permissions</h3><div class="wrap">${PERMS.map(p=>`<span class="badge ${S.permissions.has(p)?'green':''}">${S.permissions.has(p)?'✓':'—'} ${U.esc(p)}</span>`).join('')}</div><p class="hint">Assistant Admin audit history is visible only to the Super Admin.</p></div>`;return;

  }

  const statsResult=await sb.rpc('dashboard_stats');const stats=statsResult.error?{}:(statsResult.data||{});

  box.innerHTML=pageHead('Super Admin','Users, assistant permissions, storage, moderation and audit history.','<button class="btn primary" id="invite-admin">Invite Assistant Admin</button>')+`<div class="stat-grid">${Object.entries(stats).map(([k,v])=>{const action=adminStatAction(k);return `<div class="card stat ${action?'admin-stat-action':''}" data-admin-stat-key="${U.attr(k)}" ${action?`data-admin-stat="${action}" role="button" tabindex="0" aria-label="Open ${U.attr(k)} details"`:''}><div class="muted">${U.esc(k)}</div><div class="value">${k.includes('bytes')?U.fmtBytes(v):U.esc(v)}</div></div>`}).join('')}</div><div class="tabs" id="admin-tabs" style="margin-top:20px"><button class="active" data-atab="accounts">Accounts</button><button data-atab="audit">Audit history</button><button data-atab="reports">Forum reports</button><button data-atab="forum">Forum control</button><button data-atab="groups">Groups</button><button data-atab="announce">Announcement</button></div><div id="admin-body"></div>`;

  U.q('#invite-admin').onclick=inviteAssistant;U.qa('[data-atab]').forEach(b=>b.onclick=()=>{U.qa('[data-atab]').forEach(x=>x.classList.toggle('active',x===b));adminTab(b.dataset.atab)});U.qa('[data-admin-stat]',box).forEach(card=>{const open=()=>openAdminStat(card.dataset.adminStat);card.onclick=open;card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open()}}});await adminTab('accounts');

}


function adminStatAction(key){
  if(key==='Tracked file bytes')return 'files';
  if(key==='Meetings')return 'meetings';
  if(key==='Inactive users')return 'inactive';
  if(key==='Active in 5 minutes')return 'active';
  return '';
}

async function refreshAdminStats(){
  const result=await sb.rpc('dashboard_stats');
  if(result.error)return;
  const stats=result.data||{};
  U.qa('[data-admin-stat-key]').forEach(card=>{
    const key=card.dataset.adminStatKey;
    if(!(key in stats))return;
    const value=U.q('.value',card);
    if(value)value.textContent=key.includes('bytes')?U.fmtBytes(stats[key]):String(stats[key]);
  });
}

async function adminDeleteUserFromStat(p){
  if(!p||p.id===S.user.id)return false;
  if(!await U.confirmBox('Delete user account',`Permanently delete ${p.full_name}'s account, sessions, access and linked member data? This cannot be undone.`,'Delete account'))return false;
  let deleted=false,rpcError=null,edgeError=null;
  try{
    try{const rpc=await sb.rpc('admin_delete_user',{target:p.id});if(rpc.error)rpcError=rpc.error;else deleted=rpc.data===true}catch(e){rpcError=e}
    if(!deleted){
      try{const edge=await sb.functions.invoke('admin-users',{body:{action:'delete',target:p.id,hard:true}});if(edge.error||edge.data?.error)edgeError=edge.error||new Error(edge.data.error);else deleted=true}catch(e){edgeError=e}
    }
    let exists=null;
    try{const verify=await sb.rpc('admin_user_exists',{target:p.id});if(!verify.error)exists=verify.data===true}catch{}
    if(exists===true||(!deleted&&exists!==false))throw edgeError||rpcError||new Error('Account deletion was blocked by the database.');
    U.toast('User account permanently deleted.','ok');
    await refreshAdminStats();
    return true;
  }catch(e){U.toast(U.errorText(e),'error');return false;}
}

async function adminOpenUserStat(mode){
  const result=await sb.rpc('admin_list_profiles');
  if(result.error){U.toast(U.errorText(result.error),'error');return;}
  const cutoff=Date.now()-5*60*1000;
  const all=result.data||[];
  const rows=all.filter(p=>{
    const last=p.last_active_at?new Date(p.last_active_at).getTime():NaN;
    return mode==='active'
      ? p.status==='active'&&Number.isFinite(last)&&last>cutoff
      : p.status==='disabled'||(Number.isFinite(last)&&last<=cutoff);
  });
  const title=mode==='active'?'Active in 5 minutes':'Inactive users';
  const r=U.modal({title,wide:true,body:`<div class="list" id="admin-stat-users">${rows.length?rows.map(p=>`<div class="list-item" data-stat-user="${p.id}"><div class="body"><b>${U.esc(p.full_name||'Member')}</b>${p.public_id?`<small class="muted">@${U.esc(p.public_id)}</small>`:''}<p>${U.esc((p.role||'student').replaceAll('_',' '))} · ${U.esc(p.status||'active')}</p><small>${p.last_active_at?'Last active '+U.fmtDate(p.last_active_at):'Last active unavailable'}</small></div>${p.id===S.user.id?'<span class="muted">Current Super Admin</span>':`<button class="btn danger small" data-stat-delete-user="${p.id}">Delete</button>`}</div>`).join(''):'<div class="empty">No users in this list.</div>'}</div>`,actions:'<button class="btn" data-close>Close</button>'});
  U.qa('[data-stat-delete-user]',r).forEach(b=>b.onclick=async()=>{const p=rows.find(x=>x.id===b.dataset.statDeleteUser);if(!p)return;b.disabled=true;const ok=await adminDeleteUserFromStat(p);if(ok){U.closeModal();await adminOpenUserStat(mode)}else if(b.isConnected)b.disabled=false;});
}

async function adminViewTrackedFile(file){
  if(!file?.object_path)return;
  try{
    const signed=await sb.storage.from('group-files').createSignedUrl(file.object_path,600);
    if(signed.error)throw signed.error;
    const url=signed.data?.signedUrl;if(!url)throw new Error('Preview link could not be created.');
    const mime=String(file.mime_type||'').toLowerCase(),name=file.name||'Tracked file';
    if(mime.startsWith('image/')||mime.startsWith('video/')){
      window.EduWorkspace.openMediaViewer({url,mime,name,download:async()=>{const d=await sb.storage.from('group-files').download(file.object_path);if(d.error)throw d.error;U.download(name,d.data,mime||d.data.type||'application/octet-stream');}});
      return;
    }
    if(mime.startsWith('audio/')){
      U.modal({title:name,wide:true,body:`<div class="card card-pad"><p class="muted">${U.esc(file.group_name||'Unknown group')} · ${U.fmtBytes(Number(file.size_bytes)||0)}</p><audio controls autoplay preload="metadata" style="width:100%" src="${U.attr(url)}"></audio></div>`,actions:'<button class="btn" data-close>Close</button>'});
      return;
    }
    if(mime==='application/pdf'){
      U.modal({title:name,wide:true,body:`<iframe title="${U.attr(name)}" src="${U.attr(url)}" style="width:100%;height:min(72dvh,760px);border:0;border-radius:12px;background:#fff"></iframe>`,actions:'<button class="btn" data-close>Close</button>'});
      return;
    }
    U.modal({title:name,wide:true,body:`<div class="card card-pad"><h3>${U.esc(name)}</h3><p>${U.fmtBytes(Number(file.size_bytes)||0)} · ${U.esc(file.mime_type||'file')}</p><p class="muted">${U.esc(file.group_name||'Unknown group')} · uploaded by ${U.esc(file.uploader_name||'Unknown user')}</p><p class="hint">This file type does not have an in-app preview. Use Open file to inspect it before deleting.</p><button class="btn primary" id="admin-open-tracked-file">Open file</button></div>`,actions:'<button class="btn" data-close>Close</button>'});
    U.q('#admin-open-tracked-file')?.addEventListener('click',()=>window.open(url,'_blank','noopener,noreferrer'));
  }catch(e){U.toast(U.errorText(e),'error');}
}

async function adminOpenTrackedFiles(){
  const result=await sb.rpc('admin_dashboard_files');
  if(result.error){U.toast(U.errorText(result.error),'error');return;}
  const rows=result.data||[];
  const r=U.modal({title:'Tracked files',wide:true,body:`<div class="list" id="admin-tracked-files">${rows.length?rows.map(f=>`<div class="list-item" data-admin-file="${f.id}"><div class="body"><b>${U.esc(f.name||'File')}</b><p>${U.fmtBytes(Number(f.size_bytes)||0)} · ${U.esc(f.mime_type||'file')}</p><small>${U.esc(f.group_name||'Unknown group')} · uploaded by ${U.esc(f.uploader_name||'Unknown user')} · ${U.fmtDate(f.created_at)}</small></div><div class="row wrap"><button class="btn small" data-admin-view-file="${f.id}">View</button><button class="btn danger small" data-admin-delete-file="${f.id}">Delete</button></div></div>`).join(''):'<div class="empty">No tracked group files.</div>'}</div>`,actions:'<button class="btn" data-close>Close</button>'});
  U.qa('[data-admin-view-file]',r).forEach(b=>b.onclick=()=>{const file=rows.find(x=>x.id===b.dataset.adminViewFile);if(file)adminViewTrackedFile(file);});
  U.qa('[data-admin-delete-file]',r).forEach(b=>b.onclick=async()=>{
    const file=rows.find(x=>x.id===b.dataset.adminDeleteFile);if(!file)return;
    if(!await U.confirmBox('Delete tracked file',`Delete ${file.name||'this file'} from storage and remove its shared file message?`,'Delete'))return;
    b.disabled=true;
    try{
      const storageResult=await sb.storage.from('group-files').remove([file.object_path]);
      if(storageResult.error)throw storageResult.error;
      const dbResult=await sb.rpc('admin_delete_tracked_file',{file_input:file.id});
      if(dbResult.error)throw dbResult.error;
      U.toast('Tracked file deleted.','ok');
      await refreshAdminStats();
      U.closeModal();
      await adminOpenTrackedFiles();
    }catch(e){U.toast(U.errorText(e),'error');if(b.isConnected)b.disabled=false;}
  });
}

async function adminOpenMeetingsStat(){
  const result=await sb.rpc('admin_dashboard_meetings');
  if(result.error){U.toast(U.errorText(result.error),'error');return;}
  const rows=result.data||[];
  const r=U.modal({title:'Meetings',wide:true,body:`<div class="list" id="admin-meeting-list">${rows.length?rows.map(m=>`<div class="list-item" data-admin-meeting="${m.id}"><div class="body"><b>${U.esc(m.title||'Meeting')}</b><p>${U.esc((m.meeting_kind||'meeting').replaceAll('_',' '))} · ${m.ended_at?'Ended':'Available'}</p><small>Host ${U.esc(m.host_name||'Unknown')} · ${U.esc(m.group_name||'No group')} · ${U.fmtDate(m.created_at)}</small></div><button class="btn danger small" data-admin-delete-meeting="${m.id}">Delete</button></div>`).join(''):'<div class="empty">No meetings.</div>'}</div>`,actions:`${rows.length?'<button class="btn danger" id="admin-clear-all-meetings">Clear all</button>':''}<button class="btn" data-close>Close</button>`});
  U.qa('[data-admin-delete-meeting]',r).forEach(b=>b.onclick=async()=>{
    const m=rows.find(x=>x.id===b.dataset.adminDeleteMeeting);if(!m)return;
    if(!await U.confirmBox('Delete meeting',`Delete ${m.title||'this meeting'} and its meeting history?`,'Delete'))return;
    b.disabled=true;
    try{const d=await sb.rpc('admin_delete_meeting',{meeting_input:m.id});if(d.error)throw d.error;U.toast('Meeting deleted.','ok');await refreshAdminStats();U.closeModal();await adminOpenMeetingsStat()}catch(e){U.toast(U.errorText(e),'error');if(b.isConnected)b.disabled=false;}
  });
  U.q('#admin-clear-all-meetings',r)?.addEventListener('click',async()=>{
    const total=rows.length;
    // confirmBox uses the same modal root. Close the meeting list first so we never
    // continue with a detached/stale modal button inside Android WebView.
    U.closeModal();
    const confirmed=await U.confirmBox('Clear all meetings',`Delete all ${total} meeting records? This cannot be undone.`,'Clear all');
    if(!confirmed){await adminOpenMeetingsStat();return;}
    try{
      let bulkError=null;
      const bulk=await sb.rpc('admin_clear_meetings');
      if(bulk.error)bulkError=bulk.error;

      // Always verify against the server. If the bulk RPC was blocked by one stale
      // dependency, safely fall back to the already-tested single-meeting RPC.
      let check=await sb.rpc('admin_dashboard_meetings');
      if(check.error)throw check.error;
      let remaining=check.data||[];
      if(bulkError||remaining.length){
        for(const m of remaining){
          const one=await sb.rpc('admin_delete_meeting',{meeting_input:m.id});
          if(one.error)throw one.error;
        }
        check=await sb.rpc('admin_dashboard_meetings');
        if(check.error)throw check.error;
        remaining=check.data||[];
      }
      if(remaining.length)throw bulkError||new Error(`${remaining.length} meeting records could not be cleared.`);

      U.toast(`${total} meeting records cleared.`,'ok');
      await refreshAdminStats();
    }catch(e){
      U.toast(U.errorText(e),'error');
      await adminOpenMeetingsStat();
    }
  });
}

async function openAdminStat(action){
  if(action==='files')return adminOpenTrackedFiles();
  if(action==='meetings')return adminOpenMeetingsStat();
  if(action==='active'||action==='inactive')return adminOpenUserStat(action);
}

async function adminTab(tab){const box=U.q('#admin-body');box.innerHTML='<div class="loading">Loading…</div>';if(tab==='accounts')return adminAccounts();if(tab==='audit')return adminAudit();if(tab==='reports')return adminReports();if(tab==='forum')return adminForumControl();if(tab==='groups')return adminGroups();if(tab==='announce')return adminAnnouncement()}

async function adminAccounts(){

  const box=U.q('#admin-body');let profiles=[],rm={};let result=await sb.rpc('admin_list_profiles');if(!result.error){profiles=result.data||[];rm=Object.fromEntries(profiles.map(x=>[x.id,x.role||'student']))}else{const direct=await sb.from('profiles').select('id,full_name,public_id,status,created_at,last_active_at').order('created_at',{ascending:false}).limit(250);if(direct.error){box.innerHTML=`<div class="card card-pad"><h3>Accounts</h3><p class="danger-text">${U.esc(U.errorText(result.error||direct.error))}</p><p>Run <b>SUPABASE_FINAL_FIX_2026_09_30.sql</b> once. The rest of the Admin Dashboard remains available.</p></div>`;return}profiles=direct.data||[];const ids=profiles.map(x=>x.id),roles=ids.length?(await sb.from('user_roles').select('*').in('user_id',ids)).data||[]:[];rm=Object.fromEntries(roles.map(x=>[x.user_id,x.role]))}

  box.innerHTML=`<div class="card card-pad"><div class="table-wrap"><table><thead><tr><th>User</th><th>Role</th><th>Status</th><th>Last active</th><th>Actions</th></tr></thead><tbody>${profiles.map(p=>`<tr><td><strong>${U.esc(p.full_name)}</strong>${p.public_id?`<br><span class="code">@${U.esc(p.public_id)}</span>`:''}<br><small class="muted">${U.esc(p.id)}</small></td><td>${U.esc((rm[p.id]||'student').replaceAll('_',' '))}</td><td><span class="badge ${p.status==='active'?'green':'red'}">${U.esc(p.status||'active')}</span></td><td>${p.last_active_at?U.fmtDate(p.last_active_at):'Never'}</td><td>${p.id===S.user.id?'<span class="muted">Current Super Admin</span>':`<button class="btn small" data-info-user="${p.id}">Info</button> <button class="btn small" data-access="${p.id}">Access</button>${rm[p.id]==='assistant_admin'?` <button class="btn ghost small" data-sessions="${p.id}">Sessions</button> <button class="btn ghost small" data-reset="${p.id}">Reset password</button>`:''} <button class="btn danger small" data-delete-user="${p.id}">Delete account</button>`}</td></tr>`).join('')}</tbody></table></div></div>`;

  U.qa('[data-access]',box).forEach(b=>b.onclick=()=>editAccount(b.dataset.access,profiles.find(x=>x.id===b.dataset.access),rm[b.dataset.access]||'student'));
  U.qa('[data-sessions]',box).forEach(b=>b.onclick=()=>showSessions(b.dataset.sessions,profiles.find(x=>x.id===b.dataset.sessions)));
  U.qa('[data-reset]',box).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Reset Assistant password','Send a password-reset email to this Assistant Admin?','Send reset'))return;const {data,error}=await sb.functions.invoke('admin-users',{body:{action:'reset',target:b.dataset.reset}});if(error||data?.error)U.toast(data?.error||U.errorText(error),'error');else U.toast('Reset email sent.','ok')});
  U.qa('[data-info-user]',box).forEach(b=>b.onclick=()=>{const p=profiles.find(x=>x.id===b.dataset.infoUser),role=rm[p.id]||'student';U.modal({title:'Member information',body:`<div class="stack"><p><b>Name:</b> ${U.esc(p.full_name||'')}</p><p><b>Public User ID:</b> <span class="code">${p.public_id?'@'+U.esc(p.public_id):'Not set'}</span></p><p><b>Account UUID:</b> <span class="code">${U.esc(p.id)}</span></p><p><b>Role:</b> ${U.esc(role.replaceAll('_',' '))}</p><p><b>Status:</b> ${U.esc(p.status||'')}</p><p><b>Created:</b> ${U.fmtDate(p.created_at)}</p><p><b>Last active:</b> ${p.last_active_at?U.fmtDate(p.last_active_at):'Never'}</p></div>`,actions:'<button class="btn" data-close>Close</button>'});});
  U.qa('[data-delete-user]',box).forEach(b=>b.onclick=async()=>{const p=profiles.find(x=>x.id===b.dataset.deleteUser);if(!p)return;if(!await U.confirmBox('Delete user account',`Permanently delete ${p.full_name}'s account, sessions, access and linked member data? This cannot be undone.`,'Delete account'))return;b.disabled=true;const label=b.textContent;b.textContent='Deleting…';try{let deleted=false,rpcError=null,edgeError=null;try{const rpc=await sb.rpc('admin_delete_user',{target:p.id});if(rpc.error)rpcError=rpc.error;else deleted=rpc.data===true}catch(e){rpcError=e}if(!deleted){try{const edge=await sb.functions.invoke('admin-users',{body:{action:'delete',target:p.id,hard:true}});if(edge.error||edge.data?.error)edgeError=edge.error||new Error(edge.data.error);else deleted=true}catch(e){edgeError=e}}let exists=null;try{const verify=await sb.rpc('admin_user_exists',{target:p.id});if(!verify.error)exists=verify.data===true}catch{}if(exists===true||(!deleted&&exists!==false)){const err=edgeError||rpcError||new Error('Account deletion was blocked by the database. Run SUPABASE_SUPER_ADMIN_DELETE_FIX_2026_09_30.sql once and try again.');throw err}U.toast('User account permanently deleted.','ok');await adminAccounts()}catch(e){const msg=U.errorText(e);U.toast(/admin_delete_user|function .* does not exist|permission denied|foreign key|constraint/i.test(msg)?msg+' — Run SUPABASE_SUPER_ADMIN_DELETE_FIX_2026_09_30.sql once.':msg,'error')}finally{if(b.isConnected){b.disabled=false;b.textContent=label}}});

}

async function editAccount(id,p,currentRole){

  let current=[];if(currentRole==='assistant_admin'){const r=await sb.from('assistant_admin_permissions').select('permission').eq('user_id',id);current=(r.data||[]).map(x=>x.permission)}

  const roleHtml=[['student','Student'],['assistant_admin','Assistant Admin']].map(x=>`<option value="${x[0]}" ${currentRole===x[0]?'selected':''}>${x[1]}</option>`).join('');const r=U.modal({title:`Access — ${p.full_name}`,body:`<div class="field"><label>Role</label><select id="acc-role" class="select">${roleHtml}</select></div><label class="switch"><input id="acc-enabled" type="checkbox" ${p.status==='active'?'checked':''}><span>Account enabled</span></label><h4>Assistant permissions</h4><div class="stack">${PERMS.map(x=>`<label class="switch"><input type="checkbox" data-perm="${U.attr(x)}" ${current.includes(x)?'checked':''}><span>${U.esc(x)}</span></label>`).join('')}</div><p class="hint">Super Admin role cannot be assigned from this screen.</p>`,actions:'<button class="btn ghost" data-close>Cancel</button><button class="btn primary" id="save-access">Save access</button>'});

  U.q('#save-access',r).onclick=async()=>{const new_role=U.q('#acc-role',r).value,enabled=U.q('#acc-enabled',r).checked,permissions=U.qa('[data-perm]:checked',r).map(x=>x.dataset.perm);const {error}=await sb.rpc('admin_account',{target:id,new_role,enabled,permissions});if(error)U.toast(U.errorText(error),'error');else{U.closeModal();U.toast('Account access updated.','ok');adminAccounts()}};

}

async function showSessions(id,p){const {data,error}=await sb.rpc('admin_sessions',{target:id});if(error){U.toast(U.errorText(error),'error');return}const r=U.modal({title:`Sessions — ${p.full_name}`,body:`<div class="list">${data?.length?data.map(s=>`<div class="list-item"><div class="body"><b>${U.esc(U.shortId(s.session_id))}</b><p>${U.fmtDate(s.created_at)}</p></div><button class="btn danger small" data-kick="${s.session_id}">Force logout</button></div>`).join(''):'<div class="empty">No active sessions.</div>'}</div>`,actions:'<button class="btn ghost" data-close>Close</button><button class="btn danger" id="kick-all">Force logout all devices</button>'});const kick=async sid=>{const {data:d,error:e}=await sb.functions.invoke('admin-users',{body:{action:'revoke',target:id,session_id:sid||null}});if(e||d?.error)U.toast(d?.error||U.errorText(e),'error');else{U.toast('Access revoked.','ok');U.closeModal()}};U.qa('[data-kick]',r).forEach(b=>b.onclick=()=>kick(b.dataset.kick));U.q('#kick-all',r).onclick=()=>kick(null)}

async function inviteAssistant(){const v=await U.promptBox({title:'Invite Assistant Admin',fields:[{label:'Full name',max:100},{label:'Email',type:'email'}],submit:'Send invitation',note:'The Assistant Admin will receive an email and can set a password through Supabase Auth.'});if(!v)return;const {data,error}=await sb.functions.invoke('admin-users',{body:{action:'invite',name:v[0],email:v[1]}});if(error||data?.error)U.toast(data?.error||U.errorText(error),'error');else{U.toast('Assistant Admin invitation sent.','ok');adminAccounts()}}

async function adminAudit(){const box=U.q('#admin-body');const {data,error}=await sb.from('admin_audit_logs').select('*').order('created_at',{ascending:false}).limit(250);if(error)throw error;box.innerHTML=`<div class="card card-pad"><div class="table-wrap"><table><thead><tr><th>Time</th><th>Admin</th><th>Action</th><th>Resource</th><th>Metadata</th></tr></thead><tbody>${data?.length?data.map(x=>`<tr><td>${U.fmtDate(x.created_at)}</td><td>${U.esc(x.actor_name)}</td><td>${U.esc(x.action)}</td><td>${U.esc(x.resource)}</td><td><span class="code">${U.esc(JSON.stringify(x.metadata||{}))}</span></td></tr>`).join(''):'<tr><td colspan="5">No audit events.</td></tr>'}</tbody></table></div></div>`}

async function adminReports(){const box=U.q('#admin-body');const {data,error}=await sb.from('forum_reports').select('*').order('created_at',{ascending:false}).limit(200);if(error)throw error;const names=await namesFor((data||[]).map(x=>x.reporter_id));box.innerHTML=`<div class="card card-pad"><div class="list">${data?.length?data.map(x=>`<div class="list-item"><div class="body"><h3>${U.esc(x.reason)}</h3><p>Reporter ${U.esc(names[x.reporter_id]?.full_name||'User')} • ${U.fmtDate(x.created_at)} • post ${U.shortId(x.post_id)}</p></div><label class="switch"><input type="checkbox" data-resolve="${x.id}" ${x.resolved?'checked':''}><span>Resolved</span></label></div>`).join(''):'<div class="empty">No reports.</div>'}</div></div>`;U.qa('[data-resolve]',box).forEach(c=>c.onchange=async()=>{const {error}=await sb.from('forum_reports').update({resolved:c.checked}).eq('id',c.dataset.resolve);if(error){c.checked=!c.checked;U.toast(U.errorText(error),'error')}})}

async function adminForumControl(){
 const box=U.q('#admin-body');let approval=false;try{const row=(await sb.from('forum_settings').select('require_approval').eq('id',1).maybeSingle()).data;approval=!!row?.require_approval}catch{}
 const pending=(await sb.from('forum_posts').select('id,title,body,public_author_id,created_at,approval_status').eq('approval_status','pending').order('created_at',{ascending:false}).limit(100));const rows=pending.error?[]:(pending.data||[]),names=await namesFor(rows.map(x=>x.public_author_id));
 box.innerHTML=`<div class="card card-pad"><h3>Forum moderation</h3><label class="switch"><input id="forum-approval-toggle" type="checkbox" ${approval?'checked':''}><span>Require admin approval for non-admin posts</span></label><p class="hint">When enabled, student posts stay pending until a Super Admin/authorized moderator approves them.</p><button class="btn" id="edit-forum-rules">Edit forum rules</button><h3 style="margin-top:22px">Pending posts</h3><div class="list">${rows.length?rows.map(x=>`<div class="list-item"><div class="body"><b>${U.esc(x.title||'Untitled')}</b><p>${U.esc((x.body||'').slice(0,220))}</p><small>${U.esc(names[x.public_author_id]?.full_name||'Member')} · ${U.fmtDate(x.created_at)}</small></div><button class="btn primary small" data-approve-post="${x.id}">Approve</button><button class="btn danger small" data-reject-post="${x.id}">Reject</button></div>`).join(''):'<div class="empty">No pending posts.</div>'}</div></div>`;
 U.q('#forum-approval-toggle').onchange=async e=>{const r=await sb.from('forum_settings').upsert({id:1,require_approval:e.target.checked,updated_by:S.user.id});if(r.error){e.target.checked=!e.target.checked;U.toast('Forum approval storage is not installed yet. Run the included Supabase feature update once.','error')}};
 U.q('#edit-forum-rules').onclick=editForumRules;U.qa('[data-approve-post]',box).forEach(b=>b.onclick=async()=>{const {error}=await sb.from('forum_posts').update({approval_status:'approved',approved_by:S.user.id,approved_at:new Date().toISOString()}).eq('id',b.dataset.approvePost);if(error)U.toast(U.errorText(error),'error');else adminForumControl()});U.qa('[data-reject-post]',box).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Reject post','Delete this pending forum post?','Reject'))return;const {error}=await sb.from('forum_posts').delete().eq('id',b.dataset.rejectPost);if(error)U.toast(U.errorText(error),'error');else adminForumControl()});
}
async function editForumRules(){
 const {data,error}=await sb.from('forum_rules').select('*').order('id');if(error){U.toast(U.errorText(error),'error');return}const r=U.modal({title:'Edit forum rules',wide:true,body:`<div id="rule-editor">${(data||[]).map((x,i)=>`<div class="card card-pad" data-rule-row="${x.id}"><label class="field">Title<input class="input" data-rule-title value="${U.attr(x.title||'')}"></label><label class="field">Rule<textarea class="textarea" data-rule-body>${U.esc(x.body||'')}</textarea></label></div>`).join('')}</div>`,actions:'<button class="btn" data-close>Cancel</button><button class="btn primary" id="save-rules">Save rules</button>'});U.q('#save-rules',r).onclick=async()=>{for(const row of U.qa('[data-rule-row]',r)){const update={title:U.q('[data-rule-title]',row).value.trim(),body:U.q('[data-rule-body]',row).value.trim()};const result=await sb.from('forum_rules').update(update).eq('id',row.dataset.ruleRow);if(result.error){U.toast(U.errorText(result.error),'error');return}}U.closeModal();U.toast('Forum rules updated.','ok')};
}
async function adminGroups(){
 const box=U.q('#admin-body'),{data,error}=await sb.from('groups').select('*').order('created_at',{ascending:false}).limit(200);if(error)throw error;box.innerHTML=`<div class="card card-pad"><h3>Groups control</h3><div class="list">${data?.length?data.map(g=>`<div class="list-item"><div class="body"><b>${U.esc(g.name)}</b><p>${U.esc(g.description||'')}</p></div><button class="btn small" data-admin-open-group="${g.id}">Open</button><button class="btn danger small" data-admin-delete-group="${g.id}">Delete</button></div>`).join(''):'<div class="empty">No groups.</div>'}</div></div>`;U.qa('[data-admin-open-group]',box).forEach(b=>b.onclick=()=>openGroup(b.dataset.adminOpenGroup));U.qa('[data-admin-delete-group]',box).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Delete group','Delete this group and its conversation?','Delete'))return;const {error}=await sb.from('groups').delete().eq('id',b.dataset.adminDeleteGroup);if(error)U.toast(U.errorText(error),'error');else adminGroups()});
}

async function adminAnnouncement(){const box=U.q('#admin-body');box.innerHTML=`<div class="card card-pad" style="max-width:720px"><h3>Send app-wide announcement</h3><p class="muted">Creates a notification for every active Edu Chat Pro account.</p><textarea id="admin-msg" class="textarea" maxlength="500" placeholder="Announcement"></textarea><button class="btn primary" id="send-ann" style="margin-top:10px">Send announcement</button></div>`;U.q('#send-ann').onclick=async()=>{const message=U.q('#admin-msg').value.trim();if(!message)return;const {error}=await sb.rpc('admin_announcement',{message});if(error)U.toast(U.errorText(error),'error');else{U.q('#admin-msg').value='';U.toast('Announcement sent.','ok')}}}



// Offline shell caching only. Authentication/data still require network.

if('serviceWorker' in navigator && location.protocol==='https:'){const registerSW=()=>navigator.serviceWorker.register('sw.js',{updateViaCache:'all'}).catch(()=>{});if('requestIdleCallback'in window)requestIdleCallback(registerSW,{timeout:15000});else setTimeout(registerSW,10000);}

async function selectGroupMembers(g,after){

 const r=U.modal({title:'Add group members',body:'<input class="input" id="member-search" placeholder="Search registered users by name" autocomplete="off"><p id="selected-count" class="hint">0 selected</p><div id="member-results" class="list"></div>',actions:'<button class="btn ghost" data-close>Cancel</button><button class="btn primary" id="confirm-members">Add selected</button>'});

 const selected=new Set();let generation=0,timer;

 async function search(){if(!U.q('#member-search',r))return;const gen=++generation;try{const rows=must(await sb.rpc('search_group_candidates',{group_id_input:g.id,name_query:U.q('#member-search',r).value.trim()}));if(gen!==generation||!r.isConnected)return;const list=U.q('#member-results',r);list.innerHTML=rows.length?rows.map(p=>`<label class="list-item"><input type="checkbox" data-person="${p.id}" ${selected.has(p.id)?'checked':''}>${avatarHtml(p)}<span>${U.esc(p.full_name)}</span></label>`).join(''):'<p class="empty">No matching users.</p>';hydrateAvatars(list);U.qa('[data-person]',list).forEach(c=>c.onchange=()=>{c.checked?selected.add(c.dataset.person):selected.delete(c.dataset.person);U.q('#selected-count',r).textContent=`${selected.size} selected`})}catch(e){U.toast(U.errorText(e),'error')}}

 U.q('#member-search',r).oninput=()=>{generation++;clearTimeout(timer);timer=setTimeout(search,250)};

 U.q('#confirm-members',r).onclick=async e=>{if(!selected.size)return;U.setBusy(e.target,true);try{must(await sb.rpc('add_group_members',{group_id_input:g.id,user_ids:[...selected]}));U.closeModal();await after()}catch(err){U.toast(U.errorText(err),'error')}finally{U.setBusy(e.target,false)}};await search();

}

async function sendGroupAttachment(g,file,duration=0,caption=""){

 if(!g.allow_member_messaging&&!isAdmin())throw new Error('Only Admin or Super Admin can post while member texting is off.');

 if(!file.size||file.size>10485760)throw new Error('Choose a file under 10 MB.');

 const types={pdf:'application/pdf',doc:'application/msword',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',ppt:'application/vnd.ms-powerpoint',pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',xls:'application/vnd.ms-excel',xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',zip:'application/zip',txt:'text/plain',csv:'text/csv'};

 const mime=types[file.name.split('.').pop().toLowerCase()]||attachmentMime(file);

 const path=`${g.id}/${U.uuid()}/${U.safeName(file.name)}`;must(await sb.storage.from('group-files').upload(path,file,{contentType:mime}));let meta;

 try{meta=must(await sb.from('group_files').insert({group_id:g.id,uploaded_by:S.user.id,name:U.safeName(file.name),object_path:path,size_bytes:file.size,mime_type:mime}).select().single());must(await sb.from('group_messages').insert({group_id:g.id,sender_id:S.user.id,body:caption||(mime.startsWith('audio/')?'Voice message':'Shared a file'),file_id:meta.id,duration_ms:duration}));}catch(e){await sb.storage.from('group-files').remove([path]);if(meta)await sb.from('group_files').delete().eq('id',meta.id);throw e}

}

const reactionEmoji={like:'👍',love:'❤️',care:'🥰',haha:'😂',wow:'😮',sad:'😢',angry:'😡'};

async function hydrateSocial(root){

 U.qa('[data-forum-image]',root).forEach(img=>{const wrap=document.createElement('div');wrap.innerHTML=mediaMarkup('forum-images',img.dataset.forumImage,'','Shared media');img.replaceWith(wrap)});await hydrateMedia(root);

 await Promise.all(U.qa('[data-reactions]',root).map(hydrateReaction));

}

async function hydrateReaction(bar){

 try{let result=await sb.rpc('forum_reaction_summary',{post_input:bar.dataset.reactions}),summary;

 if(['PGRST202','42883'].includes(result.error?.code)){summary={counts:{},mine:null};for(let offset=0;;offset+=500){const rows=must(await sb.from('forum_reactions').select('user_id,reaction').eq('post_id',bar.dataset.reactions).order('user_id').range(offset,offset+499))||[];for(const row of rows){summary.counts[row.reaction]=(summary.counts[row.reaction]||0)+1;if(row.user_id===S.user.id)summary.mine=row.reaction}if(rows.length<500)break}}else summary=must(result);

 summary=summary||{counts:{},mine:null};bar.innerHTML=Object.entries(reactionEmoji).map(([key,emoji])=>`<button class="reaction ${summary.mine===key?'active':''}" data-reaction="${key}" title="${key}" aria-pressed="${summary.mine===key}">${emoji} <span>${summary.counts?.[key]||0}</span></button>`).join('');

 U.qa('[data-reaction]',bar).forEach(b=>b.onclick=async()=>{U.qa('button',bar).forEach(x=>x.disabled=true);try{if(summary.mine===b.dataset.reaction)must(await sb.from('forum_reactions').delete().eq('post_id',bar.dataset.reactions).eq('user_id',S.user.id));else must(await sb.from('forum_reactions').upsert({post_id:bar.dataset.reactions,user_id:S.user.id,reaction:b.dataset.reaction}));await hydrateReaction(bar)}catch(e){U.toast(U.errorText(e),'error');U.qa('button',bar).forEach(x=>x.disabled=false)}});

 }catch(e){bar.textContent='Reactions unavailable: '+U.errorText(e)}

}



async function renderPeople(){

 S.page='people';U.qa('[data-nav]',app()).forEach(x=>x.classList.toggle('active',x.dataset.nav==='people'));chatLayout();

 cleanupChannel();S.group=null;S.direct=null;

 const box=U.q('#page');box.innerHTML=pageHead('Chats','Find a registered Edu Chat Pro user and start a conversation.','<button class="btn ghost" id="return-groups">Groups</button>')+'<div class="card card-pad"><input class="input" id="people-query" placeholder="Search by name or @UserID" autocomplete="off"><div class="list" id="people-results"></div><button class="btn ghost" id="people-more">Load more</button></div>';

 U.q('#return-groups').onclick=()=>navigate('groups');let offset=0,generation=0,timer;

 async function load(append=false){const input=U.q('#people-query');if(!input)return;const gen=++generation;try{const q=input.value.trim().replace(/^@/,'');let rows=[];if(q){const r=await sb.rpc('search_public_profiles',{search_text:q,max_results:30});if(r.error)throw r.error;rows=r.data||[]}else{let query=sb.from('profiles').select('id,full_name,avatar_path,public_id').eq('status','active').neq('id',S.user.id).order('full_name').order('id').range(offset,offset+29);rows=must(await query)}if(gen!==generation||!U.q('#people-query'))return;const list=U.q('#people-results');if(!append)list.innerHTML='';list.insertAdjacentHTML('beforeend',rows.map(p=>`<div class="list-item">${avatarHtml(p)}<div class="body"><h3>${U.esc(p.full_name)}</h3>${window.EduPresence.badge(p.id)}${p.public_id?`<small class="muted">@${U.esc(p.public_id)}</small>`:''}</div><button class="btn primary small" data-dm-user="${p.id}">${U.icon('chat')} Message</button></div>`).join(''));if(!offset&&!rows.length)list.innerHTML='<p class="empty">No matching users.</p>';U.q('#people-more').hidden=!!q||rows.length<30;U.qa('[data-dm-user]',list).forEach(b=>b.onclick=()=>openDirectChat(b.dataset.dmUser));await hydrateAvatars(list)}catch(e){U.toast(U.errorText(e),'error')}}

 U.q('#people-query').oninput=()=>{generation++;clearTimeout(timer);offset=0;timer=setTimeout(()=>load(),250)};U.q('#people-more').onclick=()=>{offset+=30;load(true)};await load();

}

async function renderDirectConversation(id){

 try{

 cleanupChannel();S.page='people';U.qa('[data-nav]',app()).forEach(x=>x.classList.toggle('active',x.dataset.nav==='people'));S.group=null;S.direct=id;

 let person=must(await sb.from('profiles').select('id,full_name,avatar_path').eq('id',id).single());

 chatLayout('direct');const box=U.q('#page');box.innerHTML=`<div class="direct-heading row"><button class="btn ghost" id="dm-back">←</button>${avatarHtml(person)}<div class="body"><h2>${U.esc(person.full_name)}</h2><span class="muted">Private conversation</span></div><div class="spacer"></div><button class="btn ghost" id="dm-audio" title="Audio call">${U.icon('phone')}</button><button class="btn ghost" id="dm-video" title="Video call">${U.icon('camera')}</button></div><div class="card card-pad chat-panel"><button type="button" class="btn ghost small" id="dm-older">Load older messages</button><div class="chat-log" id="dm-log"></div><form class="composer" id="dm-form"><div class="row"><button type="button" class="btn attach-button" id="dm-attach" aria-label="Attach file">+</button><input type="file" hidden id="dm-file"><input class="input" id="dm-text" maxlength="4000" placeholder="Write a message…" required><button class="btn primary">${U.icon('send')} Send</button></div></form></div>`;

 U.q('#dm-back').onclick=()=>navigate('chats');hydrateAvatars(box);

 let dmLimit=30,dmLoadGeneration=0,dmSignature='';const load=async()=>{const generation=++dmLoadGeneration;const rows=must(await sb.from('direct_messages').select('*').or(`and(sender_id.eq.${S.user.id},recipient_id.eq.${id}),and(sender_id.eq.${id},recipient_id.eq.${S.user.id})`).order('created_at',{ascending:false}).limit(dmLimit));if(generation!==dmLoadGeneration||S.direct!==id||!U.q('#dm-log'))return;const updatedPerson=await namesFor([id]);person=updatedPerson[id]||person;const log=U.q('#dm-log');if(!log||S.direct!==id)return;const signature=JSON.stringify([rows,person]);if(signature===dmSignature){hydrateChatReactions(log,'direct');return}dmSignature=signature;const nearBottom=log.scrollHeight-log.scrollTop-log.clientHeight<100;syncMessages(log,rows.length?[...rows].reverse().map(m=>`<div data-message-id="${m.id}" data-created="${m.created_at}" data-stamp="${U.attr(JSON.stringify([m,person]))}" class="message-row ${m.sender_id===S.user.id?'mine':''}">${avatarHtml(m.sender_id===S.user.id?S.profile:person)}<div class="message ${m.sender_id===S.user.id?'mine':''}"><div class="meta">${messageMeta(person.full_name,m.created_at,m.sender_id===S.user.id)}</div><div class="bodytext">${U.esc(m.body)}</div>${m.attachment_path?mediaMarkup('direct-files',m.attachment_path,m.mime_type,m.file_name):''}${m.sender_id===S.user.id?`<button class="text-btn danger-text" data-dm-delete="${m.id}">Delete</button>`:''}</div></div>`).join(''):'<div class="empty chat-empty"><div class="chat-art">•••</div><h2>No messages yet</h2><p>Say hello and start a conversation.</p></div>');const older=U.q('#dm-older');if(older)older.hidden=rows.length<dmLimit;await hydrateAvatars(log);await hydrateMedia(log);linkGroupInvites(log);addDayMarkers(log);hydrateChatReactions(log,S.group?'group':'direct');if(nearBottom)log.scrollTop=log.scrollHeight;U.qa('[data-dm-delete]',log).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Delete message','Delete your message?','Delete'))return;try{must(await sb.from('direct_messages').delete().eq('id',b.dataset.dmDelete).eq('sender_id',S.user.id));await load()}catch(e){U.toast(U.errorText(e),'error')}})};

 U.q('#dm-older').onclick=()=>{dmLimit+=30;load().catch(e=>U.toast(U.errorText(e),'error'))};

 U.q('#dm-attach').onclick=()=>U.q('#dm-file').click();U.q('#dm-file').onchange=async e=>{const file=e.target.files?.[0];if(!file)return;const b=U.q('#dm-attach');b.disabled=true;try{await sendDirectAttachment(id,file);await load()}catch(err){U.toast(U.errorText(err),'error')}finally{b.disabled=false;e.target.value=''}};installVoice(U.q('#dm-form'),async(file,duration)=>{await sendDirectAttachment(id,file,duration);await load()});S.pageRefresh=load;

 U.q('#dm-form').onsubmit=async e=>{e.preventDefault();const input=U.q('#dm-text'),body=input.value.trim(),button=e.submitter;if(!body)return;U.setBusy(button,true);try{must(await sb.rpc('send_direct_message',{other:id,message:body}));input.value='';await load();const log=U.q('#dm-log');if(log)log.scrollTop=log.scrollHeight}catch(e){U.toast(U.errorText(e),'error')}finally{U.setBusy(button,false)}};

 for(const [selector,video]of [['#dm-audio',false],['#dm-video',true]])U.q(selector).onclick=async e=>{const button=e.currentTarget;U.setBusy(button,true);try{const meeting=must(await sb.rpc('start_direct_call',{target:id,video}));await openMeeting(must(await sb.from('meetings').select('*').eq('id',meeting).single()),{autoJoin:true,video})}catch(e){U.toast(U.errorText(e),'error')}finally{U.setBusy(button,false)}};

 await load();const log=U.q('#dm-log');if(log)log.scrollTop=log.scrollHeight;

 S.channel=sb.channel(`dm-${S.user.id}-${id}`).on('postgres_changes',{event:'*',schema:'public',table:'direct_messages',filter:`recipient_id=eq.${S.user.id}`},()=>load().catch(()=>{})).on('postgres_changes',{event:'*',schema:'public',table:'direct_messages',filter:`sender_id=eq.${S.user.id}`},()=>load().catch(()=>{})).on('postgres_changes',{event:'*',schema:'public',table:'message_reactions'},()=>{const log=U.q('#dm-log');if(log)hydrateChatReactions(log,'direct')}).subscribe();

 }catch(e){U.toast(U.errorText(e),'error')}

}

async function receiveDirectCall(n){

 if(S.incoming||S.incomingLoading||document.querySelector('.meeting-shell'))return;

 const age=Date.now()-Date.parse(n.created_at);if(Number.isFinite(age)&&age>60000)return;

 S.incomingLoading=true;

 try{const meeting=must(await sb.from('meetings').select('*').eq('id',n.resource_id).single());if(meeting.ended_at||S.cancelledCalls?.has(n.id)||!S.user)return;

 const dialog=document.createElement('dialog'),group=n.kind==='group_call';dialog.className='incoming-call';dialog.innerHTML=`<div class="call-ring">${U.icon('phone')}</div><h2>${group?'Incoming group meeting':n.kind==='direct_call_video'?'Incoming video call':'Incoming audio call'}</h2><p>${U.esc(n.title)}</p><div class="row center"><button class="btn danger" data-decline>${group?'Dismiss':'Decline'}</button><button class="btn primary" data-answer>${group?'Join':'Answer'}</button></div>`;document.body.appendChild(dialog);dialog.showModal();let timeout;

 const close=()=>{clearTimeout(timeout);if(dialog.open)dialog.close();dialog.remove();if(S.incoming?.id===n.id)S.incoming=null;window.EduPush.dismiss(n.id)};

 S.incoming={id:n.id,close};dialog.oncancel=e=>{e.preventDefault();dialog.querySelector('[data-decline]').click()};timeout=setTimeout(close,Math.max(1000,60000-(Number.isFinite(age)?age:0)));

 dialog.querySelector('[data-decline]').onclick=async()=>{close();if(group)return;try{must(await sb.rpc('decline_direct_call',{meeting:meeting.id}))}catch(e){U.toast(U.errorText(e),'error')}};

 dialog.querySelector('[data-answer]').onclick=async()=>{close();try{const current=must(await sb.from('meetings').select('*').eq('id',meeting.id).single());await openMeeting(current,{autoJoin:true});must(await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('id',n.id))}catch(e){U.toast(U.errorText(e),'error')}};

 }catch(e){U.toast(U.errorText(e),'error')}finally{S.incomingLoading=false}

}



async function openNotification(n){

 try{

 if(n.target_kind==='group'){await openGroup(n.target_id);}
 else if(n.target_kind==='direct'){window.EduWorkspace.pending={kind:'direct',id:n.target_id};await navigate('people');}
 else if(n.target_kind==='forum'){window.EduWorkspace.pendingPost=n.target_id;await navigate('forum');}
 else if(['direct_call_audio','direct_call_video','group_call','missed_call'].includes(n.kind)){const m=must(await sb.from('meetings').select('*').eq('id',n.resource_id).maybeSingle());if(m&&!m.ended_at)await openMeeting(m);else U.toast('This call has ended.');}

 else if(n.kind==='meetings'){const m=must(await sb.from('meetings').select('*').eq('id',n.resource_id).maybeSingle());if(m)await openMeeting(m,{autoJoin:false});else await openGroup(n.resource_id,'meetings');}

 else if(n.kind==='direct_message'){const m=must(await sb.from('direct_messages').select('sender_id,recipient_id').eq('id',n.resource_id).single());await openDirectChat(m.sender_id===S.user.id?m.recipient_id:m.sender_id);}

 else if(n.kind==='mention'){if(n.target_kind==='group'||n.resource_id)await openGroup(n.target_id||n.resource_id,'chat');else await navigate('chats');}
 else if(n.kind==='group_invite'||n.kind==='group_files'||n.kind==='group_messages'||n.kind==='group_message'||n.kind==='announcement'){await openGroup(n.resource_id,n.kind==='group_files'?'files':'chat');}

 else if(['forum','forum_post','forum_reaction'].includes(n.kind)){await openPost(must(await sb.from('forum_posts').select('*').eq('id',n.resource_id).single()));}

 else await navigate('notifications');

 must(await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('id',n.id));

 }catch(e){U.toast(U.errorText(e),'error')}

}



document.addEventListener('visibilitychange',()=>{if(!document.hidden){railRefresh?.();S.meetingRefresh?.();if(!['chats','groups','people','forum'].includes(S.page))Promise.resolve(S.pageRefresh?.()).catch(()=>{})}});

window.addEventListener('online',()=>{railRefresh?.();S.meetingRefresh?.();if(!['chats','groups','people','forum'].includes(S.page))Promise.resolve(S.pageRefresh?.()).catch(()=>{})});

window.addEventListener('edu-alerts-updated',()=>S.alertsRefresh?.());

navigator.serviceWorker?.addEventListener('message',async e=>{if(e.data?.type!=='edu-open-notification'||!S.user)return;try{const n=must(await sb.from('notifications').select('*').eq('id',e.data.id).eq('user_id',S.user.id).maybeSingle());if(n){if(document.querySelector('.meeting-shell')){U.toast(n.title||'Notification');return}await openNotification(n)}}catch(err){U.toast(U.errorText(err),'error')}});

// Shared web/mobile attachment schema. Signed URLs are cached only in memory.

const mediaUrls=new Map();

async function mediaUrl(bucket,path,download=false){

 const key=bucket+'/'+path,hit=mediaUrls.get(key);

 if(!download&&hit&&hit.until>Date.now())return hit.url;

 const data=must(await sb.storage.from(bucket).createSignedUrl(path,3600,download?{download:U.safeName(path.split('/').pop())}:{}));

 if(!download){if(mediaUrls.size>300)mediaUrls.delete(mediaUrls.keys().next().value);mediaUrls.set(key,{url:data.signedUrl,until:Date.now()+3300000})}return data.signedUrl;

}

function mediaMarkup(bucket,path,mime='',name='Attachment'){
 const image=mime.startsWith('image/')||/\.(jpg|jpeg|png|webp)$/i.test(path),video=(mime.startsWith('video/')||/\.(mp4|mov|webm)$/i.test(path))&&!mime.startsWith('audio/'),audio=mime.startsWith('audio/');
 const actions=(image||video)?`<details class="ws-media-more"><summary aria-label="Media actions">⋮</summary><div class="ws-media-more-menu"><button type="button" data-media-download>Download</button></div></details>`:audio?'':`<div class="row wrap"><span>${U.esc(name)}</span><button type="button" class="btn ghost small" data-media-open>Open</button><button type="button" class="btn ghost small" data-media-download>Download</button></div>`;
 return `<div class="media-attachment ${image||video?'ws-media-attachment':''}" data-media-bucket="${U.attr(bucket)}" data-media-path="${U.attr(path)}" data-media-mime="${U.attr(mime)}" data-media-name="${U.attr(name)}"><div class="media-content"></div>${actions}</div>`;
}

async function hydrateMedia(root){
 await Promise.all(U.qa('[data-media-path]',root).map(async el=>{
 if(el.dataset.ready)return;el.dataset.ready='1';
 const bucket=el.dataset.mediaBucket,path=el.dataset.mediaPath,mime=el.dataset.mediaMime,name=el.dataset.mediaName||'Attachment';
 const kind=mime.startsWith('image/')||/\.(jpg|jpeg|png|webp)$/i.test(path)?'img':mime.startsWith('video/')||/\.(mp4|mov|webm)$/i.test(path)&&!mime.startsWith('audio/')?'video':mime.startsWith('audio/')?'audio':null;
 try{
 const url=kind==='img'?await window.EduPhotos.get(sb,S.user.id,bucket,path):await mediaUrl(bucket,path);if(!el.isConnected)return;
 const download=async()=>{const link=document.createElement('a');link.href=await mediaUrl(bucket,path,true);link.download=U.safeName(name||path.split('/').pop());link.target='_blank';link.rel='noopener';link.click()};
 const open=()=>{if(!kind){window.open(url,'_blank','noopener');return}window.EduWorkspace.openMediaViewer({url,mime,name,download});};
 el.querySelector('[data-media-open]')?.addEventListener('click',open);
 const dl=el.querySelector('[data-media-download]');if(dl)dl.onclick=async e=>{e.preventDefault();e.stopPropagation();try{await download();el.querySelector('.ws-media-more')?.removeAttribute('open')}catch(err){U.toast(U.errorText(err),'error')}};
 if(kind){const node=document.createElement(kind);node.src=url;if(kind==='img'){node.alt='Shared image';node.loading='lazy';node.decoding='async';}else if(kind==='video'){node.muted=true;node.playsInline=true;node.preload='metadata';}else{node.controls=true;node.preload='metadata';node.playsInline=true;}if(kind==='img'||kind==='video'){node.className='ws-inline-media '+(kind==='img'?'ws-inline-image':'ws-inline-video');node.tabIndex=0;node.setAttribute('role','button');node.onclick=e=>{e.preventDefault();open()};node.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open()}};}el.querySelector('.media-content').append(node);if(kind==='video'){const play=document.createElement('span');play.className='ws-inline-video-play';play.textContent='▶';el.querySelector('.media-content').classList.add('ws-inline-video-wrap');el.querySelector('.media-content').append(play);}}
 }catch(e){el.dataset.ready='';el.querySelector('.media-content').textContent='Preview unavailable. Reopen this conversation to retry.'}
 }));
}

function attachmentMime(file){const ext=file.name.split('.').pop().toLowerCase();return ({mp4:'video/mp4',mov:'video/quicktime',webm:file.type.startsWith('audio/')?'audio/webm':'video/webm',m4a:'audio/mp4',mp3:'audio/mpeg',ogg:'audio/ogg',wav:'audio/wav',aac:'audio/aac'})[ext]||file.type||'application/octet-stream'}

async function sendDirectAttachment(other,file,duration=0,caption=""){

 if(!file.size||file.size>10485760)throw new Error('Choose a file under 10 MB.');const mime=attachmentMime(file),path=`${S.user.id}/${other}/${U.uuid()}/${U.safeName(file.name)}`;

 must(await sb.storage.from('direct-files').upload(path,file,{contentType:mime}));try{must(await sb.rpc('send_direct_attachment',{other,path_input:path,name_input:U.safeName(file.name),mime_input:mime,size_input:file.size,duration_input:duration}))}catch(e){await sb.storage.from('direct-files').remove([path]);throw e}if(caption){const result=await sb.rpc('send_direct_message',{other,message:caption});if(result.error)U.toast('Attachment sent, but caption failed: '+U.errorText(result.error),'error');}

}

function installVoice(form,send){

 if(!window.MediaRecorder||!navigator.mediaDevices?.getUserMedia)return;

 const button=document.createElement('button');button.type='button';button.className='btn ghost voice-button';button.title='Record voice message';button.textContent='🎙';form.querySelector('.row').append(button);

 button.onclick=async()=>{let stream,recorder,limitTimer,clockTimer,cancelled=false,finished=false,file=null,duration=0,previewUrl='';button.disabled=true;
 try{stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}});const mime=['audio/mp4','audio/webm;codecs=opus','audio/ogg;codecs=opus'].find(t=>MediaRecorder.isTypeSupported(t));if(!mime)throw new Error('Voice recording is not supported by this browser.');recorder=new MediaRecorder(stream,{mimeType:mime});const chunks=[],startAt=Date.now();
 const bars=Array.from({length:14},()=>'<span></span>').join('');const d=document.createElement('dialog');d.className='voice-dialog';d.innerHTML=`<h2>Voice message</h2><div class="voice-record-panel" data-recording-view><div class="voice-record-mic recording">🎙</div><div class="voice-wave">${bars}</div><div class="voice-timer" data-voice-time>00:00</div><div class="voice-status">Recording… tap ✓ Done when finished.</div><div class="voice-actions"><button class="btn ghost" data-cancel>Cancel</button><button class="btn primary voice-done" data-done title="Done recording" aria-label="Done recording">✓ Done</button></div></div><div class="voice-review hidden" data-review-view><p class="voice-status">Recording complete. Preview it, then send.</p><audio controls data-preview></audio><div class="voice-actions"><button class="btn ghost" data-discard>Cancel</button><button class="btn primary" data-send>Send voice</button></div></div>`;document.body.append(d);d.showModal();
 const stopTracks=()=>{stream?.getTracks().forEach(t=>{try{t.stop()}catch{}})};const updateTime=()=>{const ms=Math.min(120000,Date.now()-startAt),sec=Math.floor(ms/1000);U.q('[data-voice-time]',d).textContent=String(Math.floor(sec/60)).padStart(2,'0')+':'+String(sec%60).padStart(2,'0')};
 const finish=()=>{if(finished)return;finished=true;duration=Math.min(120000,Date.now()-startAt);clearTimeout(limitTimer);clearInterval(clockTimer);if(recorder.state!=='inactive')recorder.stop();stopTracks()};
 const close=()=>{clearTimeout(limitTimer);clearInterval(clockTimer);stopTracks();if(previewUrl)URL.revokeObjectURL(previewUrl);d.remove();button.disabled=false};
 U.q('[data-cancel]',d).onclick=()=>{cancelled=true;finish();close()};U.q('[data-done]',d).onclick=finish;d.oncancel=e=>{e.preventDefault();cancelled=true;finish();close()};
 U.q('[data-discard]',d).onclick=()=>{cancelled=true;close()};U.q('[data-send]',d).onclick=async()=>{if(!file)return;const b=U.q('[data-send]',d);U.setBusy(b,true,'Sending…');try{await send(file,duration);close()}catch(e){U.toast(U.errorText(e),'error');if(b.isConnected)U.setBusy(b,false)}};
 recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};recorder.onstop=()=>{if(cancelled||!d.isConnected)return;const type=mime.split(';')[0],ext=type==='audio/mp4'?'m4a':type==='audio/ogg'?'ogg':'webm';file=new File(chunks,'voice.'+ext,{type});previewUrl=URL.createObjectURL(file);U.q('[data-recording-view]',d).classList.add('hidden');U.q('[data-review-view]',d).classList.remove('hidden');U.q('[data-preview]',d).src=previewUrl};
 recorder.start(250);updateTime();clockTimer=setInterval(updateTime,250);limitTimer=setTimeout(finish,120000);
 }catch(e){stream?.getTracks().forEach(t=>t.stop());button.disabled=false;U.toast(U.errorText(e),'error')}
 };
}

async function uploadForumMedia(file){

 if(!file.size||file.size>10485760)throw new Error('Choose a photo or video under 10 MB.');const video=file.type.startsWith('video/'),mime=video?attachmentMime(file):'image/jpeg';if(video&&!['video/mp4','video/webm','video/quicktime'].includes(mime))throw new Error('Choose MP4, WebM or MOV video.');

 const path=`${U.uuid()}/${U.uuid()}.${video?(mime==='video/mp4'?'mp4':mime==='video/webm'?'webm':'mov'):'jpg'}`;must(await sb.storage.from('forum-images').upload(path,video?file:await compressAvatar(file),{contentType:mime}));return path;

}

function offerWebPermissions(){

 if(localStorage.getItem('ecp-web-permissions-v1'))return;

 const banner=document.createElement('section');banner.className='permission-banner card';banner.innerHTML='<strong>Enable calls & notifications</strong><p>Allow camera, microphone and browser notifications. You can change these in site settings.</p><button class="btn primary" data-enable>Enable</button> <button class="btn ghost" data-later>Later</button>';

 document.body.append(banner);banner.querySelector('[data-later]').onclick=()=>{localStorage.setItem('ecp-web-permissions-v1','later');banner.remove()};

 banner.querySelector('[data-enable]').onclick=async e=>{e.target.disabled=true;try{await enableWebAlerts();try{const stream=await navigator.mediaDevices.getUserMedia({audio:true,video:true});stream.getTracks().forEach(t=>t.stop())}catch{U.toast('Camera or microphone was not enabled. You can allow it when joining a call.')}localStorage.setItem('ecp-web-permissions-v1','done')}finally{banner.remove()}};

}

async function oldRenderChatThreads(){

 chatLayout();cleanupChannel();S.group=null;S.direct=null;S.page='groups';

 const box=U.q('#page');box.innerHTML=pageHead('Chats','Your groups and personal conversations.','<button class="btn ghost" id="new-private">New message</button>'+(can('groups.manage')?'<button class="btn primary" id="create-thread-group">+ New group</button>':''))+'<input class="input" id="thread-search" placeholder="Search loaded conversations…"><div id="thread-list" class="list thread-list"></div><button class="btn ghost" id="thread-more">Load more</button>';

 U.q('#new-private').onclick=renderPeople;U.q('#create-thread-group')?.addEventListener('click',async()=>{const v=await U.promptBox({title:'Create group',fields:[{label:'Group name',max:120},{label:'Description',type:'textarea',required:false,max:2000}],submit:'Create'});if(!v)return;try{const g=must(await sb.from('groups').insert({name:v[0],description:v[1],created_by:S.user.id}).select().single());await openGroup(g.id)}catch(e){U.toast(U.errorText(e),'error')}});

 let rows=[],loading=false,offset=0,limit=30,timer;

 const paint=()=>{if(!box.isConnected||!U.q('#thread-list'))return;const query=U.q('#thread-search').value.toLowerCase(),list=U.q('#thread-list');list.innerHTML=rows.filter(t=>(t.name+' '+t.preview).toLowerCase().includes(query)).map(t=>`<article class="list-item thread-row"><button class="thread-open" data-kind="${t.thread_kind}" data-thread="${t.thread_id}">${t.thread_kind==='group'?`<span class="avatar">${groupImage({image_path:t.avatar_path})}</span>`:avatarHtml({full_name:t.name,avatar_path:t.avatar_path})}<span class="thread-copy"><strong>${U.esc(t.name)}</strong><span class="muted">${U.esc(t.preview||'Start a conversation')}</span><small>${t.thread_kind==='group'?'Group':'Private'} · ${U.fmtDate(t.updated_at)}</small></span></button><button class="btn ghost small" data-pin="${t.thread_id}" data-kind="${t.thread_kind}" aria-pressed="${t.pinned}" title="${t.pinned?'Unpin':'Pin'}">${t.pinned?'★ Unpin':'☆ Pin'}</button></article>`).join('')||'<p class="empty">No conversations yet.</p>';hydrateAvatars(list);hydrateGroupImages(list);

 U.qa('[data-thread]',list).forEach(b=>b.onclick=()=>b.dataset.kind==='group'?openGroup(b.dataset.thread):openDirectChat(b.dataset.thread));U.qa('[data-pin]',list).forEach(b=>b.onclick=async()=>{b.disabled=true;try{const t=rows.find(t=>t.thread_id===b.dataset.pin&&t.thread_kind===b.dataset.kind),key={user_id:S.user.id,thread_kind:t.thread_kind,thread_id:t.thread_id};must(t.pinned?await sb.from('chat_pins').delete().match(key):await sb.from('chat_pins').upsert(key));await load(true)}catch(e){U.toast(U.errorText(e),'error')}finally{b.disabled=false}})};

 const load=async(reset=false)=>{if(loading)return;loading=true;try{const found=[];if(reset)offset=0;const pages=reset?Math.ceil(limit/30):1;for(let i=0;i<pages;i++){const part=must(await sb.rpc('mobile_chat_threads',{page_offset:offset+found.length}));found.push(...part);if(part.length<30)break}if(S.page!=='groups'||!U.q('#thread-list'))return;rows=reset?found:[...rows,...found];offset=rows.length;limit=Math.max(30,offset);U.q('#thread-more').hidden=found.length<pages*30;paint()}catch(e){U.toast(U.errorText(e),'error')}finally{loading=false}};

 U.q('#thread-search').oninput=paint;U.q('#thread-more').onclick=()=>load();S.pageRefresh=()=>load(true);await load();

 const refresh=()=>{clearTimeout(timer);timer=setTimeout(()=>{if(S.page==='groups'&&U.q('#thread-list'))load(true)},250)};

 S.channel=sb.channel('chat-thread-updates');for(const table of ['chat_pins','group_messages','direct_messages','group_members','groups','profiles'])S.channel.on('postgres_changes',{event:'*',schema:'public',table},refresh);S.channel.subscribe();

}



async function renderGroups(){return renderChatThreads()}

function linkGroupInvites(root){U.qa('.bodytext,.ws-message-body,.message>div:not(.meta)',root).forEach(el=>{if(el.children.length)return;const matches=el.textContent.match(/https:\/\/[^\s<>]+/g)||[];for(const value of matches){try{const url=new URL(value),code=url.searchParams.get('group_invite');if(url.origin!==location.origin||!U.isUuid(code))continue;const button=document.createElement('button');button.className='btn small';button.textContent='Join group';button.onclick=()=>acceptGroupInvite(code);el.append(document.createElement('br'),button)}catch{}}})}



function messageTime(value){return new Date(value).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}

function messageMeta(name,date,mine=false){return `<strong>${U.esc(mine?'You':name)}</strong><time title="${U.attr(U.fmtDate(date))}">${U.esc(messageTime(date))}</time>`}

function syncMessages(log,html){

 const template=document.createElement('template');template.innerHTML=html;const old=new Map([...log.children].filter(n=>n.dataset.messageId).map(n=>[n.dataset.messageId,n]));let cursor=log.firstElementChild;const keep=new Set();

 for(let node of [...template.content.children]){const prev=old.get(node.dataset.messageId);if(prev&&prev.dataset.stamp===node.dataset.stamp)node=prev;keep.add(node);if(node!==cursor)log.insertBefore(node,cursor);cursor=node.nextElementSibling}

 for(const node of [...log.children])if(!keep.has(node))node.remove();

}

function addDayMarkers(log){let previous='';for(const row of U.qa('[data-created]',log)){const date=new Date(row.dataset.created).toLocaleDateString([],{year:'numeric',month:'short',day:'numeric'});if(date!==previous){row.dataset.day=date;row.classList.add('new-day')}else{delete row.dataset.day;row.classList.remove('new-day')}previous=date}}

let designRailChannel=null,railRefresh=null;

function stopDesignRail(){if(designRailChannel)sb.removeChannel(designRailChannel).catch(()=>{});designRailChannel=null;railRefresh=null;document.querySelector('.shell')?.classList.remove('messenger-shell')}

async function renderChatThreads(){

 chatLayout();cleanupChannel();stopDesignRail();S.group=null;S.direct=null;S.page='groups';

 const box=U.q('#page');box.classList.add('messenger-page');document.querySelector('.shell')?.classList.add('messenger-shell');box.innerHTML='<div class="messenger-layout"><aside id="conversation-rail"></aside><section id="conversation-pane"><div class="choose-conversation"><img src="ecp-logo.png" alt="Edu Chat Pro"><h1>Your conversations</h1><p>Choose a chat, or start a new conversation.</p></div></section></div>';

 await mountConversationRail();

}

async function mountConversationRail(){

 const rail=U.q('#conversation-rail');if(!rail)return;

 rail.innerHTML='<div class="rail-title"><h1>Chats</h1><button class="btn icon-btn" id="rail-new" aria-label="New conversation">+</button></div><div class="chat-filters">'+['All','Groups','Unread','Favorites'].map(t=>`<button class="${t==='All'?'selected':''}" data-chat-filter="${t}">${t}</button>`).join('')+'</div><label class="rail-search"><span>⌕</span><input id="rail-query" type="search" placeholder="Search chats, groups, people…"></label><div id="conversation-rows"></div><button class="btn ghost small" id="rail-load-more">More conversations</button>';

 let rows=[],filter='All',query='',loading=false,queued=false,offset=0,more=true,unread=new Map(),timer;

 const draw=()=>{if(!rail.isConnected)return;const list=U.q('#conversation-rows',rail);const shown=rows.filter(t=>(filter!=='Groups'||t.thread_kind==='group')&&(filter!=='Favorites'||t.pinned)&&(filter!=='Unread'||unread.has(t.thread_kind+'/'+t.thread_id))&&t.name.toLowerCase().includes(query));

 list.innerHTML=shown.map(t=>`<article class="conversation ${S.direct===t.thread_id?'selected':''}"><button class="conversation-main" data-open-kind="${t.thread_kind}" data-open-id="${t.thread_id}">${t.thread_kind==='group'?`<span class="avatar">${groupImage({image_path:t.avatar_path})}</span>`:avatarHtml({full_name:t.name,avatar_path:t.avatar_path})}<span class="conversation-copy"><strong>${U.esc(t.name)}</strong><span>${U.esc(t.preview||'Start a conversation')}</span></span><span class="conversation-end"><time>${U.esc(messageTime(t.updated_at))}</time>${unread.has(t.thread_kind+'/'+t.thread_id)?'<span class="unread-dot" aria-label="Unread messages"></span>':''}</span></button><button class="conversation-pin ${t.pinned?'pinned':''}" data-pin-id="${t.thread_id}" data-pin-kind="${t.thread_kind}" aria-label="${t.pinned?'Unpin':'Pin'} conversation">${t.pinned?'◆':'◇'}</button></article>`).join('')||'<div class="rail-empty">No matching conversations.<br><button class="text-btn" id="find-person">Find a person</button></div>';

 hydrateAvatars(list);hydrateGroupImages(list);U.q('#find-person',list)?.addEventListener('click',renderPeople);

 U.qa('[data-open-id]',list).forEach(b=>b.onclick=()=>{const t=rows.find(r=>r.thread_id===b.dataset.openId&&r.thread_kind===b.dataset.openKind);markThreadRead(t).catch(()=>{});b.dataset.openKind==='group'?openGroup(b.dataset.openId):openDirectChat(b.dataset.openId)});

 U.qa('[data-pin-id]',list).forEach(b=>b.onclick=async()=>{b.disabled=true;try{const t=rows.find(t=>t.thread_id===b.dataset.pinId&&t.thread_kind===b.dataset.pinKind),key={user_id:S.user.id,thread_kind:t.thread_kind,thread_id:t.thread_id};must(t.pinned?await sb.from('chat_pins').delete().match(key):await sb.from('chat_pins').upsert(key));await load(true)}catch(e){U.toast(U.errorText(e),'error')}finally{b.disabled=false}});

 };

 const load=async(reset=false)=>{if(loading){queued=true;return}loading=true;try{let fresh=[];const target=reset?Math.max(30,offset):30;while(fresh.length<target){const part=must(await sb.rpc('mobile_chat_threads',{page_offset:(reset?0:offset)+fresh.length}));fresh.push(...part);more=part.length===30;if(!more)break}if(!rail.isConnected)return;rows=reset?fresh:[...rows,...fresh];offset=rows.length;const r=await sb.rpc('web_unread_threads');if(!r.error)unread=new Map((r.data||[]).map(x=>[x.thread_kind+'/'+x.thread_id,true]));draw();U.q('#rail-load-more',rail).hidden=!more}catch(e){U.toast(U.errorText(e),'error')}finally{loading=false;if(queued&&rail.isConnected){queued=false;load(true)}}};

 railRefresh=()=>load(true);U.q('#rail-load-more',rail).onclick=()=>load();U.q('#rail-query',rail).oninput=e=>{query=e.target.value.trim().toLowerCase();draw()};U.qa('[data-chat-filter]',rail).forEach(b=>b.onclick=()=>{filter=b.dataset.chatFilter;U.qa('[data-chat-filter]',rail).forEach(x=>x.classList.toggle('selected',x===b));draw()});

 U.q('#rail-new',rail).onclick=()=>{const r=U.modal({title:'Start a conversation',body:'<button class="btn primary" id="new-person-design">Find a person</button>'+(can('groups.manage')?'<button class="btn" id="new-group-design">Create group</button>':'')});U.q('#new-person-design',r).onclick=()=>{U.closeModal();renderPeople()};U.q('#new-group-design',r)?.addEventListener('click',async()=>{const values=await U.promptBox({title:'Create group',fields:[{label:'Group name',max:120},{label:'Description',type:'textarea',required:false}],submit:'Create'});if(!values)return;try{const g=must(await sb.from('groups').insert({name:values[0],description:values[1],created_by:S.user.id}).select().single());await openGroup(g.id)}catch(e){U.toast(U.errorText(e),'error')}})};

 await load();if(!rail.isConnected)return;

 designRailChannel=sb.channel('web-conversation-rail-'+Date.now());for(const table of ['groups','group_messages','direct_messages','chat_pins','notifications','profiles'])designRailChannel.on('postgres_changes',{event:'*',schema:'public',table},()=>{clearTimeout(timer);timer=setTimeout(()=>{if(rail.isConnected)load(true)},250)});designRailChannel.subscribe();

}

async function markThreadRead(t){if(!t)return;const query=sb.from('notifications').update({read_at:new Date().toISOString()}).eq('user_id',S.user.id).is('read_at',null);if(t.thread_kind==='group')await query.eq('resource_id',t.thread_id).in('kind',['group_message','group_messages','announcement']);else{const messages=must(await sb.from('direct_messages').select('id').eq('sender_id',t.thread_id).eq('recipient_id',S.user.id).order('created_at',{ascending:false}).limit(200));if(messages.length)await query.eq('kind','direct_message').in('resource_id',messages.map(m=>m.id))}}

async function oldOpenDirectChat(id){

 let rail=U.q('#conversation-rail');if(rail)rail.remove();else stopDesignRail();

 await renderDirectConversation(id);

 if(S.direct!==id)return;const page=U.q('#page'),pane=document.createElement('section');pane.id='conversation-pane';while(page.firstChild)pane.append(page.firstChild);

 const layout=document.createElement('div');layout.className='messenger-layout';if(!rail){rail=document.createElement('aside');rail.id='conversation-rail'}layout.append(rail,pane);page.append(layout);page.classList.add('messenger-page');document.querySelector('.shell')?.classList.add('messenger-shell');if(!rail.children.length)await mountConversationRail();else railRefresh?.();

 U.q('#dm-back')?.addEventListener('click',()=>navigate('chats'));const text=U.q('#dm-text');text.placeholder='Type a message…';

 const emoji=document.createElement('button');emoji.type='button';emoji.className='btn ghost emoji-toggle';emoji.textContent='☺';emoji.setAttribute('aria-label','Choose emoji');emoji.onclick=()=>{const r=U.modal({title:'Choose emoji',body:['😊','👍','❤️','🎉','📚','✅','👋','😂'].map(v=>`<button class="btn">${v}</button>`).join('')});U.qa('.modal-body button',r).forEach(b=>b.onclick=()=>{text.value+=b.textContent;U.closeModal();text.focus()})};U.q('#dm-form .row').prepend(emoji);

}

async function installGroupInfo(g){

 const body=U.q('#group-body');if(!body||S.group?.id!==g.id)return;body.classList.add('group-conversation');body.querySelector('.group-info')?.remove();const info=document.createElement('aside');info.className='group-info card';info.innerHTML=`<header><strong>ⓘ &nbsp; Group info</strong><button class="text-btn" id="info-settings" aria-label="Group settings">•••</button></header><div class="group-info-title"><span class="avatar">${groupImage(g)}</span><div><h3>${U.esc(g.name)}</h3><span class="muted">Private group</span></div></div><p>${U.esc(g.description||'Connect, learn and share with your group.')}</p><div id="next-meeting-info"></div><section><div class="info-section-title"><h3>Members</h3><button class="text-btn" id="info-members">See all</button></div><div id="info-member-list"></div></section><section><div class="info-section-title"><h3>Shared media</h3><button class="text-btn" id="info-files">See all</button></div><div id="info-media-list"></div></section>`;body.append(info);const composer=body.querySelector('.chat-panel > .composer');if(composer)body.append(composer);hydrateGroupImages(info);

 U.q('#info-settings',info).onclick=()=>openGroup(g.id,'settings');U.q('#info-members',info).onclick=()=>openGroup(g.id,'members');U.q('#info-files',info).onclick=()=>openGroup(g.id,'files');

 try{const [memberResult,fileResult,meetingResult]=await Promise.all([sb.from('group_members').select('user_id').eq('group_id',g.id).limit(4),sb.from('group_files').select('*').eq('group_id',g.id).order('created_at',{ascending:false}).limit(4),sb.rpc('mobile_meetings',{group_filter:g.id,list_filter:'all',page_offset:0,newest_first:false})]);if(!info.isConnected)return;const members=must(memberResult),memberIds=members.map(m=>m.user_id),profiles=await namesFor(memberIds),roleRows=memberIds.length?(await sb.from('user_roles').select('user_id,role').in('user_id',memberIds)).data||[]:[],roleMap=Object.fromEntries(roleRows.map(x=>[x.user_id,x.role]));U.q('#info-member-list',info).innerHTML=members.map(m=>{const p=profiles[m.user_id]||{},presence=presenceLabel(p,p.role||roleMap[m.user_id]||'student');return `<div class="info-member">${avatarHtml(p)}<span><strong>${U.esc(p.full_name||'Member')}</strong><small>${m.user_id===g.created_by?'Owner':'Member'}</small>${window.EduPresence.badge(m.user_id)}</span></div>`}).join('');hydrateAvatars(info);

 const files=must(fileResult);U.q('#info-media-list',info).innerHTML=files.map(f=>`<button class="media-thumb" data-info-file="${f.id}" title="${U.attr(f.name)}">${f.mime_type?.startsWith('image/')?`<img data-info-image="${U.attr(f.object_path)}" alt="${U.attr(f.name)}">`:U.icon('file')}<small>${U.esc(f.name)}</small></button>`).join('')||'<p class="muted">No shared files yet.</p>';U.qa('[data-info-image]',info).forEach(img=>window.EduPhotos.get(sb,S.user.id,'group-files',img.dataset.infoImage).then(url=>{if(img.isConnected)img.src=url}).catch(()=>{}));U.qa('[data-info-file]',info).forEach(b=>b.onclick=()=>{const f=files.find(x=>x.id===b.dataset.infoFile),r=U.modal({title:f.name,body:mediaMarkup('group-files',f.object_path,f.mime_type,f.name)});hydrateMedia(r)});

 const meeting=(meetingResult.data||[]).find(m=>!m.ended_at);if(meeting){U.q('#next-meeting-info',info).innerHTML=`<div class="next-meeting">${U.icon('calendar')}<span><small>Next meeting</small><strong>${U.esc(meeting.title)}</strong></span><button class="btn small" id="info-join-meeting">Join</button></div>`;U.q('#info-join-meeting',info).onclick=()=>openMeeting(meeting,{autoJoin:true})}

 }catch(e){const target=U.q('#info-member-list',info);if(target)target.textContent='Open Members or Files to retry.'}

}

const chatReactionEmoji={like:'👍',love:'❤️',celebrate:'🎉',thanks:'🙏'};

async function hydrateChatReactions(log,kind){

 const nodes=U.qa('[data-message-id]',log);if(!nodes.length)return;const response=await sb.from('message_reactions').select('message_id,user_id,reaction').eq('thread_kind',kind).in('message_id',nodes.map(n=>n.dataset.messageId));if(response.error)return;

 for(const node of nodes){if(!node.isConnected)continue;let bar=node.querySelector('.chat-reactions');if(!bar){bar=document.createElement('div');bar.className='chat-reactions';node.querySelector('.message').append(bar)}const items=(response.data||[]).filter(r=>r.message_id===node.dataset.messageId),mine=items.find(r=>r.user_id===S.user.id)?.reaction;

 bar.innerHTML=Object.entries(chatReactionEmoji).map(([key,value])=>{const count=items.filter(r=>r.reaction===key).length;return `<button data-message-react="${key}" class="${count?'has-reactions':''} ${mine===key?'selected':''}" title="${key}" aria-pressed="${mine===key}">${value}${count?' '+count:''}</button>`}).join('');U.qa('[data-message-react]',bar).forEach(b=>b.onclick=async()=>{b.disabled=true;try{const key={thread_kind:kind,message_id:node.dataset.messageId,user_id:S.user.id};must(mine===b.dataset.messageReact?await sb.from('message_reactions').delete().match(key):await sb.from('message_reactions').upsert({...key,reaction:b.dataset.messageReact}));await hydrateChatReactions(log,kind)}catch(e){U.toast(U.errorText(e),'error')}finally{b.disabled=false}});

 }

}





async function changeWebGroupPhoto(g,tab='chat'){

 const input=document.createElement('input');input.type='file';input.accept='image/jpeg,image/png,image/webp';input.onchange=async()=>{const file=input.files?.[0];if(!file)return;let path,saved=false;try{const blob=await window.EduCrop(file);if(!blob)return;path=`${g.id}/${U.uuid()}.jpg`;must(await sb.storage.from('group-images').upload(path,blob,{contentType:'image/jpeg'}));must(await sb.from('groups').update({image_path:path}).eq('id',g.id).select('id,image_path').single());saved=true;if(g.image_path&&g.image_path!==path)await sb.storage.from('group-images').remove([g.image_path]);U.toast('Group photo saved.','ok');await openGroup(g.id,tab)}catch(e){if(path&&!saved)await sb.storage.from('group-images').remove([path]);U.toast(U.errorText(e)+' If upload is denied, run the supplied Supabase SQL.','error')}};input.click();

}




async function openGroup(id,tab='chat'){window.EduWorkspace.pending={kind:'group',id};window.EduWorkspace.pendingPanel=({files:'Files',members:'Members',meetings:'Meetings',drive:'Google Drive',settings:'Settings'})[tab]||null;await navigate('groups');}
async function openDirectChat(id){const thread=must(await sb.rpc('start_direct_chat',{other_user:id}));window.EduWorkspace.pending={kind:'direct',id:thread};await navigate('people');}

window.toggleTheme=toggleTheme;

init();

})();