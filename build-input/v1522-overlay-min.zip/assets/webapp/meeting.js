(() => {
  'use strict';
  const U = window.EduUI;
  const TE = new TextEncoder(), TD = new TextDecoder();
  const LK = () => window.LivekitClient;

  class MeetingController {
    constructor(client, meeting, opts = {}) {
      this.client = client;
      this.meeting = meeting;
      this.connectionId = U.uuid();
      this.room = null;
      this.mode = null; // livekit | p2p
      this.joined = false;
      this.joining = false;
      this.autoJoin = !!opts.autoJoin;
      this.guest = !!opts.guest;
      try { this.lowBandwidth = localStorage.getItem('educhat_low_bandwidth') === '1'; } catch { this.lowBandwidth = false; }
      this.heartbeatTimer = null;
      this.recording = null;
      this.recordingChunks = [];
      this.recordingStreams = [];
      this.recordingContext = null;
      this.pointerMode = false;
      this.pointerTimer = null;
      this.pointerTargetId = null;
      this.pointerAllowed = new Set();
      this.pointerGrantedBy = new Set();
      this.sharePeers = new Set();
      this.shareIdentity = new Map();
      this.screenAudioSenders = new Map();
      this.pointerMoveAt = 0;
      this.speakerMuted = false;
      this.activeSpeakerId = null;
      this.onExit = opts.onExit || (()=>{});
      this.profile = opts.profile || {};
      this.chat = [];
      this.recordingPeers = new Set();
      this.root = null;
      this._leaving = false;
      this._beforeUnload = () => this.leave(true);

      // Free WebRTC mesh fallback state. This is used automatically when the
      // LiveKit Edge Function/SFU has not been configured yet.
      this.p2pChannel = null;
      this.p2pPeers = new Map();
      this.p2pMeta = new Map();
      this.localStream = new MediaStream();
      this.cameraTrack = null;
      this.micTrack = null;
      this.screenStream = null;
      this.screenTrack = null;
      this.audioOutputId = '';this.remoteAudio=new Map();
    }

    inviteLink() {
      return `${location.origin}${location.pathname}?invite=${encodeURIComponent(this.meeting.invite_code || '')}`;
    }

    async open() {
      const root = document.createElement('div');
      root.className = 'meeting-shell';
      root.innerHTML = `
        <div class="meeting-topbar">
          <div class="meeting-title-wrap"><button class="meeting-back" data-leave title="Back / leave meeting" aria-label="Back / leave meeting">${U.icon('back')}</button><div class="meeting-title-text"><strong>${U.esc(this.meeting.title || 'Edu Chat Pro Meeting')}</strong><div class="tiny">Meeting • ${U.esc(U.shortId(this.meeting.id))}</div></div></div>
          <div class="row gap wrap"><span id="meeting-mode" class="badge">Ready</span><button class="btn ghost small" data-copy-invite>${U.icon('send')} Invite</button><button class="btn ghost small" data-leave>${U.icon('close')} Close</button></div>
        </div>
        <main class="meeting-main">
          <section id="meeting-stage" class="meeting-stage">
            <div id="join-card" class="join-card">
              <img class="brand-mark" src="ecp-logo.png" alt="Edu Chat Pro"><h2>Ready to join?</h2>
              <p id="join-help">Join your meeting with microphone and camera controls. You can also join with audio only.</p>
              <label class="switch"><input id="low-bandwidth" type="checkbox" ${this.lowBandwidth?'checked':''}><span>Low bandwidth mode — prioritize audio</span></label>
              <div class="row center gap wrap"><button class="btn primary" id="join-now">Join meeting</button><button class="btn ghost" id="join-audio">Join audio only</button></div>
              <p class="tiny">The same Edu Chat Pro account can join from phone and laptop at the same time. Each device is tracked separately for attendance.</p>
              <p id="join-error" class="danger-text tiny"></p>
            </div>
            <div id="video-grid" class="video-grid hidden"></div>
            <div id="pointer-dot" class="pointer-dot hidden"></div>
          </section>
          <aside id="meeting-side" class="meeting-side hidden"><div id="side-content"></div></aside>
        </main>
        <div id="recording-banner" class="recording-banner hidden">● Recording on this device</div>
        <footer id="meeting-controls" class="meeting-controls hidden">
          <button class="control" data-mic title="Microphone">${U.icon('mic')}<span>Mic</span></button>
          <button class="control" data-cam title="Camera">${U.icon('camera')}<span>Camera</span></button>
          <button class="control" data-speaker title="Mute sound on this device">${U.icon('headset')}<span>Sound</span></button>
          <button class="control" data-share title="Share screen">${U.icon('share')}<span>Share</span></button>
          <button class="control" data-record title="Record locally">${U.icon('record')}<span>Record</span></button>
          <button class="control" data-pointer title="Pointer">${U.icon('pointer')}<span>Pointer</span></button>
          <button class="control" data-people title="Participants">${U.icon('people')}<span>People</span></button>
          <button class="control" data-chat title="Meeting chat">${U.icon('chat')}<span>Chat</span></button>
          <button class="control" data-devices title="Audio devices">${U.icon('settings')}<span>Devices</span></button>
          <button class="control" data-fullscreen title="Full screen meeting">${U.icon('maximize')}<span>Full screen</span></button>
          <button class="control danger" data-leave title="Leave">${U.icon('phone')}<span>Leave</span></button>
        </footer>`;
      document.body.appendChild(root);
      this.root = root;
      root.querySelectorAll('[data-leave]').forEach(b=>b.onclick=()=>this.leave());
      U.q('[data-copy-invite]', root).onclick = async () => {try{if(navigator.share)await navigator.share({title:this.meeting.title,url:this.inviteLink()});else await U.copy(this.inviteLink())}catch(e){if(e.name!=='AbortError')U.toast(U.errorText(e),'error')}};
      U.q('#low-bandwidth',root).onchange=e=>{this.lowBandwidth=e.target.checked;try{localStorage.setItem('educhat_low_bandwidth',this.lowBandwidth?'1':'0')}catch{}};
      U.q('#join-now',root).onclick=()=>this.join(false);
      U.q('#join-audio',root).onclick=()=>this.join(true);
      window.addEventListener('beforeunload', this._beforeUnload);
      if (this.autoJoin) setTimeout(()=>this.join(false), 60);
    }

    setJoinError(text='') {
      const el = U.q('#join-error', this.root);
      if (el) el.textContent = text;
    }

    async functionError(error) {
      let msg = U.errorText(error);
      try {
        const response = error?.context;
        if (response && typeof response.clone === 'function') {
          const body = await response.clone().json();
          if (body?.error) msg = body.error;
        }
      } catch {}
      return msg;
    }

    async join(audioOnly=false) {
      if (this.joined || this.joining) return;
      this.joining = true;
      const joinBtn = U.q('#join-now',this.root), audioBtn=U.q('#join-audio',this.root);
      U.setBusy(joinBtn,true,'Connecting…'); audioBtn.disabled=true; this.setJoinError('');
      let liveKitFailure = null;
      try {
        // Load optional SFU only when requested; pure P2P needs no SDK.
        if(!this.guest && !LK() && window.EDUCHAT_CONFIG?.LIVEKIT_REQUIRED !== false){try{await new Promise((resolve,reject)=>{const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/livekit-client@2.22.3/dist/livekit-client.umd.min.js';s.onload=resolve;s.onerror=reject;document.head.appendChild(s)})}catch(e){liveKitFailure='Meeting library unavailable'}}
        if (!this.guest && LK() && window.EDUCHAT_CONFIG?.LIVEKIT_REQUIRED !== false) {
          try {
            await this.joinLiveKit(audioOnly);
            await this.finishJoin();
            return;
          } catch (e) {
            liveKitFailure = await this.functionError(e);
            console.warn('LiveKit join failed; trying free P2P fallback:', e);
          }
        }

        if (window.EDUCHAT_CONFIG?.P2P_FALLBACK === false) {
          throw new Error(liveKitFailure || 'Meeting server is unavailable.');
        }

        await this.joinP2P(audioOnly);
        await this.finishJoin();
        if (liveKitFailure) U.toast('LiveKit was unavailable, so Edu Chat Pro connected with the free P2P fallback.','warn');
      } catch(e) {
        const detail = U.errorText(e);
        this.setJoinError(detail);
        U.toast(detail,'error');
        await this.cleanupMediaOnly();
        U.setBusy(joinBtn,false); audioBtn.disabled=false;
      } finally {
        this.joining = false;
      }
    }

    async finishJoin() {
      this.joined=true;
      try { await this.attendance(false); } catch(e) { console.warn('Attendance start failed; call will continue', e); }
      this.heartbeatTimer=setInterval(async()=>{
        try { await this.attendance(false); } catch(e) { console.warn('Attendance heartbeat', e); }
        try {
          const {data,error}=this.guest ? await this.client.rpc('guest_meeting_status',{meeting_input:this.meeting.id}) : await this.client.from('meetings').select('ended_at').eq('id',this.meeting.id).single();
          if(this.guest&&(error||!data)){U.toast('Guest access ended.','warn');await this.leave();return;}
          if(!error && data?.ended_at){U.toast('The host ended this meeting.','warn');await this.leave();}
        } catch {}
      },20000);
      U.q('#join-card',this.root).classList.add('hidden');
      U.q('#video-grid',this.root).classList.remove('hidden');
      U.q('#meeting-controls',this.root).classList.remove('hidden');
      this.bindControls(); this.renderParticipants();
      U.q('#meeting-mode',this.root).textContent = this.mode === 'livekit' ? 'Connected · SFU' : 'Connected · Free P2P';
      U.q('#meeting-mode',this.root).className = 'badge ok';
      U.toast('Joined meeting.','ok');
    }

    async joinLiveKit(audioOnly=false) {
      const { data, error } = await U.timeout(
        this.client.functions.invoke('meeting-token',{body:{meeting_id:this.meeting.id,connection_id:this.connectionId}}),
        8000,
        'Meeting token service timed out.'
      );
      if(error) throw error;
      if(!data?.token || !data?.url) throw new Error(data?.error || 'Meeting server is not configured.');
      if(!/^wss:\/\//i.test(data.url)) throw new Error('LIVEKIT_URL must be a secure wss:// URL.');
      const L=LK();
      this.room = new L.Room({adaptiveStream:true,dynacast:true,stopLocalTrackOnUnpublish:true});
      this.bindLiveKitRoom();
      await U.timeout(this.room.connect(data.url,data.token,{autoSubscribe:true}),12000,'LiveKit connection timed out.');
      this.mode='livekit';
      // Keep camera OFF when joining. It will only request camera permission
      // after the user presses the Camera button.
      try { await this.enableCamera(false); } catch {}
      try { await this.enableMic(true); } catch(e){ U.toast(`Microphone unavailable: ${U.errorText(e)}`,'error'); }
    }

    bindLiveKitRoom(){
      const L=LK(), R=L.RoomEvent;
      const rerender=()=>this.renderParticipants();
      [R.ParticipantConnected,R.ParticipantDisconnected,R.TrackSubscribed,R.TrackUnsubscribed,R.LocalTrackPublished,R.LocalTrackUnpublished,R.TrackMuted,R.TrackUnmuted].filter(Boolean).forEach(ev=>this.room.on(ev,rerender));
      this.room.on(R.Disconnected,()=>{this.updateNetwork('Disconnected','bad'); if(this.joined)U.toast('Meeting connection ended.','error')});
      this.room.on(R.Reconnecting,()=>this.updateNetwork('Reconnecting…','warn'));
      this.room.on(R.Reconnected,()=>this.updateNetwork('Connected','ok'));
      if(R.ConnectionQualityChanged) this.room.on(R.ConnectionQualityChanged,(q,p)=>this.updateQuality(q,p));
      if(R.ActiveSpeakersChanged) this.room.on(R.ActiveSpeakersChanged,(speakers)=>{this.activeSpeakerId=speakers?.[0]?.identity||null;this.renderParticipants();});
      this.room.on(R.DataReceived,(payload,participant,kind,topic)=>this.onLiveKitData(payload,participant,topic));
      if(R.AudioPlaybackStatusChanged) this.room.on(R.AudioPlaybackStatusChanged,()=>this.ensureAudio());
    }

    async joinP2P(audioOnly=false) {
      if (!window.RTCPeerConnection || !navigator.mediaDevices?.getUserMedia) {
        throw new Error('This browser does not support WebRTC calling. Use a recent Chrome, Edge, Firefox, or Safari over HTTPS.');
      }
      await this.prepareLocalMedia(audioOnly);
      this.mode='p2p';
      const token=(await this.client.auth.getSession()).data?.session?.access_token;if(token&&this.client.realtime?.setAuth)await this.client.realtime.setAuth(token);
      const topic=`educhat-meeting:${this.meeting.id}`;
      const meta={connection_id:this.connectionId,user_id:this.client.auth.getUser ? (await this.client.auth.getUser()).data?.user?.id : '',name:this.profile.full_name||'Participant',platform:'web',joined_at:new Date().toISOString()};

      const channel=this.client.channel(topic,{config:{private:true,broadcast:{self:false},presence:{key:this.connectionId}}});
      this.p2pChannel=channel;
      channel
        .on('broadcast',{event:'signal'},({payload})=>this.handleP2PSignal(payload))
        .on('broadcast',{event:'data'},({payload})=>this.onP2PData(payload))
        .on('broadcast',{event:'hello'},({payload})=>this.handleP2PHello(payload))
        .on('presence',{event:'sync'},()=>this.syncP2PPresence())
        .on('presence',{event:'join'},()=>this.syncP2PPresence())
        .on('presence',{event:'leave'},()=>this.syncP2PPresence());

      await U.timeout(new Promise((resolve,reject)=>{
        channel.subscribe(async(status,err)=>{
          if(status==='SUBSCRIBED'){
            try{await channel.track(meta);await this.sendP2PHello();resolve();}catch(e){reject(e)}
          } else if(status==='CHANNEL_ERROR'||status==='TIMED_OUT'||status==='CLOSED') {
            reject(err || new Error(`Realtime channel ${String(status).toLowerCase()}. Run UPGRADE_FREE_P2P_MEETING.sql in Supabase.`));
          }
        });
      }),10000,'Secure meeting signaling could not connect. Run UPGRADE_FREE_P2P_MEETING.sql in Supabase.');
      await this.syncP2PPresence();
      this.updateNetwork('Waiting for participants','');
    }

    async prepareLocalMedia(audioOnly) {
      const audio={echoCancellation:true,noiseSuppression:true,autoGainControl:true};
      // Never request the camera while joining a P2P call.
      // The Camera button calls enableCamera(true) later when the user chooses it.
      const video=false;
      const stream=await navigator.mediaDevices.getUserMedia({audio,video});
      this.localStream=stream;
      this.micTrack=stream.getAudioTracks()[0]||null;
      this.cameraTrack=null;if(!this.micTrack){stream.getTracks().forEach(t=>t.stop());throw new Error('No microphone audio track is available. Check microphone permission and try again.');}
      this.micTrack.enabled=true;
    }

    iceServers(){
      const configured=window.EDUCHAT_CONFIG?.ICE_SERVERS;
      if(Array.isArray(configured)&&configured.length)return configured;
      return [
        {urls:'stun:stun.l.google.com:19302'},
        {urls:'stun:stun1.l.google.com:19302'}
      ];
    }

    async syncP2PPresence(){
      if(!this.p2pChannel)return;
      const state=this.p2pChannel.presenceState?.()||{};
      const current=new Set();
      for(const [key,list] of Object.entries(state)){
        const p=Array.isArray(list)?list[0]:null;
        const id=String(p?.connection_id||key||'');
        if(!id||id===this.connectionId)continue;
        current.add(id);
        this.p2pMeta.set(id,{name:p?.name||'Participant',user_id:p?.user_id||'',connection_id:id});
        if(!this.p2pPeers.has(id)) await this.createP2PPeer(id);
      }
      for(const id of [...this.p2pPeers.keys()]) if(!current.has(id)) this.dropP2PPeer(id);
      this.renderParticipants();
    }

    createP2PPeer(peerId){
      this.peerSetup??=new Map();
      if(this.peerSetup.has(peerId))return this.peerSetup.get(peerId);
      const task=this.buildP2PPeer(peerId).finally(()=>this.peerSetup.delete(peerId));
      this.peerSetup.set(peerId,task);return task;
    }
    async buildP2PPeer(peerId){
      if(this.p2pPeers.has(peerId))return this.p2pPeers.get(peerId);
      const pc=new RTCPeerConnection({iceServers:this.iceServers(),iceCandidatePoolSize:2});
      const peer={id:peerId,pc,stream:new MediaStream(),makingOffer:false,ignoreOffer:false,pendingIce:[],polite:this.connectionId.localeCompare(peerId)>0,audioSender:null,videoSender:null};
      this.p2pPeers.set(peerId,peer);

      pc.onnegotiationneeded=async()=>{
        try{
          peer.makingOffer=true;
          await pc.setLocalDescription();
          await this.sendSignal(peerId,{description:pc.localDescription});
        }catch(e){console.warn('negotiation',e)}finally{peer.makingOffer=false}
      };

      pc.onicecandidate=e=>{if(e.candidate)this.sendSignal(peerId,{candidate:e.candidate.toJSON?e.candidate.toJSON():e.candidate})};
      pc.ontrack=e=>{
        const track=e.track;
        if(!peer.stream.getTracks().some(t=>t.id===track.id))peer.stream.addTrack(track);
        if(track?.kind==='audio')this.attachRemoteAudio(peerId,peer.stream);
        track.onunmute=()=>{if(track.kind==='audio')this.attachRemoteAudio(peerId,peer.stream);this.renderParticipants();};
        track.onended=()=>this.renderParticipants();
        this.renderParticipants();
      };
      pc.onconnectionstatechange=()=>{
        const s=pc.connectionState;
        if(s==='connected')this.updateNetwork('Connected · Free P2P','ok');
        else if(s==='failed'||s==='disconnected')this.updateNetwork(s==='failed'?'Peer connection failed':'Reconnecting…',s==='failed'?'bad':'warn');
        if(s==='failed')try{pc.restartIce()}catch{}
      };
      const at=pc.addTransceiver('audio',{direction:'sendrecv'}); peer.audioSender=at.sender;
      const vt=pc.addTransceiver('video',{direction:'sendrecv'}); peer.videoSender=vt.sender;
      if(this.micTrack) await peer.audioSender.replaceTrack(this.micTrack);
      const currentVideo=this.screenTrack||this.cameraTrack;
      if(currentVideo) await peer.videoSender.replaceTrack(currentVideo);
      const screenAudio=this.screenStream?.getAudioTracks?.()[0];if(screenAudio){try{const sender=pc.addTrack(screenAudio,this.screenStream);this.screenAudioSenders.set(peerId,sender)}catch{}}

      this.renderParticipants();
      return peer;
    }


    async sendP2PHello(target=null){
      if(!this.p2pChannel)return;
      let userId='';try{userId=(await this.client.auth.getUser()).data?.user?.id||''}catch{}
      await this.p2pChannel.send({type:'broadcast',event:'hello',payload:{from:this.connectionId,target,user_id:userId,name:this.profile.full_name||'Participant',platform:'web'}});
    }
    async handleP2PHello(msg){
      if(!this.p2pChannel||!msg)return;
      const from=String(msg.from||''),target=String(msg.target||'');
      if(!from||from===this.connectionId||target&&target!==this.connectionId)return;
      const isNew=!this.p2pPeers.has(from);
      this.p2pMeta.set(from,{name:msg.name||'Participant',user_id:msg.user_id||'',connection_id:from,platform:msg.platform||'unknown'});
      await this.createP2PPeer(from);
      if(isNew)await this.sendP2PHello(from);
    }

    async sendSignal(target,payload){
      if(!this.p2pChannel)return;
      await this.p2pChannel.send({type:'broadcast',event:'signal',payload:{...payload,from:this.connectionId,target,name:this.profile.full_name||'Participant',platform:'web'}});
    }

    handleP2PSignal(msg){
      this.signalQueue=(this.signalQueue||Promise.resolve()).then(()=>this.applyP2PSignal(msg)).catch(e=>console.warn('Signaling:',e));return this.signalQueue;
    }
    async applyP2PSignal(msg){
      if(!this.p2pChannel||!msg||msg.target!==this.connectionId||!msg.from||msg.from===this.connectionId)return;
      const peer=await this.createP2PPeer(msg.from),pc=peer.pc;
      try{
        if(msg.description){
          const desc=msg.description;
          const offerCollision=desc.type==='offer'&&(peer.makingOffer||pc.signalingState!=='stable');
          peer.ignoreOffer=!peer.polite&&offerCollision;
          if(peer.ignoreOffer)return;
          await pc.setRemoteDescription(desc);
          for(const ice of peer.pendingIce.splice(0))await pc.addIceCandidate(ice);
          if(desc.type==='offer'){
            await pc.setLocalDescription();
            await this.sendSignal(msg.from,{description:pc.localDescription});
          }
        } else if(msg.candidate){
          if(peer.ignoreOffer)return;
          if(!pc.remoteDescription){peer.pendingIce.push(msg.candidate);return}
          await pc.addIceCandidate(msg.candidate)
        }
      }catch(e){console.warn('P2P signal error',e)}
    }

    dropP2PPeer(id){
      const peer=this.p2pPeers.get(id);if(!peer)return;
      try{peer.pc.close()}catch{}
      peer.stream.getTracks().forEach(t=>{try{t.stop()}catch{}});
      const audio=this.remoteAudio.get(id);if(audio){audio.pause();audio.srcObject=null;audio.remove();this.remoteAudio.delete(id);}
      this.screenAudioSenders.delete(id);this.p2pPeers.delete(id);this.p2pMeta.delete(id);this.renderParticipants();
    }

    updateNetwork(text,type=''){ const b=U.q('#meeting-mode',this.root); if(b){b.textContent=text;b.className=`badge ${type}`;} }
    updateQuality(quality,participant){ if(participant && participant!==this.room?.localParticipant)return; const s=String(quality||'').toLowerCase(); this.updateNetwork(s.includes('poor')?'Poor network':s.includes('good')?'Good network':s.includes('excellent')?'Excellent network':'Connected',s.includes('poor')?'warn':'ok'); }

    async attendance(leaving){
      if(this.guest){const result=await this.client.rpc('guest_meeting_heartbeat',{meeting_input:this.meeting.id,leaving});if(result.error)throw result.error;return;}
      if(!this.joined && !leaving)return;
      let r=await this.client.rpc('attendance_heartbeat',{meeting:this.meeting.id,connection:this.connectionId,leaving});
      // Backward compatibility: older EduChat databases used the 2-argument
      // heartbeat. Do not tear down a working call just because attendance has
      // not been upgraded yet.
      if(r.error && (r.error.code==='PGRST202'||/function|connection/i.test(String(r.error.message||'')))) {
        r=await this.client.rpc('attendance_heartbeat',{meeting:this.meeting.id,leaving});
      }
      if(r.error) throw r.error;
    }

    async enableMic(on){
      if(this.mode==='livekit'){
        await this.room?.localParticipant?.setMicrophoneEnabled(on);
      } else {
        if(on&&(!this.micTrack||this.micTrack.readyState==='ended')){
          const s=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});
          this.micTrack=s.getAudioTracks()[0]||null;if(this.micTrack)this.localStream.addTrack(this.micTrack);
          for(const p of this.p2pPeers.values())await p.audioSender?.replaceTrack(this.micTrack);
        }
        if(this.micTrack)this.micTrack.enabled=on;
      }
      const b=U.q('[data-mic]',this.root); if(b)b.classList.toggle('off',!on);
    }

    async enableCamera(on){
      if(this.mode==='livekit'){
        const opts={}; const L=LK();
        if(on && this.lowBandwidth && L()?.VideoPresets?.h180) opts.resolution=L().VideoPresets.h180.resolution;
        else if(on && L()?.VideoPresets?.h360) opts.resolution=L().VideoPresets.h360.resolution;
        await this.room?.localParticipant?.setCameraEnabled(on,opts);
      } else {
        if(on&&!this.cameraTrack){
          const v=this.lowBandwidth?{width:{ideal:320,max:480},height:{ideal:180,max:270},frameRate:{ideal:12,max:15}}:{width:{ideal:640,max:1280},height:{ideal:360,max:720},frameRate:{ideal:20,max:30}};
          const s=await navigator.mediaDevices.getUserMedia({video:v,audio:false});
          this.cameraTrack=s.getVideoTracks()[0]||null;if(this.cameraTrack)this.localStream.addTrack(this.cameraTrack);
        }
        if(this.cameraTrack)this.cameraTrack.enabled=on;
        if(!this.screenTrack){for(const p of this.p2pPeers.values())await p.videoSender?.replaceTrack(on?this.cameraTrack:null)}
        this.renderParticipants();
      }
      const b=U.q('[data-cam]',this.root); if(b)b.classList.toggle('off',!on);
    }

    liveKitSourceEnabled(source){
      if(!this.room)return false;
      const pubs=Array.from(this.room.localParticipant.trackPublications?.values?.()||[]);
      return pubs.some(p=>p.source===source && p.track && !p.track.isMuted);
    }

    bindControls(){
      const root=this.root,L=LK();
      U.q('[data-mic]',root).onclick=async()=>{try{const on=this.mode==='livekit'?this.liveKitSourceEnabled(L.Track.Source.Microphone):!!this.micTrack?.enabled; await this.enableMic(!on);}catch(e){U.toast(U.errorText(e),'error')}};
      U.q('[data-cam]',root).onclick=async()=>{try{const on=this.mode==='livekit'?this.liveKitSourceEnabled(L.Track.Source.Camera):!!this.cameraTrack?.enabled; await this.enableCamera(!on);}catch(e){U.toast(U.errorText(e),'error')}};
      U.q('[data-speaker]',root).onclick=()=>this.toggleSpeaker();
      U.q('[data-share]',root).onclick=()=>this.toggleScreenShare();
      U.q('[data-record]',root).onclick=()=>this.toggleRecording();
      U.q('[data-pointer]',root).onclick=()=>this.togglePointer();
      U.q('[data-people]',root).onclick=()=>this.showPeople();
      U.q('[data-chat]',root).onclick=()=>this.showChat();
      U.q('[data-devices]',root).onclick=()=>this.showDevices();
      U.q('[data-fullscreen]',root).onclick=()=>this.toggleFullscreen();
      const stage=U.q('#meeting-stage',root);
      stage.onpointermove=e=>this.pointerMove(e);
      stage.onpointerdown=e=>{if(this.pointerMode)this.pointerMove(e,true)};
    }

    toggleSpeaker(){
      this.speakerMuted=!this.speakerMuted;
      for(const audio of this.remoteAudio.values())audio.muted=this.speakerMuted;
      for(const el of U.qa('audio',this.root))if(!el.dataset.local)el.muted=this.speakerMuted;
      const b=U.q('[data-speaker]',this.root);if(b)b.classList.toggle('off',this.speakerMuted);
      U.toast(this.speakerMuted?'Meeting sound muted on this device.':'Meeting sound enabled on this device.','ok');
    }

    async toggleFullscreen(){
      try{const target=this.root;if(!document.fullscreenElement)await target.requestFullscreen?.();else await document.exitFullscreen?.();}catch(e){U.toast('Full screen is not available in this browser.','warn')}
    }

    async sharePickerHelp(){
      return U.confirmBox('Share your screen','Your browser will show its secure screen-share picker. Choose Entire screen, Window/App, or Browser tab. For a tab, enable “Share tab audio” when you want participants to hear it. Edu Chat Pro cannot bypass this permission dialog.','Choose what to share');
    }

    displayMediaSupported(){
      return !!(navigator.mediaDevices?.getDisplayMedia || navigator.getDisplayMedia);
    }

    async requestDisplayMedia(){
      const getDisplay=navigator.mediaDevices?.getDisplayMedia?.bind(navigator.mediaDevices) || navigator.getDisplayMedia?.bind(navigator);
      if(!getDisplay)throw new Error('Screen sharing is not supported by this mobile/tablet browser. Open Edu Chat Pro in a recent Chrome/Edge/Safari version that provides screen sharing.');
      const mobile=matchMedia('(max-width:1024px)').matches || /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent||'');
      const attempts=mobile?
        [
          {video:true,audio:true},
          {video:true,audio:false}
        ]:
        [
          {video:{frameRate:{ideal:20,max:30}},audio:true,systemAudio:'include',surfaceSwitching:'include',selfBrowserSurface:'include'},
          {video:true,audio:true},
          {video:true,audio:false}
        ];
      let last;
      for(const constraints of attempts){
        try{return await getDisplay(constraints)}catch(e){
          if(e?.name==='NotAllowedError'||e?.name==='AbortError')throw e;
          last=e;
        }
      }
      throw last||new Error('Screen sharing could not start on this browser/device.');
    }

    async toggleScreenShare(){
      const b=U.q('[data-share]',this.root);
      try{
        if(this.mode==='livekit'){
          const L=LK(),src=L.Track.Source.ScreenShare,on=this.liveKitSourceEnabled(src);
          if(on){await this.room.localParticipant.setScreenShareEnabled(false);this.sendData({type:'share-state',active:false,owner:this.connectionId,identity:this.room?.localParticipant?.identity||''},'screen');}
          else {
            // Keep source selection in the browser/OS picker, like Google Meet. On
            // phones/tablets use simpler constraints first because several mobile
            // browsers reject desktop-only display-capture options.
            if(!this.displayMediaSupported())throw new Error('Screen sharing is not supported by this mobile/tablet browser. Try a recent Chrome/Edge/Safari build or the desktop web app.');
            const mobile=matchMedia('(max-width:1024px)').matches || /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent||'');
            try{await this.room.localParticipant.setScreenShareEnabled(true,{audio:true});}
            catch(first){
              if(first?.name==='NotAllowedError'||first?.name==='AbortError')throw first;
              try{await this.room.localParticipant.setScreenShareEnabled(true,{audio:false});}
              catch(second){
                if(second?.name==='NotAllowedError'||second?.name==='AbortError')throw second;
                if(mobile)throw new Error('This mobile/tablet browser blocked screen capture. Update the browser or use a browser that supports screen sharing.');
                await this.room.localParticipant.setScreenShareEnabled(true);
              }
            }
            this.sendData({type:'share-state',active:true,owner:this.connectionId,identity:this.room?.localParticipant?.identity||''},'screen');
          }
          b.classList.toggle('active',!on); this.renderParticipants(); return;
        }
        if(this.screenTrack){await this.stopP2PScreenShare();return;}
        if(!this.displayMediaSupported())throw new Error('Screen sharing is not supported by this mobile/tablet browser. Open Edu Chat Pro in a browser that supports screen sharing.');
        // Request display capture from the Share-button gesture. Desktop browsers can
        // offer Entire Screen / Window-App / Tab; mobile/tablet source choices are
        // controlled by the OS/browser and may offer the whole display only.
        this.screenStream=await this.requestDisplayMedia();
        this.screenTrack=this.screenStream.getVideoTracks()[0]||null;
        if(!this.screenTrack)throw new Error('No screen video track was provided.');
        for(const [id,p] of this.p2pPeers){await p.videoSender?.replaceTrack(this.screenTrack);const audioTrack=this.screenStream.getAudioTracks()[0];if(audioTrack){try{const sender=p.pc.addTrack(audioTrack,this.screenStream);this.screenAudioSenders.set(id,sender)}catch{}}}
        this.screenTrack.addEventListener('ended',()=>this.stopP2PScreenShare(),{once:true});
        b.classList.add('active');this.sendData({type:'share-state',active:true,owner:this.connectionId},'screen');this.renderParticipants();
      }catch(e){if(e?.name!=='NotAllowedError'&&e?.name!=='AbortError')U.toast(`Screen share: ${U.errorText(e)}`,'error')}
    }

    async stopP2PScreenShare(){
      const t=this.screenTrack;this.screenTrack=null;
      if(t)try{t.stop()}catch{}
      this.screenStream?.getTracks().forEach(x=>{try{x.stop()}catch{}});this.screenStream=null;
      const back=this.cameraTrack?.enabled?this.cameraTrack:null;
      for(const [id,p] of this.p2pPeers){await p.videoSender?.replaceTrack(back);const sender=this.screenAudioSenders.get(id);if(sender){try{p.pc.removeTrack(sender)}catch{}this.screenAudioSenders.delete(id);}}
      this.pointerAllowed.clear();this.sendData({type:'share-state',active:false,owner:this.connectionId},'screen');
      U.q('[data-share]',this.root)?.classList.remove('active');this.renderParticipants();
    }

    recordingAudioStreams(){
      const streams=[];
      if(this.mode==='p2p')for(const p of this.p2pPeers.values())if(p.stream?.getAudioTracks().length)streams.push(new MediaStream(p.stream.getAudioTracks()));
      if(this.mode==='livekit'&&this.room)for(const p of this.room.remoteParticipants.values()){const tracks=this.participantPubs(p).filter(x=>String(x.source).includes('microphone')&&x.track).map(x=>x.track.mediaStreamTrack).filter(Boolean);if(tracks.length)streams.push(new MediaStream(tracks));}
      return streams;
    }

    async toggleRecording(){
      if(this.recording?.state==='recording'){ await this.stopRecording(); return; }
      if(!navigator.mediaDevices?.getDisplayMedia || !window.MediaRecorder){U.toast('This browser cannot record screen locally. Use a recent Chrome/Edge/Firefox browser.','error');return;}
      const ok=await U.confirmBox('Start local recording','The browser will ask for recording permission. Choose the Edu Chat Pro meeting tab or the screen you want recorded and enable tab/system audio when available. Edu Chat Pro will also mix available meeting audio. Other participants are notified.','Start recording');
      if(!ok)return;
      try{
        const display=await navigator.mediaDevices.getDisplayMedia({video:{frameRate:{ideal:20,max:30}},audio:true,systemAudio:'include',preferCurrentTab:true,surfaceSwitching:'include',selfBrowserSurface:'include'});
        const streams=[display,...this.recordingAudioStreams()]; let mic=null;
        try{mic=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false});streams.push(mic);}catch{}
        const combined=new MediaStream(); display.getVideoTracks().forEach(t=>combined.addTrack(t));
        const audioTracks=[];streams.forEach(s=>s.getAudioTracks().forEach(t=>audioTracks.push(t)));
        if(audioTracks.length){
          const C=window.AudioContext||window.webkitAudioContext; const ctx=new C();this.recordingContext=ctx;const dest=ctx.createMediaStreamDestination();
          streams.forEach(s=>{if(s.getAudioTracks().length){try{ctx.createMediaStreamSource(new MediaStream(s.getAudioTracks())).connect(dest)}catch{}}});
          dest.stream.getAudioTracks().forEach(t=>combined.addTrack(t));
        }
        const types=['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'];const mime=types.find(t=>MediaRecorder.isTypeSupported(t))||'';
        this.recordingChunks=[];this.recordingStreams=[display,...(mic?[mic]:[])];const rec=new MediaRecorder(combined,mime?{mimeType:mime}:undefined);this.recording=rec;
        rec.ondataavailable=e=>{if(e.data?.size)this.recordingChunks.push(e.data)};rec.onstop=()=>this.saveRecording(mime||'video/webm');
        display.getVideoTracks()[0].addEventListener('ended',()=>{if(rec.state==='recording')this.stopRecording()},{once:true});rec.start(1000);
        U.q('#recording-banner',this.root).classList.remove('hidden');U.q('[data-record]',this.root).classList.add('active');
        this.sendData({type:'recording',active:true,name:this.profile.full_name||'Participant'},'recording');U.toast('Recording started on this device.','ok');
      }catch(e){if(e?.name!=='NotAllowedError'&&e?.name!=='AbortError')U.toast(`Recording: ${U.errorText(e)}`,'error')}
    }
    async stopRecording(){ if(!this.recording)return; try{if(this.recording.state!=='inactive')this.recording.stop();}catch{} this.recordingStreams.forEach(s=>s.getTracks().forEach(t=>{if(t!==this.micTrack&&t!==this.cameraTrack&&t!==this.screenTrack)try{t.stop()}catch{}})); try{await this.recordingContext?.close()}catch{} this.recordingContext=null; U.q('#recording-banner',this.root)?.classList.add('hidden');U.q('[data-record]',this.root)?.classList.remove('active');this.sendData({type:'recording',active:false,name:this.profile.full_name||'Participant'},'recording'); }
    async saveRecording(mime){
      if(!this.recordingChunks.length){this.recording=null;return}
      const blob=new Blob(this.recordingChunks,{type:mime}),stamp=new Date().toISOString().replace(/[:.]/g,'-'),name=`EduChatPro-${U.safeName(this.meeting.title||'meeting')}-${stamp}.webm`;
      try{if(window.showSaveFilePicker){const h=await showSaveFilePicker({suggestedName:name,types:[{description:'WebM meeting recording',accept:{'video/webm':['.webm']}}]});const w=await h.createWritable();await w.write(blob);await w.close();}else U.download(name,blob,mime);U.toast('Recording saved to this device.','ok');}catch(e){if(e?.name!=='AbortError')U.download(name,blob,mime)}
      this.recordingChunks=[];this.recording=null;
    }

    async sendData(obj,topic='educhat'){
      if(this.mode==='livekit'){
        if(!this.room?.localParticipant)return;try{await this.room.localParticipant.publishData(TE.encode(JSON.stringify({...obj,from:this.connectionId})),{reliable:true,topic});}catch(e){console.warn(e)}
      } else if(this.p2pChannel) {
        try{await this.p2pChannel.send({type:'broadcast',event:'data',payload:{...obj,from:this.connectionId,name:obj.name||this.profile.full_name||'Participant',topic}})}catch(e){console.warn(e)}
      }
    }
    onLiveKitData(payload,participant,topic){let data;try{data=JSON.parse(TD.decode(payload))}catch{return}data._identity=participant?.identity||data.identity||'';this.handleData(data,participant?.name||'Participant',data.from||participant?.identity||data.name)}
    onP2PData(data){if(!data||data.from===this.connectionId)return;this.handleData(data,data.name||this.p2pMeta.get(data.from)?.name||'Participant',data.from)}
    async handleData(data,name,id){
      if(data.type==='chat'){this.chat.push({name,text:data.text||'',time:new Date()});if(U.q('#meeting-side',this.root)?.dataset.mode==='chat')this.showChat();}
      if(data.type==='share-state'){const owner=data.owner||id;if(data._identity)this.shareIdentity.set(data._identity,owner);if(data.active)this.sharePeers.add(owner);else{this.sharePeers.delete(owner);this.pointerGrantedBy.delete(owner);if(data._identity)this.shareIdentity.delete(data._identity);}this.renderParticipants();}
      if(data.type==='pointer-request'&&data.target===this.connectionId&&(this.screenTrack||this.liveKitSourceEnabled(LK()?.Track?.Source?.ScreenShare))){const allow=await U.confirmBox('Allow remote pointer',`${data.name||name||'A participant'} wants to point on the screen you are sharing. Allow their cursor to appear on your shared screen?`,'Allow pointer');if(allow)this.pointerAllowed.add(id);else this.pointerAllowed.delete(id);this.sendData({type:'pointer-permission',target:id,owner:this.connectionId,granted:allow},'pointer');}
      if(data.type==='pointer-permission'&&data.target===this.connectionId){if(data.granted){this.pointerGrantedBy.add(data.owner||id);this.pointerTargetId=data.owner||id;U.toast('Pointer permission granted. Move your cursor over the shared screen.','ok');}else{this.pointerGrantedBy.delete(data.owner||id);U.toast('The screen sharer did not allow remote pointer.','warn');}}
      if(data.type==='pointer'&&(!data.sender||this.pointerAllowed.has(id)||data.target!==this.connectionId))this.showPointer(Number(data.x),Number(data.y),data.name||name,data.target||id);
      if(data.type==='recording'){if(data.active)this.recordingPeers.add(id);else this.recordingPeers.delete(id); if(data.active)U.toast(`${data.name||name||'A participant'} started recording.`,'warn');}
    }
    pointerTile(){const tiles=U.qa('.video-tile',this.root);return tiles.find(t=>t.classList.contains('spotlight')&&t.dataset.sharing==='1')||tiles.find(t=>t.dataset.sharing==='1')||null;}
    async togglePointer(){
      if(this.pointerMode){this.pointerMode=false;this.pointerTargetId=null;U.q('[data-pointer]',this.root).classList.remove('active');U.toast('Pointer disabled.','ok');return;}
      const tile=this.pointerTile();if(!tile){U.toast('Start or select a shared screen first.','warn');return;}
      const owner=tile.dataset.owner;if(!owner){U.toast('Shared-screen owner is unavailable.','warn');return;}
      if(owner!==this.connectionId&&!this.pointerGrantedBy.has(owner)){this.sendData({type:'pointer-request',target:owner,name:this.profile.full_name||'Participant'},'pointer');U.toast('Pointer permission requested from the screen sharer.','ok');return;}
      this.pointerMode=true;this.pointerTargetId=owner;U.q('[data-pointer]',this.root).classList.add('active');U.toast('Pointer enabled. Move over the shared screen.','ok');
    }
    pointerMove(e,force=false){
      if(!this.pointerMode)return;const tile=this.pointerTile();if(!tile||tile.dataset.owner!==this.pointerTargetId)return;const now=performance.now();if(!force&&now-this.pointerMoveAt<35)return;this.pointerMoveAt=now;const r=tile.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)return;const data={type:'pointer',target:this.pointerTargetId,sender:this.connectionId,x:(e.clientX-r.left)/r.width,y:(e.clientY-r.top)/r.height,name:this.profile.full_name||'Participant'};this.sendData(data,'pointer');this.showPointer(data.x,data.y,data.name,data.target);
    }
    showPointer(x,y,name,targetId){if(!(x>=0&&x<=1&&y>=0&&y<=1))return;const tile=U.qa('.video-tile',this.root).find(t=>t.dataset.owner===targetId&&t.dataset.sharing==='1')||this.pointerTile();if(!tile)return;let d=tile.querySelector('.pointer-dot');if(!d){d=document.createElement('div');d.className='pointer-dot';tile.appendChild(d);}d.dataset.name=name||'Pointer';d.style.left=`${x*100}%`;d.style.top=`${y*100}%`;d.classList.remove('hidden');clearTimeout(d._hide);d._hide=setTimeout(()=>d.classList.add('hidden'),1800)}

    participantPubs(p){ return Array.from(p?.trackPublications?.values?.()||[]); }
    async fullscreenTile(tile){
      if(!tile)return;
      try{if(document.fullscreenElement===tile)await document.exitFullscreen?.();else await tile.requestFullscreen?.();}
      catch{U.toast('Full screen is not available in this browser.','warn')}
    }
    addShareFullscreen(tile){
      if(!tile||tile.dataset.sharing!=='1')return;
      const b=document.createElement('button');b.type='button';b.className='share-fullscreen-btn';b.title='View shared screen full screen';b.setAttribute('aria-label','View shared screen full screen');b.innerHTML=`${U.icon('maximize')}<span>Full screen</span>`;
      b.onclick=e=>{e.stopPropagation();this.fullscreenTile(tile)};tile.appendChild(b);
    }
    applySpotlight(grid){
      const tiles=[...grid.children];if(!tiles.length)return;
      const sharing=tiles.find(t=>t.dataset.sharing==='1');
      const local=tiles.find(t=>t.dataset.local==='1');
      const remotes=tiles.filter(t=>t.dataset.local!=='1');
      const oneToOne=!sharing&&local&&remotes.length===1;
      let focus=sharing;
      if(!focus&&this.activeSpeakerId)focus=remotes.find(t=>t.dataset.identity===this.activeSpeakerId&&t.dataset.video==='1');
      if(!focus)focus=remotes.find(t=>t.dataset.video==='1')||remotes[0]||tiles.find(t=>t.dataset.video==='1')||tiles[0];
      tiles.forEach(t=>{t.classList.toggle('spotlight',t===focus);t.classList.toggle('self-preview',oneToOne&&t===local)});
      grid.classList.toggle('one-to-one-call',!!oneToOne);
      grid.classList.toggle('has-spotlight',!oneToOne&&tiles.length>1);
    }
    renderParticipants(){
      if(this.mode==='p2p')return this.renderP2PParticipants();
      if(!this.room)return;const grid=U.q('#video-grid',this.root);if(!grid)return;grid.innerHTML='';
      const people=[this.room.localParticipant,...Array.from(this.room.remoteParticipants.values())];
      for(const p of people){
        const local=p===this.room.localParticipant,owner=local?this.connectionId:p.identity;
        const mappedOwner=local?this.connectionId:(this.shareIdentity.get(p.identity)||owner);
        const tile=document.createElement('article');tile.className='video-tile';tile.dataset.owner=mappedOwner||'';tile.dataset.identity=p.identity||mappedOwner||'';tile.dataset.local=local?'1':'0';const name=p.name||(local?(this.profile.full_name||'You'):'Participant');
        tile.innerHTML=`<div class="video-placeholder"><div class="avatar big">${U.esc(name.slice(0,1).toUpperCase())}</div></div><div class="video-label">${U.esc(name)}${local?' (You)':''}</div>`;
        const pubs=this.participantPubs(p),screen=pubs.find(x=>String(x.source).includes('screen')&&x.track),cam=pubs.find(x=>String(x.source).includes('camera')&&x.track),video=screen||cam;
        tile.dataset.sharing=screen?'1':'0';tile.dataset.video=video?'1':'0';if(screen&&!local)this.sharePeers.add(mappedOwner);
        if(video?.track){try{const el=video.track.attach();el.autoplay=true;el.playsInline=true;el.muted=local;tile.prepend(el);}catch{}}
        const audios=pubs.filter(x=>String(x.source).includes('microphone')&&x.track);for(const pub of audios){if(!local){try{const a=pub.track.attach();a.autoplay=true;a.style.display='none';a.muted=this.speakerMuted;tile.appendChild(a);a.play().catch(()=>this.audioUnlockButton())}catch{}}}
        grid.appendChild(tile);if(screen)this.addShareFullscreen(tile);
      }
      grid.dataset.count=String(people.length);this.applySpotlight(grid);
    }

    renderP2PParticipants(){
      const grid=U.q('#video-grid',this.root);if(!grid)return;grid.innerHTML='';
      const add=(name,stream,local=false,peerId='self',sharing=false)=>{if(!local)this.attachRemoteAudio(peerId,stream);
        const tile=document.createElement('article');tile.className='video-tile';tile.dataset.owner=local?this.connectionId:peerId;tile.dataset.identity=peerId;tile.dataset.local=local?'1':'0';tile.dataset.sharing=sharing?'1':'0';
        tile.innerHTML=`<div class="video-placeholder"><div class="avatar big">${U.esc((name||'P')[0].toUpperCase())}</div></div><div class="video-label">${U.esc(name||'Participant')}${local?' (You)':''}</div>`;
        if(stream?.getVideoTracks().length){tile.dataset.video='1';const v=document.createElement('video');v.autoplay=true;v.playsInline=true;v.muted=true;v.srcObject=new MediaStream(stream.getVideoTracks());tile.prepend(v);v.play().catch(()=>{});}else tile.dataset.video='0';
        grid.appendChild(tile);if(sharing)this.addShareFullscreen(tile);
      };
      const localVideo=new MediaStream();const videoTrack=this.screenTrack||(this.cameraTrack?.enabled?this.cameraTrack:null);if(videoTrack)localVideo.addTrack(videoTrack);if(this.micTrack)localVideo.addTrack(this.micTrack);
      add(this.profile.full_name||'You',localVideo,true,this.connectionId,!!this.screenTrack);
      for(const [id,p] of this.p2pPeers)add(this.p2pMeta.get(id)?.name||'Participant',p.stream,false,id,this.sharePeers.has(id));
      grid.dataset.count=String(this.p2pPeers.size+1);this.applySpotlight(grid);
    }

    side(title,html,mode){const s=U.q('#meeting-side',this.root);s.classList.remove('hidden');s.dataset.mode=mode;U.q('#side-content',s).innerHTML=`<div class="side-head"><strong>${U.esc(title)}</strong><button class="icon-btn" data-x>${U.icon('close')}</button></div>${html}`;U.q('[data-x]',s).onclick=()=>s.classList.add('hidden');return s}
    showPeople(){
      let ps=[];
      if(this.mode==='livekit'&&this.room) ps=[this.room.localParticipant,...Array.from(this.room.remoteParticipants.values())].map(p=>({name:p.name||'Participant',id:p.identity,local:p===this.room.localParticipant}));
      else ps=[{name:this.profile.full_name||'You',id:this.connectionId,local:true},...[...this.p2pPeers.keys()].map(id=>({name:this.p2pMeta.get(id)?.name||'Participant',id,local:false}))];
      this.side(`Participants (${ps.length})`,`<div class="list">${ps.map(p=>`<div class="list-item"><span class="avatar">${U.esc((p.name||'P')[0])}</span><div><strong>${U.esc(p.name||'Participant')}${p.local?' (You)':''}</strong><div class="tiny">${U.esc(U.shortId(p.id))}</div></div></div>`).join('')}</div>`,'people');
    }
    showChat(){const html=`<div class="meeting-chat" id="meeting-chat-list">${this.chat.length?this.chat.map(m=>`<div class="chat-line"><b>${U.esc(m.name)}</b><span>${U.esc(m.text)}</span></div>`).join(''):'<div class="empty">No meeting chat yet.</div>'}</div><form id="meeting-chat-form" class="composer"><input class="input" id="meeting-chat-input" maxlength="1000" placeholder="Message participants"><button class="btn primary">Send</button></form>`;const s=this.side('Meeting chat',html,'chat');U.q('#meeting-chat-form',s).onsubmit=e=>{e.preventDefault();const i=U.q('#meeting-chat-input',s),text=i.value.trim();if(!text)return;this.chat.push({name:'You',text,time:new Date()});this.sendData({type:'chat',text,name:this.profile.full_name||'You'},'chat');i.value='';this.showChat()};}

    async showDevices(){
      try{
        const devices=await navigator.mediaDevices.enumerateDevices(),ins=devices.filter(x=>x.kind==='audioinput'),outs=devices.filter(x=>x.kind==='audiooutput');
        const html=`<div class="field"><label>Microphone</label><select id="audio-in" class="select"><option value="">System default</option>${ins.map(x=>`<option value="${U.attr(x.deviceId)}">${U.esc(x.label||'Microphone')}</option>`).join('')}</select></div><div class="field"><label>Speaker / headphone</label><select id="audio-out" class="select"><option value="">System default</option>${outs.map(x=>`<option value="${U.attr(x.deviceId)}">${U.esc(x.label||'Output')}</option>`).join('')}</select></div><p class="hint">Speaker selection depends on browser/OS support. Bluetooth/USB headsets normally appear after permission is granted.</p>`;
        const s=this.side('Audio devices',html,'devices');
        U.q('#audio-in',s).onchange=e=>this.switchMicrophone(e.target.value);
        U.q('#audio-out',s).onchange=e=>this.switchOutput(e.target.value);
      }catch(e){U.toast(U.errorText(e),'error')}
    }

    async switchMicrophone(deviceId){
      try{
        if(this.mode==='livekit'){await this.room.switchActiveDevice('audioinput',deviceId);return;}
        const s=await navigator.mediaDevices.getUserMedia({audio:{...(deviceId?{deviceId:{exact:deviceId}}:{}),echoCancellation:true,noiseSuppression:true},video:false}),track=s.getAudioTracks()[0];
        const old=this.micTrack;track.enabled=old?.enabled??true;this.micTrack=track;if(old){this.localStream.removeTrack(old);old.stop()}this.localStream.addTrack(track);for(const p of this.p2pPeers.values())await p.audioSender?.replaceTrack(track);U.toast('Microphone changed.','ok');
      }catch(e){U.toast(U.errorText(e),'error')}
    }
    async switchOutput(deviceId){
      try{
        if(this.mode==='livekit'&&this.room?.switchActiveDevice){await this.room.switchActiveDevice('audiooutput',deviceId);return;}
        if(!HTMLMediaElement.prototype.setSinkId){U.toast('Choose the speaker in your device settings; this browser does not support speaker selection.','warn');return}this.audioOutputId=deviceId;for(const el of U.qa('video,audio',this.root)){if(el.setSinkId&&!el.muted)await el.setSinkId(deviceId)}U.toast('Audio output changed.','ok');
      }catch(e){U.toast('This browser does not allow selecting that speaker/headset.','warn')}
    }

    attachRemoteAudio(id,stream){
      if(!this.root||!stream)return;let audio=this.remoteAudio.get(id);
      if(!audio){audio=document.createElement('audio');audio.autoplay=true;audio.playsInline=true;audio.setAttribute('aria-hidden','true');audio.style.cssText='position:absolute;width:1px;height:1px;opacity:.001;pointer-events:none;left:-9999px;top:0';audio.dataset.remotePeer=id;this.root.appendChild(audio);this.remoteAudio.set(id,audio);}
      if(audio.srcObject!==stream)audio.srcObject=stream;
      audio.muted=this.speakerMuted;audio.volume=1;
      if(this.audioOutputId&&audio.setSinkId)audio.setSinkId(this.audioOutputId).catch(()=>{});
      if(audio.paused&&stream.getAudioTracks().some(t=>t.readyState==='live'))audio.play().catch(()=>this.audioUnlockButton());
    }
    audioUnlockButton(){
      if(!this.root||this.root.querySelector('[data-unlock-audio]'))return;
      const button=document.createElement('button');button.type='button';button.dataset.unlockAudio='1';button.className='btn primary';button.textContent='Tap to hear audio';
      button.style.cssText='position:absolute;bottom:90px;left:50%;transform:translateX(-50%);z-index:50';
      button.onclick=async()=>{try{if(this.room)await this.room.startAudio();await Promise.all([...this.remoteAudio.values()].map(a=>a.play()));button.remove();}catch{U.toast('Enable sound for this website and check the speaker/headphone output.','error');}};this.root.appendChild(button);
    }
    async ensureAudio(){try{await this.room?.startAudio();if(this.room&&this.room.canPlaybackAudio===false)this.audioUnlockButton();}catch{this.audioUnlockButton();}}


    async cleanupMediaOnly(){
      try{await this.room?.disconnect()}catch{}this.room=null;
      for(const id of [...this.p2pPeers.keys()])this.dropP2PPeer(id);
      if(this.p2pChannel){try{await this.p2pChannel.untrack()}catch{}try{await this.client.removeChannel(this.p2pChannel)}catch{}this.p2pChannel=null;}
      this.localStream?.getTracks().forEach(t=>{try{t.stop()}catch{}});this.localStream=new MediaStream();this.cameraTrack=null;this.micTrack=null;
      if(this.screenTrack)try{this.screenTrack.stop()}catch{}this.screenTrack=null;this.screenStream=null;this.mode=null;
    }

    async leave(silent=false){for(const audio of this.remoteAudio.values()){audio.pause();audio.srcObject=null;audio.remove();}this.remoteAudio.clear();
      if(this._leaving)return;this._leaving=true;clearInterval(this.heartbeatTimer);clearTimeout(this.pointerTimer);
      if(this.recording?.state==='recording')await this.stopRecording();
      if(this.joined){try{await U.timeout(this.attendance(true),2000)}catch{}}
      try{if(!this.guest)await this.client.rpc('finish_direct_call',{meeting_input:this.meeting.id})}catch{}
      await this.cleanupMediaOnly();this.joined=false;window.removeEventListener('beforeunload',this._beforeUnload);this.root?.remove();this.root=null;if(!silent)this.onExit();
    }
  }

  window.EduMeeting={open:async(client,meeting,opts)=>{const c=new MeetingController(client,meeting,opts);await c.open();return c},MeetingController};
})();
