package com.nextechdigitalacademy.educhat_pro

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import io.flutter.plugin.common.MethodChannel

/**
 * Requests every permission that Edu Chat Pro needs for calls, voice and alerts.
 *
 * Missing permissions are checked on every app start instead of being hidden by
 * a one-time "completed" flag. Android itself decides whether it can show the
 * native prompt again. When Android has permanently blocked a prompt, the app
 * shows a clear shortcut to the app permission/settings screen.
 */
class StartupPermissions(private val activity: Activity) {
    private var pending: MethodChannel.Result? = null

    private fun requestedPermissions(): MutableList<String> = mutableListOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO
    ).apply {
        if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun missingPermissions(): List<String> = requestedPermissions().filter {
        activity.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
    }

    fun request(result: MethodChannel.Result) {
        if (pending != null) {
            result.error("busy", "Permission setup is already open", null)
            return
        }
        pending = result
        val missing = missingPermissions()
        if (missing.isEmpty()) {
            fullScreen()
        } else {
            activity.requestPermissions(missing.toTypedArray(), 804)
        }
    }

    fun permissionResult(code: Int): Boolean {
        if (code != 804) return false
        val missing = missingPermissions()
        if (missing.isNotEmpty()) {
            showMissingSettings(missing)
        } else {
            fullScreen()
        }
        return true
    }

    private fun label(permission: String): String = when (permission) {
        Manifest.permission.CAMERA -> "Camera"
        Manifest.permission.RECORD_AUDIO -> "Microphone"
        Manifest.permission.BLUETOOTH_CONNECT -> "Nearby devices / Bluetooth"
        Manifest.permission.POST_NOTIFICATIONS -> "Notifications"
        else -> "Permission"
    }

    private fun showMissingSettings(missing: List<String>) {
        if (pending == null) return
        val names = missing.map(::label).distinct().joinToString(", ")
        AlertDialog.Builder(activity)
            .setTitle("Permission needed")
            .setMessage("Allow $names so calls, voice messages, video and notifications work correctly. If Android no longer shows the permission popup, open App permissions and set them to Allow. Edu Chat Pro will ask again the next time the permission is needed.")
            .setPositiveButton("Open app permissions") { _, _ ->
                try {
                    activity.startActivityForResult(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${activity.packageName}")
                        ), 807
                    )
                } catch (_: Exception) {
                    fullScreen()
                }
            }
            .setNegativeButton("Not now") { _, _ -> fullScreen() }
            .setOnCancelListener { fullScreen() }
            .show()
    }

    private fun fullScreen() {
        if (pending == null) return
        val manager = activity.getSystemService(Activity.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 34 && !manager.canUseFullScreenIntent()) {
            AlertDialog.Builder(activity)
                .setTitle("Incoming call screen")
                .setMessage("Allow Edu Chat Pro to show incoming calls over the lock screen. Android will open this app’s call-screen setting.")
                .setPositiveButton("Open setting") { _, _ ->
                    try {
                        activity.startActivityForResult(
                            Intent(
                                Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                Uri.parse("package:${activity.packageName}")
                            ), 805
                        )
                    } catch (_: Exception) {
                        finish()
                    }
                }
                .setNegativeButton("Not now") { _, _ -> finish() }
                .setOnCancelListener { finish() }
                .show()
        } else finish()
    }

    fun activityResult(code: Int): Boolean {
        if (code == 807) {
            // Do not trap the user in a settings loop. The next app start or
            // feature use will request anything that is still missing.
            fullScreen()
            return true
        }
        if (code == 805) {
            finish()
            return true
        }
        return false
    }

    private fun finish() {
        val result = pending
        pending = null
        result?.success(null)
    }
}
