import 'stored_image.dart';
import 'package:flutter/material.dart';
import '../services/edu_repository.dart';
import '../services/profile_photos.dart';

class UserAvatar extends StatefulWidget {
  const UserAvatar(
      {super.key,
      required this.repo,
      this.userId,
      this.path,
      this.name,
      this.radius = 22});
  final EduRepository repo;
  final String? userId, path, name;
  final double radius;
  @override
  State<UserAvatar> createState() => _UserAvatarState();
}

class _UserAvatarState extends State<UserAvatar> {
  ProfilePhotos? photos;
  String? watchedId;
  void changed() {
    if (mounted) setState(() {});
  }

  void attach() {
    final id = widget.userId;
    if (id == null || id.isEmpty) return;
    watchedId = id;
    photos = ProfilePhotos.acquire(widget.repo, id);
    photos!.addListener(changed);
  }

  void detach() {
    photos?.removeListener(changed);
    if (watchedId != null) photos?.release(watchedId!);
    photos = null;
    watchedId = null;
  }

  @override
  void initState() {
    super.initState();
    attach();
  }

  @override
  void didUpdateWidget(UserAvatar old) {
    super.didUpdateWidget(old);
    if (old.userId != widget.userId || old.repo != widget.repo) {
      detach();
      attach();
    }
  }

  @override
  void dispose() {
    detach();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final fresh = photos?.profiles[widget.userId];
    final savedPath = fresh?['avatar_path'] as String?;
    // A row supplied by the chat/forum query is already current. Do not let a
    // just-restored metadata cache with a null path hide that photo.
    final path = savedPath == null || savedPath.isEmpty ? widget.path : savedPath;
    return CircleAvatar(
        radius: widget.radius,
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
        child: path == null || path.isEmpty
            ? Icon(Icons.person_rounded,
                color: Theme.of(context).colorScheme.primary)
            : ClipOval(
                child: StoredImage(
                    key: ValueKey('${widget.userId}/$path'),
                    repo: widget.repo,
                    bucket: 'avatars',
                    path: path,
                    width: widget.radius * 2,
                    height: widget.radius * 2,
                    decodeWidth: 160,
                    // A stable icon is preferable to a progress/loading
                    // indicator while a first-time photo is read from disk.
                    placeholder: Icon(Icons.person_rounded,
                        color: Theme.of(context).colorScheme.primary))));
  }
}
