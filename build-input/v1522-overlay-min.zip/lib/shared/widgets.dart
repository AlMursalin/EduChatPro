import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'social_widgets.dart';
import 'package:flutter/material.dart';
import '../services/edu_repository.dart';
import '../theme/app_theme.dart';

void notice(BuildContext context, Object message) {
  final messenger = ScaffoldMessenger.maybeOf(context);
  if (messenger == null) return;
  messenger
    ..hideCurrentSnackBar()
    ..hideCurrentMaterialBanner()
    ..showMaterialBanner(MaterialBanner(
        content: Text(message.toString()),
        leading: const Icon(Icons.info_outline),
        actions: [
          TextButton(
              onPressed: messenger.hideCurrentMaterialBanner,
              child: const Text('Close'))
        ]));
}

/// Stored as readable text so older app/web versions can still show replies.
class ChatReplyParts {
  const ChatReplyParts({required this.body, this.quote});
  final String body;
  final String? quote;
}

String replyMessage(String name, String quoted, String body) {
  final clean = quoted.replaceAll(RegExp(r'\s+'), ' ').trim();
  final clipped = clean.substring(0, clean.length > 240 ? 240 : clean.length);
  return '↪ $name: $clipped\n\n$body';
}

ChatReplyParts splitReplyMessage(String value) {
  if (!value.startsWith('↪ ')) return ChatReplyParts(body: value);
  final cut = value.indexOf('\n\n');
  if (cut < 0) return ChatReplyParts(body: value);
  return ChatReplyParts(
      body: value.substring(cut + 2), quote: value.substring(2, cut));
}

Future<void> perform(BuildContext context, Future<void> Function() action,
    {String? success}) async {
  try {
    await action();
    if (context.mounted && success != null) notice(context, success);
  } catch (e) {
    if (context.mounted) notice(context, e);
  }
}

Future<bool> confirm(BuildContext context, String title, String body) async =>
    await showDialog<bool>(
        context: context,
        builder: (context) =>
            AlertDialog(title: Text(title), content: Text(body), actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: Text('Cancel')),
              FilledButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: Text('Confirm'))
            ])) ??
    false;

Future<List<String>?> formDialog(
    BuildContext context, String title, List<String> labels,
    {List<String>? initial}) async {
  final controllers = List.generate(
      labels.length, (i) => TextEditingController(text: initial?[i] ?? ''));
  final key = GlobalKey<FormState>();
  final result = await showDialog<List<String>>(
      context: context,
      builder: (context) => AlertDialog(
              title: Text(title),
              content: SizedBox(
                  width: 440,
                  child: Form(
                      key: key,
                      child: SingleChildScrollView(
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: List.generate(
                                  labels.length,
                                  (i) => Padding(
                                      padding: EdgeInsets.only(bottom: 16),
                                      child: TextFormField(
                                          controller: controllers[i],
                                          decoration: InputDecoration(
                                              labelText: labels[i]),
                                          maxLines:
                                              labels[i].contains('Description')
                                                  ? 4
                                                  : 1,
                                          validator: (v) =>
                                              (v ?? '').trim().isEmpty
                                                  ? 'Required'
                                                  : null))))))),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text('Cancel')),
                FilledButton(
                    onPressed: () {
                      if (key.currentState!.validate()) {
                        Navigator.pop(context,
                            controllers.map((c) => c.text.trim()).toList());
                      }
                    },
                    child: Text('Save'))
              ]));
  // Dialog route may still animate; dispose controllers after that transition.
  Future<void>.delayed(Duration(milliseconds: 400), () {
    for (final c in controllers) {
      c.dispose();
    }
  });
  return result;
}

class PageHeader extends StatelessWidget {
  const PageHeader(this.title, this.subtitle,
      {super.key, this.actions = const []});
  final String title, subtitle;
  final List<Widget> actions;
  @override
  Widget build(BuildContext context) => Padding(
      padding: EdgeInsets.fromLTRB(24, 28, 24, 20),
      child: LayoutBuilder(builder: (context, constraints) {
        final compact = constraints.maxWidth < 620;
        final heading = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title, style: Theme.of(context).textTheme.headlineMedium),
              SizedBox(height: 6),
              Text(subtitle, style: Theme.of(context).textTheme.bodyMedium)
            ]);
        if (compact) {
          return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                heading,
                if (actions.isNotEmpty) ...[
                  SizedBox(height: 16),
                  Wrap(spacing: 10, runSpacing: 10, children: actions)
                ]
              ]);
        }
        return Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Expanded(child: heading),
          if (actions.isNotEmpty)
            Wrap(spacing: 10, runSpacing: 10, children: actions)
        ]);
      }));
}

class PagedList extends StatefulWidget {
  const PagedList(
      {super.key,
      required this.load,
      required this.builder,
      this.reverse = false,
      this.cacheKey,
      this.empty = 'Nothing here yet.'});
  final Future<List<JsonRow>> Function(int offset) load;
  final Widget Function(JsonRow row) builder;
  final String empty;
  final String? cacheKey;
  final bool reverse;
  @override
  State<PagedList> createState() => PagedListState();
}

class PagedListState extends State<PagedList> with WidgetsBindingObserver {
  static final snapshots = <String, List<JsonRow>>{};
  final rows = <JsonRow>[];
  final ScrollController _scroll = ScrollController();
  Future<void>? activeRefresh;
  bool refreshQueued = false;
  void remember() {
    final key = widget.cacheKey;
    if (key == null) return;
    snapshots.remove(key);
    snapshots[key] = List.of(rows);
    while (snapshots.length > 24) snapshots.remove(snapshots.keys.first);
    unawaited(_writeDisk());
  }

  bool busy = false, more = true;
  Object? error;
  int generation = 0;
  bool _serverLoaded = false;
  bool _readingHistory = false;

  Future<File?> _diskFile() async {
    final key = widget.cacheKey;
    if (key == null) return null;
    final dir = Directory(
        '${(await getApplicationSupportDirectory()).path}/ecp-list-cache');
    await dir.create(recursive: true);
    return File('${dir.path}/${sha256.convert(utf8.encode(key))}.json');
  }

  Future<void> _restoreDisk() async {
    if (widget.cacheKey == null || rows.isNotEmpty) return;
    try {
      final file = await _diskFile();
      if (file == null || !await file.exists()) return;
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! List || !mounted || _serverLoaded || rows.isNotEmpty) {
        return;
      }
      final cached = decoded
          .whereType<Map>()
          .map((e) => JsonRow.from(Map<String, dynamic>.from(e)))
          .toList();
      if (cached.isNotEmpty) setState(() => rows.addAll(cached));
    } catch (_) {}
  }

  Future<void> _writeDisk() async {
    if (widget.cacheKey == null) return;
    try {
      final file = await _diskFile();
      await file?.writeAsString(jsonEncode(rows.take(200).toList()),
          flush: false);
    } catch (_) {}
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    rows.addAll(snapshots[widget.cacheKey] ?? const <JsonRow>[]);
    _scroll.addListener(_onScroll);
    unawaited(_restoreDisk());
    refresh();
  }

  void _onScroll() {
    if (!_scroll.hasClients) return;
    final position = _scroll.position;
    _readingHistory = widget.reverse && position.pixels > 80;
    // Forum and normal lists load the next page on downward scrolling. In a
    // reversed chat the visual top is also the remaining scroll extent.
    if (!busy && more && position.extentAfter < 280) unawaited(next());
    // Scrolling must never cause a complete server refresh.  It made chat
    // rows (and their avatars) rebuild repeatedly while someone read a
    // conversation. Realtime and explicit sends already refresh this list.
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) unawaited(refresh());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _scroll.removeListener(_onScroll);
    _scroll.dispose();
    super.dispose();
  }

  Future<void> refresh() {
    if (activeRefresh != null) {
      refreshQueued = true;
      return activeRefresh!;
    }
    if (busy) {
      refreshQueued = true;
      return Future.value();
    }
    activeRefresh = _refresh().whenComplete(() {
      activeRefresh = null;
      if (refreshQueued && mounted) {
        refreshQueued = false;
        unawaited(refresh());
      }
    });
    return activeRefresh!;
  }

  Future<void> _refresh() async {
    if (!mounted) return;
    if (busy) {
      refreshQueued = true;
      return;
    }
    final current = ++generation;
    busy = true;
    try {
      final result = <JsonRow>[];
      final target = rows.length < 30 ? 30 : rows.length;
      var hasMore = true;
      while (result.length < target && hasMore) {
        final page = await widget.load(result.length);
        result.addAll(page);
        hasMore = page.length == EduRepository.pageSize;
      }
      if (mounted && current == generation) {
        _serverLoaded = true;
        busy = false;
        final changed = jsonEncode(rows) != jsonEncode(result) ||
            error != null ||
            more != hasMore;
        // Do not replace the list while someone is reading old messages at
        // the top. New messages are fetched when they return to the bottom.
        if (widget.reverse && _readingHistory && rows.isNotEmpty && changed) {
          return;
        }
        if (changed)
          setState(() {
            rows
              ..clear()
              ..addAll(result);
            more = hasMore;
            error = null;
          });
        remember();
      }
    } catch (e) {
      if (mounted && current == generation) setState(() => error = e);
    } finally {
      busy = false;
    }
  }

  Future<void> next() async {
    if (busy || !more) return;
    final current = generation;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final result = await widget.load(rows.length);
      if (mounted && current == generation) {
        setState(() {
          rows.addAll(result);
          remember();
          more = result.length == EduRepository.pageSize;
        });
      }
    } catch (e) {
      if (mounted && current == generation) setState(() => error = e);
    } finally {
      if (mounted && current == generation) setState(() => busy = false);
      if (refreshQueued && mounted) {
        refreshQueued = false;
        unawaited(refresh());
      }
    }
  }

  @override
  Widget build(BuildContext context) => rows.isEmpty &&
          !busy &&
          error == null &&
          widget.empty == 'No messages yet'
      ? const ChatEmpty()
      : RefreshIndicator(
          onRefresh: refresh,
          child: ListView.builder(
              controller: _scroll,
              reverse: widget.reverse,
              padding: EdgeInsets.fromLTRB(24, 0, 24, 28),
              physics: AlwaysScrollableScrollPhysics(),
              itemCount: rows.length + 1,
              itemBuilder: (context, index) {
                if (index < rows.length)
                  return KeyedSubtree(
                      key: ValueKey(rows[index]['id'] ??
                          '${rows[index]['thread_kind']}/${rows[index]['thread_id'] ?? index}'),
                      child: widget.builder(rows[index]));
                return Padding(
                    padding: EdgeInsets.all(20),
                    child: Column(children: [
                      if (error != null) ...[
                        Container(
                            padding: EdgeInsets.all(16),
                            decoration: BoxDecoration(
                                color: Color(0xFFFFF3F4),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: Color(0xFFFFD9DE))),
                            child: Text('Could not load: $error',
                                style: TextStyle(color: AppColors.danger))),
                        TextButton(onPressed: refresh, child: Text('Retry'))
                      ] else if (busy)
                        const SizedBox.shrink()
                      else if (rows.isEmpty &&
                          widget.empty == 'No messages yet')
                        const ChatEmpty()
                      else if (rows.isEmpty)
                        Padding(
                            padding: EdgeInsets.symmetric(vertical: 30),
                            child: Column(children: [
                              Icon(Icons.inbox_outlined,
                                  size: 42,
                                  color: Theme.of(context)
                                      .colorScheme
                                      .onSurfaceVariant),
                              SizedBox(height: 12),
                              Text(widget.empty, textAlign: TextAlign.center)
                            ]))
                      else if (more)
                        OutlinedButton(
                            onPressed: next, child: Text('Load more'))
                    ]));
              }));
}
