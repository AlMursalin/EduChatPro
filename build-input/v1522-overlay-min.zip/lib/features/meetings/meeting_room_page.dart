import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../services/local_recording.dart';
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart' as rtc;
import 'package:flutter_background/flutter_background.dart';
import 'package:uuid/uuid.dart';
import '../../config/app_config.dart';
import '../../services/edu_repository.dart';
import '../../services/supabase_webrtc_backend.dart';
import '../../shared/widgets.dart';
import '../../shared/meeting_invite.dart';

class MeetingRoomPage extends StatefulWidget {
  static String? activeMeetingId;
  const MeetingRoomPage({
    super.key,
    required this.repo,
    required this.meetingId,
    this.autoJoin = false,
    this.startWithMic = true,
    this.startWithCamera = false,
    this.callTitle,
  });
  final EduRepository repo;
  final String meetingId;
  final bool autoJoin;
  final bool startWithMic;
  final bool startWithCamera;
  final String? callTitle;

  @override
  State<MeetingRoomPage> createState() => _MeetingRoomPageState();
}

class _MeetingRoomPageState extends State<MeetingRoomPage> {
  final String connectionId = const Uuid().v4();
  late final SupabaseWebRtcBackend backend;
  Timer? heartbeat;
  bool expandedVideo=false;
  bool controlsExpanded=false;
  bool screenShareTransition=false;
  bool _screenShareBusy = false;
  bool busy = false;
  bool joined = false;
  bool _rebuildQueued = false;
  bool lowBandwidth = false;
  String? focusedPeer;
  final screenPeers=<String>{};
  final pointerAllowed=<String>{};
  final pointerGrants=<String>{};
  String? pointerTarget;
  Timer? pointerTimer;
  bool speaker = true;
  bool leaving = false;
  bool pointerMode = false;
  Offset? pointer;
  String? error;
  final List<String> chat = [];
  // This chat is deliberately scoped to the active WebRTC room.  It is sent
  // over the meeting data channel, never written to the permanent inbox, and
  // is discarded when the meeting ends.
  final ValueNotifier<int> _chatRevision = ValueNotifier<int>(0);
  final webRecorder = createLocalMeetingRecorder();
  rtc.MediaRecorder? nativeRecorder;
  bool recording = false;
  String? recordingPath;
  String? meetingTitle;

  @override
  void initState() {
    super.initState();
    MeetingRoomPage.activeMeetingId = widget.meetingId;
    backend = SupabaseWebRtcBackend(
      widget.repo,
      meetingId: widget.meetingId,
      connectionId: connectionId,
    );
    backend.addListener(_changed);
    backend.onData = _handleData;
    _prepare();
  }

  Future<void> _prepare() async {
    try {
      final meeting = await widget.repo.client
          .from('meetings')
          .select('title')
          .eq('id', widget.meetingId)
          .single();
      meetingTitle = meeting['title'];
      await backend.initialize();
      if (widget.autoJoin && mounted) await join();
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  void _changed() {
    if (!mounted || _rebuildQueued) return;
    _rebuildQueued = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _rebuildQueued = false;
      if (mounted) setState(() {});
    });
  }

  void _handleData(Map<String, dynamic> data) async {
    final type = data['type']?.toString();
    if (type == 'chat') {
      final text = data['text']?.toString() ?? '';
      if (text.isNotEmpty && text.length <= 1000) {
        chat.add('${data['name'] ?? 'Participant'}: $text');
        if (chat.length > 100) chat.removeAt(0);
        _chatRevision.value++;
      }
    } else if(type=='share-state'){
      final id=(data['owner']??data['from'])?.toString();
      if(id!=null){if(data['active']==true){screenPeers.add(id);focusedPeer=id;}else{screenPeers.remove(id);pointerGrants.remove(id);if(focusedPeer==id)focusedPeer=null;}}
    } else if(type=='pointer-request'&&data['target']==connectionId&&backend.screenEnabled){
      final id=data['from']?.toString();if(id==null||!mounted)return;
      final allow=await confirm(context,'Allow pointer','${data['name']??'A participant'} wants to point on your shared screen.');
      if(allow)pointerAllowed.add(id);else pointerAllowed.remove(id);
      await backend.sendData({'type':'pointer-permission','target':id,'owner':connectionId,'granted':allow});
    } else if(type=='pointer-permission'&&data['target']==connectionId){
      final id=data['owner']?.toString();if(id==null)return;
      if(data['granted']==true){pointerGrants.add(id);pointerTarget=id;pointerMode=true;}else{pointerGrants.remove(id);pointerMode=false;}
    } else if (type == 'pointer') {
      final target=data['target']?.toString(),sender=data['from']?.toString();
      if(target==null||target!=(focusedPeer??screenPeers.firstOrNull))return;
      if(target==connectionId&&sender!=connectionId&&!pointerAllowed.contains(sender))return;
      pointerTimer?.cancel();pointerTimer=Timer(const Duration(seconds:2),(){if(mounted)setState(()=>pointer=null);});
      final x = data['x'];
      final y = data['y'];
      if (x is num && y is num) {
        pointer = Offset(x.toDouble().clamp(0, 1), y.toDouble().clamp(0, 1));
      }
    }
    if (mounted) setState(() {});
  }

  Future<void> join() async {
    if (busy || joined) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      // Acquire audio BEFORE announcing presence/offering SDP.
      await backend.microphone(widget.startWithMic);
      await backend.setSpeaker(speaker);
      if(widget.startWithCamera)await backend.camera(true,lowBandwidth:lowBandwidth);
      await backend.connect();
      try {
        await widget.repo.attendance(widget.meetingId, connectionId);
      } catch (_) {}
      joined = true;

      heartbeat = Timer.periodic(const Duration(seconds: 25), (_) async {
        if (!joined) return;
        try {
          final row = await widget.repo.client
              .from('meetings')
              .select('ended_at')
              .eq('id', widget.meetingId)
              .single();
          if (row['ended_at'] != null) {
            await leave();
            return;
          }
          await widget.repo.attendance(widget.meetingId, connectionId);
        } catch (_) {}
      });
    } catch (e) {
      error = e.toString();
      await backend.disconnect();
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> leave() async {
    if (leaving) return;
    leaving = true;
    heartbeat?.cancel();
    if (recording) {
      try {
        await toggleRecording();
      } catch (_) {}
    }
    try {
      await widget.repo
          .attendance(widget.meetingId, connectionId, leaving: true);
    } catch (_) {}
    if (!kIsWeb &&
        defaultTargetPlatform == TargetPlatform.android &&
        FlutterBackground.isBackgroundExecutionEnabled) {
      try {
        await FlutterBackground.disableBackgroundExecution();
      } catch (_) {}
    }
    try {
      await widget.repo.client.rpc('finish_direct_call',
          params: {'meeting_input': widget.meetingId});
    } catch (_) {}
    await backend.disconnect();
    joined = false;
    chat.clear();
    _chatRevision.value++;
    if (mounted) Navigator.pop(context);
  }

  Future<void> _run(Future<void> Function() fn) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      await fn();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.toString())));
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> toggleScreen() async {
    if (_screenShareBusy) return;
    _screenShareBusy = true;
    if (mounted) setState(() {});
    final enable = !backend.screenEnabled;
    try {
      if (enable && !kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
        final initialized = await FlutterBackground.initialize(
          androidConfig: const FlutterBackgroundAndroidConfig(
            notificationTitle: 'Edu Chat Pro',
            notificationText: 'Screen sharing is active',
            notificationImportance: AndroidNotificationImportance.normal,
          ),
        );
        if (!initialized) {
          throw StateError('Android screen-share service could not start.');
        }
        final allowed = await rtc.Helper.requestCapturePermission();
        if (!allowed) return;
        final background = await FlutterBackground.enableBackgroundExecution();
        if (!background) {
          throw StateError('Screen-share foreground service could not start.');
        }
      }

      await backend.shareScreen(enable).timeout(const Duration(seconds: 12));

      if (!enable &&
          !kIsWeb &&
          defaultTargetPlatform == TargetPlatform.android &&
          FlutterBackground.isBackgroundExecutionEnabled) {
        await FlutterBackground.disableBackgroundExecution();
      }
    } catch (_) {
      if (enable &&
          !kIsWeb &&
          defaultTargetPlatform == TargetPlatform.android &&
          FlutterBackground.isBackgroundExecutionEnabled) {
        await FlutterBackground.disableBackgroundExecution();
      }
      rethrow;
    } finally {
      _screenShareBusy = false;
      if (mounted) setState(() {});
    }
  }

  Future<void> togglePointer() async {
    if(pointerMode){setState(()=>pointerMode=false);return;}
    final target=backend.screenEnabled?connectionId:(screenPeers.isEmpty?null:screenPeers.first);
    if(target==null){notice(context,'Select a shared screen first.');return;}
    if(target!=connectionId&&!pointerGrants.contains(target)){await backend.sendData({'type':'pointer-request','target':target});if(mounted)notice(context,'Pointer permission requested.');return;}
    setState((){pointerTarget=target;focusedPeer=target;pointerMode=true;});
  }

  Future<void> meetingChat() async {
    final input = TextEditingController();
    final scroll = ScrollController();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => DraggableScrollableSheet(
        initialChildSize: .62,
        minChildSize: .35,
        maxChildSize: .92,
        expand: false,
        builder: (_, controller) => Material(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          clipBehavior: Clip.antiAlias,
          child: SafeArea(
            top: false,
            child: Column(children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 16, 12, 8),
                child: Row(children: [
                  Icon(Icons.forum_outlined), SizedBox(width: 10),
                  Expanded(child: Text('Meeting chat', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
                ]),
              ),
              const Divider(height: 1),
              Expanded(
                child: ValueListenableBuilder<int>(
                  valueListenable: _chatRevision,
                  builder: (_, __, ___) {
                    WidgetsBinding.instance.addPostFrameCallback((_) {
                      if (scroll.hasClients) scroll.jumpTo(scroll.position.maxScrollExtent);
                    });
                    if (chat.isEmpty) return const Center(child: Text('No messages yet. Messages disappear when this call ends.'));
                    return ListView.separated(
                      controller: scroll,
                      padding: const EdgeInsets.all(16),
                      itemCount: chat.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (_, index) {
                        final line = chat[index];
                        final divider = line.indexOf(': ');
                        final who = divider < 0 ? 'Participant' : line.substring(0, divider);
                        final text = divider < 0 ? line : line.substring(divider + 2);
                        final mine = who == 'You';
                        return Align(
                          alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                          child: Container(
                            constraints: const BoxConstraints(maxWidth: 420),
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: mine ? Theme.of(context).colorScheme.primaryContainer : Theme.of(context).colorScheme.surfaceContainerHighest,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(who, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                              const SizedBox(height: 3), SelectableText(text),
                            ]),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(12, 8, 12, 12 + MediaQuery.viewInsetsOf(sheetContext).bottom),
                child: Row(children: [
                  Expanded(child: TextField(controller: input, maxLength: 1000, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(counterText: '', hintText: 'Write a message…', border: OutlineInputBorder()))),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    icon: const Icon(Icons.send),
                    onPressed: () async {
                      final text = input.text.trim();
                      if (text.isEmpty) return;
                      input.clear();
                      await backend.sendData({'type': 'chat', 'text': text});
                      chat.add('You: $text');
                      if (chat.length > 100) chat.removeAt(0);
                      _chatRevision.value++;
                    },
                  ),
                ]),
              ),
            ]),
          ),
        ),
      ),
    );
    input.dispose();
    scroll.dispose();
  }

  Future<void> copyInvite() async {
    await perform(context, () async {
      final meeting = await widget.repo.client
          .from('meetings')
          .select()
          .eq('id', widget.meetingId)
          .single();
      if (mounted) await showMeetingInvite(context, meeting);
    });
  }

  Future<void> toggleRecording() async {
    if (recording) {
      if (kIsWeb) {
        await webRecorder.stop();
        await webRecorder.save();
      } else {
        await nativeRecorder?.stop();
      }
      if (mounted) setState(() => recording = false);
      await backend.sendData({
        'type': 'chat',
        'name': backend.displayName,
        'text': 'Recording stopped.'
      });
      if (!kIsWeb && recordingPath != null)
        await Share.shareXFiles([XFile(recordingPath!)],
            sharePositionOrigin: const Rect.fromLTWH(0, 0, 100, 100));
      return;
    }
    if (!await confirm(context, 'Record this call?',
        'Confirm that participants agree. On mobile this saves your camera video locally; use screen recording for a full meeting view.'))
      return;
    if (kIsWeb) {
      await webRecorder.start(
          meetingId: widget.meetingId, participantsConsented: true);
    } else {
      if (!backend.cameraEnabled || backend.cameraTrack == null)
        throw StateError('Turn on your camera before recording.');
      final dir = await getApplicationDocumentsDirectory();
      recordingPath =
          '${dir.path}/EduChat-${DateTime.now().millisecondsSinceEpoch}.mp4';
      nativeRecorder = rtc.MediaRecorder();
      await nativeRecorder!
          .start(recordingPath!, videoTrack: backend.cameraTrack);
    }
    if (mounted) setState(() => recording = true);
    await backend.sendData({
      'type': 'chat',
      'name': backend.displayName,
      'text': 'Started recording with participant consent.'
    });
  }

  void showPeople() => showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF202326),
      builder: (c) => SafeArea(
              child: ListView(shrinkWrap: true, children: [
            ListTile(
                title: Text('${backend.displayName} (You)',
                    style: const TextStyle(color: Colors.white))),
            for (final p in backend.peers.values)
              ListTile(
                  leading:
                      const Icon(Icons.person_outline, color: Colors.white70),
                  title:
                      Text(p.name, style: const TextStyle(color: Colors.white)))
          ])));
  void showDevices() => showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF202326),
      builder: (c) => StatefulBuilder(
          builder: (c, refresh) => SafeArea(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                ListTile(
                    textColor: Colors.white,
                    iconColor: Colors.white,
                    leading: const Icon(Icons.cameraswitch),
                    title: const Text('Switch camera'),
                    onTap: backend.cameraEnabled
                        ? () => _run(backend.switchCamera)
                        : null),
                SwitchListTile(
                    title: const Text('Speaker',
                        style: TextStyle(color: Colors.white)),
                    value: speaker,
                    onChanged: (v) async {
                      await _run(() async {
                        speaker = v;
                        await backend.setSpeaker(v);
                      });
                      refresh(() {});
                    }),
                SwitchListTile(
                    title: const Text('Low bandwidth',
                        style: TextStyle(color: Colors.white)),
                    value: lowBandwidth,
                    onChanged: (v) {
                      setState(() => lowBandwidth = v);
                      refresh(() {});
                    })
              ]))));
  Widget callControl(IconData icon, String label, VoidCallback? action,
      {bool active = false, bool danger = false}) {
    final color = danger
        ? const Color(0xFFE62B35)
        : active
            ? const Color(0xFF1877F2)
            : const Color(0xFF2A2F36);
    return SizedBox(
      width: 66,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Material(
            color: action == null ? const Color(0xFF1E2227) : color,
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: action,
              child: SizedBox(
                width: 52,
                height: 52,
                child: Icon(icon,
                    color: action == null ? Colors.white30 : Colors.white,
                    size: 25),
              ),
            ),
          ),
          const SizedBox(height: 5),
          Text(label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  color: action == null ? Colors.white38 : Colors.white70,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _videoTile({
    required String name,
    required rtc.RTCVideoRenderer renderer,
    required bool local,
    bool sharing = false,
    bool compact = false,
    bool primary = false,
  }) {
    final hasVideo =
        renderer.srcObject?.getVideoTracks().any((t) => t.enabled) ?? false;
    final radius = compact ? 16.0 : (primary ? 0.0 : 22.0);
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF2D3742), Color(0xFF10151B), Color(0xFF05070A)],
          ),
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (hasVideo)
              rtc.RTCVideoView(
                renderer,
                mirror: local && !backend.screenEnabled,
                objectFit: sharing
                    ? rtc.RTCVideoViewObjectFit.RTCVideoViewObjectFitContain
                    : rtc.RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
              )
            else
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircleAvatar(
                      radius: compact ? 23 : (primary ? 58 : 34),
                      backgroundColor: const Color(0xFF147D74),
                      child: Text(
                        name.isEmpty ? '?' : name[0].toUpperCase(),
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: compact ? 19 : (primary ? 42 : 28),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    if (primary) ...[
                      const SizedBox(height: 13),
                      Text(
                        local ? '$name · You' : name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        backend.peers.isEmpty ? 'Calling…' : 'Connected',
                        style: const TextStyle(color: Colors.white60, fontSize: 12),
                      ),
                    ],
                  ],
                ),
              ),
            Positioned(
              left: compact ? 6 : 12,
              bottom: compact ? 6 : 12,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: compact ? 6 : 9, vertical: compact ? 3 : 5),
                  child: Text(
                    local ? '$name · You' : name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: compact ? 8.5 : 10.5,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _topOverlay(int count) => SafeArea(
        bottom: false,
        child: Container(
          padding: const EdgeInsets.fromLTRB(6, 4, 6, 22),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xD9000000), Color(0x00000000)],
            ),
          ),
          child: Row(
            children: [
              IconButton(
                tooltip: 'Back',
                onPressed: busy ? null : leave,
                icon: const Icon(Icons.arrow_back, color: Colors.white),
              ),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      meetingTitle ?? widget.callTitle ?? 'Meeting',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      recording
                          ? '● Recording · $count participants'
                          : backend.peers.isEmpty
                              ? 'Calling…'
                              : 'Connected · $count participants',
                      style: TextStyle(
                        color: recording
                            ? const Color(0xFFFF6B70)
                            : const Color(0xFFB8F2D9),
                        fontSize: 10.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: expandedVideo ? 'Show participant previews' : 'Focus view',
                onPressed: () => setState(() => expandedVideo = !expandedVideo),
                icon: Icon(
                  expandedVideo ? Icons.fullscreen_exit : Icons.fullscreen,
                  color: Colors.white,
                ),
              ),
              IconButton(
                tooltip: 'Invite / Share meeting link',
                onPressed: copyInvite,
                icon: const Icon(Icons.link, color: Colors.white),
              ),
            ],
          ),
        ),
      );

  Widget _bottomControls() {
    final extra=<Widget>[
      callControl(speaker?Icons.volume_up:Icons.volume_off,'Speaker',busy?null:()=>_run(() async{speaker=!speaker;await backend.setSpeaker(speaker);if(mounted)setState((){});}),active:speaker),
      callControl(Icons.desktop_windows_outlined,backend.screenEnabled?'Stop share':'Share',(busy||screenShareTransition)?null:()=>_run(() async {screenShareTransition=true;if(mounted)setState((){});try{await toggleScreen();}finally{screenShareTransition=false;if(mounted)setState((){});}}),active:backend.screenEnabled),
      callControl(Icons.radio_button_checked,recording?'Stop':'Record',busy?null:()=>_run(toggleRecording),active:recording),
      callControl(Icons.near_me_outlined,'Pointer',togglePointer,active:pointerMode),callControl(Icons.people_outline,'People',showPeople),callControl(Icons.chat_bubble_outline,'Chat',meetingChat),callControl(Icons.headset_mic_outlined,'Devices',showDevices)];
    return SafeArea(top:false,child:Padding(padding:const EdgeInsets.fromLTRB(8,0,8,7),child:Column(mainAxisSize:MainAxisSize.min,children:[
      AnimatedSize(duration:const Duration(milliseconds:190),curve:Curves.easeOutCubic,alignment:Alignment.bottomCenter,child:controlsExpanded?Container(width:double.infinity,margin:const EdgeInsets.only(bottom:8),padding:const EdgeInsets.fromLTRB(10,13,10,9),decoration:BoxDecoration(color:const Color(0xF2181C22),borderRadius:BorderRadius.circular(26),border:Border.all(color:Colors.white12),boxShadow:const[BoxShadow(color:Colors.black54,blurRadius:24,offset:Offset(0,10))]),child:Wrap(alignment:WrapAlignment.center,runAlignment:WrapAlignment.center,spacing:4,runSpacing:9,children:extra)):const SizedBox.shrink()),
      Container(padding:const EdgeInsets.fromLTRB(5,8,5,6),decoration:BoxDecoration(color:const Color(0xEA11151A),borderRadius:BorderRadius.circular(30),border:Border.all(color:Colors.white12),boxShadow:const[BoxShadow(color:Colors.black54,blurRadius:20,offset:Offset(0,8))]),child:Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[
        callControl(backend.micEnabled?Icons.mic:Icons.mic_off,'Mic',busy?null:()=>_run(()=>backend.microphone(!backend.micEnabled)),active:backend.micEnabled),
        callControl(backend.cameraEnabled?Icons.videocam:Icons.videocam_off,'Camera',busy?null:()=>_run(()=>backend.camera(!backend.cameraEnabled,lowBandwidth:lowBandwidth)),active:backend.cameraEnabled),
        callControl(Icons.call_end,'End',busy?null:leave,danger:true),
        callControl(controlsExpanded?Icons.keyboard_arrow_down:Icons.keyboard_arrow_up,controlsExpanded?'Less':'More',()=>setState(()=>controlsExpanded=!controlsExpanded),active:controlsExpanded)])
    )])));
  }

  // v141 mobile screen-share cleanup
  @override
  void dispose() {
    try {
      if (backend.screenEnabled) {
        backend.shareScreen(false);
      }
      if (!kIsWeb &&
          defaultTargetPlatform == TargetPlatform.android &&
          FlutterBackground.isBackgroundExecutionEnabled) {
        FlutterBackground.disableBackgroundExecution();
      }
    } catch (_) {}

    if (MeetingRoomPage.activeMeetingId == widget.meetingId)
      MeetingRoomPage.activeMeetingId = null;
    heartbeat?.cancel();
    pointerTimer?.cancel();
    _chatRevision.dispose();
    if (recording && !kIsWeb) {
      unawaited(
          nativeRecorder?.stop().then<void>((_) {}).catchError((Object _) {}) ??
              Future<void>.value());
    }
    unawaited(webRecorder.dispose());
    backend.removeListener(_changed);
    backend.dispose();
    if (!kIsWeb &&
        defaultTargetPlatform == TargetPlatform.android &&
        FlutterBackground.isBackgroundExecutionEnabled) {
      unawaited(FlutterBackground.disableBackgroundExecution());
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final peerList = backend.peers.values.toList();
    final count = joined ? peerList.length + 1 : 0;
    return PopScope(
      canPop: !joined,
      onPopInvoked: (didPop) {
        if (!didPop) leave();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF05070A),
        body: !joined
            ? SafeArea(
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 520),
                    child: Card(
                      margin: const EdgeInsets.all(20),
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.video_call_outlined, size: 54),
                            const SizedBox(height: 12),
                            const Text(
                              'Camera stays OFF when you join. It only turns on after you press Camera and allow permission.',
                              textAlign: TextAlign.center,
                            ),
                            if (error != null) ...[
                              const SizedBox(height: 12),
                              SelectableText(error!,
                                  style: TextStyle(
                                      color: Theme.of(context).colorScheme.error)),
                            ],
                            const SizedBox(height: 18),
                            FilledButton.icon(
                              onPressed: busy ? null : join,
                              icon: const Icon(Icons.login),
                              label: Text(busy ? 'Connecting…' : 'Join call'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              )
            : LayoutBuilder(
                builder: (context, box) {
                  final ids = <String>[
                    ...peerList.map((p) => p.id),
                    connectionId,
                  ];
                  final shares = screenPeers.where(ids.contains).toList();
                  final chosen = ids.contains(focusedPeer)
                      ? focusedPeer!
                      : (shares.isNotEmpty
                          ? shares.first
                          : (peerList.isNotEmpty
                              ? peerList.first.id
                              : connectionId));
                  final others = ids.where((id) => id != chosen).toList();

                  Widget tile(String id,
                      {bool compact = false, bool primary = false}) {
                    final self = id == connectionId;
                    final p = self ? null : backend.peers[id];
                    if (!self && p == null) return const SizedBox.shrink();
                    return GestureDetector(
                      onTap: compact
                          ? () => setState(() => focusedPeer = id)
                          : null,
                      child: _videoTile(
                        name: self ? backend.displayName : p!.name,
                        renderer:
                            self ? backend.localRenderer : p!.renderer,
                        local: self,
                        sharing: self
                            ? backend.screenEnabled
                            : screenPeers.contains(id),
                        compact: compact,
                        primary: primary,
                      ),
                    );
                  }

                  final isOneToOne = ids.length <= 2;
                  final compactHeight = box.maxWidth < 600 ? 94.0 : 118.0;
                  return Stack(
                    fit: StackFit.expand,
                    children: [
                      Positioned.fill(child: tile(chosen, primary: true)),
                      if (backend.lastError != null)
                        Positioned(
                          top: MediaQuery.paddingOf(context).top + 70,
                          left: 12,
                          right: 12,
                          child: Material(
                            color: const Color(0xD9A32929),
                            borderRadius: BorderRadius.circular(12),
                            child: Padding(
                              padding: const EdgeInsets.all(9),
                              child: Text(backend.lastError!,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 11)),
                            ),
                          ),
                        ),
                      if (!expandedVideo && others.isNotEmpty && isOneToOne)
                        Positioned(
                          right: 12,
                          bottom: 96,
                          child: SizedBox(
                            width: box.maxWidth < 600 ? 112 : 160,
                            height: box.maxWidth < 600 ? 145 : 190,
                            child: tile(others.first, compact: true),
                          ),
                        ),
                      if (!expandedVideo && others.isNotEmpty && !isOneToOne)
                        Positioned(
                          left: 8,
                          right: 8,
                          bottom: 94,
                          height: compactHeight,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            physics: const BouncingScrollPhysics(),
                            itemCount: others.length,
                            separatorBuilder: (_, __) => const SizedBox(width: 7),
                            itemBuilder: (_, i) => SizedBox(
                              width: compactHeight * .72,
                              child: tile(others[i], compact: true),
                            ),
                          ),
                        ),
                      if (pointerMode)
                        Positioned.fill(
                          child: GestureDetector(
                            behavior: HitTestBehavior.translucent,
                            onTapDown: (d) async {
                              final usableHeight =
                                  (box.maxHeight - 88).clamp(1.0, box.maxHeight);
                              final pos = Offset(
                                (d.localPosition.dx / box.maxWidth).clamp(0, 1),
                                (d.localPosition.dy / usableHeight).clamp(0, 1),
                              );
                              setState(() => pointer = pos);
                              await backend.sendData({
                                'type': 'pointer',
                                'target': pointerTarget,
                                'x': pos.dx,
                                'y': pos.dy,
                              });
                            },
                          ),
                        ),
                      if (pointer != null)
                        Positioned(
                          left: pointer!.dx * box.maxWidth,
                          top: pointer!.dy * (box.maxHeight - 88),
                          child: const IgnorePointer(
                            child: Icon(Icons.near_me,
                                color: Colors.amber, size: 34),
                          ),
                        ),
                      Positioned(top: 0, left: 0, right: 0, child: _topOverlay(count)),
                      Positioned(left: 0, right: 0, bottom: 0, child: _bottomControls()),
                    ],
                  );
                },
              ),
      ),
    );
  }

}
