import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../config/app_config.dart';
import '../../shared/widgets.dart';
import '../../shared/app_brand.dart';
import '../../theme/app_theme.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController(),
      password = TextEditingController(),
      name = TextEditingController();
  final form = GlobalKey<FormState>();
  bool signup = false, busy = false, hidePassword = true;
  String? authError;

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    name.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    if (busy) return;
    if (!form.currentState!.validate()) return;
    setState(() {
      busy = true;
      authError = null;
    });
    try {
      final auth = Supabase.instance.client.auth;
      if (signup) {
        await auth.signUp(
            email: email.text.trim(),
            password: password.text,
            data: {'full_name': name.text.trim()},
            emailRedirectTo: AppConfig.authRedirect);
        if (mounted) {
          notice(context,
              'Check your email to verify your account before signing in.');
        }
      } else {
        await auth.signInWithPassword(
            email: email.text.trim(), password: password.text);
      }
    } on AuthException catch (e) {
      final message = e.message.toLowerCase();
      if (mounted)
        setState(() => authError = message.contains('invalid login credentials')
            ? 'Email or password was not accepted. Use the same account as the website, or tap Forgot password to reset it. Passwords are case-sensitive.'
            : message.contains('email not confirmed')
                ? 'Verify your email first. Use Resend verification below.'
                : e.message);
    } catch (_) {
      if (mounted)
        setState(() => authError =
            'Could not connect. Check your internet and try again.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> recoverAccount() async {
    if (busy) return;
    final controller = TextEditingController(text: email.text.trim());
    final address = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Recover account'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
                'Enter the email used for this account. The secure recovery link lets you reset the password and confirm or change your User ID.'),
            const SizedBox(height: 14),
            TextField(
              controller: controller,
              autofocus: true,
              keyboardType: TextInputType.emailAddress,
              autofillHints: const [AutofillHints.email],
              decoration: const InputDecoration(
                  labelText: 'Account email',
                  prefixIcon: Icon(Icons.mail_outline_rounded)),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(
                  dialogContext, controller.text.trim().toLowerCase()),
              child: const Text('Send recovery email')),
        ],
      ),
    );
    controller.dispose();
    if (address == null || address.isEmpty) return;
    if (!address.contains('@')) {
      if (mounted) notice(context, 'Enter a valid account email.');
      return;
    }
    setState(() {
      busy = true;
      authError = null;
    });
    try {
      await Supabase.instance.client.auth.resetPasswordForEmail(address,
          redirectTo: AppConfig.authRedirect);
      if (mounted) {
        notice(context,
            'Recovery email sent. Open the secure link to reset your password and confirm or change your User ID, then sign in here with the new password.');
      }
    } on AuthException catch (e) {
      if (mounted) setState(() => authError = e.message);
    } catch (_) {
      if (mounted) {
        setState(() => authError =
            'Could not send the recovery email. Check your internet and try again.');
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Widget _benefit(IconData icon, String title, String text) => Padding(
        padding: EdgeInsets.only(bottom: 22),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.13),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(icon, color: Colors.white),
          ),
          SizedBox(width: 14),
          Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title,
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.surface,
                      fontWeight: FontWeight.w800)),
              SizedBox(height: 4),
              Text(text, style: TextStyle(color: Colors.white70, height: 1.4)),
            ]),
          )
        ]),
      );

  Widget _formCard(BuildContext context) => Card(
        child: Padding(
          padding: EdgeInsets.all(30),
          child: Form(
            key: form,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(child: AppBrand()),
                SizedBox(height: 28),
                Text(signup ? 'Create your account' : 'Welcome back',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineMedium),
                SizedBox(height: 8),
                Text(
                  signup
                      ? 'Join your classes, groups and live learning spaces.'
                      : 'Sign in to continue your learning journey.',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                SizedBox(height: 28),
                if (signup) ...[
                  TextFormField(
                    controller: name,
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                        labelText: 'Full name',
                        prefixIcon: Icon(Icons.person_outline_rounded)),
                    maxLength: 100,
                    validator: (v) =>
                        (v ?? '').trim().isEmpty ? 'Enter your name' : null,
                  ),
                  SizedBox(height: 14),
                ],
                TextFormField(
                  controller: email,
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  autofillHints: [AutofillHints.email],
                  decoration: InputDecoration(
                      labelText: 'Email address',
                      prefixIcon: Icon(Icons.mail_outline_rounded)),
                  validator: (v) => v != null && v.contains('@')
                      ? null
                      : 'Enter a valid email',
                ),
                SizedBox(height: 14),
                TextFormField(
                  controller: password,
                  obscureText: hidePassword,
                  autofillHints: signup
                      ? [AutofillHints.newPassword]
                      : [AutofillHints.password],
                  decoration: InputDecoration(
                    labelText: 'Password',
                    prefixIcon: Icon(Icons.lock_outline_rounded),
                    suffixIcon: IconButton(
                      tooltip: hidePassword ? 'Show password' : 'Hide password',
                      onPressed: () =>
                          setState(() => hidePassword = !hidePassword),
                      icon: Icon(hidePassword
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined),
                    ),
                  ),
                  validator: (v) {
                    if ((v ?? '').isEmpty) return 'Enter your password';
                    if (signup && v!.length < 12)
                      return 'Use at least 12 characters';
                    return null;
                  },
                  onFieldSubmitted: (_) {
                    if (!busy) submit();
                  },
                ),
                SizedBox(height: 22),
                if (authError != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Text(authError!,
                        style: TextStyle(
                            color: Theme.of(context).colorScheme.error)),
                  ),
                FilledButton.icon(
                  onPressed: busy ? null : submit,
                  icon: busy
                      ? SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                      : Icon(signup
                          ? Icons.person_add_alt_1_rounded
                          : Icons.login_rounded),
                  label: Text(busy
                      ? 'Please wait…'
                      : signup
                          ? 'Create account'
                          : 'Sign in'),
                ),
                SizedBox(height: 8),
                TextButton(
                  onPressed:
                      busy ? null : () => setState(() => signup = !signup),
                  child: Text(signup
                      ? 'Already have an account? Sign in'
                      : 'New to Edu Chat Pro? Create an account'),
                ),
                Divider(height: 28),
                Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 4,
                  children: [
                    TextButton(
                      onPressed: busy ? null : recoverAccount,
                      child: const Text('Forgot password / User ID?'),
                    ),
                    TextButton(
                      onPressed: busy
                          ? null
                          : () => perform(context, () async {
                                if (!email.text.contains('@')) {
                                  throw FormatException(
                                      'Enter your email first.');
                                }
                                await Supabase.instance.client.auth.resend(
                                    type: OtpType.signup,
                                    email: email.text.trim(),
                                    emailRedirectTo: AppConfig.authRedirect);
                              }, success: 'Verification email requested.'),
                      child: Text('Resend verification'),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: LayoutBuilder(builder: (context, constraints) {
            final desktop = constraints.maxWidth >= 900;
            if (!desktop) {
              return Center(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(20),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: 480),
                    child: _formCard(context),
                  ),
                ),
              );
            }
            return Row(children: [
              Expanded(
                child: Container(
                  margin: EdgeInsets.all(22),
                  padding: EdgeInsets.all(48),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Theme.of(context).colorScheme.primary,
                        Theme.of(context).colorScheme.primary
                      ],
                    ),
                    borderRadius: BorderRadius.circular(28),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AppBrand(light: true),
                      SizedBox(height: 42),
                      Text('One place for your\nlearning community.',
                          style: TextStyle(
                              color: Theme.of(context).colorScheme.surface,
                              fontSize: 42,
                              height: 1.12,
                              fontWeight: FontWeight.w900)),
                      SizedBox(height: 18),
                      Text(
                        'Stay connected with classmates, discussions, files and live meetings — without losing focus.',
                        style: TextStyle(
                            color: Colors.white70, fontSize: 16, height: 1.55),
                      ),
                      SizedBox(height: 38),
                      _benefit(Icons.groups_2_outlined, 'Learning groups',
                          'Keep class conversations and resources organized.'),
                      _benefit(Icons.forum_outlined, 'Community forum',
                          'Ask questions and continue discussions beyond class.'),
                      _benefit(
                          Icons.video_camera_front_outlined,
                          'Live meetings',
                          'Join online learning sessions from the same workspace.'),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: Center(
                  child: SingleChildScrollView(
                    padding: EdgeInsets.all(42),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(maxWidth: 480),
                      child: _formCard(context),
                    ),
                  ),
                ),
              )
            ]);
          }),
        ),
      );
}

class PasswordPage extends StatefulWidget {
  const PasswordPage({super.key, this.onSaved});
  final VoidCallback? onSaved;
  @override
  State<PasswordPage> createState() => _PasswordPageState();
}

class _PasswordPageState extends State<PasswordPage> {
  final password = TextEditingController(),
      repeat = TextEditingController(),
      publicId = TextEditingController();
  bool busy = false, hide = true, loadingProfile = true;
  String currentId = '';

  @override
  void initState() {
    super.initState();
    _loadAccount();
  }

  Future<void> _loadAccount() async {
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user != null) {
        final row = await Supabase.instance.client
            .from('profiles')
            .select('public_id')
            .eq('id', user.id)
            .maybeSingle();
        currentId = (row?['public_id']?.toString() ?? '').toLowerCase();
        publicId.text = currentId;
      }
    } catch (_) {
      // Password recovery still works if the optional public ID lookup is slow.
    } finally {
      if (mounted) setState(() => loadingProfile = false);
    }
  }

  String normalizeId(String value) {
    var result = value.trim().toLowerCase().replaceFirst(RegExp(r'^@+'), '');
    result = result.replaceAll(RegExp(r'[^a-z0-9_]'), '');
    return result.length > 24 ? result.substring(0, 24) : result;
  }

  Future<void> saveRecovery() async {
    if (busy) return;
    final id = normalizeId(publicId.text);
    if (!RegExp(r'^[a-z][a-z0-9_]{3,23}$').hasMatch(id)) {
      notice(context,
          'User ID must be 4–24 characters, start with a letter, and use only letters, numbers or _.');
      return;
    }
    if (password.text.length < 8 || password.text != repeat.text) {
      notice(context,
          'Passwords must match and contain at least 8 characters.');
      return;
    }
    setState(() => busy = true);
    try {
      if (id != currentId) {
        final available = await Supabase.instance.client
            .rpc('public_id_available', params: {'candidate': id});
        if (available != true) {
          throw const FormatException(
              'That User ID is already taken or unavailable. Choose another one.');
        }
      }
      await Supabase.instance.client.auth
          .updateUser(UserAttributes(password: password.text));
      if (id != currentId) {
        await Supabase.instance.client
            .rpc('set_my_public_id', params: {'new_id': id});
        currentId = id;
      }
      if (!mounted) return;
      notice(context, 'Account recovered. Password and User ID are ready.');
      if (widget.onSaved != null) {
        widget.onSaved!();
      } else {
        Navigator.pop(context);
      }
    } on AuthException catch (e) {
      if (mounted) notice(context, e.message);
    } catch (e) {
      if (mounted) notice(context, e);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    password.dispose();
    repeat.dispose();
    publicId.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final email = Supabase.instance.client.auth.currentUser?.email ?? '';
    return Scaffold(
      appBar: AppBar(title: const Text('Recover account')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const AppLogo(size: 58),
                  const SizedBox(height: 20),
                  Text('Secure your account',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 8),
                  const Text(
                    'Set a new password and confirm or change your unique User ID.',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  InputDecorator(
                    decoration: const InputDecoration(
                        labelText: 'Account email',
                        prefixIcon: Icon(Icons.mail_outline_rounded)),
                    child: SelectableText(email),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: publicId,
                    enabled: !loadingProfile,
                    autocorrect: false,
                    enableSuggestions: false,
                    maxLength: 24,
                    decoration: InputDecoration(
                      labelText: 'User ID',
                      prefixText: '@',
                      prefixIcon: const Icon(Icons.alternate_email_rounded),
                      helperText: loadingProfile
                          ? 'Loading current User ID…'
                          : '4–24 characters · starts with a letter · letters, numbers and _ only',
                    ),
                  ),
                  const SizedBox(height: 4),
                  TextField(
                    controller: password,
                    obscureText: hide,
                    decoration: InputDecoration(
                      labelText: 'New password',
                      prefixIcon: const Icon(Icons.lock_outline_rounded),
                      suffixIcon: IconButton(
                        onPressed: () => setState(() => hide = !hide),
                        icon: Icon(hide
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: repeat,
                    obscureText: hide,
                    decoration: const InputDecoration(
                        labelText: 'Confirm new password',
                        prefixIcon: Icon(Icons.lock_reset_rounded)),
                  ),
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: busy || loadingProfile ? null : saveRecovery,
                      child: Text(busy ? 'Updating…' : 'Update User ID & password'),
                    ),
                  )
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

