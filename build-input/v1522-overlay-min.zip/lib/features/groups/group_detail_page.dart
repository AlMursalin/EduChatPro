import '../../shared/stored_image.dart';
import '../../shared/group_invite_action.dart';
import '../../shared/media_attachment.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter/services.dart';
import '../../config/app_config.dart';
import '../../shared/voice_widgets.dart';
import '../../services/live_refresh.dart';
import 'package:intl/intl.dart' hide TextDirection;
import '../../shared/social_widgets.dart';
import 'dart:async';
import 'dart:typed_data';
import '../profile/avatar_crop_page.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/validation.dart';
import '../../services/edu_repository.dart';
import '../../shared/widgets.dart';
import '../../services/image_utils.dart';
import '../../shared/group_avatar.dart';
import '../../shared/user_avatar.dart';
import '../meetings/meetings_page.dart';
import '../meetings/meeting_room_page.dart';
import '../direct_chat/direct_chat_page.dart';

class GroupDetailPage extends StatefulWidget {
  const GroupDetailPage({super.key, required this.repo, required this.group});
  final EduRepository repo;
  final JsonRow group;
  @override
  State<GroupDetailPage> createState() => _GroupDetailPageState();
}

class _GroupDetailPageState extends State<GroupDetailPage> {
  final message = TextEditingController();
  final chat = GlobalKey<PagedListState>(),
      files = GlobalKey<PagedListState>(),
      members = GlobalKey<PagedListState>();
  final selected = <String, JsonRow>{};
  final permissions = <String, bool>{};
  late JsonRow group;
  String? drive;
  LiveRefresh? live;
  bool sending = false, announcement = false;
  bool changingImage = false;
  String accountRole = 'student';
  String? replyQuote;
  RealtimeChannel? channel;
  Timer? debounce;
  String get id => group['id'] as String;
  bool can(String p) => permissions[p] ?? false;
  bool get isOwner => group['created_by'] == widget.repo.userId;
  bool get canManageGroup => can('groups.manage') || isOwner;
  bool get canManageMembers => can('members.manage') || isOwner;
  bool get canManageFiles => can('files.manage') || isOwner;
  bool get canAnnounce => can('announcements.create') || isOwner;
  bool get canSetMemberMessaging =>
      const {'super_admin', 'assistant_admin', 'admin'}.contains(accountRole);
  @override
  void initState() {
    super.initState();
    group = Map.of(widget.group);
    load();
    live = LiveRefresh(widget.repo.client, load,
        tables: ['groups'], filterColumn: 'id', filterValue: id);
    channel = widget.repo.client
        .channel('group-$id')
        .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'group_messages',
            filter: PostgresChangeFilter(
                type: PostgresChangeFilterType.eq,
                column: 'group_id',
                value: id),
            callback: (_) {
              debounce?.cancel();
              debounce = Timer(const Duration(milliseconds: 400),
                  () => chat.currentState?.refresh());
            })
        .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'group_files',
            filter: PostgresChangeFilter(
                type: PostgresChangeFilterType.eq,
                column: 'group_id',
                value: id),
            callback: (_) {
              files.currentState?.refresh();
              chat.currentState?.refresh();
            })
        .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'group_members',
            filter: PostgresChangeFilter(
                type: PostgresChangeFilterType.eq,
                column: 'group_id',
                value: id),
            callback: (_) => members.currentState?.refresh())
        .subscribe((status, error) {
      if (status == RealtimeSubscribeStatus.subscribed) {
        chat.currentState?.refresh();
        files.currentState?.refresh();
        members.currentState?.refresh();
      }
    });
  }

  Future<void> load() async {
    await perform(context, () async {
      for (final p in [
        'groups.manage',
        'members.manage',
        'files.manage',
        'announcements.create'
      ]) {
        permissions[p] = await widget.repo.allowed(p);
      }
      accountRole = await widget.repo.role();
      final d = await widget.repo.client
          .from('group_drive_links')
          .select()
          .eq('group_id', id)
          .maybeSingle();
      final g = await widget.repo.client
          .from('groups')
          .select()
          .eq('id', id)
          .single();
      if (mounted) {
        setState(() {
          drive = d?['url'];
          group = g;
        });
      }
    });
  }

  @override
  void dispose() {
    live?.dispose();
    message.dispose();
    debounce?.cancel();
    if (channel != null) widget.repo.client.removeChannel(channel!);
    super.dispose();
  }

  Future<void> inviteGroup({bool rotate = false}) async {
    await perform(context, () async {
      final code = await widget.repo.client.rpc('get_group_invite',
          params: {'group_input': id, 'rotate_input': rotate});
      final link = '${AppConfig.appUrl}/group.html?group_invite=$code';
      if (!mounted) return;
      await showDialog(
          context: context,
          builder: (c) => AlertDialog(
                  title: const Text('Group invitation link'),
                  content: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Text(
                        'Share this link in WhatsApp, Messenger or any chat. Valid for 7 days. Recipients sign in to join.'),
                    const SizedBox(height: 12),
                    SelectableText(link)
                  ]),
                  actions: [
                    TextButton(
                        onPressed: () {
                          Navigator.pop(c);
                          inviteGroup(rotate: true);
                        },
                        child: const Text('Replace link')),
                    TextButton(
                        onPressed: () =>
                            Clipboard.setData(ClipboardData(text: link))
                                .then((_) {
                              if (mounted) notice(context, 'Link copied');
                            }),
                        child: const Text('Copy')),
                    FilledButton(
                        onPressed: () => Share.share(
                            'Join ${group['name']} on Edu Chat Pro: $link'),
                        child: const Text('Share'))
                  ]));
    });
  }

  Future<void> send() async {
    if (message.text.trim().isEmpty || sending) return;
    final typed = message.text.trim();
    final body =
        replyQuote == null ? typed : replyMessage('Reply', replyQuote!, typed);
    setState(() => sending = true);
    await perform(context, () async {
      await widget.repo.add('group_messages',
          {'group_id': id, 'body': body, 'is_announcement': announcement});
      message.clear();
      if (mounted) setState(() => replyQuote = null);
      await chat.currentState?.refresh();
    });
    if (mounted) setState(() => sending = false);
  }

  Future<void> startDirectCall(JsonRow member, {required bool video}) async {
    final otherId = member['user_id']?.toString();
    final profile = member['profiles'] as Map<String, dynamic>?;
    final otherName = profile?['full_name']?.toString() ?? 'Member';
    if (otherId == null || otherId == widget.repo.userId) return;
    await perform(context, () async {
      final meeting =
          await widget.repo.client.rpc('start_direct_call', params: {
        'target': otherId,
        'video': video,
      });
      if (!mounted) return;
      await Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => MeetingRoomPage(
                    repo: widget.repo,
                    meetingId: meeting.toString(),
                    autoJoin: true,
                    startWithMic: true,
                    callTitle: video
                        ? 'Video call · $otherName'
                        : 'Audio call · $otherName',
                  )));
    });
  }

  Future<void> changeImage() async {
    if (changingImage || !canManageGroup) return;
    setState(() => changingImage = true);
    try {
      await perform(context, () async {
        final selected = await FilePicker.platform
            .pickFiles(type: FileType.image, withData: true);
        if (selected == null) return;
        final file = selected.files.single;
        if (file.bytes == null || file.size > 10 * 1024 * 1024) {
          throw const FormatException('Select an image under 10 MB.');
        }
        final preview = await compute(cropPreview, file.bytes!);
        if (!mounted) return;
        final cropped = await Navigator.push<Uint8List>(
            context,
            MaterialPageRoute(
                fullscreenDialog: true,
                builder: (_) => AvatarCropPage(
                    bytes: preview, title: 'Adjust group photo')));
        if (cropped == null) return;
        final bytes = await compute(thumbnail, cropped);
        final path = '$id/${const Uuid().v4()}.jpg';
        try {
          await widget.repo.client.storage.from('group-images').uploadBinary(
              path, bytes,
              fileOptions: const FileOptions(contentType: 'image/jpeg'));
        } on StorageException catch (e) {
          final denied = e.message.toLowerCase().contains('row-level security');
          throw StateError(denied
              ? 'Group photo permission needs the server fix. Run EduChatPro_v1.1.7_Group_Photo_RLS_Fix.sql in Supabase SQL Editor, then tap Add / crop group photo again. Your selected photo was not saved.'
              : 'Could not upload the group photo: ${e.message}');
        }
        try {
          final saved = await widget.repo.client
              .from('groups')
              .update({'image_path': path})
              .eq('id', id)
              .select('id,image_path')
              .single();
          if (saved['image_path'] != path)
            throw StateError('The group photo could not be saved.');
        } catch (_) {
          try {
            await widget.repo.client.storage
                .from('group-images')
                .remove([path]);
          } catch (_) {}
          rethrow;
        }
        await MediaCache.store(widget.repo, 'group-images', path, bytes);
        final old = group['image_path'];
        if (mounted) setState(() => group['image_path'] = path);
        if (old != null && old != path) {
          try {
            await widget.repo.client.storage.from('group-images').remove([old]);
          } catch (_) {}
        }
        PagedListState.snapshots.remove('${widget.repo.userId}/threads');
        if (mounted) notice(context, 'Group photo saved.');
        await load();
      });
    } finally {
      if (mounted) setState(() => changingImage = false);
    }
  }

  Future<void> upload({bool toChat = false}) async {
    await perform(context, () async {
      final picked = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: Validation.mimeTypes.keys.toList(),
          withData: true);
      if (picked == null) return;
      final f = picked.files.single;
      if (f.bytes == null) throw StateError('Could not read file');
      final file = await widget.repo.uploadFile(id, f.name, f.bytes!);
      if (toChat) {
        try {
          await widget.repo.add('group_messages',
              {'group_id': id, 'body': 'Shared a file', 'file_id': file['id']});
        } catch (_) {
          await widget.repo.deleteFiles([file]);
          rethrow;
        }
        await chat.currentState?.refresh();
      }
      await files.currentState?.refresh();
    }, success: 'File upload finished.');
  }

  Future<void> deleteSelected({bool all = false}) async {
    if (!await confirm(
        context,
        all ? 'Delete all group files?' : 'Delete selected files?',
        all
            ? 'All stored files in this group will be permanently deleted.'
            : 'Delete ${selected.length} selected files permanently?')) return;
    if (!mounted) return;
    await perform(context, () async {
      if (all) {
        await widget.repo.deleteAllFiles(id);
      } else {
        await widget.repo.deleteFiles(selected.values.toList());
      }
      selected.clear();
      await files.currentState?.refresh();
      if (mounted) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
      length: 6,
      child: Scaffold(
          appBar: AppBar(
              title: Row(children: [
                Semantics(
                    label:
                        canManageGroup ? 'Change group photo' : 'Group photo',
                    button: canManageGroup,
                    child: InkWell(
                        onTap: canManageGroup && !changingImage
                            ? changeImage
                            : null,
                        borderRadius: BorderRadius.circular(24),
                        child: GroupAvatar(
                            repo: widget.repo, path: group['image_path']))),
                const SizedBox(width: 10),
                Expanded(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      Text(group['name'],
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      Text(group['description'] ?? '',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodySmall)
                    ]))
              ]),
              bottom: const TabBar(isScrollable: true, tabs: [
                Tab(
                    icon: Icon(Icons.chat_bubble_outline, size: 18),
                    text: 'Chat'),
                Tab(
                    icon: Icon(Icons.description_outlined, size: 18),
                    text: 'Files'),
                Tab(
                    icon: Icon(Icons.people_outline, size: 18),
                    text: 'Members'),
                Tab(
                    icon: Icon(Icons.videocam_outlined, size: 18),
                    text: 'Meetings'),
                Tab(
                    icon: Icon(Icons.cloud_outlined, size: 18),
                    text: 'Google Drive'),
                Tab(
                    icon: Icon(Icons.settings_outlined, size: 18),
                    text: 'Settings')
              ])),
          body: TabBarView(children: [
            Column(children: [
              Expanded(
                  child: PagedList(
                      key: chat,
                      cacheKey: '${widget.repo.userId}/group/$id',
                      reverse: true,
                      load: (o) => widget.repo.page('group_messages',
                          filter: 'group_id',
                          value: id,
                          offset: o,
                          select:
                              '*,profiles(full_name,avatar_path),group_files(*)'),
                      empty: 'No messages yet',
                      builder: messageTile)),
              Padding(
                  padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
                  child: Column(children: [
                    Card(
                        color: Theme.of(context)
                            .colorScheme
                            .primaryContainer
                            .withOpacity(.4),
                        child: ListTile(
                          leading: Icon(Icons.campaign_outlined,
                              color: Theme.of(context).colorScheme.primary),
                          title: const Text('Announcement',
                              style: TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.w700)),
                          subtitle: Text(
                              announcement
                                  ? 'Sending an announcement'
                                  : 'Send important updates to the group',
                              style: const TextStyle(fontSize: 10)),
                          onTap: () => showModalBottomSheet<void>(
                              context: context,
                              isScrollControlled: true,
                              builder: (_) => SizedBox(
                                  height:
                                      MediaQuery.sizeOf(context).height * .7,
                                  child: Column(children: [
                                    const ListTile(
                                        title: Text('Announcements')),
                                    Expanded(
                                        child: PagedList(
                                            load: (o) async =>
                                                List<JsonRow>.from(await widget
                                                    .repo.client
                                                    .from('group_messages')
                                                    .select(
                                                        '*,profiles(full_name,avatar_path),group_files(*)')
                                                    .eq('group_id', id)
                                                    .eq('is_announcement', true)
                                                    .order('created_at',
                                                        ascending: false)
                                                    .range(o, o + 29)),
                                            builder: messageTile,
                                            empty: 'No announcements yet.'))
                                  ]))),
                          trailing: canAnnounce
                              ? Switch(
                                  value: announcement,
                                  onChanged: (v) =>
                                      setState(() => announcement = v))
                              : const Icon(Icons.chevron_right),
                        )),
                    const SizedBox(height: 8),
                    if (group['allow_member_messaging'] == true ||
                        canManageGroup)
                      Column(mainAxisSize: MainAxisSize.min, children: [
                        if (replyQuote != null)
                          Container(
                              width: double.infinity,
                              margin: const EdgeInsets.only(bottom: 6),
                              padding: const EdgeInsets.fromLTRB(12, 7, 5, 7),
                              decoration: BoxDecoration(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .surfaceContainerHighest,
                                  borderRadius: BorderRadius.circular(12)),
                              child: Row(children: [
                                const Icon(Icons.reply, size: 16),
                                const SizedBox(width: 7),
                                Expanded(
                                    child: Text(replyQuote!,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis)),
                                IconButton(
                                    icon: const Icon(Icons.close, size: 18),
                                    onPressed: () =>
                                        setState(() => replyQuote = null))
                              ])),
                        Row(children: [
                          IconButton(
                              tooltip: 'Attach file',
                              onPressed: () => upload(toChat: true),
                              icon: const Icon(Icons.add_circle_outline)),
                          Expanded(
                              child: TextField(
                                  controller: message,
                                  minLines: 1,
                                  maxLines: 4,
                                  maxLength: 4000,
                                  decoration: InputDecoration(
                                      suffixIcon: IconButton(
                                          tooltip: 'Emoji',
                                          icon: const Icon(
                                              Icons.sentiment_satisfied_alt),
                                          onPressed: () =>
                                              pickChatEmoji(context, message)),
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(28)),
                                      counterText: '',
                                      hintText: 'Write to this group…'),
                                  onSubmitted: (_) => send())),
                          IconButton(
                              tooltip: 'Voice message',
                              onPressed: sending
                                  ? null
                                  : () => perform(context, () async {
                                        final note = await recordVoice(context);
                                        if (note == null) return;
                                        await widget.repo.sendMedia(
                                            group: id,
                                            bytes: note.bytes,
                                            name: 'voice.m4a',
                                            mime: 'audio/mp4',
                                            durationMs: note.durationMs);
                                        await chat.currentState?.refresh();
                                      }),
                              icon: const Icon(Icons.mic_none_rounded)),
                          const SizedBox(width: 4),
                          IconButton.filled(
                              onPressed: sending ? null : send,
                              icon: const Icon(Icons.send))
                        ])
                      ])
                    else
                      const Text(
                          'Member messaging is paused by an administrator.')
                  ]))
            ]),
            Column(children: [
              PageHeader('Class files', 'Private files · up to 10 MB each',
                  actions: [
                    if (group['allow_member_messaging'] == true ||
                        canManageFiles)
                      FilledButton.icon(
                          onPressed: upload,
                          icon: const Icon(Icons.upload_file),
                          label: const Text('Upload')),
                    if (canManageFiles) ...[
                      TextButton(
                          onPressed:
                              selected.isEmpty ? null : () => deleteSelected(),
                          child: Text('Delete selected (${selected.length})')),
                      TextButton(
                          onPressed: () => deleteSelected(all: true),
                          child: const Text('Delete all'))
                    ]
                  ]),
              Expanded(
                  child: PagedList(
                      key: files,
                      load: (o) => widget.repo.page('group_files',
                          filter: 'group_id', value: id, offset: o),
                      builder: (f) => Card(
                          child: ListTile(
                              leading: canManageFiles
                                  ? Checkbox(
                                      value: selected.containsKey(f['id']),
                                      onChanged: (v) => setState(() {
                                            if (v!) {
                                              selected[f['id']] = f;
                                            } else {
                                              selected.remove(f['id']);
                                            }
                                          }))
                                  : const Icon(Icons.description_outlined),
                              title: Text(f['name']),
                              subtitle:
                                  Text('${(f['size_bytes'] / 1024).ceil()} KB'),
                              onTap: () => perform(context, () async {
                                    await MediaAttachment(
                                            repo: widget.repo,
                                            bucket: 'group-files',
                                            path: f['object_path'],
                                            name: f['name'],
                                            mime: f['mime_type'] ?? '')
                                        .open(context);
                                  }),
                              trailing: (canManageFiles ||
                                      f['uploaded_by'] == widget.repo.userId)
                                  ? IconButton(
                                      icon: const Icon(Icons.delete_outline),
                                      onPressed: () async {
                                        if (await confirm(context,
                                                'Delete file?', f['name']) &&
                                            context.mounted) {
                                          await perform(context, () async {
                                            await widget.repo.deleteFiles([f]);
                                            await files.currentState?.refresh();
                                          });
                                        }
                                      })
                                  : null))))
            ]),
            Column(children: [
              PageHeader('Members', 'People in this learning space', actions: [
                if (canManageMembers)
                  OutlinedButton.icon(
                      onPressed: () => inviteGroup(),
                      icon: const Icon(Icons.link),
                      label: const Text('Invite link')),
                if (canManageMembers)
                  FilledButton(
                      onPressed: () async {
                        final added = await showDialog<bool>(
                            context: context,
                            builder: (_) =>
                                MemberPicker(repo: widget.repo, group: id));
                        if (added == true)
                          await members.currentState?.refresh();
                      },
                      child: const Text('Add member'))
              ]),
              Expanded(
                  child: PagedList(
                      key: members,
                      load: (o) => widget.repo.page('group_members',
                          filter: 'group_id',
                          value: id,
                          offset: o,
                          select: '*,profiles(full_name,avatar_path)'),
                      builder: (m) {
                        final otherId = m['user_id']?.toString() ?? '';
                        final profile = m['profiles'] as Map<String, dynamic>?;
                        final otherName =
                            profile?['full_name']?.toString() ?? 'Member';
                        final mine = otherId == widget.repo.userId;
                        return ListTile(
                          leading: UserAvatar(
                            repo: widget.repo,
                            userId: otherId,
                            path: profile?['avatar_path'],
                            name: otherName,
                          ),
                          title: Text(mine ? '$otherName (You)' : otherName),
                          subtitle: SelectableText(otherId),
                          trailing: mine
                              ? const Icon(Icons.person_outline_rounded)
                              : PopupMenuButton<String>(
                                  tooltip: 'Member actions',
                                  onSelected: (action) async {
                                    if (action == 'chat') {
                                      await Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (_) => DirectChatPage(
                                                    repo: widget.repo,
                                                    otherUserId: otherId,
                                                    otherName: otherName,
                                                    otherAvatarPath:
                                                        profile?['avatar_path']
                                                            ?.toString(),
                                                  )));
                                    } else if (action == 'audio') {
                                      await startDirectCall(m, video: false);
                                    } else if (action == 'video') {
                                      await startDirectCall(m, video: true);
                                    } else if (action == 'remove' &&
                                        canManageMembers) {
                                      if (await confirm(
                                              context,
                                              'Remove member?',
                                              'They will lose access to this group.') &&
                                          context.mounted) {
                                        await perform(context, () async {
                                          await widget.repo.client
                                              .from('group_members')
                                              .delete()
                                              .eq('group_id', id)
                                              .eq('user_id', otherId);
                                          await members.currentState?.refresh();
                                        });
                                      }
                                    }
                                  },
                                  itemBuilder: (_) => [
                                    const PopupMenuItem(
                                        value: 'chat',
                                        child: ListTile(
                                            leading:
                                                Icon(Icons.chat_bubble_outline),
                                            title: Text('Private message'))),
                                    const PopupMenuItem(
                                        value: 'audio',
                                        child: ListTile(
                                            leading: Icon(Icons.call_outlined),
                                            title: Text('Audio call'))),
                                    const PopupMenuItem(
                                        value: 'video',
                                        child: ListTile(
                                            leading:
                                                Icon(Icons.videocam_outlined),
                                            title: Text('Video call'))),
                                    if (canManageMembers)
                                      const PopupMenuItem(
                                          value: 'remove',
                                          child: ListTile(
                                              leading: Icon(
                                                  Icons.person_remove_outlined),
                                              title:
                                                  Text('Remove from group'))),
                                  ],
                                ),
                        );
                      }))
            ]),
            MeetingsPage(repo: widget.repo, group: id),
            ListView(padding: const EdgeInsets.all(24), children: [
              const Icon(Icons.folder_open_outlined, size: 72),
              const SizedBox(height: 20),
              Text('Google Drive',
                  style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 12),
              const Text(
                  'Your administrator can connect a shared learning folder here.'),
              const SizedBox(height: 20),
              if (drive != null) ...[
                SelectableText(drive!),
                const SizedBox(height: 16),
                FilledButton.icon(
                    onPressed: () => perform(context, () async {
                          await launchUrl(Uri.parse(drive!),
                              mode: LaunchMode.externalApplication);
                        }),
                    icon: const Icon(Icons.open_in_new),
                    label: const Text('Open group folder'))
              ] else
                const Text('No folder has been connected.'),
              if (canManageGroup) ...[
                const SizedBox(height: 24),
                OutlinedButton(
                    onPressed: () async {
                      final v = await formDialog(
                          context, 'Connect Google Drive', ['Folder URL'],
                          initial: [drive ?? '']);
                      if (v != null && context.mounted) {
                        await perform(context, () async {
                          if (!Validation.driveUrl(v[0])) {
                            throw const FormatException(
                                'Use an https://drive.google.com/drive/folders/... URL.');
                          }
                          await widget.repo.update(
                              'group_drive_links', id, {'url': v[0]},
                              key: 'group_id');
                          await load();
                        });
                      }
                    },
                    child: const Text('Add or replace folder URL')),
                if (drive != null)
                  TextButton(
                      onPressed: () async {
                        if (await confirm(context, 'Remove link?',
                                'The actual Google Drive folder is not deleted.') &&
                            context.mounted) {
                          await perform(context, () async {
                            await widget.repo.update(
                                'group_drive_links', id, {'url': null},
                                key: 'group_id');
                            await load();
                          });
                        }
                      },
                      child: const Text('Remove folder URL'))
              ]
            ]),
            ListView(padding: const EdgeInsets.all(24), children: [
              Center(
                  child: GroupAvatar(
                      repo: widget.repo,
                      path: group['image_path'],
                      radius: 44)),
              if (canManageGroup)
                TextButton(
                    onPressed: changingImage ? null : changeImage,
                    child: Text(changingImage
                        ? 'Saving photo…'
                        : 'Add / crop group photo')),
              Text(group['description']),
              const SizedBox(height: 20),
              SwitchListTile(
                  title: const Text('Allow Member Messaging'),
                  subtitle: const Text(
                      'Controls member messages and file uploads. Poll voting stays available.'),
                  value: group['allow_member_messaging'],
                  onChanged: canSetMemberMessaging
                      ? (v) => perform(context, () async {
                            await widget.repo.client
                                .rpc('set_group_member_permissions', params: {
                              'group_input': id,
                              'messaging_enabled': v,
                              'calls_enabled':
                                  group['allow_member_calls'] != false,
                            });
                            await load();
                          })
                      : null),
              if (canManageGroup)
                OutlinedButton(
                    onPressed: () async {
                      final v = await formDialog(
                          context, 'Edit group', ['Name', 'Description'],
                          initial: [group['name'], group['description']]);
                      if (v != null && context.mounted) {
                        await perform(context, () async {
                          await widget.repo.update('groups', id,
                              {'name': v[0], 'description': v[1]});
                          await load();
                        });
                      }
                    },
                    child: const Text('Edit group')),
              const SizedBox(height: 12),
              if (!isOwner)
                OutlinedButton.icon(
                    onPressed: () async {
                      if (await confirm(context, 'Leave group?',
                              'You will lose access until someone adds you again.') &&
                          context.mounted) {
                        await perform(context, () async {
                          await widget.repo.client
                              .from('group_members')
                              .delete()
                              .eq('group_id', id)
                              .eq('user_id', widget.repo.userId);
                          if (context.mounted) Navigator.pop(context);
                        });
                      }
                    },
                    icon: const Icon(Icons.logout_rounded),
                    label: const Text('Leave group'))
              else
                OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.red.shade700),
                    onPressed: () async {
                      if (await confirm(context, 'Delete this group?',
                              'Messages, files and group meetings will be removed. This cannot be undone.') &&
                          context.mounted) {
                        await perform(context, () async {
                          await widget.repo.deleteAllFiles(id);
                          final imagePath = group['image_path']?.toString();
                          if (imagePath != null && imagePath.isNotEmpty) {
                            await widget.repo.client.storage
                                .from('group-images')
                                .remove([imagePath]);
                          }
                          await widget.repo.remove('groups', id);
                          if (context.mounted) Navigator.pop(context);
                        });
                      }
                    },
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('Delete group'))
            ]),
          ])));
  Widget messageTile(JsonRow m) {
    final mine = m['sender_id'] == widget.repo.userId;
    final parts = splitReplyMessage(m['body']?.toString() ?? '');
    final profile = m['profiles'] as Map<String, dynamic>?;
    final name = profile?['full_name']?.toString() ?? 'Member';
    final avatarPath = profile?['avatar_path']?.toString();
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints:
            BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width * 0.86),
        child: GestureDetector(
          onLongPress: () => setState(
              () => replyQuote = parts.body.isEmpty ? parts.quote : parts.body),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              textDirection: mine ? TextDirection.rtl : TextDirection.ltr,
              children: [
                UserAvatar(
                  repo: widget.repo,
                  userId: m['sender_id'],
                  path: avatarPath,
                  name: name,
                  radius: 16,
                ),
                const SizedBox(width: 7),
                Flexible(
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(12, 9, 12, 7),
                    decoration: BoxDecoration(
                      color: mine
                          ? Theme.of(context).colorScheme.primaryContainer
                          : Theme.of(context).colorScheme.surface,
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(12),
                        topRight: const Radius.circular(12),
                        bottomLeft: Radius.circular(mine ? 12 : 3),
                        bottomRight: Radius.circular(mine ? 3 : 12),
                      ),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x18000000),
                          blurRadius: 2,
                          offset: Offset(0, 1),
                        )
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          if (m['is_announcement'] == true) ...[
                            Icon(Icons.campaign_rounded,
                                size: 16, color: Color(0xFF087FCC)),
                            const SizedBox(width: 5),
                          ],
                          Flexible(
                            child: Text(
                              mine ? 'You' : name,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                            ),
                          ),
                        ]),
                        const SizedBox(height: 4),
                        if (m['meeting_id'] != null)
                          const Icon(Icons.call_outlined, size: 18),
                        if (parts.quote != null)
                          Container(
                              width: double.infinity,
                              margin: const EdgeInsets.only(bottom: 7),
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(.07),
                                  borderRadius: BorderRadius.circular(10)),
                              child: Text(parts.quote!,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 12))),
                        SelectableText(parts.body),
                        GroupInviteAction(text: parts.body),
                        if (m['group_files']?['mime_type']
                                ?.toString()
                                .startsWith('audio/') ==
                            true)
                          VoicePlayer(
                              repo: widget.repo,
                              bucket: 'group-files',
                              path: m['group_files']['object_path'],
                              durationMs: m['duration_ms'] ?? 0)
                        else if (m['group_files'] != null)
                          GroupAttachment(
                              repo: widget.repo,
                              file: JsonRow.from(m['group_files']),
                              canDelete: mine || canManageFiles,
                              onDeleted: () {
                                chat.currentState?.refresh();
                                files.currentState?.refresh();
                              }),
                        const SizedBox(height: 5),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Text(
                            DateFormat('h:mm a').format(
                                DateTime.parse(m['created_at']).toLocal()),
                            style:
                                Theme.of(context).textTheme.bodySmall?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceVariant,
                                      fontSize: 10,
                                    ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
