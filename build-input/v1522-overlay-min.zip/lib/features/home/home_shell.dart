import 'mobile_web_workspace.dart';
import 'package:flutter/foundation.dart';
import '../../services/group_links.dart';
import '../groups/group_detail_page.dart';
import '../../services/notification_router.dart';
import '../../services/live_refresh.dart';
import '../../shared/stored_image.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import '../../theme/theme_controller.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/edu_repository.dart';
import '../../services/notification_service.dart';
import '../../shared/widgets.dart';
import '../../shared/app_brand.dart';
import '../../shared/user_avatar.dart';
import '../../theme/app_theme.dart';
import '../groups/groups_page.dart';
import '../forum/forum_page.dart';
import '../meetings/meetings_page.dart';
import '../notifications/notifications_page.dart';
import '../profile/profile_page.dart';
import '../admin/admin_page.dart';
import '../meetings/meeting_room_page.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.repo});
  final EduRepository repo;
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  final workspaceKey=GlobalKey<MobileWebWorkspaceState>();
  LiveRefresh? live;
  int selected = 0;
  String role = 'student';
  JsonRow? profile;
  Timer? timer;
  bool checking = false;
  bool callDialogOpen = false;
  BuildContext? callPrompt;
  String? activeCallId;
  Timer? callExpiry;
  RealtimeChannel? callsChannel;
  late final NotificationService notifications;

  @override
  void initState() {
    super.initState();
    notifications = NotificationService(widget.repo);
    start();
    GroupLinks.pending.addListener(openGroupInvite);
    WidgetsBinding.instance.addPostFrameCallback((_)=>openGroupInvite());
    listenForCalls();
    live = LiveRefresh(widget.repo.client, () async {
      await checkSession();
      await notifications.retryRegistration();
      final p = await widget.repo.profile();
      if (mounted) setState(() => profile = p);
    },
        tables: ['profiles'],
        filterColumn: 'id',
        filterValue: widget.repo.userId);
    timer = Timer.periodic(const Duration(seconds: 30), (_) {
      unawaited(checkSession());
      unawaited(notifications.retryRegistration());
    });
  }

  bool joiningGroup=false;
  Future<void> openGroupInvite() async {
    final code=GroupLinks.pending.value;
    if(code==null||joiningGroup||!mounted)return;
    joiningGroup=true;
    try {
      if(!await confirm(context,'Join group','Join the group from this invitation using your current account?')){GroupLinks.pending.value=null;return;}
      final id=await widget.repo.client.rpc('join_group_invite',params:{'code_input':code});
      final group=await widget.repo.client.from('groups').select().eq('id',id).single();
      GroupLinks.pending.value=null;
      if(mounted){if(workspaceKey.currentState!=null)await workspaceKey.currentState!.route({'kind':'group','id':id});else await Navigator.push(context,MaterialPageRoute(builder:(_)=>GroupDetailPage(repo:widget.repo,group:group)));}
    }catch(e){GroupLinks.pending.value=null;if(mounted)notice(context,e);}finally{joiningGroup=false;}
  }

  Future<void> start() async {
    await checkSession();
    if (!mounted || widget.repo.client.auth.currentUser == null) return;
    try {
      await notifications.resume(onOpen: (data) async {
        try {
          final notificationId = data['notification_id'];
          if (notificationId == null) return;
          final n = await widget.repo.client
              .from('notifications')
              .select()
              .eq('id', notificationId)
              .maybeSingle();
          if (!mounted || n == null) return;
          if (n['kind'] == 'direct_call_audio' ||
              n['kind'] == 'direct_call_video' ||
              n['kind'] == 'group_call') {
            final meeting = await widget.repo.client
                .from('meetings')
                .select('ended_at')
                .eq('id', n['resource_id'])
                .maybeSingle();
            if (meeting != null && meeting['ended_at'] == null && mounted) {
              await NotificationService.native
                  .invokeMethod('dismissCall', {'id': n['resource_id']?.toString() ?? notificationId.toString()});
              if (data['action'] == 'answer' || data['action'] == 'decline') {
                if (callPrompt != null && callPrompt!.mounted)
                  Navigator.pop(callPrompt!);
              }
              if (data['action'] == 'decline') {
                if (n['kind'] != 'group_call')
                  await widget.repo.client.rpc('decline_direct_call',
                      params: {'meeting': n['resource_id']});
                return;
              }
              if (data['action'] == 'answer') {
                if (MeetingRoomPage.activeMeetingId != null) return;
                await Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => MeetingRoomPage(
                            repo: widget.repo,
                            meetingId: n['resource_id'],
                            autoJoin: true,
                            startWithMic: true,startWithCamera:n['kind']=='direct_call_video')));
                if(mounted && workspaceKey.currentState!=null) {
                  await workspaceKey.currentState!.route({'page':'forum'});
                }
                return;
              }
              await handleIncomingCall(n);
              return;
            }
          }
          if (mounted) {
            if(workspaceKey.currentState!=null) await workspaceKey.currentState!.route({'notification':Map<String,dynamic>.from(n)});
            else await openNotificationDestination(context, widget.repo, Map<String,dynamic>.from(n));
          }
        } catch (e) {
          if (mounted) notice(context, e);
          if (mounted) setState(() => selected = 3);
        }
      });
    } catch (e) {
      if (mounted) notice(context, 'Notification setup: $e');
    }
    try {
      final r = await widget.repo.role();
      final p = await widget.repo.profile();
      if (mounted)
        setState(() {
          role = r;
          profile = p;
        });
    } catch (e) {
      if (mounted) notice(context, e);
    }
  }

  void listenForCalls() {
    callsChannel = widget.repo.client
        .channel('incoming-calls-${widget.repo.userId}')
        .onPostgresChanges(
            event: PostgresChangeEvent.insert,
            schema: 'public',
            table: 'notifications',
            filter: PostgresChangeFilter(
                type: PostgresChangeFilterType.eq,
                column: 'user_id',
                value: widget.repo.userId),
            callback: (payload) {
              final row = Map<String, dynamic>.from(payload.newRecord);
              unawaited(notifications.showNotification(row));
              final kind = row['kind']?.toString();
              if (kind == 'call_cancel') {
                unawaited(NotificationService.native
                    .invokeMethod('dismissCall', {'id': row['resource_id']}));
                if (activeCallId == row['resource_id'] &&
                    callPrompt != null &&
                    callPrompt!.mounted) Navigator.pop(callPrompt!);
              }
              if (kind == 'direct_call_audio' ||
                  kind == 'direct_call_video' ||
                  kind == 'group_call') {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (mounted) handleIncomingCall(row);
                });
              }
            })
        .subscribe();
  }

  Future<void> handleIncomingCall(JsonRow call) async {
    if (callDialogOpen || !mounted || MeetingRoomPage.activeMeetingId != null)
      return;
    final meetingId = call['resource_id']?.toString();
    if (meetingId == null || meetingId.isEmpty) return;
    callDialogOpen = true;
    try {
      final m = await widget.repo.client
          .from('meetings')
          .select('ended_at')
          .eq('id', meetingId)
          .maybeSingle();
      final created = DateTime.tryParse(call['created_at']?.toString() ?? '');
      if (!mounted ||
          m == null ||
          m['ended_at'] != null ||
          (created != null &&
              DateTime.now().difference(created).inSeconds > 60)) {
        callDialogOpen = false;
        return;
      }
    } catch (_) {
      callDialogOpen = false;
      return;
    }
    activeCallId = meetingId;
    callExpiry?.cancel();
    callExpiry = Timer(const Duration(seconds: 60), () {
      if (callPrompt != null && callPrompt!.mounted) Navigator.pop(callPrompt!);
    });
    final video =
        call['kind'] == 'direct_call_video' || call['kind'] == 'group_call';
    final groupCall = call['kind'] == 'group_call';
    final accepted = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) {
          callPrompt = dialogContext;
          return AlertDialog(
            title: Text(video ? 'Incoming video call' : 'Incoming audio call'),
            content:
                Text(call['title']?.toString() ?? 'Someone is calling you.'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: Text('Decline')),
              FilledButton.icon(
                  onPressed: () => Navigator.pop(dialogContext, true),
                  icon: Icon(video ? Icons.videocam : Icons.call),
                  label: Text('Answer')),
            ],
          );
        });
    callExpiry?.cancel();
    callPrompt = null;
    activeCallId = null;
    try {
      await NotificationService.native
          .invokeMethod('dismissCall', {'id': meetingId});
      if (accepted == true) {
        await widget.repo.update('notifications', call['id'],
            {'read_at': DateTime.now().toUtc().toIso8601String()});
        if (mounted) {
          await Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => MeetingRoomPage(
                        repo: widget.repo,
                        meetingId: meetingId,
                        autoJoin: true,
                        startWithMic: true,
                        startWithCamera:video,
                        callTitle: video
                            ? 'Incoming video call'
                            : 'Incoming audio call',
                      )));
          if(mounted && workspaceKey.currentState!=null) {
            await workspaceKey.currentState!.route({'page':'forum'});
          }
        }
      } else if (accepted == false && !groupCall) {
        await widget.repo.client
            .rpc('decline_direct_call', params: {'meeting': meetingId});
        await widget.repo.update('notifications', call['id'],
            {'read_at': DateTime.now().toUtc().toIso8601String()});
      }
    } catch (e) {
      if (mounted) notice(context, e);
    } finally {
      callDialogOpen = false;
    }
  }

  Future<void> checkSession() async {
    if (checking) return;
    checking = true;
    try {
      final active = await widget.repo.client.rpc('is_active');
      if (active != true) {
        if (mounted)
          notice(context,
              'This account is disabled or its session was revoked. Contact your administrator.');
        try {
          await notifications.unregister();
        } catch (_) {}
        await widget.repo.client.auth.signOut(scope: SignOutScope.local);
        return;
      }
      await widget.repo.heartbeat();
    } catch (_) {
      // Keep the local session active during temporary network outages.
    } finally {
      checking = false;
    }
  }

  @override
  void dispose() {
    GroupLinks.pending.removeListener(openGroupInvite);
    live?.dispose();
    timer?.cancel();
    callExpiry?.cancel();
    if (callsChannel != null) widget.repo.client.removeChannel(callsChannel!);
    notifications.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if(!kIsWeb && defaultTargetPlatform==TargetPlatform.android){
      return MobileWebWorkspace(key:workspaceKey,repo:widget.repo,onEnableAlerts:()=>notifications.enablePush(),onLogout:()async{await notifications.unregister();await widget.repo.client.auth.signOut(scope:SignOutScope.local);});
    }

    final labels = <String>[
      'Chats & groups',
      'Public forum',
      'Calls & meetings',
      'Notifications',
      'My profile',
      if (role != 'student') 'Administration',
    ];
    final subtitles = [
      'Message, group chat and more',
      'Discuss and share knowledge',
      'Audio, video and live classes',
      'See your latest alerts',
      'View and edit your profile',
      'Manage users and settings'
    ];
    final tileColors = [
      Colors.blue,
      Colors.deepPurple,
      Colors.green,
      Colors.pink,
      Colors.orange,
      Colors.indigo
    ];
    final icons = <IconData>[
      Icons.chat_bubble_outline_rounded,
      Icons.forum_outlined,
      Icons.call_outlined,
      Icons.notifications_none_rounded,
      Icons.person_outline_rounded,
      if (role != 'student') Icons.admin_panel_settings_outlined,
    ];
    final pages = <Widget>[
      GroupsPage(repo: widget.repo),
      ForumPage(repo: widget.repo),
      MeetingsPage(repo: widget.repo),
      NotificationsPage(repo: widget.repo),
      ProfilePage(repo: widget.repo, notifications: notifications),
      if (role != 'student') AdminPage(repo: widget.repo, role: role),
    ];

    if (selected >= pages.length) selected = 0;
    final width = MediaQuery.sizeOf(context).width;
    final wide = width >= 900;

    Widget navigation() => SafeArea(
          child: Padding(
            padding: EdgeInsets.fromLTRB(14, 16, 14, 14),
            child: Column(children: [
              Padding(
                padding: EdgeInsets.fromLTRB(10, 6, 10, 22),
                child: AppBrand(),
              ),
              Expanded(
                child: ListView.separated(
                  itemCount: labels.length,
                  separatorBuilder: (_, __) => SizedBox(height: 12),
                  itemBuilder: (context, i) => ListTile(
                    minLeadingWidth: 24,
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 14, vertical: 3),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    selected: selected == i,
                    selectedTileColor: Theme.of(context)
                        .colorScheme
                        .primaryContainer
                        .withOpacity(.5),
                    iconColor: selected == i
                        ? Theme.of(context).colorScheme.primary
                        : Theme.of(context).colorScheme.onSurfaceVariant,
                    textColor: selected == i
                        ? Theme.of(context).colorScheme.primary
                        : Theme.of(context).colorScheme.onSurface,
                    leading: Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                            color: tileColors[i].withOpacity(.12),
                            borderRadius: BorderRadius.circular(15)),
                        child: Icon(icons[i], color: tileColors[i])),
                    subtitle: Text(subtitles[i],
                        style: const TextStyle(fontSize: 12)),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    title: Text(labels[i],
                        style: TextStyle(
                            fontWeight: selected == i
                                ? FontWeight.w800
                                : FontWeight.w600)),
                    onTap: () {
                      setState(() => selected = i);
                      if (!wide) Navigator.pop(context);
                    },
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                      color: Theme.of(context).colorScheme.outlineVariant),
                ),
                child: Column(children: [
                  ListTile(
                    contentPadding: EdgeInsets.symmetric(horizontal: 8),
                    leading: UserAvatar(
                      repo: widget.repo,
                      userId: widget.repo.userId,
                      path: profile?['avatar_path'],
                      name: profile?['full_name'],
                      radius: 21,
                    ),
                    title: Text(profile?['full_name'] ?? 'My account',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text(role.replaceAll('_', ' '),
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                    onTap: () {
                      setState(() => selected = 4);
                      if (!wide) Navigator.pop(context);
                    },
                  ),
                  ThemePicker(),
                  Divider(height: 1),
                  ListTile(
                    contentPadding: EdgeInsets.symmetric(horizontal: 8),
                    leading: Icon(Icons.logout_rounded),
                    title: Text('Sign out',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                    onTap: () => perform(context, () async {
                      await notifications.unregister();
                      PagedListState.snapshots.clear();
                      await MediaCache.clear();
                      await widget.repo.client.auth
                          .signOut(scope: SignOutScope.local);
                    }),
                  ),
                ]),
              )
            ]),
          ),
        );

    return Scaffold(
      appBar: wide
          ? null
          : AppBar(
              titleSpacing: 0,
              title: AppBrand(compact: true),
              actions: [
                IconButton(
                  tooltip: 'Notifications',
                  onPressed: () => setState(() => selected = 3),
                  icon: Icon(Icons.notifications_none_rounded),
                ),
                SizedBox(width: 6),
              ],
            ),
      drawer: wide
          ? null
          : Drawer(
              width: MediaQuery.sizeOf(context).width * .88,
              child: navigation()),
      body: Row(children: [
        if (wide) ...[
          Container(
            width: 270,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              border: Border(
                  right: BorderSide(
                      color: Theme.of(context).colorScheme.outlineVariant)),
            ),
            child: navigation(),
          ),
        ],
        Expanded(child: pages[selected]),
      ]),
      bottomNavigationBar: wide
          ? null
          : NavigationBar(
              selectedIndex: selected <= 4 ? selected : 4,
              onDestinationSelected: (i) => setState(() => selected = i),
              destinations: [
                NavigationDestination(
                    icon: Icon(Icons.chat_bubble_outline_rounded),
                    label: 'Chats'),
                NavigationDestination(
                    icon: Icon(Icons.forum_outlined), label: 'Forum'),
                NavigationDestination(
                    icon: Icon(Icons.call_outlined), label: 'Calls'),
                NavigationDestination(
                    icon: Icon(Icons.notifications_none_rounded),
                    label: 'Alerts'),
                NavigationDestination(
                    icon: Icon(Icons.person_outline_rounded), label: 'Profile'),
              ],
            ),
    );
  }
}

