import 'dart:async';
import 'dart:convert';
import 'dart:io';
import '../shared/stored_image.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'edu_repository.dart';
import 'live_refresh.dart';

/// Share one subscription and batch lookup across all visible author avatars.
class ProfilePhotos extends ChangeNotifier {
  ProfilePhotos._(this.repo) : ownerId = repo.userId {
    live = LiveRefresh(repo.client, refresh, tables: ['profiles']);
    hydrated = _restore();
  }
  static final Map<String, ProfilePhotos> _stores = {};
  static ProfilePhotos acquire(EduRepository repo, String id) {
    final store = _stores.putIfAbsent(repo.userId, () => ProfilePhotos._(repo));
    store.refs[id] = (store.refs[id] ?? 0) + 1;
    if (!store.profiles.containsKey(id)) store.live.request();
    return store;
  }

  final EduRepository repo;
  final String ownerId;
  final refs = <String, int>{};
  final profiles = <String, JsonRow>{};
  late LiveRefresh live;
  late final Future<void> hydrated;
  bool closed = false;

  Future<File> _cacheFile() async {
    final root = await getApplicationSupportDirectory();
    final dir = Directory('${root.path}/ecp-profile-cache');
    await dir.create(recursive: true);
    return File('${dir.path}/$ownerId.json');
  }

  /// Avatar paths and display names change rarely. Persisting them means an
  /// existing conversation can paint immediately after an app restart, while
  /// Realtime still replaces stale values when a profile is edited.
  Future<void> _restore() async {
    try {
      final file = await _cacheFile();
      if (!await file.exists()) return;
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! Map || closed) return;
      var changed = false;
      decoded.forEach((key, value) {
        if (key is String && value is Map) {
          final row = JsonRow.from(Map<String, dynamic>.from(value));
          if (row['id'] == key) {
            profiles.putIfAbsent(key, () {
              changed = true;
              return row;
            });
          }
        }
      });
      if (changed && !closed) notifyListeners();
    } catch (_) {
      // The network profile lookup remains the fallback for a corrupt cache.
    }
  }

  Future<void> _save() async {
    try {
      final file = await _cacheFile();
      await file.writeAsString(jsonEncode(profiles), flush: false);
    } catch (_) {}
  }

  Future<void> refresh() async {
    await hydrated;
    final ids = refs.keys.toList();
    for (var start = 0; start < ids.length; start += 80) {
      final rows = await repo.client
          .from('profiles')
          .select('id,avatar_path,full_name')
          .inFilter('id', ids.skip(start).take(80).toList());
      if (closed) return;
      var changed = false;
      for (final row in rows) {
        final id = row['id'] as String;
        final old = profiles[id];
        if (old == null ||
            old['avatar_path'] != row['avatar_path'] ||
            old['full_name'] != row['full_name']) {
          profiles[id] = row;
          final path = row['avatar_path'] as String?;
          if (path != null && path.isNotEmpty)
            unawaited(MediaCache.get(repo, 'avatars', path)
                .then<void>((_) {})
                .catchError((Object _) {}));
          changed = true;
        }
      }
      if (changed) {
        notifyListeners();
        unawaited(_save());
      }
    }
  }

  void release(String id) {
    final count = (refs[id] ?? 1) - 1;
    if (count > 0) {
      refs[id] = count;
    } else {
      refs.remove(id);
    }
    if (refs.isEmpty) {
      // Keep the account-scoped metadata and image warm after leaving a
      // thread. Re-opening the inbox then uses the cached avatar path instead
      // of querying/downloading every profile again.
      return;
    }
  }
}
