import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';

import 'edu_repository.dart';

/// Small account-scoped on-device cache for conversation history.
/// It never replaces Supabase; the page paints it first and then reconciles
/// only new server messages in the background.
class ConversationCache {
  static Future<File> _file(EduRepository repo, String key) async {
    final dir = Directory(
        '${(await getApplicationSupportDirectory()).path}/ecp-conversations/${repo.userId}');
    await dir.create(recursive: true);
    final digest = sha256.convert(utf8.encode(key)).toString();
    return File('${dir.path}/$digest.json');
  }

  static Future<List<JsonRow>> read(EduRepository repo, String key) async {
    try {
      final file = await _file(repo, key);
      if (!await file.exists()) return const [];
      final raw = jsonDecode(await file.readAsString());
      if (raw is! List) return const [];
      return raw
          .whereType<Map>()
          .map((row) => JsonRow.from(Map<String, dynamic>.from(row)))
          .toList(growable: false);
    } catch (_) {
      return const [];
    }
  }

  static Future<void> write(
      EduRepository repo, String key, List<JsonRow> rows) async {
    try {
      final file = await _file(repo, key);
      // A bounded cache prevents one very busy chat consuming device storage.
      await file.writeAsString(jsonEncode(rows.take(200).toList()),
          flush: false);
    } catch (_) {
      // A cache write must never block messaging.
    }
  }
}
