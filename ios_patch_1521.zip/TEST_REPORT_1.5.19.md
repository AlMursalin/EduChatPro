# Edu Chat Pro v1.5.19+69 — Test Report

## Automated / static / package tests

| Test | Result | Notes |
|---|---|---|
| `app.js` syntax | PASS | `node --check` |
| `app-web118.js` syntax | PASS | `node --check` |
| All 7 inline `index.html` scripts syntax | PASS | Extracted and checked with Node |
| Requested stat-card mapping only | PASS | Tracked files, Meetings, Inactive users, Active in 5 minutes are interactive; other stat cards stay unchanged |
| Source browser UI test | PASS | Chromium/Playwright: all 4 cards open correct lists; file delete flow updates stat; active/inactive filtering verified |
| Packaged APK browser UI test | PASS | Same Playwright test rerun against `index.html` extracted from final APK |
| Backend list RPCs installed | PASS | Super Admin file and meeting list RPCs exist |
| Backend cleanup RPCs installed | PASS | File delete, meeting delete, meeting clear-all RPCs exist |
| Super Admin `group-files` Storage policies | PASS | SELECT and DELETE policies installed |
| Rollback integration test | PASS | Existing tracked-file delete, meeting delete and meeting clear-all executed inside a DB transaction; final in-transaction meeting count reached zero; transaction rolled back |
| Live-data rollback preservation | PASS | After rollback: 42 meetings, 5 tracked files, 2,814,810 tracked bytes, 13 users — unchanged from pre-test state |
| Meeting FK/message-edit integration | PASS | Initial rollback test exposed a trigger conflict; guard was fixed and the full rollback integration completed without error |
| APK non-signature diff | PASS | Only `AndroidManifest.xml`, `index.html`, `app.js`, `app-web118.js`, and `v159-runtime.js` changed versus v1.5.18 |
| Native Flutter/WebRTC libraries unchanged | PASS | `libapp.so`, `libflutter.so`, and WebRTC native library byte-for-byte unchanged |
| APK version | PASS | `versionName 1.5.19`, `versionCode 69` |
| APK ZIP integrity | PASS | No corrupt ZIP entries |
| ARM64 native 16 KiB alignment | PASS | All packaged ARM64 `.so` files aligned/stored correctly |
| APK v1 signature | PASS | `jarsigner` reports jar verified (self-signed certificate warning expected) |
| APK v2 signature | PASS | Signing-block digest/crypto verification passed |
| Signing certificate continuity | PASS | Same SHA-256 certificate as v1.5.18: `DB:7E:66:25:2E:19:78:B0:6D:53:1E:68:D5:F0:B8:BD:B5:C4:D1:B0:B6:B0:A9:F2:80:0C:D3:7B:05:9A:12:D9` |

## Not performed destructively on live user data

- A real user account was not permanently deleted for testing.
- A real Storage object was not permanently removed for testing.
- Real meeting/file database deletion was tested only inside a transaction that was rolled back.

## Device-only tests

| Test | Result |
|---|---|
| Install/update on a physical Android device | NOT DEVICE TESTED |
| Tap cards on a physical phone/tablet | NOT DEVICE TESTED |
| Permanently delete a real Storage file from a physical device | NOT DEVICE TESTED |

No physical Android device/emulator is connected to this environment, so those items are not falsely marked PASS.
