# Edu Chat Pro 1.5.17+67 — Startup Hotfix

## Scope
This build is a minimal hotfix on top of v1.5.16. No feature redesign or database change was introduced.

## Fixed
- Fixed the Android WebView startup failure that showed **“Edu Chat Pro startup problem / The main application did not finish startup.”**
- Root cause: the embedded `EduPresence` IIFE inside `assets/webapp/index.html` ended with `})()` instead of `})();`. Because the next bundled runtime also began with `(`, JavaScript treated it as a continuation and threw a top-level TypeError before `init()` could run.
- Added the missing statement terminator so the next bundled runtime starts independently.
- Preserved the v1.5.16 presence, scroll, media preview/download, and call-return changes unchanged.

## Version
- versionName: `1.5.17`
- versionCode: `67`

## Signing
- Reused the exact v1.5.16 signing certificate for update compatibility.
