-- Edu Chat Pro 1.5.13
-- Super Admin can always create a group poll even while normal member messaging is OFF.

drop policy if exists group_polls_create on public.group_polls;

create policy group_polls_create
on public.group_polls
for insert
to authenticated
with check (
  created_by = (select auth.uid())
  and in_group(group_id)
  and (
    private.ecp_account_role((select auth.uid()))::text = 'super_admin'
    or private.ecp_is_group_admin((select auth.uid()))
    or exists (
      select 1 from public.groups g
      where g.id = group_polls.group_id
        and g.allow_member_messaging is true
    )
  )
);
