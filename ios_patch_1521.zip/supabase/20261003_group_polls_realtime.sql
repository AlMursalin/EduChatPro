-- Edu Chat Pro 1.5.11: per-group polls with single-choice voting.
-- Poll voting intentionally remains available when member messaging/calling is OFF.

create table if not exists public.group_polls (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.groups(id) on delete cascade,
  created_by uuid not null references auth.users(id) on delete cascade,
  question text not null check (char_length(btrim(question)) between 1 and 300),
  options jsonb not null check (jsonb_typeof(options) = 'array' and jsonb_array_length(options) between 2 and 6),
  created_at timestamptz not null default now(),
  closed_at timestamptz
);

create index if not exists group_polls_group_created_idx on public.group_polls(group_id, created_at);

create table if not exists public.group_poll_votes (
  poll_id uuid not null references public.group_polls(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  choice integer not null check (choice >= 0 and choice < 6),
  created_at timestamptz not null default now(),
  primary key (poll_id, user_id)
);

create index if not exists group_poll_votes_poll_idx on public.group_poll_votes(poll_id);

alter table public.group_polls enable row level security;
alter table public.group_poll_votes enable row level security;

drop policy if exists group_polls_select_member on public.group_polls;
create policy group_polls_select_member on public.group_polls
for select to authenticated
using (
  private.ecp_account_role(auth.uid()) in ('super_admin','assistant_admin','admin')
  or exists (select 1 from public.group_members gm where gm.group_id = group_polls.group_id and gm.user_id = auth.uid())
);

drop policy if exists group_polls_insert_allowed on public.group_polls;
create policy group_polls_insert_allowed on public.group_polls
for insert to authenticated
with check (
  created_by = auth.uid()
  and (
    private.ecp_account_role(auth.uid()) in ('super_admin','assistant_admin','admin')
    or exists (
      select 1 from public.group_members gm
      join public.groups g on g.id = gm.group_id
      where gm.group_id = group_polls.group_id
        and gm.user_id = auth.uid()
        and g.allow_member_messaging is true
    )
  )
);

drop policy if exists group_polls_update_allowed on public.group_polls;
create policy group_polls_update_allowed on public.group_polls
for update to authenticated
using (
  private.ecp_account_role(auth.uid()) in ('super_admin','assistant_admin','admin')
  or created_by = auth.uid()
)
with check (
  private.ecp_account_role(auth.uid()) in ('super_admin','assistant_admin','admin')
  or created_by = auth.uid()
);

drop policy if exists group_polls_delete_allowed on public.group_polls;
create policy group_polls_delete_allowed on public.group_polls
for delete to authenticated
using (
  private.ecp_account_role(auth.uid()) in ('super_admin','assistant_admin','admin')
  or created_by = auth.uid()
);

drop policy if exists group_poll_votes_select_member on public.group_poll_votes;
create policy group_poll_votes_select_member on public.group_poll_votes
for select to authenticated
using (
  exists (
    select 1 from public.group_polls p
    where p.id = group_poll_votes.poll_id
      and (
        private.ecp_account_role(auth.uid()) in ('super_admin','assistant_admin','admin')
        or exists (select 1 from public.group_members gm where gm.group_id = p.group_id and gm.user_id = auth.uid())
      )
  )
);

drop policy if exists group_poll_votes_insert_member on public.group_poll_votes;
create policy group_poll_votes_insert_member on public.group_poll_votes
for insert to authenticated
with check (
  user_id = auth.uid()
  and exists (
    select 1 from public.group_polls p
    where p.id = group_poll_votes.poll_id
      and p.closed_at is null
      and (
        private.ecp_account_role(auth.uid()) in ('super_admin','assistant_admin','admin')
        or exists (select 1 from public.group_members gm where gm.group_id = p.group_id and gm.user_id = auth.uid())
      )
  )
);

drop policy if exists group_poll_votes_update_member on public.group_poll_votes;
create policy group_poll_votes_update_member on public.group_poll_votes
for update to authenticated
using (user_id = auth.uid())
with check (
  user_id = auth.uid()
  and exists (
    select 1 from public.group_polls p
    where p.id = group_poll_votes.poll_id
      and p.closed_at is null
      and (
        private.ecp_account_role(auth.uid()) in ('super_admin','assistant_admin','admin')
        or exists (select 1 from public.group_members gm where gm.group_id = p.group_id and gm.user_id = auth.uid())
      )
  )
);

drop policy if exists group_poll_votes_delete_member on public.group_poll_votes;
create policy group_poll_votes_delete_member on public.group_poll_votes
for delete to authenticated
using (user_id = auth.uid() or private.ecp_account_role(auth.uid()) in ('super_admin','assistant_admin','admin'));

-- Realtime publication: idempotent.
do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='group_polls') then
    alter publication supabase_realtime add table public.group_polls;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='group_poll_votes') then
    alter publication supabase_realtime add table public.group_poll_votes;
  end if;
end $$;
