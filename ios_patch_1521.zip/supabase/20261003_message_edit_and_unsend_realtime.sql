-- Edu Chat Pro v1.5.15: own-message editing + realtime unsend
-- Applied to production Supabase on 2026-10-03.

alter table public.direct_messages add column if not exists edited_at timestamptz null;
alter table public.group_messages add column if not exists edited_at timestamptz null;
alter table public.direct_messages replica identity full;
alter table public.group_messages replica identity full;

-- Allow clients to edit only the message body. Immutable fields are also protected by triggers below.
grant update(body) on public.direct_messages to authenticated;
grant update(body) on public.group_messages to authenticated;

drop policy if exists direct_message_edit on public.direct_messages;
create policy direct_message_edit on public.direct_messages for update to authenticated
using (is_active() and sender_id=(select auth.uid()))
with check (is_active() and sender_id=(select auth.uid()));

drop policy if exists group_message_edit on public.group_messages;
create policy group_message_edit on public.group_messages for update to authenticated
using (in_group(group_id) and sender_id=(select auth.uid()))
with check (in_group(group_id) and sender_id=(select auth.uid()));

drop policy if exists group_message_access_boundary on public.group_messages;

create or replace function private.ecp_guard_direct_message_edit() returns trigger language plpgsql security invoker set search_path='' as $$
begin
 if auth.uid() is null or old.sender_id is distinct from auth.uid() then raise exception 'You can only edit your own message.' using errcode='42501'; end if;
 if new.id is distinct from old.id or new.sender_id is distinct from old.sender_id or new.recipient_id is distinct from old.recipient_id or new.created_at is distinct from old.created_at or new.attachment_path is distinct from old.attachment_path or new.file_name is distinct from old.file_name or new.mime_type is distinct from old.mime_type or new.size_bytes is distinct from old.size_bytes or new.duration_ms is distinct from old.duration_ms or new.meeting_id is distinct from old.meeting_id or new.thread_id is distinct from old.thread_id or new.attachment_name is distinct from old.attachment_name or new.attachment_mime is distinct from old.attachment_mime then raise exception 'Only the message text can be edited.' using errcode='42501'; end if;
 new.body:=btrim(new.body); if new.body is null or new.body='' then raise exception 'Message cannot be empty.' using errcode='22023'; end if;
 if new.body is distinct from old.body then new.edited_at:=clock_timestamp(); else new.edited_at:=old.edited_at; end if; return new;
end $$;
drop trigger if exists ecp_guard_direct_message_edit on public.direct_messages;
create trigger ecp_guard_direct_message_edit before update on public.direct_messages for each row execute function private.ecp_guard_direct_message_edit();

create or replace function private.ecp_guard_group_message_edit() returns trigger language plpgsql security invoker set search_path='' as $$
begin
 if auth.uid() is null or old.sender_id is distinct from auth.uid() then raise exception 'You can only edit your own message.' using errcode='42501'; end if;
 if new.id is distinct from old.id or new.group_id is distinct from old.group_id or new.sender_id is distinct from old.sender_id or new.is_announcement is distinct from old.is_announcement or new.created_at is distinct from old.created_at or new.file_id is distinct from old.file_id or new.duration_ms is distinct from old.duration_ms or new.meeting_id is distinct from old.meeting_id or new.attachment_path is distinct from old.attachment_path or new.attachment_name is distinct from old.attachment_name or new.attachment_mime is distinct from old.attachment_mime then raise exception 'Only the message text can be edited.' using errcode='42501'; end if;
 new.body:=btrim(new.body); if new.body is null or new.body='' then raise exception 'Message cannot be empty.' using errcode='22023'; end if;
 if new.body is distinct from old.body then new.edited_at:=clock_timestamp(); else new.edited_at:=old.edited_at; end if; return new;
end $$;
drop trigger if exists ecp_guard_group_message_edit on public.group_messages;
create trigger ecp_guard_group_message_edit before update on public.group_messages for each row execute function private.ecp_guard_group_message_edit();
