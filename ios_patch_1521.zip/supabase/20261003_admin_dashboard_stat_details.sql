-- Edu Chat Pro v1.5.19
-- Super Admin dashboard stat-card detail lists and cleanup actions.

create or replace function public.admin_dashboard_files()
returns table(
  id uuid,
  group_id uuid,
  group_name text,
  uploaded_by uuid,
  uploader_name text,
  name text,
  object_path text,
  size_bytes bigint,
  mime_type text,
  created_at timestamptz
)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if auth.uid() is null or not exists (
    select 1 from public.user_roles r
    where r.user_id = auth.uid() and r.role::text = 'super_admin'
  ) then
    raise exception 'Super Admin access required' using errcode='42501';
  end if;

  return query
  select f.id, f.group_id, g.name, f.uploaded_by, p.full_name,
         f.name, f.object_path, f.size_bytes, f.mime_type, f.created_at
  from public.group_files f
  left join public.groups g on g.id = f.group_id
  left join public.profiles p on p.id = f.uploaded_by
  order by f.created_at desc, f.id desc;
end;
$$;

create or replace function public.admin_delete_tracked_file(file_input uuid)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  object_name text;
begin
  if auth.uid() is null or not exists (
    select 1 from public.user_roles r
    where r.user_id = auth.uid() and r.role::text = 'super_admin'
  ) then
    raise exception 'Super Admin access required' using errcode='42501';
  end if;

  select f.object_path into object_name
  from public.group_files f
  where f.id = file_input;

  if object_name is null then
    return null;
  end if;

  delete from public.chat_reactions r
  where r.kind = 'group'
    and r.message_id in (select m.id from public.group_messages m where m.file_id = file_input);

  delete from public.message_reactions r
  where r.thread_kind = 'group'
    and r.message_id in (select m.id from public.group_messages m where m.file_id = file_input);

  delete from public.saved_messages s
  where s.kind = 'group'
    and s.message_id in (select m.id from public.group_messages m where m.file_id = file_input);

  delete from public.group_messages where file_id = file_input;
  delete from public.group_files where id = file_input;
  return object_name;
end;
$$;

create or replace function public.admin_dashboard_meetings()
returns table(
  id uuid,
  title text,
  group_id uuid,
  group_name text,
  host_id uuid,
  host_name text,
  meeting_kind text,
  starts_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz,
  invite_code uuid
)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if auth.uid() is null or not exists (
    select 1 from public.user_roles r
    where r.user_id = auth.uid() and r.role::text = 'super_admin'
  ) then
    raise exception 'Super Admin access required' using errcode='42501';
  end if;

  return query
  select m.id, m.title, m.group_id, g.name, m.host_id, p.full_name,
         m.meeting_kind, m.starts_at, m.ended_at, m.created_at, m.invite_code
  from public.meetings m
  left join public.groups g on g.id = m.group_id
  left join public.profiles p on p.id = m.host_id
  order by m.created_at desc, m.id desc;
end;
$$;

create or replace function public.admin_delete_meeting(meeting_input uuid)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  affected integer := 0;
begin
  if auth.uid() is null or not exists (
    select 1 from public.user_roles r
    where r.user_id = auth.uid() and r.role::text = 'super_admin'
  ) then
    raise exception 'Super Admin access required' using errcode='42501';
  end if;

  delete from public.assistance_events where meeting_id = meeting_input;
  delete from public.meetings where id = meeting_input;
  get diagnostics affected = row_count;
  return affected > 0;
end;
$$;

create or replace function public.admin_clear_meetings()
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  affected integer := 0;
begin
  if auth.uid() is null or not exists (
    select 1 from public.user_roles r
    where r.user_id = auth.uid() and r.role::text = 'super_admin'
  ) then
    raise exception 'Super Admin access required' using errcode='42501';
  end if;

  delete from public.assistance_events
  where meeting_id in (select id from public.meetings);
  delete from public.meetings;
  get diagnostics affected = row_count;
  return affected;
end;
$$;

-- The Storage SDK performs object removal through storage.objects RLS.
-- Existing group policies require group membership, so give the Super Admin
-- explicit read/delete access to tracked group-files from the dashboard.
drop policy if exists ecp_super_admin_group_files_read on storage.objects;
create policy ecp_super_admin_group_files_read
on storage.objects for select to authenticated
using (
  bucket_id = 'group-files'
  and exists (
    select 1 from public.user_roles r
    where r.user_id = auth.uid() and r.role::text = 'super_admin'
  )
);

drop policy if exists ecp_super_admin_group_files_delete on storage.objects;
create policy ecp_super_admin_group_files_delete
on storage.objects for delete to authenticated
using (
  bucket_id = 'group-files'
  and exists (
    select 1 from public.user_roles r
    where r.user_id = auth.uid() and r.role::text = 'super_admin'
  )
);

revoke all on function public.admin_dashboard_files() from public, anon;
revoke all on function public.admin_delete_tracked_file(uuid) from public, anon;
revoke all on function public.admin_dashboard_meetings() from public, anon;
revoke all on function public.admin_delete_meeting(uuid) from public, anon;
revoke all on function public.admin_clear_meetings() from public, anon;

grant execute on function public.admin_dashboard_files() to authenticated;
grant execute on function public.admin_delete_tracked_file(uuid) to authenticated;
grant execute on function public.admin_dashboard_meetings() to authenticated;
grant execute on function public.admin_delete_meeting(uuid) to authenticated;
grant execute on function public.admin_clear_meetings() to authenticated;
