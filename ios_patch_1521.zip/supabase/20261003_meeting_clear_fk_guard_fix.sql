-- Edu Chat Pro v1.5.19
-- Preserve meeting-linked chat messages when Super Admin deletes meeting records.
-- PostgreSQL ON DELETE SET NULL is allowed only when invoked as a nested FK action;
-- normal users are still restricted to editing message text only.

create or replace function private.ecp_guard_direct_message_edit()
returns trigger
language plpgsql
security invoker
set search_path = ''
as $$
begin
  if pg_trigger_depth() > 1
     and old.meeting_id is not null
     and new.meeting_id is null
     and new.id is not distinct from old.id
     and new.sender_id is not distinct from old.sender_id
     and new.recipient_id is not distinct from old.recipient_id
     and new.body is not distinct from old.body
     and new.created_at is not distinct from old.created_at
     and new.attachment_path is not distinct from old.attachment_path
     and new.file_name is not distinct from old.file_name
     and new.mime_type is not distinct from old.mime_type
     and new.size_bytes is not distinct from old.size_bytes
     and new.duration_ms is not distinct from old.duration_ms
     and new.thread_id is not distinct from old.thread_id
     and new.attachment_name is not distinct from old.attachment_name
     and new.attachment_mime is not distinct from old.attachment_mime
     and new.edited_at is not distinct from old.edited_at then
    return new;
  end if;

  if auth.uid() is null or old.sender_id is distinct from auth.uid() then
    raise exception 'You can only edit your own message.' using errcode='42501';
  end if;

  if new.id is distinct from old.id
     or new.sender_id is distinct from old.sender_id
     or new.recipient_id is distinct from old.recipient_id
     or new.created_at is distinct from old.created_at
     or new.attachment_path is distinct from old.attachment_path
     or new.file_name is distinct from old.file_name
     or new.mime_type is distinct from old.mime_type
     or new.size_bytes is distinct from old.size_bytes
     or new.duration_ms is distinct from old.duration_ms
     or new.meeting_id is distinct from old.meeting_id
     or new.thread_id is distinct from old.thread_id
     or new.attachment_name is distinct from old.attachment_name
     or new.attachment_mime is distinct from old.attachment_mime then
    raise exception 'Only the message text can be edited.' using errcode='42501';
  end if;

  new.body := btrim(new.body);
  if new.body is null or new.body = '' then
    raise exception 'Message cannot be empty.' using errcode='22023';
  end if;

  if new.body is distinct from old.body then
    new.edited_at := clock_timestamp();
  else
    new.edited_at := old.edited_at;
  end if;
  return new;
end;
$$;

create or replace function private.ecp_guard_group_message_edit()
returns trigger
language plpgsql
security invoker
set search_path = ''
as $$
begin
  if pg_trigger_depth() > 1
     and old.meeting_id is not null
     and new.meeting_id is null
     and new.id is not distinct from old.id
     and new.group_id is not distinct from old.group_id
     and new.sender_id is not distinct from old.sender_id
     and new.body is not distinct from old.body
     and new.is_announcement is not distinct from old.is_announcement
     and new.created_at is not distinct from old.created_at
     and new.file_id is not distinct from old.file_id
     and new.duration_ms is not distinct from old.duration_ms
     and new.attachment_path is not distinct from old.attachment_path
     and new.attachment_name is not distinct from old.attachment_name
     and new.attachment_mime is not distinct from old.attachment_mime
     and new.edited_at is not distinct from old.edited_at then
    return new;
  end if;

  if auth.uid() is null or old.sender_id is distinct from auth.uid() then
    raise exception 'You can only edit your own message.' using errcode='42501';
  end if;

  if new.id is distinct from old.id
     or new.group_id is distinct from old.group_id
     or new.sender_id is distinct from old.sender_id
     or new.is_announcement is distinct from old.is_announcement
     or new.created_at is distinct from old.created_at
     or new.file_id is distinct from old.file_id
     or new.duration_ms is distinct from old.duration_ms
     or new.meeting_id is distinct from old.meeting_id
     or new.attachment_path is distinct from old.attachment_path
     or new.attachment_name is distinct from old.attachment_name
     or new.attachment_mime is distinct from old.attachment_mime then
    raise exception 'Only the message text can be edited.' using errcode='42501';
  end if;

  new.body := btrim(new.body);
  if new.body is null or new.body = '' then
    raise exception 'Message cannot be empty.' using errcode='22023';
  end if;

  if new.body is distinct from old.body then
    new.edited_at := clock_timestamp();
  else
    new.edited_at := old.edited_at;
  end if;
  return new;
end;
$$;
