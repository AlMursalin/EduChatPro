# Edu Chat Pro v1.5.21 — iOS Readiness Report

## Scope

Base: Edu Chat Pro v1.5.21+71. The Android native source was not modified. The iOS work adds a platform layer around the same Flutter application and the same `assets/webapp` mobile runtime.

## Implemented

- iOS uses `UiKitView` while Android continues to use `AndroidView`.
- iOS native workspace host uses `WKWebView` and loads the bundled `assets/webapp/index.html`.
- `ECP_NATIVE` JavaScript prompt bridge maps to the existing Flutter method channel contract.
- Standard JavaScript alert, confirm, and prompt dialogs are handled on iOS, so existing poll/edit/delete confirmations remain usable.
- Supabase session sync, route/back bridge, meeting launch, QR scan, logout, copy, blob export and HTTPS download hooks are wired.
- WKWebView camera/microphone capture delegate is present for iOS 15+ and Info.plist usage strings are included.
- File export uses the iOS Files document picker.
- Flutter-native video attachment preview uses AVPlayerViewController.
- Flutter-native voice recording/playback uses AVAudioRecorder/AVPlayer and returns `.m4a` bytes to the existing Dart UI.
- iOS custom deep-link scheme `educhat://` is configured.
- Firebase Messaging initialization is platform-aware: Android keeps its existing FirebaseOptions; iOS reads `GoogleService-Info.plist` when supplied.
- Foreground iOS notification presentation is enabled after Firebase initializes.
- One-command macOS preparation script and unsigned GitHub Actions build workflow are included.

## Automated checks completed in this environment

- Swift source parse (`swiftc -parse`) — PASS.
- iOS Info.plist / entitlements parse — PASS.
- macOS setup/build shell syntax (`bash -n`) — PASS.
- GitHub workflow YAML parse — PASS.
- iOS plugin metadata for app_links, Firebase, file picker, secure storage, WebRTC, scanner, path provider, share and URL launcher — PRESENT.
- All standalone web runtime JavaScript files — syntax PASS.
- All 7 inline JavaScript blocks in `assets/webapp/index.html` — syntax PASS.
- Android native directory compared with v1.5.21 base — byte-for-byte unchanged.

## Not executed here

This environment is Linux and has no Xcode/iOS SDK/Apple signing identity. Therefore these remain macOS/device checks:

- `flutter build ios` / Xcode compile.
- CocoaPods integration on macOS.
- signed IPA creation.
- physical iPhone install/launch.
- APNs token registration and killed-app notification delivery.
- camera/microphone capture in WKWebView on a physical iPhone.
- two-device WebRTC audio/video call.
- iOS screen sharing / ReplayKit behavior.

## Firebase requirement

The Android `google-services.json` cannot supply an iOS Firebase app ID. Add an iOS app in the existing Firebase project with bundle ID:

`com.nextechdigitalacademy.educhatpro`

Then place its real `GoogleService-Info.plist` at project root and rerun `bash scripts/prepare_ios.sh`.

Without that plist, the app is designed to continue running with push notifications disabled rather than fail startup.

## Signing / install

The included `BUILD_IOS.sh` and GitHub workflow create an unsigned iOS app/IPA artifact. A normal iPhone requires Apple code signing. Open `ios/Runner.xcworkspace` after preparation, choose your Apple Team, and build to the connected iPhone or create a signed IPA/TestFlight build.
