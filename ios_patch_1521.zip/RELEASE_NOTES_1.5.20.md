# Edu Chat Pro v1.5.20+70

## Fixed
- Super Admin dashboard **Meetings → Clear all** flow.
- The Meetings list modal is now closed before opening the confirmation dialog, preventing Android WebView from continuing with a detached/stale modal button.
- After confirmation the app calls `admin_clear_meetings`, verifies the server meeting list is empty, and falls back to `admin_delete_meeting` for any remaining records.
- Dashboard meeting count refreshes after the server confirms the clear operation.
- If clearing fails, the remaining meeting list is reopened and the server error is shown.

## Scope
- No chat, group, forum, poll, call, notification, media, presence, user-management, or other Admin Panel behavior was changed.
- No new Supabase migration was required for this hotfix; the existing clear/delete meeting RPCs were reused.
