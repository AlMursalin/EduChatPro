# Edu Chat Pro 1.5.11+61 Test Report

## Automated checks completed in this build environment

| Test | Result | Notes |
|---|---|---|
| JavaScript syntax: modified runtime files | PASS | `node --check` passed for presence/cache/runtime files and all inline scripts extracted from `index.html`. |
| 20-second chat full-refresh timer removed | PASS | No active 20-second chat refresh remains in the packaged unified-chat runtime. |
| Presence heartbeat separated from presence-list fetch | PASS | 25-second timer sends heartbeat only; visible/missing IDs are fetched initially/on demand, and last-seen text repaints locally. |
| Stable chat-list DOM | PASS (static) | Keyed row reconciliation preserves unchanged conversation DOM nodes and avatars. |
| Stable message DOM / voice element preservation | PASS (static) | Keyed message reconciliation keeps unchanged `<audio>` / `<video>` nodes instead of replacing the full message container. |
| Old-message scroll logic preserved | PASS (static) | Existing scroll anchoring remains; realtime inserts only auto-bottom when the user is already near the bottom. |
| Avatar/media cache guard | PASS (static) | Loaded avatar identity is account + bucket + path; repeated render passes skip already-loaded unchanged images. Persistent IndexedDB photo keys are account-scoped. |
| Inline image/video preview | PASS (static) | Open action now uses in-app media modal for image/video; Download remains available. |
| Temporary local message reaction guard | PASS | `local-*`/nonpersisted message IDs are rejected before reaction DB calls. |
| Green incoming-message in-app toast removed | PASS (static) | Incoming notifications continue through native push; generic success/error toasts remain. |
| Announcement appears at top | PASS (static) | Dedicated dismissible top announcement banner is packaged. |
| Group permission UI is per-group unified toggle | PASS (static) | Admin/Super Admin-compatible RPC writes both messaging and call flags for the selected group only. |
| Poll creation rule | PASS (static) | Members can create only while messaging is ON; admins can create while OFF. |
| Poll voting while messaging OFF | PASS (static + SQL) | Poll vote RLS is independent from `allow_member_messaging`; one vote per `(poll_id,user_id)` is enforced. |
| Poll realtime DOM | PASS (static) | Poll/vote events update keyed poll state instead of replacing the whole conversation. |
| APK version | PASS | `versionName=1.5.11`, `versionCode=61`. |
| APK packaged assets match updated source | PASS | SHA-256 compared for all modified WebView runtime files. |
| APK ZIP integrity | PASS | `unzip -t` reports no errors. |
| APK JAR signature verification | PASS | `jarsigner -verify` reports `jar verified`. |
| Native ARM64 libraries remain uncompressed/aligned | PASS | `libflutter.so` and `libapp.so` are stored and 16 KiB aligned. |

## Tests not possible in this container

- Real two-device Android audio-call test (A hears B / B hears A, speaker/Bluetooth/weak-network recovery): **NOT RUN** because no Android devices/emulator are attached.
- Foreground/background/closed FCM delivery on a real phone: **NOT RUN** for the same reason.
- A true `flutter clean` + Flutter AOT rebuild: **NOT RUN** because this container does not contain a Flutter SDK/Android SDK and has no usable SDK download path. The supplied APK is therefore a verified WebView-asset hot-patch of the user's existing ARM64 binary, not a fresh Flutter AOT compilation.

## Important native-call note

The updated source includes an additional WebRTC remote-audio routing improvement (`remote track enabled`, Android communication audio mode reapplied, speaker route state preserved). Because a Flutter toolchain is unavailable here, that Dart change is present in the source ZIP but is **not newly AOT-compiled into this hot-patched APK**. The APK retains the native call implementation from the user's original v1.5.10 binary.
