# Edu Chat Pro 1.5.11+61

- Replaced 20-second full chat refresh with Supabase realtime event handling and targeted UI patches.
- Added keyed DOM reconciliation so unchanged messages, avatars and media elements are preserved.
- Preserved old-message scroll position and active voice playback during unrelated realtime updates.
- Presence now does initial/missing-only lookup plus heartbeat; the heartbeat no longer refetches the full presence list.
- Avatar/media loaders avoid re-requesting unchanged assets already loaded for the same account/path.
- Added in-app image/video preview while retaining Download.
- Removed redundant green incoming-message toast; Android system notifications remain.
- Important announcements render in a dismissible top banner.
- Group member messaging/calling permission is presented as one per-group toggle.
- Group polls remain votable when member messaging is disabled; poll DOM updates are keyed and realtime vote events patch the affected state.
- Added Poll access from the group conversation menu.
- Added temporary/local message ID guard for reaction database calls.
