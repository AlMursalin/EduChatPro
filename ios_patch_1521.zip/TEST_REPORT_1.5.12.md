# Edu Chat Pro v1.5.12+62 — Test Report

## Scope and honesty note

The final APK was statically/package-tested in this environment. There is no Flutter SDK, Android SDK/ADB, emulator, or physical Android device available here, so real-device interaction tests cannot be truthfully marked PASS. Those items are marked **NOT TESTED ON DEVICE** rather than being guessed.

## Source/runtime static tests

**PASS — 24/24 automated static acceptance checks**

Verified:

- version is 1.5.12+62
- Group Conversation three-dot menu contains Create Poll
- normal direct-chat branch does not add Create Poll
- menu calls the active `EduOpenGroupPollComposer`
- member poll creation follows `allow_member_messaging`
- poll voting remains available to group members
- poll vote uses `(poll_id,user_id)` upsert behavior
- poll and vote realtime listeners exist
- persistent IndexedDB photo cache exists
- cache identity includes user/bucket/path
- final runtime checks persistent cache before network access
- duplicate concurrent avatar fetches are deduplicated
- already-loaded same-path avatar nodes are not reloaded
- inbox header avatar is pinned to stable eager cached behavior
- profile realtime logic no longer unconditionally reloads the chat list
- presence-only profile changes do not trigger chat-list reload
- forum watcher listens for profile changes
- forum profile changes replace only affected post cards
- no 45-second notification polling remains in active index runtime
- no 45-second notification polling remains in standalone web targets
- presence heartbeat does not call chat/forum full loaders
- `v157-runtime.js` is loaded after earlier runtime patches
- required Supabase migration file exists
- all changed standalone JS and every inline script in `index.html` pass `node --check`

## Live Supabase/backend verification

**PASS** — Connected project: `Edu Chat Project` (`xaqctutviuxwjuqjuidx`).

- `group_polls` exists with RLS enabled.
- `group_poll_votes` exists with RLS enabled.
- both tables are in Supabase Realtime publication.
- one-vote-per-user identity is represented by the `(poll_id,user_id)` primary key.
- live migration `group_poll_member_create_when_enabled` was applied successfully.
- verified live `group_polls_create` policy: authenticated group members may create when `allow_member_messaging IS TRUE`; privileged group admins remain allowed.
- verified existing vote policies allow group members to insert/update their own valid vote, independent of the member messaging toggle.

Supabase security advisor also reports pre-existing project-wide warnings unrelated to this narrow update. They were intentionally not modified because the user requested all unrelated behavior stay the same.

## APK package verification

**PASS**

- ZIP integrity: no errors.
- AndroidManifest: `versionName=1.5.12`, `versionCode=62`.
- package ID remains `com.example.EduChatPro`.
- required modified assets are physically present in `flutter_assets/assets/webapp/`.
- source-to-APK SHA-256 hashes match for `v156-runtime.js`, `v157-runtime.js`, `app.js`, `app-web118.js`, and `educhat-r4.js`.
- packaged `index.html` contains `v157-runtime.js`, Create Poll group menu code, and targeted profile update code.
- APK Signature Scheme v2: VERIFIED by local verifier.
- JAR/v1 signature: VERIFIED.
- signer SHA-256 certificate matches the last v1.5.11 fixed APK exactly: `B5:E1:5E:AD:80:B2:02:C4:65:94:CF:9E:49:38:3D:03:6A:68:CE:93:A1:0C:39:21:55:4F:C2:48:78:9E:3B:BC`.
- all stored native `.so` files remain 16 KB aligned.
- non-signature APK comparison against v1.5.11 shows only 7 intended entries changed/added (manifest + six web assets); all other packaged entries remain unchanged.

## Functional acceptance status

- **PASS (code/backend/package verified):** Create Poll is in group three-dot menu only.
- **PASS (code/backend verified):** group messaging ON member poll-create permission.
- **PASS (code/backend verified):** messaging OFF blocks member poll creation while vote remains allowed.
- **PASS (code/package verified):** cache-first stable inbox-header avatar logic.
- **PASS (code/package verified):** cache-first forum/chat avatar logic and targeted profile updates.
- **PASS (code/package verified):** removal of repeating profile-driven chat-list refresh and 45-second notification polling.
- **PASS (code/package verified):** unchanged media DOM strategy remains in place for targeted chat realtime updates.
- **NOT TESTED ON DEVICE:** visual no-flicker behavior over several minutes on a real phone.
- **NOT TESTED ON DEVICE:** real voice playback continuity while another device sends realtime events.
- **NOT TESTED ON DEVICE:** two-device poll UI/vote interaction.
- **NOT TESTED ON DEVICE:** actual Android Package Installer installation/upgrade screen.
- **NOT TESTED ON DEVICE:** two-device WebRTC audio/call behavior (native code was intentionally left unchanged from v1.5.11 in this narrow update).

## Important build note

A genuine `flutter clean` / Flutter AOT rebuild could not be run because Flutter/Android SDK tooling is unavailable in this environment. To satisfy the instruction to keep the last updated app otherwise exactly the same, the verified v1.5.11 installable APK was used as the binary base, only the explicitly listed WebView assets and version manifest were replaced, then the package was re-aligned and re-signed with the same certificate as that v1.5.11 build.
