# Edu Chat Pro 1.5.17+67 — Test Report

| Test | Result | Notes |
|---|---|---|
| Reproduce v1.5.16 startup runtime failure | PASS | The old embedded presence boundary throws a top-level TypeError when immediately followed by the next IIFE. |
| Fixed presence/IIFE boundary execution | PASS | The packaged v1.5.17 presence block executes and the following IIFE runs (`PACKAGED NEXT IIFE OK`). |
| Inline JavaScript syntax | PASS | All 7 inline scripts extracted from the packaged `index.html` pass `node --check`. |
| Unsafe IIFE boundary scan | PASS | No `})()`-without-semicolon boundary remains before another executable `(` block. |
| APK payload scope | PASS | Compared with v1.5.16: only `AndroidManifest.xml`, `index.html`, and `v159-runtime.js` payload bytes changed. |
| Native ARM64 binaries unchanged | PASS | `libapp.so`, `libflutter.so`, and WebRTC native library hashes match v1.5.16. |
| APK ZIP integrity | PASS | `unzip -t` reports no compressed-data errors. |
| ARM64 16 KiB alignment | PASS | Stored ARM64 `.so` entries are 16 KiB aligned. |
| APK v1 signature | PASS | JAR signature verification reports the jar verified (self-signed certificate warning only). |
| APK v2 signing block | PASS | v2 block/content digest verified by packaging verifier. |
| Same signing certificate as v1.5.16 | PASS | SHA-256 certificate fingerprint is identical: `DB:7E:66:25:2E:19:78:B0:6D:53:1E:68:D5:F0:B8:BD:B5:C4:D1:B0:B6:B0:A9:F2:80:0C:D3:7B:05:9A:12:D9`. |
| Version | PASS | Packaged as `1.5.17+67`. |
| Physical Android install/start test | NOT DEVICE TESTED | No Android device/emulator is connected in this environment. |

## APK SHA-256
`6b0a47f162d617fc55670e4d067b481bdd0223899059111a1dbda1bdc4986937`
