# Edu Chat Pro v1.5.15+65

## New message actions
- Added **Edit** for a user's own sent messages in both direct inbox and group chat.
- Edited message text is saved on Supabase and propagated through existing realtime message UPDATE events.
- Edited messages display an **Edited** indicator.
- **Unsend for everyone** now removes the server message and relies on targeted realtime DELETE updates instead of reloading the full conversation.
- Unsend/edit actions preserve the current message-list viewport so the chat does not jump upward.

## Backend
- Added `edited_at` to `direct_messages` and `group_messages`.
- Added own-message UPDATE policies and edit guards so only message text can be edited.
- Added authenticated UPDATE permission for the `body` column.
- Set direct/group message replica identity to FULL so realtime DELETE events contain enough row context to remove the message from every open conversation.
- Removed the overly broad group-message ALL policy; existing dedicated SELECT/INSERT/DELETE policies remain in effect.

## Preserved
- Existing v1.5.14 poll, member messaging realtime permission, forum/cache, calls, notifications, UI, and other unrelated features were left unchanged.
