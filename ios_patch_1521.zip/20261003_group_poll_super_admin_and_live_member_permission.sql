-- Edu Chat Pro v1.5.14
-- Super Admin may create a group poll even if not present in group_members.
-- Other admins may create while authorized; normal members may create only when member messaging is ON.
drop policy if exists group_polls_create on public.group_polls;

create policy group_polls_create
on public.group_polls
for insert
to authenticated
with check (
  created_by = (select auth.uid())
  and (
    private.ecp_account_role((select auth.uid()))::text = 'super_admin'
    or (
      in_group(group_id)
      and (
        private.ecp_is_group_admin((select auth.uid()))
        or exists (
          select 1
          from public.groups g
          where g.id = group_polls.group_id
            and g.allow_member_messaging is true
        )
      )
    )
  )
);
