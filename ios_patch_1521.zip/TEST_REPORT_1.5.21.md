# Edu Chat Pro v1.5.21+71 — Test Report

## Requested changes
- PASS — Tracked files list contains both View and Delete actions.
- PASS — Image tracked-file View creates a signed Storage URL and opens the existing in-app media viewer.
- PASS — Audio/PDF/unsupported-file preview paths are present and syntax-valid.
- PASS — Presence UI skips DOM repaint when the visible status signature is unchanged.
- PASS — Transient empty realtime presence state keeps `Active now` stable instead of blinking offline.
- PASS — After the transient state, server confirmation returning active keeps `Active now` unchanged.
- PASS — Server confirmation returning inactive changes the visible status only after confirmation.

## Packaged APK verification
- PASS — Final packaged `index.html`, `presence.js`, and `v160-runtime.js` were extracted from the APK and retested.
- PASS — All inline JavaScript in `index.html` passed `node --check` before packaging.
- PASS — Final standalone `presence.js` and `v160-runtime.js` passed JavaScript syntax checks.
- PASS — APK ZIP integrity verified.
- PASS — APK Signature Scheme v2 RSA/SHA-256 signature verified cryptographically.
- PASS — APK v2 content digest recomputed and matched the signed digest.
- PASS — AndroidManifest versionName = 1.5.21 and versionCode = 71.
- PASS — All ARM64 native `.so` files remain STORED and 16 KiB aligned.
- PASS — `libapp.so`, `libflutter.so`, and `libjingle_peerconnection_so.so` are byte-for-byte unchanged from v1.5.20.
- PASS — Content diff from v1.5.20 is limited to AndroidManifest version metadata, `index.html`, `presence.js`, and new `v160-runtime.js` (ignoring old signature metadata).

## Device-only tests
- NOT DEVICE TESTED — Physical Android tap/visual test of tracked-file View.
- NOT DEVICE TESTED — Two-device realtime Active now/offline transition test.
- NOT DEVICE TESTED — Update-install over v1.5.20, because the v1.5.20 private signing key is not available in this runtime.

## Signing note
The v1.5.20 private signing key is not available in the current execution environment. The final APK is correctly v2-signed with a new certificate. Therefore Android will require uninstalling a currently installed v1.5.20 before installing v1.5.21. Server-side account/messages remain in Supabase, but uninstalling clears local app cache/data.
