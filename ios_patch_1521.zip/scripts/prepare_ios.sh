#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This setup script must run on macOS because Xcode/CocoaPods are required." >&2
  exit 2
fi
for tool in flutter pod ruby; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "$tool is required and is not on PATH." >&2
    exit 2
  fi
done

FLUTTER_VERSION="$(flutter --version 2>/dev/null | head -1 || true)"
echo "Using $FLUTTER_VERSION"

# Add the standard Flutter iOS Xcode shell around the existing application only
# when it is missing. Existing Android files and application source stay intact.
if [[ ! -f ios/Runner.xcodeproj/project.pbxproj ]]; then
  flutter create --platforms=ios --org com.nextechdigitalacademy --project-name educhat_pro .
fi

cp ios_support/AppDelegate.swift ios/Runner/AppDelegate.swift
cp ios_support/Info.plist ios/Runner/Info.plist
cp ios_support/Runner.entitlements ios/Runner/Runner.entitlements

# CocoaPods/Flutter plugin deployment target.
python3 - <<'PY'
from pathlib import Path
import re
p=Path('ios/Podfile')
s=p.read_text() if p.exists() else ''
if re.search(r"^platform :ios,",s,flags=re.M):
    s=re.sub(r"^platform :ios,.*$", "platform :ios, '15.0'", s, flags=re.M)
else:
    s="platform :ios, '15.0'\n"+s
p.write_text(s)
PY

# Firebase iOS configuration is intentionally not invented. If the real plist
# is supplied, copy it before editing the Xcode project so it can be bundled.
if [[ -f GoogleService-Info.plist ]]; then
  cp GoogleService-Info.plist ios/Runner/GoogleService-Info.plist
  echo "Firebase iOS config copied."
else
  rm -f ios/Runner/GoogleService-Info.plist
  echo "NOTE: GoogleService-Info.plist is missing. The app can build, but iOS push notifications stay disabled until it is added."
fi

# CocoaPods ships the xcodeproj Ruby gem. Use it instead of fragile text edits so
# repeated prepare runs do not duplicate Xcode build settings or file references.
ruby <<'RUBY'
require 'xcodeproj'
project = Xcodeproj::Project.open('ios/Runner.xcodeproj')
target = project.targets.find { |t| t.name == 'Runner' }
raise 'Runner target not found' unless target

target.build_configurations.each do |config|
  config.build_settings['PRODUCT_BUNDLE_IDENTIFIER'] = 'com.nextechdigitalacademy.educhatpro'
  config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '15.0'
  config.build_settings['CODE_SIGN_ENTITLEMENTS'] = 'Runner/Runner.entitlements'
end

runner_group = project.main_group.children.find { |g| g.respond_to?(:display_name) && g.display_name == 'Runner' }
if File.exist?('ios/Runner/GoogleService-Info.plist') && runner_group
  ref = runner_group.files.find { |f| f.path == 'GoogleService-Info.plist' } || runner_group.new_file('GoogleService-Info.plist')
  unless target.resources_build_phase.files_references.include?(ref)
    target.resources_build_phase.add_file_reference(ref, true)
  end
end
project.save
RUBY

# Generate branded AppIcon files from the existing Edu Chat Pro logo.
if command -v sips >/dev/null 2>&1 && [[ -f assets/ecp-logo.png && -f ios/Runner/Assets.xcassets/AppIcon.appiconset/Contents.json ]]; then
  python3 - <<'PY'
from pathlib import Path
import json,subprocess
root=Path('ios/Runner/Assets.xcassets/AppIcon.appiconset')
meta=json.loads((root/'Contents.json').read_text())
for image in meta.get('images',[]):
    fn=image.get('filename'); size=image.get('size'); scale=image.get('scale')
    if not fn or not size or not scale: continue
    pixels=max(1,round(float(size.split('x')[0])*float(scale.rstrip('x'))))
    subprocess.run(['sips','-z',str(pixels),str(pixels),'assets/ecp-logo.png','--out',str(root/fn)],check=True,stdout=subprocess.DEVNULL)
PY
fi

flutter pub get
(
  cd ios
  pod install --repo-update
)

echo
echo "iOS project prepared: ios/Runner.xcworkspace"
echo "Open the workspace in Xcode, choose your Apple Team, verify Push Notifications + Background Modes, then run on your iPhone."
