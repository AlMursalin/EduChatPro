# iOS Xcode project generation

The Xcode project is generated on macOS from Flutter's official template to match the installed Flutter toolchain.

Run from the project root:

```bash
bash scripts/prepare_ios.sh
```

The script creates `ios/Runner.xcworkspace` when missing, then installs the Edu Chat Pro `WKWebView` bridge and iOS configuration from `ios_support/`.
