(()=>{
'use strict';
if(window.__ECP_V155_RUNTIME)return;window.__ECP_V155_RUNTIME=true;
const qa=(s,r=document)=>[...r.querySelectorAll(s)];
const photos=window.EduPhotos;
if(window.EduWorkspace?.photos&&photos?.peek){
  const originalPhotos=window.EduWorkspace.photos.bind(window.EduWorkspace);
  window.EduWorkspace.photos=async(root,sb)=>{const session=await sb.auth.getSession(),user=session.data.session?.user?.id;if(!user)return;const images=qa('[data-photo]',root);await Promise.all(images.map(async img=>{const identity=`${user}|${img.dataset.bucket||'avatars'}|${img.dataset.photo}`;if(img.dataset.photoLoaded===identity&&img.src)return;const cached=await photos.peek(user,img.dataset.bucket,img.dataset.photo);if(cached&&img.isConnected){img.src=cached;img.dataset.photoLoaded=identity;}}));return originalPhotos(root,sb);};
}
window.EduGroupPollsRemainAvailable=true;
})();
