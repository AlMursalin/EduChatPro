(()=>{
'use strict';if(window.__ECP_V156_RUNTIME)return;window.__ECP_V156_RUNTIME=true;
// Compatibility marker. The real conversation menu now owns Create Poll.
})();
