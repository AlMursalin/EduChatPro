(()=>{
'use strict';
if(window.__ECP_V158_RUNTIME)return;window.__ECP_V158_RUNTIME=true;
window.__ECP_BUILD='1.5.15+65';
const q=(s,r=document)=>r.querySelector(s),qa=(s,r=document)=>[...r.querySelectorAll(s)];
const state=()=>window.__ECP_STATE||null;
const client=()=>window.__ECP_SB||null;
const role=()=>String(state()?.role||'student');
const privileged=()=>['super_admin','assistant_admin','admin'].includes(role());
const superAdmin=()=>role()==='super_admin';
let roleChecked='';
async function ensureRole(){
  const s=state(),db=client(),id=s?.user?.id;if(!s||!db||!id)return role();
  if(roleChecked===id&&['super_admin','assistant_admin','admin','student'].includes(String(s.role||'')))return s.role;
  try{const r=await db.from('user_roles').select('role').eq('user_id',id).maybeSingle();if(!r.error&&r.data?.role){s.role=r.data.role;roleChecked=id;}}catch{}
  return s.role||'student';
}
function canMemberSend(g){return !!g&&(privileged()||g.allow_member_messaging===true);}
function canCreatePoll(g){return !!g&&(superAdmin()||privileged()||g.allow_member_messaging===true);}
function setDisabled(el,disabled){if(el)el.disabled=!!disabled;}
function applyGroupState(row,{optimistic=false}={}){
  const s=state();if(!s?.group?.id||!row?.id||s.group.id!==row.id)return false;
  const mapped={...row};if(Object.prototype.hasOwnProperty.call(row,'image_path'))mapped.avatar_path=row.image_path;
  Object.assign(s.group,mapped);
  const g=s.group,send=canMemberSend(g),allowPoll=canCreatePoll(g);
  setDisabled(q('#message-input'),!send);setDisabled(q('#ws-send button[type="submit"]'),!send);setDisabled(q('#attach-file'),!send);setDisabled(q('#voice-record'),!send);
  const input=q('#message-input');if(input){if(!send)input.placeholder='Group messaging is paused by an administrator.';else if(/paused by an administrator/i.test(input.placeholder||''))input.placeholder='Type a message…';}
  setDisabled(q('#chat-input'),!send);setDisabled(q('#chat-form button[type="submit"]'),!send);setDisabled(q('#chat-attach'),!send);
  const legacyInput=q('#chat-input');if(legacyInput){if(!send)legacyInput.placeholder='Group messaging is paused by an administrator.';else if(/paused by an administrator/i.test(legacyInput.placeholder||''))legacyInput.placeholder='Write to this group…';}
  const pollBtn=q('#create-group-poll');if(pollBtn){pollBtn.disabled=!allowPoll;pollBtn.title=allowPoll?'Create Poll':'Poll creation is disabled while member messaging is off.';}
  const pollAttach=q('[data-ecp152-attach="poll"]');if(pollAttach){pollAttach.classList.toggle('locked',!allowPoll);pollAttach.setAttribute('aria-disabled',String(!allowPoll));const small=q('small',pollAttach);if(small)small.textContent=allowPoll?'Create a poll':'Poll creation is not allowed while member messaging is disabled.';}
  const toggle=q('#allow-chat');if(toggle){toggle.disabled=!superAdmin();if(toggle.checked!==!!g.allow_member_messaging)toggle.checked=!!g.allow_member_messaging;}
  if(row.name){const h=q('.ws-heading-copy h2');if(h)h.textContent=row.name;const thread=q(`[data-thread="${CSS.escape(row.id)}"][data-kind="group"] .ws-thread-title b`);if(thread)thread.textContent=row.name;}
  if(Object.prototype.hasOwnProperty.call(row,'description')){const sub=q('#chat-subtitle');if(sub&&state()?.group?.id===row.id)sub.textContent=row.description||'Group conversation';const desc=q(`[data-thread="${CSS.escape(row.id)}"][data-kind="group"] .ws-thread-description`);if(desc)desc.textContent=row.description||'';}
  if(Object.prototype.hasOwnProperty.call(row,'image_path')){const imgs=qa(`[data-thread="${CSS.escape(row.id)}"][data-kind="group"] img[data-photo],.ws-conversation-header>.ws-avatar img[data-photo]`);for(const img of imgs){if(img.dataset.photo!==row.image_path){img.dataset.photo=row.image_path||'';img.removeAttribute('src');delete img.dataset.photoLoaded;}}try{window.EduWorkspace?.photos?.(document,client())}catch{}}
  window.dispatchEvent(new CustomEvent('ecp:group-permission-changed',{detail:{group_id:g.id,allow_member_messaging:!!g.allow_member_messaging,allow_member_calls:g.allow_member_calls!==false,optimistic}}));
  return true;
}
window.__ECP_APPLY_GROUP_STATE=applyGroupState;
async function reconcileCurrentGroup(){const s=state(),db=client(),id=s?.group?.id;if(!db||!id)return;const r=await db.from('groups').select('id,name,description,image_path,allow_member_messaging,allow_member_calls,updated_at').eq('id',id).maybeSingle();if(!r.error&&r.data)applyGroupState(r.data);}
let channel=null,started=false;
async function start(){if(started)return;const db=client(),s=state();if(!db||!s?.user?.id)return;started=true;await ensureRole();
  channel=db.channel('ecp158-group-live').on('postgres_changes',{event:'UPDATE',schema:'public',table:'groups'},payload=>{const row=payload.new||{};applyGroupState(row);}).subscribe();
  reconcileCurrentGroup().catch(()=>{});
}
// Local toggle: update controls immediately, then the server realtime event confirms the exact state.
document.addEventListener('change',e=>{const t=e.target;if(t?.id!=='allow-chat')return;const s=state();if(!s?.group?.id)return;applyGroupState({id:s.group.id,allow_member_messaging:!!t.checked},{optimistic:true});setTimeout(()=>reconcileCurrentGroup().catch(()=>{}),900);},true);
// When a group conversation/menu/settings DOM appears, synchronize once without polling.
let syncRaf=0;new MutationObserver(()=>{cancelAnimationFrame(syncRaf);syncRaf=requestAnimationFrame(()=>{start().catch(()=>{});ensureRole().then(()=>{const g=state()?.group;if(g)applyGroupState({id:g.id,allow_member_messaging:g.allow_member_messaging,allow_member_calls:g.allow_member_calls,name:g.name,description:g.description,image_path:g.image_path||g.avatar_path});}).catch(()=>{});});}).observe(document.documentElement,{subtree:true,childList:true});
const boot=setInterval(()=>{if(client()&&state()?.user?.id){clearInterval(boot);start().catch(()=>{});}},250);setTimeout(()=>clearInterval(boot),20000);
window.addEventListener('online',()=>reconcileCurrentGroup().catch(()=>{}));
})();
