(()=>{
  'use strict';
  const isAndroidNative=!!window.EduNative;
  if(!isAndroidNative)return;

  const q=(s,r=document)=>r.querySelector(s);
  const qa=(s,r=document)=>[...r.querySelectorAll(s)];
  const page=()=>q('#page');
  const messageLog=()=>q('#message-log')||q('#dm-log')||q('#chat-log')||q('.ws-message-log')||q('.chat-log');
  const composerInput=()=>q('#message-input')||q('#dm-text')||q('#chat-input');
  let keyboardActive=false, previousKeyboardActive=false, raf=0, settleTimers=[],followBottom=true,manualIntentUntil=0,lastManualTop=0;

  function clearSettle(){for(const t of settleTimers)clearTimeout(t);settleTimers=[];}
  function atChatBottom(log){return !log || (log.scrollHeight-log.scrollTop-log.clientHeight)<100;}
  function setFollow(value){followBottom=!!value;window.__ECP_CHAT_FOLLOW=followBottom;if(!followBottom)clearSettle();}
  function scrollChatBottom(force=false){
    const log=messageLog();
    if(!log)return;
    if(force)setFollow(true);
    if(!followBottom)return;
    cancelAnimationFrame(raf);
    raf=requestAnimationFrame(()=>{if(followBottom&&log.isConnected)log.scrollTop=log.scrollHeight;});
  }
  function settleBottom(force=false){
    clearSettle();
    scrollChatBottom(force);
    for(const ms of [45,110,220])settleTimers.push(setTimeout(()=>scrollChatBottom(false),ms));
  }
  function markManualIntent(){const log=messageLog();manualIntentUntil=Date.now()+900;lastManualTop=log?.scrollTop||0;}
  function updateViewport(){
    const vv=window.visualViewport;
    const height=vv?.height||window.innerHeight;
    const top=vv?.offsetTop||0;
    document.documentElement.style.setProperty('--ecp-native-vh',`${Math.round(height)}px`);
    document.documentElement.style.setProperty('--ecp-native-vtop',`${Math.round(top)}px`);
    const active=document.activeElement;
    previousKeyboardActive=keyboardActive;
    keyboardActive=!!(vv&&window.innerHeight-vv.height>120&&active&&/^(INPUT|TEXTAREA)$/.test(active.tagName));
    document.documentElement.classList.toggle('ecp-keyboard-open',keyboardActive);
    if(active===composerInput()&&followBottom&&(keyboardActive||previousKeyboardActive!==keyboardActive))settleBottom(false);
    if(previousKeyboardActive&&!keyboardActive&&followBottom)setTimeout(()=>scrollChatBottom(false),80);
  }

  window.EduChatScroll={
    shouldFollow:()=>followBottom,
    reset:()=>{manualIntentUntil=0;setFollow(true);},
    beginSend:()=>{manualIntentUntil=0;setFollow(true);settleBottom(true);},
    settle:()=>settleBottom(false)
  };

  document.addEventListener('focusin',e=>{
    if(e.target===composerInput()){
      document.documentElement.classList.add('ecp-chat-input-focus');
      setFollow(atChatBottom(messageLog()));
      if(followBottom)settleBottom(false);
    }
  },true);
  document.addEventListener('focusout',e=>{
    if(e.target===composerInput()){
      document.documentElement.classList.remove('ecp-chat-input-focus');
      clearSettle();
      setTimeout(()=>{updateViewport();if(followBottom)scrollChatBottom(false);},40);
    }
  },true);

  window.visualViewport?.addEventListener('resize',updateViewport,{passive:true});
  window.visualViewport?.addEventListener('scroll',updateViewport,{passive:true});
  window.addEventListener('resize',updateViewport,{passive:true});
  let mutationRaf=0;
  new MutationObserver(()=>{
    const input=composerInput();if(!input||document.activeElement!==input||!followBottom)return;
    cancelAnimationFrame(mutationRaf);mutationRaf=requestAnimationFrame(()=>scrollChatBottom(false));
  }).observe(document.documentElement,{subtree:true,childList:true});
  document.addEventListener('touchstart',e=>{const log=messageLog();if(log&&e.target.closest?.('#message-log,#dm-log,#chat-log,.ws-message-log,.chat-log'))markManualIntent();},{passive:true,capture:true});
  document.addEventListener('pointerdown',e=>{const log=messageLog();if(log&&e.target.closest?.('#message-log,#dm-log,#chat-log,.ws-message-log,.chat-log'))markManualIntent();},true);
  document.addEventListener('wheel',e=>{const log=messageLog();if(log&&e.target.closest?.('#message-log,#dm-log,#chat-log,.ws-message-log,.chat-log'))markManualIntent();},{passive:true,capture:true});
  document.addEventListener('scroll',e=>{
    const log=messageLog();if(!log||e.target!==log)return;
    const now=log.scrollTop,bottom=atChatBottom(log),manual=Date.now()<manualIntentUntil;
    if(manual&&!bottom)setFollow(false);else if(bottom)setFollow(true);
    lastManualTop=now;
  },true);
  updateViewport();

  function clickFirst(selectors,root=document){
    for(const s of selectors){const el=q(s,root);if(el){el.click();return true;}}
    return false;
  }

  // Called by Flutter/Android when system Back is pressed. Keep navigation inside
  // the app first, matching Messenger: keyboard -> dialog -> conversation list -> app exit.
  window.EduMobileBack=()=>{
    const active=document.activeElement;
    if(active&&active===composerInput()){active.blur();return true;}
    if(active&&/^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName)&&(keyboardActive||document.documentElement.classList.contains('ecp-chat-input-focus'))){active.blur();return true;}

    const modal=q('#modal-root .modal');
    if(modal){
      if(clickFirst(['[data-close]','[data-no]','#crop-cancel'],modal))return true;
      window.EduUI?.closeModal?.();
      return true;
    }

    const dialogs=qa('dialog[open]');const openDialog=dialogs.length?dialogs[dialogs.length-1]:null;
    if(openDialog){
      const decline=q('[data-decline]',openDialog);
      if(decline){decline.click();return true;}
      try{openDialog.close();if(!openDialog.classList.contains('ecp-full-media-viewer'))openDialog.remove();}catch{}
      return true;
    }

    const root=page();
    if(root?.classList.contains('panels-open')){
      q('#forum-panel-close',root)?.click();
      root.classList.remove('panels-open');
      return true;
    }
    if(root?.classList.contains('conversation-open')){
      const back=q('#back-chats',root);
      if(back)back.click(); else root.classList.remove('conversation-open');
      return true;
    }
    // Legacy group/direct chat pages used by parts of the current web bundle.
    // On phones Back always returns to the unified Chats list, never exits.
    const groupBack=q('#back-groups',root);
    if(groupBack&&(q('#group-body',root)||root?.classList.contains('chat-workspace'))){
      if(typeof window.navigate==='function')window.navigate('chats'); else groupBack.click();
      return true;
    }
    if(root?.classList.contains('messenger-page')&&root.classList.contains('direct-workspace')){
      if(typeof window.navigate==='function'){window.navigate('chats');return true;}
      const back=q('#dm-back',root);
      if(back){back.click();return true;}
    }
    return false;
  };
  // v1.2.6 Messenger-style send: keep IME focused until Android Back.
  let ecpSendTouchAt=0;const ecpSendSelector='#ws-send button[type="submit"],#dm-form button[type="submit"],#chat-form button[type="submit"],.ws-composer button[type="submit"],.composer button[type="submit"]';
  document.addEventListener('pointerdown',e=>{const button=e.target.closest?.(ecpSendSelector),input=composerInput();if(!button||!input||document.activeElement!==input)return;e.preventDefault();ecpSendTouchAt=Date.now();const form=button.closest('form');requestAnimationFrame(()=>{try{input.focus({preventScroll:true})}catch{input.focus()}if(form&&!button.disabled)form.requestSubmit(button);settleBottom(true);});},true);
  document.addEventListener('click',e=>{if(Date.now()-ecpSendTouchAt<700&&e.target.closest?.(ecpSendSelector)){e.preventDefault();e.stopImmediatePropagation();}},true);

})();

// v1.2.9 final mobile UX contract.
(()=>{
  'use strict';
  if(!window.EduNative)return;
  const q=(sel,root=document)=>root.querySelector(sel);
  const qa=(sel,root=document)=>[...root.querySelectorAll(sel)];


  // v1.5.18: scrolling/keyboard follow is owned by the single EduChatScroll controller
  // installed above. Keep only these selectors here for the Back-navigation contract.
  const composer=()=>q('#message-input,#dm-text,#chat-input');
  const log=()=>q('#message-log,#dm-log,#chat-log,.ws-message-log,.chat-log');

  // Exact Android Back contract:
  // keyboard -> current chat; conversation -> chat list;
  // alerts/saved/call -> chat; chat -> home/forum; home/forum -> exit.
  const prior=window.EduMobileBackSafe||window.EduMobileBack;
  window.EduMobileBack=()=>{
    try{
      const active=document.activeElement, input=composer();
      if(active&&input&&active===input){active.blur();return true;}

      const root=q('#page');
      const current=root?.dataset?.page||((typeof S!=='undefined'&&S.page)||'');

      // Let existing chat-detail/modal logic close the inner view first.
      if(q('dialog[open],.modal:not(.hidden)') ||
         root?.classList.contains('conversation-open') ||
         root?.classList.contains('direct-workspace') ||
         (root?.classList.contains('chat-workspace')&&q('#group-body',root))){
        if(typeof prior==='function'&&prior())return true;
      }

      const nav=window.__ECP_NAV||(window.__ECP_NAV={stack:[],ready:true,suppress:false});
      const go=target=>{
        if(!target||target===current||typeof window.navigate!=='function')return false;
        nav.suppress=true; window.navigate(target); return true;
      };

      if(current==='notifications'||current==='saved'||current==='meetings')return go('chats');
      if(current==='chats'||current==='groups'||current==='people')return go('forum');
      if(current==='forum')return false;

      // For other pages preserve actual reverse navigation where possible.
      while(nav.stack?.length){
        const target=nav.stack.pop();
        if(target&&target!==current&&go(target))return true;
      }
      if(current==='profile'||current==='admin')return go('forum');
      if(current)return go('forum');
      return false;
    }catch(err){
      console.warn('v1.2.9 back fallback',err);
      return false;
    }
  };
  window.EduMobileBackSafe=window.EduMobileBack;

  // Persistent photo behavior: decode asynchronously, rely on WebView HTTP cache/CacheStorage,
  // and only refresh when the URL/path changes in realtime.
  const tuneImages=(root=document)=>{
    qa('img',root).forEach(img=>{
      img.decoding='async';
      if(!img.hasAttribute('loading'))img.loading='lazy';
    });
  };
  tuneImages();
  new MutationObserver(muts=>{
    for(const m of muts)for(const n of m.addedNodes)if(n?.nodeType===1)tuneImages(n);
  }).observe(document.documentElement,{subtree:true,childList:true});

  // Messenger/Facebook-style typing animation hook for any existing typing status.
  const typingCss=document.createElement('style');
  typingCss.textContent=`
    .ecp-typing-dots,.typing-dots,.ws-typing-dots{display:inline-flex;align-items:center;gap:3px;height:18px}
    .ecp-typing-dots i,.typing-dots i,.ws-typing-dots i{width:5px;height:5px;border-radius:50%;background:currentColor;opacity:.35;animation:ecpTyping 1s infinite ease-in-out}
    .ecp-typing-dots i:nth-child(2),.typing-dots i:nth-child(2),.ws-typing-dots i:nth-child(2){animation-delay:.14s}
    .ecp-typing-dots i:nth-child(3),.typing-dots i:nth-child(3),.ws-typing-dots i:nth-child(3){animation-delay:.28s}
    @keyframes ecpTyping{0%,60%,100%{transform:translateY(0);opacity:.3}30%{transform:translateY(-4px);opacity:1}}
  `;
  document.head.appendChild(typingCss);
})();


(()=>{
  'use strict';
  if(!window.EduNative)return;
  const previous=window.EduMobileBack;
  window.EduMobileBack=()=>{
    // Preserve the established inner-chat flow first: keyboard -> chat list.
    if(typeof previous==='function' && previous())return true;
    let current='';
    try{current=typeof S!=='undefined'?(S.page||''):'';}catch{}
    if(current==='saved'){
      if(typeof window.navigate==='function')window.navigate('chats');
      return true;
    }
    if(['profile','notifications','meetings','chats','groups','people','admin'].includes(current)){
      if(typeof window.navigate==='function')window.navigate('forum');
      return true;
    }
    // Home/forum deliberately returns false so Flutter exits the app.
    if(current==='forum')return false;
    const root=document.querySelector('#page');
    const heading=root?.querySelector('.ws-page-heading h1')?.textContent?.trim().toLowerCase()||'';
    if(heading==='saved'){
      if(typeof window.navigate==='function')window.navigate('chats');
      return true;
    }
    if(/profile|notification|alert|call|meeting|chat|group/.test(heading)){
      if(typeof window.navigate==='function')window.navigate('forum');
      return true;
    }
    return false;
  };
})();


// v1.2.6 final Android back override

(()=>{
  'use strict';
  if(!window.EduNative)return;
  const prior=window.EduMobileBack;
  window.EduMobileBack=()=>{
    const root=document.querySelector('#page');
    const active=document.activeElement;
    const composer=document.querySelector('#message-input,#dm-text,#chat-input');
    if(active&&composer&&active===composer){active.blur();return true;}
    if(document.querySelector('.modal:not(.hidden),dialog[open]')||root?.classList.contains('conversation-open')||root?.classList.contains('direct-workspace')||(root?.querySelector('#group-body')&&root?.classList.contains('chat-workspace'))){
      if(typeof prior==='function'&&prior())return true;
    }
    const current=root?.dataset?.page||'';
    const nav=window.__ECP_NAV||(window.__ECP_NAV={stack:[],ready:true,suppress:false});
    const go=(target,reset=false)=>{if(!target||target===current)return false;if(reset)nav.stack.length=0;nav.suppress=true;if(typeof window.navigate==='function'){window.navigate(target);return true;}return false;};
    if(current==='notifications'||current==='saved')return go('chats',true);
    if(['chats','groups','people'].includes(current))return go('forum',true);
    if(current==='forum')return false;
    while(nav.stack?.length){const target=nav.stack.pop();if(target&&target!==current)return go(target,false);}
    if(current)return go('forum',true);
    return typeof prior==='function'?prior():false;
  };
})();

