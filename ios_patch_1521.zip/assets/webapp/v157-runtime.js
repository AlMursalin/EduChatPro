(()=>{
'use strict';
if(window.__ECP_V157_RUNTIME)return;window.__ECP_V157_RUNTIME=true;
window.__ECP_BUILD='1.5.14+64';
const q=(s,r=document)=>r.querySelector(s),qa=(s,r=document)=>[...r.querySelectorAll(s)];
const state=()=>{try{return window.__ECP_STATE||(typeof S!=='undefined'?S:null)}catch{return window.__ECP_STATE||null}};
const W=window.EduWorkspace,photos=window.EduPhotos;
const hot=new Map(),pending=new Map();let cachedUser='';
async function userId(client){const live=state()?.user?.id;if(live){cachedUser=live;return live;}if(cachedUser)return cachedUser;try{const r=await client.auth.getSession();cachedUser=r.data.session?.user?.id||'';}catch{}return cachedUser;}
async function stablePhotos(root,client){
  if(!root||!client||!photos?.get)return;
  const user=await userId(client);if(!user)return;
  await Promise.all(qa('img[data-photo]',root).map(async img=>{
    const path=img.dataset.photo,bucket=img.dataset.bucket||'avatars';if(!path)return;
    const id=`${user}|${bucket}|${path}`;
    if(img.dataset.photoLoaded===id&&img.src)return;
    const memory=hot.get(id);if(memory){if(img.isConnected&&img.dataset.photo===path){img.src=memory;img.dataset.photoLoaded=id;}return;}
    let url='';try{url=await photos.peek?.(user,bucket,path)||'';}catch{}
    if(url){hot.set(id,url);if(img.isConnected&&img.dataset.photo===path){img.src=url;img.dataset.photoLoaded=id;}return;}
    let task=pending.get(id);if(!task){task=Promise.resolve(photos.get(client,user,bucket,path)).finally(()=>pending.delete(id));pending.set(id,task);}
    try{url=await task;if(url)hot.set(id,url);if(img.isConnected&&img.dataset.photo===path&&url){img.src=url;img.dataset.photoLoaded=id;}}catch{img.alt=img.alt||'Profile';}
  }));
}
if(W&&photos?.get)W.photos=stablePhotos;

// New DOM nodes get the already-cached blob URL. No full page/list refresh is performed here.
let scheduled=false;const hydrate=()=>{if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;let client=null;try{client=window.__ECP_SB||(typeof sb!=='undefined'?sb:null)}catch{}if(client&&W?.photos)W.photos(document,client).catch(()=>{});});};
new MutationObserver(hydrate).observe(document.documentElement,{subtree:true,childList:true});

// The inbox header avatar behaves like a fixed icon and survives app restarts.
// A small data-URL copy is stored only for conversation header avatars; the normal persistent photo cache remains the main cache.
const HEADER_PREFIX='ecp-header-avatar-v158:';
const headerKey=(user,path)=>HEADER_PREFIX+user+':'+path;
function pruneHeaderCache(user,key){try{const ik=HEADER_PREFIX+'keys:'+user,list=JSON.parse(localStorage.getItem(ik)||'[]').filter(k=>k!==key);list.unshift(key);while(list.length>12){const old=list.pop();localStorage.removeItem(old);}localStorage.setItem(ik,JSON.stringify(list));}catch{}}
async function rememberHeader(img,user,path){if(!user||!path||img.dataset.ecpHeaderStored===path)return;img.dataset.ecpHeaderStored=path;try{const src=img.currentSrc||img.src;if(!src)return;let data=src;if(!src.startsWith('data:')){const r=await fetch(src);if(!r.ok)return;const blob=await r.blob();if(blob.size>220000)return;data=await new Promise((resolve,reject)=>{const fr=new FileReader();fr.onload=()=>resolve(String(fr.result||''));fr.onerror=reject;fr.readAsDataURL(blob);});}if(img.dataset.photo!==path||!data.startsWith('data:'))return;const key=headerKey(user,path);localStorage.setItem(key,data);pruneHeaderCache(user,key);}catch{}}
const pinHeader=()=>{const img=q('.ws-conversation-header>.ws-avatar img[data-photo]');if(!img)return;img.loading='eager';img.decoding='async';const path=img.dataset.photo,user=cachedUser||'';if(user&&path&&!img.getAttribute('src')){try{const saved=localStorage.getItem(headerKey(user,path));if(saved){img.src=saved;img.dataset.photoLoaded=`${user}|avatars|${path}`;}}catch{}}if(user&&path&&!img.dataset.ecpHeaderBound){img.dataset.ecpHeaderBound='1';img.addEventListener('load',()=>rememberHeader(img,user,img.dataset.photo).catch(()=>{}));if(img.complete&&img.src)rememberHeader(img,user,path).catch(()=>{});}};
new MutationObserver(()=>requestAnimationFrame(pinHeader)).observe(document.documentElement,{subtree:true,childList:true});pinHeader();

// Safety fallback for any older embedded menu copy. It never appears in one-to-one chat.
document.addEventListener('click',e=>{
  if(!e.target.closest?.('#show-details')||!state()?.group?.id)return;
  setTimeout(()=>{
    const modal=q('#modal-root .modal-backdrop')||q('#modal-root .modal')||q('#modal-root');if(!modal||q('#create-group-poll,[data-ecp157-poll]',modal))return;
    const stack=q('.stack',modal);if(!stack)return;
    const b=document.createElement('button');b.type='button';b.className='btn';b.dataset.ecp157Poll='1';b.textContent='Create Poll';
    b.onclick=()=>{window.EduUI?.closeModal?.();if(typeof window.EduOpenGroupPollComposer==='function')window.EduOpenGroupPollComposer();else window.EduUI?.toast?.('Poll tools are still loading. Please try again.','error');};
    const invite=q('#group-invite-menu',stack);stack.insertBefore(b,invite||stack.firstChild);
  },0);
},true);
})();
