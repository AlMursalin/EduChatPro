# Edu Chat Pro v1.5.21 — iOS build package

This package keeps the existing Edu Chat Pro application logic and bundled `assets/webapp` runtime. Android remains unchanged. On iOS, the same mobile web workspace is hosted in `WKWebView` through a Flutter `UiKitView`.

## What the iOS bridge includes

- Same mobile chat/forum/admin web workspace as Android.
- Supabase session bridge and native route/back bridge.
- In-app meeting launch into the existing Flutter/WebRTC meeting screen.
- Camera/microphone permission support for WKWebView and Flutter WebRTC.
- File input support through WKWebView/iOS.
- Export/download to the iOS Files picker.
- Native video preview for Flutter-native attachment screens.
- Native `.m4a` voice recording/playback bridge for Flutter-native chat screens.
- `educhat://group` deep-link scheme. An optional associated-domain entitlement template is included for universal links.
- Firebase Messaging iOS hook; foreground alerts are enabled when Firebase iOS is configured.
- Background modes for audio and remote notifications.

## Requirements

- macOS with Xcode installed.
- Flutter 3.22.2 recommended (this project was built around that toolchain).
- CocoaPods.
- An Apple Team for installing a signed build on a physical iPhone.

## 1. Prepare the iOS Xcode project

From the project root on a Mac:

```bash
bash scripts/prepare_ios.sh
```

The script runs `flutter create --platforms=ios` only when `ios/Runner.xcodeproj` is missing, then installs the Edu Chat Pro iOS native bridge and CocoaPods.

## 2. Firebase / APNs

The Android Firebase file cannot be reused on iOS. In the same Firebase project, add an iOS app using this bundle ID:

`com.nextechdigitalacademy.educhatpro`

Download `GoogleService-Info.plist`, place it at the project root, then run `bash scripts/prepare_ios.sh` again.

The default `Runner.entitlements` is intentionally empty so the project can also be signed with a Personal Team for basic on-device testing. For production notifications/universal links, open `ios/Runner.xcworkspace` and enable:

- Signing & Capabilities → **Push Notifications**
- Background Modes → **Remote notifications**
- Background Modes → **Audio, AirPlay, and Picture in Picture** if you want call audio to continue under allowed iOS background conditions.
- **Associated Domains** only if your Apple Team/App ID supports it.

`ios_support/Runner.Push.entitlements.example` shows the APNs/associated-domain keys, but let Xcode manage the actual production entitlements/profile.

For universal links, your website also needs Apple’s `apple-app-site-association` file for `nextechdigitalacademy.is-best.net`. The custom `educhat://group` scheme works independently of that website file.

## 3. Run on your iPhone

Open:

`ios/Runner.xcworkspace`

Choose your Apple Team, connect the iPhone, choose the device, then press **Run**.

Or build from the terminal after signing is configured:

```bash
flutter build ipa --release --dart-define-from-file=config.json
```

## Unsigned CI build

`BUILD_IOS.sh` builds an unsigned iOS `.app` and packages it as an unsigned `.ipa`. It is useful for CI/testing but it is **not directly installable on a normal iPhone until it is signed**.

A GitHub Actions workflow is included at:

`.github/workflows/build-ios-unsigned.yml`

## iOS-specific limitations to validate on a real iPhone

- iOS killed/background incoming-call behavior is not the same as Android full-screen call notifications. Ordinary FCM/APNs notifications are supported after Firebase/APNs setup. A true system CallKit incoming-call UI while the app is terminated requires a PushKit/VoIP server flow and Apple entitlements; that is intentionally not faked here.
- Screen sharing on iOS depends on `flutter_webrtc`/ReplayKit support and should be tested on a physical iPhone. If a full Broadcast Upload Extension is required for your target iOS version/use case, add it in Xcode.
- The source package was prepared in a Linux environment, so Xcode compilation/signing must be run on macOS before claiming a final signed IPA is installable.
