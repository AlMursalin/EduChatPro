# Edu Chat Pro v1.5.18+68 — Test Report

## Automated PASS

- `assets/webapp/native-mobile-patch.js` JavaScript syntax: PASS
- `assets/webapp/v150-runtime.js` JavaScript syntax: PASS
- `assets/webapp/v159-runtime.js` JavaScript syntax: PASS
- All 7 inline JavaScript blocks in packaged `index.html`: PASS
- Browser scroll-controller test: PASS
  - near-bottom composer focus follows newest message;
  - manual upward scroll disables follow;
  - resize/keyboard-style callbacks do not move the manually selected position;
  - delayed settle callbacks do not pull the chat back down after manual scroll;
  - a new send re-enables follow once, and a subsequent manual scroll wins.
- Browser group-mention UI test: PASS
  - `@ali` produces Alice Rahman suggestion;
  - selecting the suggestion inserts `@Alice Rahman `;
  - selected member ID is retained as the mention target.
- Supabase server support: PASS
  - `notify_chat_mentions` RPC exists;
  - `group_members`, `profiles`, and `notifications` are enabled in `supabase_realtime`.
- APK ZIP integrity: PASS
- Packaged modified web assets match updated source: PASS
- Version marker `1.5.18+68`: PASS
- Native ARM64 libraries are byte-for-byte unchanged from v1.5.17: PASS
- ARM64 native libraries remain 16 KiB aligned: PASS
- APK v1/JAR signature verification: PASS (self-signed certificate warning expected)
- APK v2 signature block/digest verification: PASS
- Signing certificate matches v1.5.17 exactly: PASS

## NOT DEVICE TESTED

The environment does not have a physical Android phone/emulator connected, so these cannot honestly be marked as device PASS:

- Samsung/Android IME opening and closing on a real device
- touch inertia while manually scrolling a long production conversation
- two-account live mention notification delivery on real phones

The browser behavior, server prerequisites, packaged runtime code, APK integrity, signing, and native-library preservation were verified.
