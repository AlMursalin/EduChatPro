# Edu Chat Pro v1.5.15+65 Test Report

## Automated/static checks
- PASS — active `index.html` inline JavaScript syntax.
- PASS — `educhat-r4.js` syntax.
- PASS — own-message **Edit** action exists for direct/group chat.
- PASS — edit writes message body to Supabase with `.update({body})` and receives the updated row.
- PASS — edited messages render an `Edited` indicator using server `edited_at`.
- PASS — **Unsend for everyone** no longer calls full `loadMessages()` after deletion.
- PASS — unsend updates local state only for the removed message and existing realtime handles DELETE for other clients.
- PASS — viewport capture/restore is used around message actions to prevent scroll jump.
- PASS — `direct_messages.edited_at` exists in production Supabase.
- PASS — `group_messages.edited_at` exists in production Supabase.
- PASS — own-message UPDATE RLS policies exist for both message tables.
- PASS — authenticated users have UPDATE permission on message `body`.
- PASS — immutable message metadata is protected by BEFORE UPDATE triggers.
- PASS — both message tables use REPLICA IDENTITY FULL for realtime DELETE context.
- PASS — APK ZIP integrity.
- PASS — APK contains the exact updated runtime assets.
- PASS — only intended packaged entries changed from v1.5.14: manifest, `index.html`, `educhat-r4.js`, `v158-runtime.js`.
- PASS — manifest versionName `1.5.15`, versionCode `65`.
- PASS — ARM64 native libraries remain 16 KB aligned.
- PASS — v1/JAR signature verifies.
- PASS — APK Signature Scheme v2 content/signature verification.
- PASS — same signing certificate as v1.5.14.

## Device-only acceptance tests
- NOT DEVICE TESTED — send a direct message on Device A, edit it, confirm Device B updates immediately.
- NOT DEVICE TESTED — send a group message on Device A, edit it, confirm all open group clients update immediately.
- NOT DEVICE TESTED — unsend direct/group message and confirm it disappears from all devices without scroll jump.
- NOT DEVICE TESTED — confirm message-action/confirmation UI does not move the current viewport on the user's phone/tablet.

No physical Android device/emulator is connected in this environment, so device-only behaviors are not marked PASS without real-device execution.
