# Edu Chat Pro v1.5.18+68

This release is based on v1.5.17 and intentionally changes only the requested chat keyboard/scroll behavior and group @mention behavior.

## Changes

- Messenger-style keyboard behavior in direct and group chat:
  - when the composer is focused while already near the bottom, the newest message stays visible above the keyboard;
  - after a manual upward scroll, auto-follow is disabled immediately;
  - keyboard resize, DOM updates, delayed send callbacks, and keyboard close no longer force the user back to the bottom;
  - returning manually to the bottom re-enables normal follow behavior;
  - sending a new message starts at the newest message, but a manual scroll during the send wins and remains preserved.
- Removed the duplicate Android chat auto-follow implementation so only one scroll controller owns keyboard/send following.
- Group @mentions are now reliable in the active unified group conversation:
  - typing `@` opens group-member suggestions;
  - suggestions filter by the typed name;
  - selecting a member inserts `@Full Name` at the caret;
  - the selected user ID is retained for reliable mention notification targeting;
  - group member changes invalidate the local mention suggestion cache;
  - existing `notify_chat_mentions` server RPC remains the notification path.
- No unrelated UI, call, media, poll, forum, notification, or native Flutter/WebRTC behavior was changed.

## Version

- Version name: 1.5.18
- Version code: 68
- ABI: arm64-v8a
