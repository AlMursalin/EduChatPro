# Edu Chat Pro v1.5.13+63 — Release Notes

This update is based directly on the previously delivered v1.5.12 build. Unrelated app features, screens and native libraries are preserved.

## Requested changes

- Super Admin can create a group poll even when **Allow member messaging** is OFF.
- Normal members still cannot create a poll while member messaging is OFF, but they can vote in existing polls.
- Supabase RLS now explicitly guarantees the Super Admin poll-create override at database level.
- Forum default feed is persistent/cache-first: reopening the Forum, including after app restart, restores the previous feed immediately instead of repeatedly downloading/rebuilding it.
- Forum no longer performs periodic/full-feed reloads while idle. It listens for real Supabase Realtime changes and patches the affected item where possible.
- Forum reactions, comments, votes and saved-state updates patch only the affected post instead of reloading the whole feed.
- A real forum post INSERT/UPDATE/DELETE can synchronize the feed because the server content actually changed.
- Forum profile changes update only posts belonging to the changed profile.
- Inbox header profile photo is persistent-cache-first. After the first successful load it remains available across conversation reopen/app restart and the same avatar path is not downloaded again.
- The inbox header avatar is invalidated only when the user's profile `avatar_path`/version actually changes.
- Existing IndexedDB/Cache API avatar caching remains the primary persistent cache; a small header-avatar local cache is used as an immediate restore path when possible.

## Package

- Version: `1.5.13+63`
- ABI: `arm64-v8a`
- Base: Edu Chat Pro v1.5.12
