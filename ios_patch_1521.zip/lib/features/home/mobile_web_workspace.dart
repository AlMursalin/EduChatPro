import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/edu_repository.dart';
import '../auth/qr_web_login_page.dart';
import '../meetings/meeting_room_page.dart';

class MobileWebWorkspace extends StatefulWidget {
  const MobileWebWorkspace({super.key,required this.repo,required this.onLogout,required this.onEnableAlerts});
  final EduRepository repo;
  final Future<void> Function() onLogout,onEnableAlerts;
  @override
  State<MobileWebWorkspace> createState()=>MobileWebWorkspaceState();
}
class MobileWebWorkspaceState extends State<MobileWebWorkspace> with WidgetsBindingObserver {
  MethodChannel? channel;
  StreamSubscription<AuthState>? auth;
  final pending=<Map<String,dynamic>>[];
  bool ready=false;
  Future<void>? refreshing;
  Future<Map<String,dynamic>> currentSession() async {
    var s=widget.repo.client.auth.currentSession;
    if(s==null)throw PlatformException(code:'session',message:'Sign in to continue.');
    if((s.expiresAt??0)*1000<DateTime.now().millisecondsSinceEpoch+60000){
      refreshing??=widget.repo.client.auth.refreshSession().then<void>((_){}).whenComplete(()=>refreshing=null);
      await refreshing;s=widget.repo.client.auth.currentSession;
    }
    if(s==null)throw PlatformException(code:'session',message:'Sign in to continue.');
    return {'access_token':s.accessToken,'refresh_token':s.refreshToken};
  }
  Future<void> syncSession() async {try{final value=await currentSession();if(mounted)await channel?.invokeMethod('session',{'json':jsonEncode(value)});}catch(_){}}

  String sessionJson(){final s=widget.repo.client.auth.currentSession;return jsonEncode({'access_token':s?.accessToken,'refresh_token':s?.refreshToken});}
  @override
  void initState(){super.initState();WidgetsBinding.instance.addObserver(this);auth=widget.repo.client.auth.onAuthStateChange.listen((state){if(state.session!=null)channel?.invokeMethod('session',{'json':sessionJson()});});}
  Future<void> route(Map<String,dynamic> target) async {
    if(!ready||channel==null){pending.add(target);return;}
    await channel!.invokeMethod('evaluate',{'code':'window.EduMobileRoute(${jsonEncode(target)}).catch(e=>window.EduUI.toast(e.message,"error"))'});
  }
  Future<bool> handleSystemBack() async {
    final c=channel;
    if(c==null)return false;
    if(!ready){
      for(var i=0;i<6&&!ready;i++) await Future<void>.delayed(const Duration(milliseconds:80));
      if(!ready)return true;
    }
    try{return await c.invokeMethod<bool>('back')??false;}catch(_){return false;}
  }
  Future<dynamic> call(MethodCall call) async {
    final data=Map<String,dynamic>.from(call.arguments as Map? ?? {});
    switch(call.method){
      case 'session':return currentSession();
      case 'ready':
        ready=true;for(final target in pending.toList()){await route(target);}pending.clear();return true;
      case 'meeting':
        final id=data['id']?.toString()??'';
        if(!RegExp(r'^[0-9a-fA-F-]{36}$').hasMatch(id))throw PlatformException(code:'meeting',message:'Invalid meeting');
        if(MeetingRoomPage.activeMeetingId!=null)return false;
        final m=await widget.repo.client.from('meetings').select('id,ended_at').eq('id',id).single();
        if(m['ended_at']!=null)throw PlatformException(code:'ended',message:'This meeting has ended.');
        if(!mounted)return false;
        await Navigator.push(context,MaterialPageRoute(builder:(_)=>MeetingRoomPage(repo:widget.repo,meetingId:id,autoJoin:data['autoJoin']==true,startWithCamera:data['video']==true)));
        // Keep the WebView on its existing route; the web runtime restores the exact inbox/thread and scroll position.
        return true;
      case 'scanQr':
        if(mounted)await Navigator.push(context,MaterialPageRoute(builder:(_)=>QrWebLoginPage(repo:widget.repo)));return true;
      case 'logout': await widget.onLogout();return true;
      case 'enableAlerts':await widget.onEnableAlerts();return true;
      case 'copy':await Clipboard.setData(ClipboardData(text:data['text']?.toString()??''));return true;
      case 'saveBlob':return channel!.invokeMethod('saveBytes',data);
      case 'download':
        final url=Uri.tryParse(data['url']?.toString()??'');
        if(url==null||url.scheme!='https')throw PlatformException(code:'url',message:'Invalid download link.');
        return const MethodChannel('educhat/files').invokeMethod('download',data);
      default:throw MissingPluginException(call.method);
    }
  }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state){
    if(state==AppLifecycleState.resumed){channel?.invokeMethod('resume');unawaited(syncSession());channel?.invokeMethod('evaluate',{'code':"window.dispatchEvent(new Event('online'));document.dispatchEvent(new Event('visibilitychange'));"});}
    else if(state==AppLifecycleState.paused){channel?.invokeMethod('pause');}
  }
  @override
  void dispose(){auth?.cancel();WidgetsBinding.instance.removeObserver(this);channel?.setMethodCallHandler(null);super.dispose();}
  void _platformViewReady(int id){
    channel=MethodChannel('educhat/workspace/$id');
    channel!.setMethodCallHandler(call);
  }

  Widget _workspaceView(){
    final params={'session':sessionJson()};
    if(!kIsWeb&&defaultTargetPlatform==TargetPlatform.android){
      return AndroidView(
        viewType:'educhat/workspace',
        creationParams:params,
        creationParamsCodec:const StandardMessageCodec(),
        onPlatformViewCreated:_platformViewReady,
      );
    }
    if(!kIsWeb&&defaultTargetPlatform==TargetPlatform.iOS){
      return UiKitView(
        viewType:'educhat/workspace',
        creationParams:params,
        creationParamsCodec:const StandardMessageCodec(),
        onPlatformViewCreated:_platformViewReady,
      );
    }
    return const Center(child:Text('This workspace is available on Android and iOS.'));
  }

  @override
  Widget build(BuildContext context)=>PopScope(
    canPop:false,
    onPopInvoked:(didPop) async {
      if(didPop)return;
      final handled=await handleSystemBack();
      if(!handled&&mounted&&defaultTargetPlatform==TargetPlatform.android){
        await SystemNavigator.pop();
      }
    },
    child:Scaffold(
      resizeToAvoidBottomInset:true,
      body:SafeArea(child:_workspaceView()),
    )
  );
}
