import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart' as rtc;
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/edu_repository.dart';

class P2PPeer {
  P2PPeer(
      {required this.id,
      required this.pc,
      required this.renderer,
      required this.name,
      required this.platform});
  final String id;
  final rtc.RTCPeerConnection pc;
  final rtc.RTCVideoRenderer renderer;
  String name;
  String platform;
  rtc.RTCRtpSender? videoSender;
  rtc.MediaStream? remoteStream;
  bool remoteReady = false, pendingOffer = false, ignoreOffer = false;
  final candidates = <rtc.RTCIceCandidate>[];
}

class SupabaseWebRtcBackend extends ChangeNotifier {
  SupabaseWebRtcBackend(this.repo,
      {required this.meetingId, required this.connectionId});

  final EduRepository repo;
  final String meetingId;
  final String connectionId;

  final Map<String, P2PPeer> peers = {};
  rtc.RTCVideoRenderer localRenderer = rtc.RTCVideoRenderer();
  rtc.MediaStream? localStream;
  rtc.MediaStreamTrack? micTrack;
  rtc.MediaStreamTrack? cameraTrack;
  rtc.MediaStreamTrack? screenTrack;
  rtc.MediaStream? screenStream;
  RealtimeChannel? channel;
  Timer? helloTimer;
  bool connected = false;
  bool micEnabled = false;
  bool cameraEnabled = false;
  bool screenEnabled = false;
  bool _speakerEnabled = true;
  String displayName = 'Participant';
  String userId = '';
  void Function(Map<String, dynamic>)? onData;
  String? lastError;
  bool _disposed = false;
  Future<void> _signals = Future.value();
  void _enqueue(Future<void> Function() action) {
    _signals = _signals.then((_) async {
      if (!_disposed) await action();
    }).catchError((Object e) {
      lastError = 'Call connection: $e';
      notifyListeners();
    });
  }

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  static const List<Map<String, dynamic>> _defaultIce = [
    {'urls': 'stun:stun.l.google.com:19302'},
    {'urls': 'stun:stun1.l.google.com:19302'},
  ];

  List<Map<String, dynamic>> get iceServers {
    // Optional TURN values can be injected with --dart-define at build time.
    const turnUrl = String.fromEnvironment('TURN_URL', defaultValue: '');
    const turnUser = String.fromEnvironment('TURN_USERNAME', defaultValue: '');
    const turnCredential =
        String.fromEnvironment('TURN_CREDENTIAL', defaultValue: '');
    final servers = <Map<String, dynamic>>[..._defaultIce];
    if (turnUrl.trim().isNotEmpty) {
      servers.add({
        'urls': turnUrl.trim(),
        if (turnUser.isNotEmpty) 'username': turnUser,
        if (turnCredential.isNotEmpty) 'credential': turnCredential,
      });
    }
    return servers;
  }

  Future<void> initialize() async {
    if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
      await rtc.Helper.setAndroidAudioConfiguration(
          rtc.AndroidAudioConfiguration.communication);
    }
    await localRenderer.initialize();
    localStream = await rtc.createLocalMediaStream('educhat-local');
    localRenderer.srcObject = localStream;
    userId = repo.userId;
    try {
      final p = await repo.client
          .from('profiles')
          .select('full_name')
          .eq('id', userId)
          .single();
      displayName = (p['full_name']?.toString().trim().isNotEmpty ?? false)
          ? p['full_name'].toString().trim()
          : 'Participant';
    } catch (_) {}
  }

  Future<void> connect() async {
    if (connected) return;
    final topic = 'educhat-meeting:$meetingId';
    final completer = Completer<void>();
    final c = repo.client.channel(
      topic,
      opts: RealtimeChannelConfig(
        private: true,
        key: connectionId,
      ),
    );
    channel = c;

    c
        .onBroadcast(
            event: 'signal', callback: (p) => _enqueue(() => _handleSignal(p)))
        .onBroadcast(
            event: 'data',
            callback: (payload) {
              if (payload['from'] == connectionId) return;
              onData?.call(Map<String, dynamic>.from(payload));
            })
        .onBroadcast(
            event: 'hello', callback: (p) => _enqueue(() => _handleHello(p)))
        .onBroadcast(
            event: 'leave',
            callback: (payload) {
              final id = payload['from']?.toString();
              if (id != null && id != connectionId) _dropPeer(id);
            })
        .subscribe((status, error) async {
      if (status == RealtimeSubscribeStatus.subscribed) {
        try {
          await c.track({
            'connection_id': connectionId,
            'user_id': userId,
            'name': displayName,
            'platform': 'flutter',
            'joined_at': DateTime.now().toIso8601String(),
          });
          connected = true;
          await _sendHello();
          helloTimer?.cancel();
          helloTimer = Timer.periodic(const Duration(seconds: 8), (_) {
            _sendHello();
          });
          if (!completer.isCompleted) completer.complete();
          notifyListeners();
        } catch (e) {
          if (!completer.isCompleted) completer.completeError(e);
        }
      } else if (status == RealtimeSubscribeStatus.channelError ||
          status == RealtimeSubscribeStatus.timedOut ||
          status == RealtimeSubscribeStatus.closed) {
        final e = StateError(
            'Supabase Realtime meeting channel failed: ${error ?? status.name}');
        if (!completer.isCompleted) completer.completeError(e);
      }
    });

    await completer.future.timeout(const Duration(seconds: 12));
  }

  Future<void> _sendHello({String? target}) async {
    final c = channel;
    if (c == null) return;
    await c.sendBroadcastMessage(event: 'hello', payload: {
      'from': connectionId,
      'target': target,
      'user_id': userId,
      'name': displayName,
      'platform': 'flutter',
    });
    if (screenEnabled)
      await sendData(
          {'type': 'share-state', 'owner': connectionId, 'active': true});
  }

  Future<void> _handleHello(Map<String, dynamic> payload) async {
    final from = payload['from']?.toString() ?? '';
    final target = payload['target']?.toString();
    if (from.isEmpty || from == connectionId) return;
    if (target != null && target.isNotEmpty && target != connectionId) return;
    final platform = payload['platform']?.toString() ?? 'web';
    final name = payload['name']?.toString() ?? 'Participant';
    final isNew = !peers.containsKey(from);
    final peer = await _ensurePeer(from, name: name, platform: platform);
    if (isNew) {
      await _sendHello(target: from);
      // Browser peers already create an offer after Presence sees us. Between
      // two Flutter peers, the stable lexical rule chooses one offerer.
      if (platform == 'flutter' && connectionId.compareTo(from) < 0) {
        await _offer(peer);
      }
    }
  }

  Future<P2PPeer> _ensurePeer(String id,
      {String name = 'Participant', String platform = 'unknown'}) async {
    final existing = peers[id];
    if (existing != null) {
      existing.name = name;
      existing.platform = platform;
      return existing;
    }
    final pc = await rtc.createPeerConnection(
        {'iceServers': iceServers, 'sdpSemantics': 'unified-plan'});
    final renderer = rtc.RTCVideoRenderer();
    await renderer.initialize();
    final peer = P2PPeer(
        id: id, pc: pc, renderer: renderer, name: name, platform: platform);
    peer.remoteStream = await rtc.createLocalMediaStream("remote-$id");
    peers[id] = peer;

    pc.onIceCandidate = (candidate) async {
      if (candidate.candidate == null) return;
      await _sendSignal(id, {
        'candidate': {
          'candidate': candidate.candidate,
          'sdpMid': candidate.sdpMid,
          'sdpMLineIndex': candidate.sdpMLineIndex,
        }
      });
    };
    pc.onTrack = (event) async {
      // Android plays remote audio reliably when the original incoming stream
      // is attached to the renderer. Streamless tracks still need a local
      // container, which is why both WebRTC forms are handled here.
      if (!peers.containsKey(id)) return;
      final incoming = event.streams.isNotEmpty ? event.streams.first : null;
      final remote = incoming ?? peer.remoteStream;
      if (remote == null) return;
      if (incoming == null &&
          !remote.getTracks().any((t) => t.id == event.track.id)) {
        await remote.addTrack(event.track);
      }
      peer.remoteStream = remote;
      renderer.srcObject = remote;
      if (event.track.kind == 'audio') {
        event.track.enabled = true;
        if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
          await rtc.Helper.setAndroidAudioConfiguration(
              rtc.AndroidAudioConfiguration.communication);
          await rtc.Helper.setSpeakerphoneOn(_speakerEnabled);
        }
      }
      notifyListeners();
    };
    pc.onConnectionState = (state) {
      notifyListeners();
      if (state == rtc.RTCPeerConnectionState.RTCPeerConnectionStateFailed ||
          state == rtc.RTCPeerConnectionState.RTCPeerConnectionStateClosed) {
        // Keep the tile until Realtime presence/leave catches up, but attempt ICE restart.
        if (state == rtc.RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
          _enqueue(() async {
            await pc.restartIce();
            await _offer(peer);
          });
        }
      }
    };

    final stream = localStream;
    if (stream != null) {
      for (final track in stream.getAudioTracks()) {
        await pc.addTrack(track, stream);
      }
      final video = screenEnabled ? screenTrack : cameraTrack;
      if (video != null)
        peer.videoSender =
            await pc.addTrack(video, screenEnabled ? screenStream! : stream);
    }
    notifyListeners();
    return peer;
  }

  Future<void> _offer(P2PPeer peer) async {
    final state = await peer.pc.getSignalingState();
    if (state != rtc.RTCSignalingState.RTCSignalingStateStable) {
      peer.pendingOffer = true;
      return;
    }
    peer.pendingOffer = false;
    final offer = await peer.pc.createOffer(
        {'offerToReceiveAudio': true, 'offerToReceiveVideo': true});
    await peer.pc.setLocalDescription(offer);
    await _sendSignal(peer.id, {
      'description': {'type': offer.type, 'sdp': offer.sdp}
    });
  }

  Future<void> _sendSignal(String target, Map<String, dynamic> body) async {
    final c = channel;
    if (c == null) return;
    await c.sendBroadcastMessage(event: 'signal', payload: {
      ...body,
      'from': connectionId,
      'target': target,
      'name': displayName,
      'platform': 'flutter',
    });
  }

  Future<void> _handleSignal(Map<String, dynamic> msg) async {
    if (msg['target']?.toString() != connectionId) return;
    final from = msg['from']?.toString() ?? '';
    if (from.isEmpty || from == connectionId) return;
    final peer = await _ensurePeer(
      from,
      name: msg['name']?.toString() ?? 'Participant',
      platform: msg['platform']?.toString() ?? 'web',
    );
    try {
      final description = msg['description'];
      if (description is Map) {
        final type = description['type']?.toString();
        final sdp = description['sdp']?.toString();
        if (type != null && sdp != null) {
          final state = await peer.pc.getSignalingState();
          final collision = type == 'offer' &&
              state != rtc.RTCSignalingState.RTCSignalingStateStable;
          peer.ignoreOffer = collision && connectionId.compareTo(from) < 0;
          if (peer.ignoreOffer) return;
          if (collision)
            await peer.pc
                .setLocalDescription(rtc.RTCSessionDescription('', 'rollback'));
          await peer.pc
              .setRemoteDescription(rtc.RTCSessionDescription(sdp, type));
          peer.remoteReady = true;
          for (final ice in peer.candidates) {
            await peer.pc.addCandidate(ice);
          }
          peer.candidates.clear();
          if (type == 'offer') {
            final answer = await peer.pc.createAnswer();
            await peer.pc.setLocalDescription(answer);
            await _sendSignal(from, {
              'description': {'type': answer.type, 'sdp': answer.sdp}
            });
          }
        }
      }
      if (peer.pendingOffer &&
          description is Map &&
          description['type'] == 'answer') await _offer(peer);
      final candidate = msg['candidate'];
      if (candidate is Map && candidate['candidate'] != null) {
        if (peer.ignoreOffer) return;
        final ice = rtc.RTCIceCandidate(
          candidate['candidate']?.toString(),
          candidate['sdpMid']?.toString(),
          candidate['sdpMLineIndex'] is int
              ? candidate['sdpMLineIndex'] as int
              : int.tryParse(candidate['sdpMLineIndex']?.toString() ?? ''),
        );
        if (peer.remoteReady) {
          await peer.pc.addCandidate(ice);
        } else {
          peer.candidates.add(ice);
        }
      }
    } catch (e) {
      lastError = 'WebRTC signal error: $e';
      notifyListeners();
    }
  }

  Future<void> _renegotiateAll() async {
    for (final peer in peers.values) {
      // Only Flutter-to-Flutter connections use our deterministic offer rule.
      // For browser peers an offer is still safe after a local media change.
      await _offer(peer);
    }
  }

  Future<void> microphone(bool enabled) async {
    if (enabled && micTrack == null) {
      final s = await rtc.navigator.mediaDevices.getUserMedia({
        'audio': {
          'echoCancellation': true,
          'noiseSuppression': true,
          'autoGainControl': true,
          'googEchoCancellation': true,
          'googNoiseSuppression': true,
          'googAutoGainControl': true
        },
        'video': false,
      });
      micTrack = s.getAudioTracks().isEmpty ? null : s.getAudioTracks().first;
      if (micTrack != null && localStream != null) {
        await localStream!.addTrack(micTrack!);
        for (final p in peers.values) {
          await p.pc.addTrack(micTrack!, localStream!);
        }
        await _renegotiateAll();
      }
    }
    micTrack?.enabled = enabled;
    micEnabled = enabled && micTrack != null;
    if (enabled && micTrack == null)
      throw StateError(
          'No microphone is available. Allow microphone permission.');
    notifyListeners();
  }

  Future<void> camera(bool enabled, {bool lowBandwidth = false}) async {
    if (enabled && cameraTrack == null) {
      final video = lowBandwidth
          ? {'facingMode': 'user', 'width': 320, 'height': 180, 'frameRate': 12}
          : {
              'facingMode': 'user',
              'width': 640,
              'height': 360,
              'frameRate': 24
            };
      final s = await rtc.navigator.mediaDevices
          .getUserMedia({'audio': false, 'video': video});
      cameraTrack =
          s.getVideoTracks().isEmpty ? null : s.getVideoTracks().first;
      if (cameraTrack != null && localStream != null) {
        await localStream!.addTrack(cameraTrack!);
        await _renegotiateAll();
      }
    }
    cameraTrack?.enabled = enabled;
    cameraEnabled = enabled && cameraTrack != null;
    if (!screenEnabled && cameraTrack != null) {
      for (final p in peers.values) {
        if (p.videoSender == null) {
          p.videoSender = await p.pc.addTrack(cameraTrack!, localStream!);
        } else {
          await p.videoSender!.replaceTrack(cameraTrack!);
        }
      }
      await _renegotiateAll();
    }
    localRenderer.srcObject = screenEnabled ? screenStream : localStream;
    notifyListeners();
  }

  Future<void> switchCamera() async {
    final t = cameraTrack;
    if (t != null) await rtc.Helper.switchCamera(t);
  }

  Future<void> setSpeaker(bool enabled) async {
    _speakerEnabled = enabled;
    if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
      await rtc.Helper.setAndroidAudioConfiguration(
          rtc.AndroidAudioConfiguration.communication);
    }
    await rtc.Helper.setSpeakerphoneOn(enabled);
  }

  Future<void> shareScreen(bool enabled) async {
    if (enabled) {
      if (screenTrack != null) return;
      screenStream = await rtc.navigator.mediaDevices
          .getDisplayMedia({'video': true, 'audio': false});
      screenTrack = screenStream!.getVideoTracks().isEmpty
          ? null
          : screenStream!.getVideoTracks().first;
      final t = screenTrack;
      if (t == null) return;
      for (final p in peers.values) {
        if (p.videoSender != null)
          await p.videoSender!.replaceTrack(t);
        else
          p.videoSender = await p.pc.addTrack(t, screenStream!);
      }
      screenEnabled = true;
      localRenderer.srcObject = screenStream;
      t.onEnded = () {
        if (screenEnabled) unawaited(shareScreen(false));
      };
      await _renegotiateAll();
      await sendData(
          {'type': 'share-state', 'owner': connectionId, 'active': true});
      notifyListeners();
      return;
    }
    screenEnabled = false;
    final t = screenTrack;
    screenTrack = null;
    if (t != null) await t.stop();
    for (final p in peers.values) {
      await p.videoSender?.replaceTrack(cameraTrack);
    }
    for (final t in screenStream?.getTracks() ?? <rtc.MediaStreamTrack>[]) {
      await t.stop();
    }
    screenStream = null;
    screenEnabled = false;
    localRenderer.srcObject = localStream;
    await _renegotiateAll();
    await sendData(
        {'type': 'share-state', 'owner': connectionId, 'active': false});
    notifyListeners();
  }

  Future<void> sendData(Map<String, dynamic> data) async {
    final c = channel;
    if (c == null) return;
    await c.sendBroadcastMessage(event: 'data', payload: {
      ...data,
      'from': connectionId,
      'name': displayName,
    });
  }

  Future<void> disconnect() async {
    helloTimer?.cancel();
    helloTimer = null;
    final c = channel;
    if (c != null) {
      try {
        await c.sendBroadcastMessage(
            event: 'leave', payload: {'from': connectionId});
      } catch (_) {}
      try {
        await c.untrack();
      } catch (_) {}
      try {
        await repo.client.removeChannel(c);
      } catch (_) {}
    }
    channel = null;
    for (final id in peers.keys.toList()) {
      await _dropPeer(id);
    }
    for (final track in localStream?.getTracks() ?? <rtc.MediaStreamTrack>[]) {
      await track.stop();
    }
    for (final track in screenStream?.getTracks() ?? <rtc.MediaStreamTrack>[]) {
      await track.stop();
    }
    localStream = null;
    micTrack = null;
    cameraTrack = null;
    screenTrack = null;
    micEnabled = false;
    cameraEnabled = false;
    screenEnabled = false;
    screenStream = null;
    connected = false;
    notifyListeners();
  }

  Future<void> _dropPeer(String id) async {
    final p = peers.remove(id);
    if (p == null) return;
    try {
      await p.pc.close();
    } catch (_) {}
    try {
      await p.pc.dispose();
    } catch (_) {}
    try {
      p.renderer.srcObject = null;
      await p.remoteStream?.dispose();
      await p.renderer.dispose();
    } catch (_) {}
    notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    helloTimer?.cancel();
    unawaited(disconnect());
    localRenderer.dispose();
    super.dispose();
  }
}
