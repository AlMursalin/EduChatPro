# Edu Chat Pro v1.5.12+62 — Release Notes

This update is intentionally based on the last updated v1.5.11 build. Existing native code and unrelated packaged files were kept unchanged; only the requested WebView/runtime assets, version metadata, and the required Supabase poll-create policy were changed.

## Requested fixes

- Added **Create Poll** directly to **Group Conversation → top three-dot → Conversation options**.
- The group poll menu item does not appear in normal one-to-one direct chat.
- Existing poll composer remains connected to the active group poll implementation.
- Normal members can create polls when group member messaging is enabled; when it is disabled, only privileged group admins can create polls, while group members can still vote.
- Group poll votes remain one vote per user through `(poll_id, user_id)` upsert/uniqueness behavior and update through realtime poll/vote subscriptions.
- Inbox header avatars now use stable persistent photo caching: same `user + bucket + avatar_path` identities are reused without re-downloading or flashing.
- Repeated/recreated avatar nodes are hydrated from IndexedDB cache before any network fetch, with concurrent duplicate fetches deduplicated.
- Presence/last-seen-only profile updates no longer trigger a full chat-list reload. Only actual avatar/name changes can update the relevant profile UI.
- Forum profile changes are handled as targeted post-card/avatar updates rather than a full forum reload.
- Removed the old 45-second notification catch-up polling from standalone web targets; catch-up remains event/resume/network driven.
- Added final runtime patch `v157-runtime.js` after previous patches so the requested stable-cache behavior wins at runtime.

## Backend

Applied Supabase migration `group_poll_member_create_when_enabled` to the connected Edu Chat Project. The `group_polls_create` RLS policy now allows a group member to create a poll when `groups.allow_member_messaging = true`, while privileged group admins remain allowed. Poll voting remains available to group members independently of the messaging toggle.

## Build/package

- Version: **1.5.12+62**
- Package ID: `com.example.EduChatPro`
- ABI: ARM64-v8a
- APK built from the last v1.5.11 installable APK as the binary base so unrelated native code stays byte-for-byte unchanged.
- Same signing certificate as the last v1.5.11 fixed build.
