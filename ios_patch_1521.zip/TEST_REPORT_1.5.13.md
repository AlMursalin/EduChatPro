# Edu Chat Pro v1.5.13+63 — Test Report

Status meanings:
- PASS = verified by static/package/backend checks in this environment.
- NOT DEVICE TESTED = requires a physical Android device/two live clients and was not falsely marked PASS.

## Requested follow-up changes

| Test | Status | Result |
|---|---|---|
| Super Admin poll create while member messaging OFF — UI permission path | PASS | Runtime explicitly treats `super_admin` as allowed regardless of member-messaging state. |
| Super Admin poll create while member messaging OFF — database RLS | PASS | Live Supabase `group_polls_create` policy explicitly allows Super Admin. |
| Normal member poll create while messaging OFF | PASS | Runtime permission remains blocked; backend permits ordinary members only when `allow_member_messaging=true`. |
| Poll voting while messaging OFF | PASS | Existing vote RLS is group-membership/poll-open based and is not tied to member messaging. |
| Forum idle periodic full refresh removed | PASS | Modern Forum runtime contains no periodic full-feed polling timer; cache/realtime flow is used. |
| Forum restart/cache restore | PASS (code path) | Default feed is persisted locally and restored before lightweight catch-up. |
| Forum new/changed post synchronization | PASS (code path) | `forum_posts` realtime changes trigger feed synchronization; unchanged server marker does not reload feed. |
| Forum reaction update | PASS (code path) | Only affected post reaction data is refreshed/patched. |
| Forum comment update | PASS (code path) | Only affected post comment count/details are refreshed/patched. |
| Forum vote update | PASS (code path) | Only affected poll/post is refreshed/patched. |
| Forum profile picture change | PASS (code path) | Only posts for the affected profile are patched. |
| Inbox header avatar same-path stability | PASS (code path) | Existing DOM source is retained when `user + avatar_path` identity is unchanged. |
| Inbox header avatar persistent cache across restart | PASS (code path) | IndexedDB/Cache API persistence is retained and immediate local header restore was added. |
| Inbox header avatar invalidation on new profile photo | PASS (code path) | Cache identity includes avatar path/version; a different path fetches/caches the new image. |
| JavaScript syntax — modified standalone runtime files | PASS | `node --check` completed successfully. |
| JavaScript syntax — inline scripts in final `index.html` | PASS | All extracted inline scripts parse successfully. |
| Real Android visual/interaction test | NOT DEVICE TESTED | No Android phone/emulator is connected to this environment. |
| Real multi-client realtime behavior test | NOT DEVICE TESTED | Requires two authenticated live clients/devices. |

## Packaging verification

The final APK is separately checked for ZIP integrity, bundled asset hashes, versionName/versionCode, ARM64 native-library alignment, JAR/v1 signature and APK Signature Scheme v2.

## Build limitation

Flutter/Dart SDK is not installed in this execution environment. Therefore this follow-up APK is produced by preserving the previously delivered v1.5.12 native APK and replacing only the verified bundled WebView runtime assets plus manifest version metadata, then re-signing with the same hot-patch release certificate used for v1.5.12. It is not represented as a fresh Flutter AOT compilation.

## Final packaged APK verification results

- APK ZIP integrity: **PASS**
- Final APK contains source-identical modified `index.html`: **PASS**
- Final APK contains source-identical modified `app.js`: **PASS**
- Final APK contains source-identical modified `app-web118.js`: **PASS**
- Final APK contains source-identical modified `educhat-r4.js`: **PASS**
- Final APK contains source-identical modified `v152-runtime.js`: **PASS**
- Final APK contains source-identical modified `v157-runtime.js`: **PASS**
- Only intended non-signature APK entries changed vs delivered v1.5.12: **PASS**
- Manifest `versionName=1.5.13`, `versionCode=63`: **PASS**
- ARM64 stored native libraries 16 KB aligned: **PASS**
- JAR / APK v1 signature: **PASS**
- APK Signature Scheme v2: **PASS**
- Same v2 signing certificate as delivered v1.5.12 fixed APK: **PASS**
- APK content digest verification: **PASS**

Physical Android installation/UI behavior remains **NOT DEVICE TESTED** in this environment because no Android device/emulator is attached.
