import Flutter
import UIKit
import WebKit
import AVFoundation
import AVKit
import UserNotifications

@main
@objc class AppDelegate: FlutterAppDelegate {
  private var documentExporter: EduDocumentExporter?
  private var fileBridge: EduFileBridge?
  private var mediaBridge: EduMediaBridge?

  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    GeneratedPluginRegistrant.register(with: self)

    guard let registrar = self.registrar(forPlugin: "EduNativeIOS") else {
      return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }

    let presenter: () -> UIViewController? = { [weak self] in
      guard let root = self?.window?.rootViewController else { return nil }
      return AppDelegate.topController(root)
    }

    let exporter = EduDocumentExporter(presenter: presenter)
    documentExporter = exporter
    fileBridge = EduFileBridge(messenger: registrar.messenger(), presenter: presenter, exporter: exporter)
    mediaBridge = EduMediaBridge(messenger: registrar.messenger())
    registrar.register(
      EduWorkspaceFactory(messenger: registrar.messenger(), presenter: presenter, exporter: exporter),
      withId: "educhat/workspace"
    )

    UNUserNotificationCenter.current().delegate = self
    application.registerForRemoteNotifications()
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }

  private static func topController(_ root: UIViewController) -> UIViewController {
    if let presented = root.presentedViewController { return topController(presented) }
    if let nav = root as? UINavigationController, let visible = nav.visibleViewController { return topController(visible) }
    if let tab = root as? UITabBarController, let selected = tab.selectedViewController { return topController(selected) }
    return root
  }
}

final class EduWorkspaceFactory: NSObject, FlutterPlatformViewFactory {
  private let messenger: FlutterBinaryMessenger
  private let presenter: () -> UIViewController?
  private let exporter: EduDocumentExporter

  init(messenger: FlutterBinaryMessenger, presenter: @escaping () -> UIViewController?, exporter: EduDocumentExporter) {
    self.messenger = messenger
    self.presenter = presenter
    self.exporter = exporter
    super.init()
  }

  func createArgsCodec() -> FlutterMessageCodec & NSObjectProtocol {
    FlutterStandardMessageCodec.sharedInstance()
  }

  func create(withFrame frame: CGRect, viewIdentifier viewId: Int64, arguments args: Any?) -> FlutterPlatformView {
    EduWorkspace(frame: frame, viewId: viewId, args: args as? [String: Any] ?? [:], messenger: messenger, presenter: presenter, exporter: exporter)
  }
}

final class EduWorkspace: NSObject, FlutterPlatformView, WKNavigationDelegate, WKUIDelegate {
  private let webView: WKWebView
  private let channel: FlutterMethodChannel
  private let presenter: () -> UIViewController?
  private let exporter: EduDocumentExporter
  private var sessionJSON: String

  init(frame: CGRect, viewId: Int64, args: [String: Any], messenger: FlutterBinaryMessenger, presenter: @escaping () -> UIViewController?, exporter: EduDocumentExporter) {
    self.presenter = presenter
    self.exporter = exporter
    self.sessionJSON = args["session"] as? String ?? "{}"

    let configuration = WKWebViewConfiguration()
    configuration.websiteDataStore = .default()
    configuration.allowsInlineMediaPlayback = true
    configuration.mediaTypesRequiringUserActionForPlayback = []
    configuration.preferences.javaScriptCanOpenWindowsAutomatically = false
    if #available(iOS 14.0, *) {
      configuration.defaultWebpagePreferences.allowsContentJavaScript = true
    }

    self.webView = WKWebView(frame: frame, configuration: configuration)
    self.channel = FlutterMethodChannel(name: "educhat/workspace/\(viewId)", binaryMessenger: messenger)
    super.init()

    webView.backgroundColor = UIColor(red: 246.0/255.0, green: 250.0/255.0, blue: 1.0, alpha: 1.0)
    webView.isOpaque = false
    webView.scrollView.keyboardDismissMode = .interactive
    webView.navigationDelegate = self
    webView.uiDelegate = self

    channel.setMethodCallHandler { [weak self] call, result in
      self?.handle(call: call, result: result)
    }
    loadApp()
  }

  func view() -> UIView { webView }

  private func loadApp() {
    let key = FlutterDartProject.lookupKey(forAsset: "assets/webapp/index.html")
    guard let path = Bundle.main.path(forResource: key, ofType: nil) else {
      webView.loadHTMLString("<h3>Edu Chat Pro assets are missing.</h3>", baseURL: nil)
      return
    }
    let url = URL(fileURLWithPath: path)
    webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
  }

  private func handle(call: FlutterMethodCall, result: @escaping FlutterResult) {
    let args = call.arguments as? [String: Any] ?? [:]
    switch call.method {
    case "evaluate":
      webView.evaluateJavaScript(args["code"] as? String ?? "") { _, error in
        if let error = error { result(FlutterError(code: "javascript", message: error.localizedDescription, details: nil)) }
        else { result(nil) }
      }
    case "back":
      let code = """
      (function(){try{if(window.EduMobileBackSafe)return !!window.EduMobileBackSafe();return !!(window.EduMobileBack&&window.EduMobileBack());}catch(e){try{var r=document.querySelector('#page');var p=(r&&r.dataset&&r.dataset.page)||'';if((p==='notifications'||p==='saved')&&window.navigate){window.navigate('chats');return true;}if((p==='chats'||p==='groups'||p==='people')&&window.navigate){window.navigate('forum');return true;}if(p&&p!=='forum'&&window.navigate){window.navigate('forum');return true;}}catch(_e){}return false;}})()
      """
      webView.evaluateJavaScript(code) { value, _ in result((value as? NSNumber)?.boolValue ?? (value as? Bool ?? false)) }
    case "session":
      sessionJSON = args["json"] as? String ?? "{}"
      let literal = EduJS.quote(sessionJSON)
      webView.evaluateJavaScript("window.EduNativeSession&&window.EduNativeSession(JSON.parse(\(literal)))") { _, _ in result(nil) }
    case "saveBytes":
      guard let base64 = args["base64"] as? String, let data = Data(base64Encoded: base64), data.count <= 30_000_000 else {
        result(FlutterError(code: "save", message: "This file is too large or invalid.", details: nil)); return
      }
      exporter.export(data: data, name: args["name"] as? String ?? "attachment", result: result)
    case "pause", "resume":
      result(nil)
    default:
      result(FlutterMethodNotImplemented)
    }
  }

  func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
    guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
    if url.isFileURL { decisionHandler(.allow); return }
    if navigationAction.targetFrame?.isMainFrame == true {
      let allowed = ["https", "http", "mailto", "tel"].contains(url.scheme?.lowercased() ?? "")
      if allowed { UIApplication.shared.open(url) }
      decisionHandler(.cancel)
      return
    }
    decisionHandler(.allow)
  }

  func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
    guard prompt.hasPrefix("ECP_NATIVE:") else {
      presentTextPrompt(message: prompt, defaultText: defaultText, completionHandler: completionHandler)
      return
    }
    let payloadText = String(prompt.dropFirst("ECP_NATIVE:".count))
    guard let data = payloadText.data(using: .utf8),
          let payload = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
          let requestId = payload["id"] as? String,
          let method = payload["method"] as? String else {
      completionHandler(""); return
    }
    completionHandler("")
    let arguments = payload["data"] as? [String: Any] ?? [:]
    channel.invokeMethod(method, arguments: arguments) { [weak self] value in
      if let error = value as? FlutterError {
        self?.reply(id: requestId, value: nil, error: error.message ?? error.code)
      } else if let object = value as AnyObject?, object === FlutterMethodNotImplemented {
        self?.reply(id: requestId, value: nil, error: "This action is unavailable")
      } else {
        self?.reply(id: requestId, value: value, error: nil)
      }
    }
  }

  func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
    guard let presenter = presenter() else { completionHandler(); return }
    let alert = UIAlertController(title: "Edu Chat Pro", message: message, preferredStyle: .alert)
    alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
    presenter.present(alert, animated: true)
  }

  func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
    guard let presenter = presenter() else { completionHandler(false); return }
    let alert = UIAlertController(title: "Edu Chat Pro", message: message, preferredStyle: .alert)
    alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
    alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
    presenter.present(alert, animated: true)
  }

  private func presentTextPrompt(message: String, defaultText: String?, completionHandler: @escaping (String?) -> Void) {
    guard let presenter = presenter() else { completionHandler(nil); return }
    let alert = UIAlertController(title: "Edu Chat Pro", message: message, preferredStyle: .alert)
    alert.addTextField { field in field.text = defaultText }
    alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(nil) })
    alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(alert.textFields?.first?.text ?? "") })
    presenter.present(alert, animated: true)
  }

  @available(iOS 15.0, *)
  func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin, initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType, decisionHandler: @escaping (WKPermissionDecision) -> Void) {
    // This WKWebView only loads the bundled Edu Chat Pro workspace as its main
    // document; external main-frame navigations are opened outside the WebView.
    // iOS still enforces the app-level camera/microphone usage descriptions.
    decisionHandler(.grant)
  }

  private func reply(id: String, value: Any?, error: String?) {
    var payload: [String: Any] = ["id": id, "value": value ?? NSNull(), "error": error ?? NSNull()]
    if !JSONSerialization.isValidJSONObject(payload) { payload["value"] = String(describing: value ?? "") }
    guard let data = try? JSONSerialization.data(withJSONObject: payload), let json = String(data: data, encoding: .utf8) else { return }
    DispatchQueue.main.async { [weak self] in
      self?.webView.evaluateJavaScript("window.EduNativeReply&&window.EduNativeReply(\(json))", completionHandler: nil)
    }
  }

  deinit { channel.setMethodCallHandler(nil) }
}

private enum EduJS {
  static func quote(_ value: String) -> String {
    let data = try? JSONSerialization.data(withJSONObject: [value])
    let array = data.flatMap { String(data: $0, encoding: .utf8) } ?? "[\"\"]"
    return String(array.dropFirst().dropLast())
  }
}

final class EduDocumentExporter: NSObject, UIDocumentPickerDelegate {
  private let presenter: () -> UIViewController?
  private var pending: FlutterResult?
  private var tempURL: URL?

  init(presenter: @escaping () -> UIViewController?) { self.presenter = presenter }

  func export(data: Data, name: String, result: @escaping FlutterResult) {
    DispatchQueue.main.async {
      guard self.pending == nil else { result(FlutterError(code: "busy", message: "Finish the current save first.", details: nil)); return }
      let safe = name.replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: ":", with: "_")
      let folder = FileManager.default.temporaryDirectory.appendingPathComponent("EduChatExport-\(UUID().uuidString)", isDirectory: true)
      do {
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let url = folder.appendingPathComponent(safe.isEmpty ? "attachment" : safe)
        try data.write(to: url, options: .atomic)
        guard let presenter = self.presenter() else { throw NSError(domain: "EduChat", code: 1, userInfo: [NSLocalizedDescriptionKey: "Cannot open the file exporter."]) }
        self.pending = result
        self.tempURL = folder
        let picker = UIDocumentPickerViewController(forExporting: [url], asCopy: true)
        picker.delegate = self
        presenter.present(picker, animated: true)
      } catch {
        result(FlutterError(code: "save", message: error.localizedDescription, details: nil))
      }
    }
  }

  func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { finish(true) }
  func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { finish(false) }

  private func finish(_ success: Bool) {
    let result = pending
    pending = nil
    if let url = tempURL { try? FileManager.default.removeItem(at: url) }
    tempURL = nil
    result?(success)
  }
}

final class EduFileBridge: NSObject {
  private let channel: FlutterMethodChannel
  private let presenter: () -> UIViewController?
  private let exporter: EduDocumentExporter

  init(messenger: FlutterBinaryMessenger, presenter: @escaping () -> UIViewController?, exporter: EduDocumentExporter) {
    self.presenter = presenter
    self.exporter = exporter
    self.channel = FlutterMethodChannel(name: "educhat/files", binaryMessenger: messenger)
    super.init()
    channel.setMethodCallHandler { [weak self] call, result in self?.handle(call, result: result) }
  }

  private func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
    let args = call.arguments as? [String: Any] ?? [:]
    guard let raw = args["url"] as? String, let url = URL(string: raw), url.scheme?.lowercased() == "https" else {
      result(FlutterError(code: "url", message: "Invalid media link.", details: nil)); return
    }
    switch call.method {
    case "download":
      URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
        if let error = error {
          DispatchQueue.main.async { result(FlutterError(code: "download", message: error.localizedDescription, details: nil)) }
          return
        }
        guard let data = data else {
          DispatchQueue.main.async { result(FlutterError(code: "download", message: "The file could not be downloaded.", details: nil)) }
          return
        }
        self?.exporter.export(data: data, name: args["name"] as? String ?? url.lastPathComponent, result: result)
      }.resume()
    case "video":
      DispatchQueue.main.async {
        guard let presenter = self.presenter() else { result(false); return }
        let player = AVPlayer(url: url)
        let controller = AVPlayerViewController()
        controller.player = player
        presenter.present(controller, animated: true) { player.play(); result(true) }
      }
    default:
      result(FlutterMethodNotImplemented)
    }
  }

  deinit { channel.setMethodCallHandler(nil) }
}

final class EduMediaBridge: NSObject, AVAudioRecorderDelegate {
  private let channel: FlutterMethodChannel
  private var recorder: AVAudioRecorder?
  private var recordURL: URL?
  private var recordStarted: Date?
  private var player: AVPlayer?
  private var playingURL: String?

  init(messenger: FlutterBinaryMessenger) {
    self.channel = FlutterMethodChannel(name: "educhat/media", binaryMessenger: messenger)
    super.init()
    channel.setMethodCallHandler { [weak self] call, result in self?.handle(call, result: result) }
  }

  private func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
    switch call.method {
    case "record": requestAndRecord(result)
    case "stopRecord": stopRecord(result)
    case "cancelRecord": cancelRecord(); result(nil)
    case "play":
      let args = call.arguments as? [String: Any] ?? [:]
      guard let text = args["url"] as? String, let url = URL(string: text) else { result(FlutterError(code: "url", message: "Invalid audio link.", details: nil)); return }
      do {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playAndRecord, mode: .spokenAudio, options: [.defaultToSpeaker, .allowBluetooth, .allowBluetoothA2DP])
        try session.setActive(true)
        player = AVPlayer(url: url); playingURL = text; player?.play(); result(0)
      } catch { result(FlutterError(code: "audio", message: error.localizedDescription, details: nil)) }
    case "pause": player?.pause(); result(nil)
    case "status":
      let ms = Int(((player?.currentTime().seconds ?? 0).isFinite ? (player?.currentTime().seconds ?? 0) : 0) * 1000)
      result(["url": playingURL ?? "", "playing": player?.timeControlStatus == .playing, "position": ms])
    default: result(FlutterMethodNotImplemented)
    }
  }

  private func requestAndRecord(_ result: @escaping FlutterResult) {
    let session = AVAudioSession.sharedInstance()
    let start = { [weak self] in self?.startRecord(result) }
    switch session.recordPermission {
    case .granted: start()
    case .denied: result(FlutterError(code: "permission", message: "Microphone permission is required.", details: nil))
    case .undetermined:
      session.requestRecordPermission { granted in DispatchQueue.main.async { granted ? start() : result(FlutterError(code: "permission", message: "Microphone permission is required.", details: nil)) } }
    @unknown default: result(FlutterError(code: "permission", message: "Microphone permission is unavailable.", details: nil))
    }
  }

  private func startRecord(_ result: @escaping FlutterResult) {
    do {
      let session = AVAudioSession.sharedInstance()
      try session.setCategory(.playAndRecord, mode: .spokenAudio, options: [.defaultToSpeaker, .allowBluetooth])
      try session.setActive(true)
      let url = FileManager.default.temporaryDirectory.appendingPathComponent("voice-\(UUID().uuidString).m4a")
      let settings: [String: Any] = [
        AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
        AVSampleRateKey: 44100.0,
        AVNumberOfChannelsKey: 1,
        AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue,
        AVEncoderBitRateKey: 96000
      ]
      let recorder = try AVAudioRecorder(url: url, settings: settings)
      recorder.delegate = self
      recorder.prepareToRecord()
      guard recorder.record() else { throw NSError(domain: "EduChat", code: 2, userInfo: [NSLocalizedDescriptionKey: "Recording could not start."]) }
      self.recorder = recorder; self.recordURL = url; self.recordStarted = Date(); result(true)
    } catch { result(FlutterError(code: "record", message: error.localizedDescription, details: nil)) }
  }

  private func stopRecord(_ result: @escaping FlutterResult) {
    guard let recorder = recorder, let url = recordURL else { result(FlutterError(code: "record", message: "No recording is active.", details: nil)); return }
    let duration = max(Int((recordStarted.map { Date().timeIntervalSince($0) } ?? recorder.currentTime) * 1000), 1)
    recorder.stop(); self.recorder = nil; self.recordURL = nil; self.recordStarted = nil
    do {
      let data = try Data(contentsOf: url); try? FileManager.default.removeItem(at: url)
      result(["bytes": FlutterStandardTypedData(bytes: data), "duration_ms": duration])
    } catch { result(FlutterError(code: "record", message: error.localizedDescription, details: nil)) }
  }

  private func cancelRecord() {
    recorder?.stop(); recorder = nil; recordStarted = nil
    if let url = recordURL { try? FileManager.default.removeItem(at: url) }
    recordURL = nil
  }

  deinit { cancelRecord(); channel.setMethodCallHandler(nil) }
}
