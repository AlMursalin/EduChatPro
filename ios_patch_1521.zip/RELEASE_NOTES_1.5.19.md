# Edu Chat Pro v1.5.19+69 — Release Notes

Base: v1.5.18. This release changes only the requested Super Admin dashboard stat-card interactions and the backend cleanup support required by those actions.

## Added

- **Tracked file bytes** card is now clickable.
  - Opens the exact tracked `group_files` list used by the dashboard byte counter.
  - Shows file name, size, MIME type, group, uploader, and date.
  - Each item has a **Delete** action with confirmation.
  - Delete removes the Storage object first, then removes the linked tracked-file metadata and shared file message, and refreshes the dashboard byte total.
- **Meetings** card is now clickable.
  - Opens the complete Super Admin meeting list.
  - Shows title, type, host, group, state, and date.
  - Each meeting has **Delete**.
  - Includes **Clear all** with confirmation.
  - Meeting deletion preserves chat messages by allowing PostgreSQL's internal FK `SET NULL` cleanup while keeping normal user message metadata protected.
- **Inactive users** card is now clickable.
  - Uses the same `last_active_at/status` rule as `dashboard_stats`.
  - Opens the matching user list.
  - Super Admin can delete an account from the list using the existing hard-delete flow.
- **Active in 5 minutes** card is now clickable.
  - Uses the exact same 5-minute rule as `dashboard_stats`.
  - Opens matching active users.
  - Super Admin can delete an account from the list; the current Super Admin account is protected.
- Dashboard stat values refresh after file, meeting, or account cleanup without rebuilding unrelated admin features.

## Backend

- Added Super Admin RPCs:
  - `admin_dashboard_files()`
  - `admin_delete_tracked_file(uuid)`
  - `admin_dashboard_meetings()`
  - `admin_delete_meeting(uuid)`
  - `admin_clear_meetings()`
- Added Super Admin Storage read/delete policies for the `group-files` bucket so the dashboard can remove files even when the Super Admin is not a member of that group.
- Added a narrow FK cleanup exception to message-edit guards so meeting deletion can set `meeting_id = NULL` internally without allowing users to edit protected message metadata.

## Unchanged

All other v1.5.18 chat, forum, poll, call, meeting, notification, media, presence, navigation, and UI behavior is intentionally unchanged.
