# Edu Chat Pro v1.5.21+71 — Release Notes

This update is intentionally limited to the two requested changes on top of v1.5.20.

## Super Admin tracked files
- Added a **View** button beside **Delete** in Super Admin → Tracked files.
- Image and video files open in the existing in-app media viewer.
- Audio files open in an in-app audio preview.
- PDF files open in an in-app PDF preview frame where WebView supports it.
- Other file types show file metadata plus an **Open file** action.
- Existing Delete behavior remains unchanged.

## Stable Active now / presence
- Presence text no longer repaints when the visible state has not changed.
- Realtime transient sync/leave gaps no longer immediately flip Active now to offline and back.
- An apparent offline transition is confirmed against `ecp_presence_list` before the UI changes.
- Actual online realtime joins still update promptly.
- No periodic full presence polling was added.

## Unchanged
- Chat, groups, forum, polls, calls, meetings, notifications, message edit/unsend, admin meeting cleanup, and all other existing v1.5.20 behavior were intentionally left unchanged.
