#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
bash scripts/prepare_ios.sh
flutter build ios --release --no-codesign --dart-define-from-file=config.json
rm -rf build/ios/unsigned_ipa build/ios/EduChatPro-unsigned.ipa
mkdir -p build/ios/unsigned_ipa/Payload
cp -R build/ios/iphoneos/Runner.app build/ios/unsigned_ipa/Payload/
(cd build/ios/unsigned_ipa && /usr/bin/zip -qry ../EduChatPro-unsigned.ipa Payload)
echo "Unsigned iOS artifact: build/ios/EduChatPro-unsigned.ipa"
echo "For direct iPhone installation, sign the app in Xcode with your Apple Team / provisioning profile."
