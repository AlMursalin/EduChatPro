import 'services/startup_permission_gate.dart';
import 'services/group_links.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'services/notification_service.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config/app_config.dart';
import 'core/secure_session_storage.dart';
import 'features/auth/auth_page.dart';
import 'features/home/home_shell.dart';
import 'services/edu_repository.dart';
import 'theme/app_theme.dart';
import 'theme/theme_controller.dart';
import 'shared/app_brand.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ThemeController.load();
  await GroupLinks.initialize();
  try {
    await initializePush();
  } catch (_) {/* Profile offers explicit setup/retry. */}
  String? error;
  if (AppConfig.configured) {
    try {
      await Supabase.initialize(
          url: AppConfig.supabaseUrl,
          anonKey: AppConfig.supabaseKey,
          authOptions: FlutterAuthClientOptions(
              localStorage: SecureSessionStorage(),
              authFlowType: AuthFlowType.pkce));
    } catch (e) {
      error = e.toString();
    }
  }
  runApp(EduChatApp(startupError: error));
}

class EduChatApp extends StatelessWidget {
  const EduChatApp({super.key, this.startupError});
  final String? startupError;
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
      valueListenable: ThemeController.mode,
      builder: (context, mode, _) => MaterialApp(
          title: 'Edu Chat Pro',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.light(),
          darkTheme: AppTheme.dark(),
          themeMode: mode,
          home: !AppConfig.configured || startupError != null
              ? SetupPage(error: startupError)
              : const StartupPermissionGate(child: AuthGate())));
}

class SetupPage extends StatelessWidget {
  const SetupPage({super.key, this.error});
  final String? error;
  @override
  Widget build(BuildContext context) => Scaffold(
      body: Center(
          child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 560),
                  child: Card(
                      child: Padding(
                          padding: const EdgeInsets.all(32),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const AppLogo(size: 58),
                                const SizedBox(height: 24),
                                Text('Welcome to Edu Chat Pro',
                                    style: Theme.of(context)
                                        .textTheme
                                        .headlineMedium),
                                const SizedBox(height: 12),
                                const Text(
                                    'A shared space for learning, conversations and live classes.'),
                                const SizedBox(height: 28),
                                const Text('Connect your Supabase project',
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold)),
                                const SizedBox(height: 12),
                                const SelectableText(
                                    '1. Follow docs/SETUP.md to prepare your database.\n2. Copy config.example.json to config.json.\n3. Enter your Supabase URL and public anon key.\n4. Run flutter run --dart-define-from-file=config.json'),
                                if (error != null)
                                  Text('Initialization failed: $error')
                              ])))))));
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool recovery = false;
  StreamSubscription<AuthState>? subscription;
  @override
  void initState() {
    super.initState();
    subscription =
        Supabase.instance.client.auth.onAuthStateChange.listen((state) {
      if (!mounted) return;
      setState(() {
        if (state.event == AuthChangeEvent.passwordRecovery) recovery = true;
        if (state.event == AuthChangeEvent.signedOut) recovery = false;
      });
    }, onError: (Object error) {
      // A temporary token-refresh failure must not become an unhandled stream
      // error or discard an otherwise recoverable stored session.
    });
  }

  @override
  void dispose() {
    subscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (recovery) {
      return PasswordPage(onSaved: () => setState(() => recovery = false));
    }
    if (Supabase.instance.client.auth.currentSession == null) {
      return const AuthPage();
    }
    return HomeShell(
        key: ValueKey(Supabase.instance.client.auth.currentUser!.id),
        repo: EduRepository(Supabase.instance.client));
  }
}
