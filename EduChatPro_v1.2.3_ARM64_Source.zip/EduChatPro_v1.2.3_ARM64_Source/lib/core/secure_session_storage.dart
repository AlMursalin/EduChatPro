import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Native platforms use OS-backed secret storage. Web still requires HTTPS and
/// an XSS-resistant deployment: browser storage is not an HttpOnly cookie.
class SecureSessionStorage extends LocalStorage {
  final FlutterSecureStorage storage = const FlutterSecureStorage();
  static const key = 'educhat.auth.session';
  @override
  Future<void> initialize() async {}
  @override
  Future<bool> hasAccessToken() => storage.containsKey(key: key);
  @override
  Future<String?> accessToken() => storage.read(key: key);
  @override
  Future<void> persistSession(String persistSessionString) =>
      storage.write(key: key, value: persistSessionString);
  @override
  Future<void> removePersistedSession() => storage.delete(key: key);
}
