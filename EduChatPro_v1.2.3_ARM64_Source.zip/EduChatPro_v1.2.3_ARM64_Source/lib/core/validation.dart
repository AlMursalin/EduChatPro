abstract final class Validation {
  static bool driveUrl(String value) => RegExp(
          r'^https://drive\.google\.com/drive/(u/[0-9]+/)?folders/[A-Za-z0-9_-]+(\?[A-Za-z0-9_=&%.-]*)?$')
      .hasMatch(value);
  static String safeFileName(String name) {
    final value = name.replaceAll(RegExp(r'[^A-Za-z0-9._ -]'), '_');
    return value.length > 180 ? value.substring(value.length - 180) : value;
  }

  static String csvCell(Object? value) {
    var s = value?.toString() ?? '';
    // Prevent spreadsheet formula injection, including leading whitespace.
    if (RegExp(r'^\s*[=+@-]').hasMatch(s)) s = "'$s";
    return '"${s.replaceAll('"', '""')}"';
  }

  static const mimeTypes = {
    'mp4':'video/mp4',
    'mov':'video/quicktime',
    'webm':'video/webm',
    'm4v':'video/mp4',
    'pdf': 'application/pdf',
    'doc': 'application/msword',
    'docx':
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'ppt': 'application/vnd.ms-powerpoint',
    'pptx':
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'xls': 'application/vnd.ms-excel',
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'png': 'image/png',
    'webp': 'image/webp',
    'zip': 'application/zip',
    'txt': 'text/plain',
    'csv': 'text/csv',
  };
}
