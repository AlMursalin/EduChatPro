import '../../services/notification_router.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/edu_repository.dart';
import '../../shared/widgets.dart';
import '../meetings/meeting_room_page.dart';
import '../forum/forum_page.dart';

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key, required this.repo});
  final EduRepository repo;
  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  final list = GlobalKey<PagedListState>();
  RealtimeChannel? channel;
  @override
  void initState() {
    super.initState();
    channel = widget.repo.client
        .channel('notifications-${widget.repo.userId}')
        .onPostgresChanges(
            event: PostgresChangeEvent.insert,
            schema: 'public',
            table: 'notifications',
            filter: PostgresChangeFilter(
                type: PostgresChangeFilterType.eq,
                column: 'user_id',
                value: widget.repo.userId),
            callback: (_) => list.currentState?.refresh())
        .subscribe();
  }

  @override
  void dispose() {
    if (channel != null) widget.repo.client.removeChannel(channel!);
    super.dispose();
  }

  Future<void> markRead(JsonRow n) async {
    if (n['read_at'] != null) return;
    await widget.repo.update('notifications', n['id'],
        {'read_at': DateTime.now().toUtc().toIso8601String()});
  }

  Future<void> answerCall(JsonRow n) async {
    final meetingId = n['resource_id']?.toString();
    if (meetingId == null || meetingId.isEmpty) return;
    await markRead(n);
    if (!mounted) return;
    await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => MeetingRoomPage(
                  repo: widget.repo,
                  meetingId: meetingId,
                  autoJoin: true,
                  startWithMic: true,
                  callTitle: n['kind'] == 'direct_call_video'
                      ? 'Incoming video call'
                      : 'Incoming audio call',
                )));
    await list.currentState?.refresh();
  }

  Future<void> declineCall(JsonRow n) async {
    final meetingId = n['resource_id']?.toString();
    if (meetingId == null || meetingId.isEmpty) return;
    await perform(context, () async {
      if (n['kind'] != 'group_call')
        await widget.repo.client
            .rpc('decline_direct_call', params: {'meeting': meetingId});
      await markRead(n);
      await list.currentState?.refresh();
    }, success: 'Call declined.');
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        PageHeader('Notifications', 'Updates from your learning community',
            actions: [
              IconButton(
                  onPressed: () => list.currentState?.refresh(),
                  icon: const Icon(Icons.refresh))
            ]),
        Expanded(
            child: PagedList(
                key: list,
                load: (o) async => List<JsonRow>.from(await widget.repo.client
                    .from('notifications')
                    .select()
                    .neq('kind', 'call_cancel')
                    .order('created_at', ascending: false)
                    .range(o, o + 29)),
                builder: (n) {
                  final directCall = n['kind'] == 'direct_call_audio' ||
                      n['kind'] == 'direct_call_video' ||
                      n['kind'] == 'group_call';
                  return Card(
                      child: ListTile(
                          onTap: () => perform(context, () async {
                                await openNotificationDestination(
                                    context, widget.repo, n);
                                await list.currentState?.refresh();
                              }),
                          leading: Icon(directCall
                              ? (n['kind'] == 'direct_call_video'
                                  ? Icons.videocam_outlined
                                  : Icons.call_outlined)
                              : n['read_at'] == null
                                  ? Icons.mark_email_unread_outlined
                                  : Icons.drafts_outlined),
                          title: Text(n['title']),
                          subtitle: Text(n['created_at']),
                          trailing: directCall && n['read_at'] == null
                              ? Wrap(spacing: 6, children: [
                                  OutlinedButton(
                                      onPressed: () => declineCall(n),
                                      child: const Text('Decline')),
                                  FilledButton(
                                      onPressed: () => answerCall(n),
                                      child: const Text('Answer')),
                                ])
                              : n['read_at'] == null
                                  ? TextButton(
                                      onPressed: () =>
                                          perform(context, () async {
                                            await markRead(n);
                                            await list.currentState?.refresh();
                                          }),
                                      child: const Text('Mark read'))
                                  : null));
                }))
      ]);
}
