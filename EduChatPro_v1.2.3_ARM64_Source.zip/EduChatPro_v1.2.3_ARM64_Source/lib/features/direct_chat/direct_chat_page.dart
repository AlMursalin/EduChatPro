import 'dart:convert';
import '../../shared/group_invite_action.dart';
import '../../shared/media_attachment.dart';
import '../../shared/voice_widgets.dart';
import '../../shared/stored_image.dart';
import '../../services/live_refresh.dart';
import '../../services/image_utils.dart';
import '../../core/validation.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';
import '../../shared/social_widgets.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/edu_repository.dart';
import '../../shared/user_avatar.dart';
import '../../shared/widgets.dart';
import '../meetings/meeting_room_page.dart';

class DirectChatPage extends StatefulWidget {
  const DirectChatPage({
    super.key,
    required this.repo,
    required this.otherUserId,
    required this.otherName,
    this.otherAvatarPath,
  });

  final EduRepository repo;
  final String otherUserId;
  final String otherName;
  final String? otherAvatarPath;

  @override
  State<DirectChatPage> createState() => _DirectChatPageState();
}

class _DirectChatPageState extends State<DirectChatPage> {
  LiveRefresh? live;
  final composer = TextEditingController();
  final scroll = ScrollController();
  List<JsonRow> messages = [];
  RealtimeChannel? channel;
  bool loading = true;
  bool fetching = false, reloadPending = false;
  bool sending = false;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
    live = LiveRefresh(widget.repo.client, () => load(silent: true),
        tables: ['direct_messages']);
  }

  @override
  void dispose() {
    live?.dispose();
    composer.dispose();
    scroll.dispose();
    if (channel != null) widget.repo.client.removeChannel(channel!);
    super.dispose();
  }

  Future<void> load({bool silent = false}) async {
    if (fetching) {
      reloadPending = true;
      return;
    }
    fetching = true;
    try {
      final data = await widget.repo.client
          .from('direct_messages')
          .select()
          .or('and(sender_id.eq.${widget.repo.userId},recipient_id.eq.${widget.otherUserId}),and(sender_id.eq.${widget.otherUserId},recipient_id.eq.${widget.repo.userId})')
          .order('created_at', ascending: false)
          .limit(200);
      final rows =
          List<JsonRow>.from((data as List).map((e) => JsonRow.from(e as Map)));
      if (!mounted) return;
      final stick = !scroll.hasClients ||
          scroll.position.maxScrollExtent - scroll.offset < 100;
      final incoming = rows.reversed.toList();
      if (jsonEncode(messages) != jsonEncode(incoming) ||
          loading ||
          error != null)
        setState(() {
          messages = incoming;
          loading = false;
          error = null;
        });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scroll.hasClients && stick) {
          scroll.jumpTo(scroll.position.maxScrollExtent);
        }
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          loading = false;
          error = e.toString();
        });
      }
    } finally {
      fetching = false;
      if (reloadPending && mounted) {
        reloadPending = false;
        load(silent: true);
      }
    }
  }

  Future<void> send() async {
    final text = composer.text.trim();
    if (text.isEmpty || sending) return;
    setState(() => sending = true);
    await perform(context, () async {
      await widget.repo.client.rpc('send_direct_message', params: {
        'other': widget.otherUserId,
        'message': text,
      });
      composer.clear();
      await load(silent: true);
    });
    if (mounted) setState(() => sending = false);
  }

  Future<void> attach({bool voice = false}) async {
    if (sending) return;
    await perform(context, () async {
      if (voice) {
        final note = await recordVoice(context);
        if (note == null) return;
        if (mounted) setState(() => sending = true);
        try {
          await widget.repo.sendMedia(
              other: widget.otherUserId,
              bytes: note.bytes,
              name: 'voice.m4a',
              mime: 'audio/mp4',
              durationMs: note.durationMs);
        } finally {
          if (mounted) setState(() => sending = false);
        }
      } else {
        final pick = await FilePicker.platform.pickFiles(
            type: FileType.custom,
            allowedExtensions: Validation.mimeTypes.keys.toList(),
            withData: true);
        if (pick == null) return;
        final file = pick.files.single;
        var bytes = file.bytes;
        if (bytes == null || bytes.length > 10485760)
          throw const FormatException('Choose a file under 10 MB.');
        var mime = Validation.mimeTypes[file.extension?.toLowerCase()] ??
            'application/octet-stream';
        var name = file.name.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_');
        if (mime.startsWith('image/')) {
          bytes = await compute(feedImage, bytes);
          mime = 'image/jpeg';
          name = 'photo.jpg';
        }
        if (mounted) setState(() => sending = true);
        try {
          await widget.repo.sendMedia(
              other: widget.otherUserId, bytes: bytes, name: name, mime: mime);
        } finally {
          if (mounted) setState(() => sending = false);
        }
      }
      await load(silent: true);
    });
  }

  Widget attachment(JsonRow m) {
    final path = m['attachment_path'] as String?;
    if (path == null) return const SizedBox.shrink();
    final mime = m['mime_type']?.toString() ?? '';
    if (mime.startsWith('audio/'))
      return VoicePlayer(
          repo: widget.repo,
          bucket: 'direct-files',
          path: path,
          durationMs: m['duration_ms'] ?? 0);
    return MediaAttachment(
        repo: widget.repo,
        bucket: 'direct-files',
        path: path,
        mime: mime,
        name: m['file_name'] ?? 'Attachment');
  }

  Future<void> startCall({required bool video}) async {
    await perform(context, () async {
      final meeting =
          await widget.repo.client.rpc('start_direct_call', params: {
        'target': widget.otherUserId,
        'video': video,
      });
      if (!mounted) return;
      await Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => MeetingRoomPage(
                    repo: widget.repo,
                    meetingId: meeting.toString(),
                    autoJoin: true,
                    startWithMic: true,
                    callTitle: video
                        ? 'Video call · ${widget.otherName}'
                        : 'Audio call · ${widget.otherName}',
                  )));
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          titleSpacing: 0,
          title: Row(children: [
            UserAvatar(
              repo: widget.repo,
              userId: widget.otherUserId,
              path: widget.otherAvatarPath,
              name: widget.otherName,
              radius: 18,
            ),
            const SizedBox(width: 10),
            Expanded(
                child: Text(widget.otherName,
                    maxLines: 1, overflow: TextOverflow.ellipsis)),
          ]),
          actions: [
            IconButton(
                tooltip: 'Audio call',
                onPressed: () => startCall(video: false),
                icon: const Icon(Icons.call_outlined)),
            IconButton(
                tooltip: 'Video call',
                onPressed: () => startCall(video: true),
                icon: const Icon(Icons.videocam_outlined)),
          ],
        ),
        body: Column(children: [
          if (error != null)
            MaterialBanner(content: Text(error!), actions: [
              TextButton(onPressed: load, child: const Text('Retry'))
            ]),
          Expanded(
            child: messages.isEmpty && !loading
                ? const ChatEmpty(group: false)
                : ListView.builder(
                    controller: scroll,
                    padding: const EdgeInsets.all(16),
                    itemCount: messages.length,
                    itemBuilder: (context, i) {
                      final m = messages[i];
                      final mine = m['sender_id'] == widget.repo.userId;
                      return Align(
                        alignment:
                            mine ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          constraints: BoxConstraints(
                              maxWidth: MediaQuery.sizeOf(context).width * .82),
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.fromLTRB(13, 10, 13, 8),
                          decoration: BoxDecoration(
                            color: mine
                                ? Theme.of(context).colorScheme.primaryContainer
                                : Theme.of(context).colorScheme.surface,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: const [
                              BoxShadow(
                                  color: Color(0x16000000),
                                  blurRadius: 3,
                                  offset: Offset(0, 1))
                            ],
                          ),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(mine ? 'You' : widget.otherName,
                                    style: TextStyle(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary,
                                        fontWeight: FontWeight.w800,
                                        fontSize: 12)),
                                if (m['meeting_id'] != null)
                                  const Icon(Icons.call_outlined, size: 18),
                                Text(m['body']?.toString() ?? ''),
                                GroupInviteAction(
                                    text: m['body']?.toString() ?? ''),
                                attachment(m),
                                const SizedBox(height: 4),
                                Text(
                                  DateFormat('h:mm a').format(
                                      DateTime.parse(m['created_at'])
                                          .toLocal()),
                                  style: Theme.of(context).textTheme.bodySmall,
                                )
                              ]),
                        ),
                      );
                    }),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Row(children: [
                IconButton(
                    tooltip: 'Attach file',
                    onPressed: sending ? null : () => attach(),
                    icon: const Icon(Icons.add_circle_outline)),
                Expanded(
                  child: TextField(
                    controller: composer,
                    maxLength: 4000,
                    minLines: 1,
                    maxLines: 5,
                    textInputAction: TextInputAction.newline,
                    decoration: InputDecoration(
                        suffixIcon: IconButton(
                            tooltip: 'Emoji',
                            icon: const Icon(Icons.sentiment_satisfied_alt),
                            onPressed: () => pickChatEmoji(context, composer)),
                        hintText: 'Write a message…',
                        counterText: '',
                        border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(28)))),
                  ),
                ),
                IconButton(
                    tooltip: 'Voice message',
                    onPressed: sending ? null : () => attach(voice: true),
                    icon: const Icon(Icons.mic_none_rounded)),
                const SizedBox(width: 4),
                IconButton.filled(
                    onPressed: sending ? null : send,
                    icon: const Icon(Icons.send_rounded))
              ]),
            ),
          )
        ]),
      );
}
