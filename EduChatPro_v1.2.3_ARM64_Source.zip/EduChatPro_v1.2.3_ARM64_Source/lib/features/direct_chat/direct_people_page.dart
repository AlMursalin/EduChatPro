import 'package:flutter/material.dart';
import '../../services/edu_repository.dart';
import '../../shared/user_avatar.dart';
import '../../shared/widgets.dart';
import '../meetings/meeting_room_page.dart';
import 'direct_chat_page.dart';

class DirectPeoplePage extends StatefulWidget {
  const DirectPeoplePage({super.key, required this.repo});
  final EduRepository repo;

  @override
  State<DirectPeoplePage> createState() => _DirectPeoplePageState();
}

class _DirectPeoplePageState extends State<DirectPeoplePage> {
  final list = GlobalKey<PagedListState>();

  Future<void> call(JsonRow p, {required bool video}) async {
    await perform(context, () async {
      final meeting =
          await widget.repo.client.rpc('start_direct_call', params: {
        'target': p['id'],
        'video': video,
      });
      if (!mounted) return;
      await Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => MeetingRoomPage(
                    repo: widget.repo,
                    meetingId: meeting.toString(),
                    autoJoin: true,
                    startWithMic: true,
                    callTitle: video
                        ? 'Video call · ${p['full_name']}'
                        : 'Audio call · ${p['full_name']}',
                  )));
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('People')),
      body: Column(children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 16, 20, 8),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text('Start a private chat, audio call or video call.'),
          ),
        ),
        Expanded(
          child: PagedList(
            key: list,
            load: (o) async => List<JsonRow>.from(await widget.repo.client
                .from('profiles')
                .select('id,full_name,avatar_path,status,created_at')
                .eq('status', 'active')
                .neq('id', widget.repo.userId)
                .order('created_at', ascending: false)
                .range(o, o + EduRepository.pageSize - 1)),
            empty: 'No other active people are available yet.',
            builder: (p) {
              return Card(
                child: ListTile(
                  leading: UserAvatar(
                    repo: widget.repo,
                    userId: p['id'],
                    path: p['avatar_path'],
                    name: p['full_name'],
                  ),
                  title: Text(p['full_name']?.toString() ?? 'Member'),
                  subtitle: Text(p['status']?.toString() ?? ''),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => DirectChatPage(
                        repo: widget.repo,
                        otherUserId: p['id'],
                        otherName: p['full_name']?.toString() ?? 'Member',
                        otherAvatarPath: p['avatar_path']?.toString(),
                      ),
                    ),
                  ),
                  trailing: PopupMenuButton<String>(
                    tooltip: 'Actions',
                    onSelected: (action) async {
                      if (action == 'chat') {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => DirectChatPage(
                              repo: widget.repo,
                              otherUserId: p['id'],
                              otherName: p['full_name']?.toString() ?? 'Member',
                              otherAvatarPath: p['avatar_path']?.toString(),
                            ),
                          ),
                        );
                      } else if (action == 'audio') {
                        await call(p, video: false);
                      } else if (action == 'video') {
                        await call(p, video: true);
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(
                          value: 'chat', child: Text('Private message')),
                      PopupMenuItem(value: 'audio', child: Text('Audio call')),
                      PopupMenuItem(value: 'video', child: Text('Video call')),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ]));
}
