import 'dart:typed_data';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../../config/app_config.dart';
import '../../services/edu_repository.dart';
import '../../services/live_refresh.dart';
import '../../shared/widgets.dart';
import '../../shared/meeting_invite.dart';
import 'meeting_room_page.dart';

class MeetingsPage extends StatefulWidget {
  const MeetingsPage({super.key, required this.repo, this.group});
  final EduRepository repo;
  final String? group;
  @override
  State<MeetingsPage> createState() => _MeetingsPageState();
}

class _MeetingsPageState extends State<MeetingsPage> {
  final inviteText = TextEditingController();
  final inviteFocus = FocusNode();
  LiveRefresh? live;
  List<JsonRow> rows = [];
  Set<String> favorites = {};
  bool create = false,
      attendance = false,
      busy = false,
      more = true,
      newest = true;
  String filter = 'all';
  String? error;
  int generation = 0;
  @override
  void initState() {
    super.initState();
    initialize();
    live = LiveRefresh(widget.repo.client, () => load(),
        tables: ['meetings', 'meeting_favorites', 'meeting_history_hidden']);
  }

  @override
  void dispose() {
    live?.dispose();
    inviteText.dispose();
    inviteFocus.dispose();
    super.dispose();
  }

  Future<void> initialize() async {
    try {
      var allowed = await widget.repo.allowed('meetings.create');
      if (!allowed && widget.group != null) {
        final g = await widget.repo.client
            .from('groups')
            .select('created_by')
            .eq('id', widget.group!)
            .single();
        allowed = g['created_by'] == widget.repo.userId;
      }
      final a = await widget.repo.allowed('attendance.read');
      if (mounted)
        setState(() {
          create = allowed;
          attendance = a;
        });
      await load();
    } catch (e) {
      if (mounted) setState(() => error = meetingError(e));
    }
  }

  String meetingError(Object e) {
    if (e is PostgrestException &&
        ['PGRST202', '42P01', '42703', 'PGRST205'].contains(e.code)) {
      return 'Meeting setup needs an update. Run EduChatPro_v1.1.1_Supabase_Fix.sql in your Supabase SQL Editor, then tap Retry. Your existing data will stay.';
    }
    return e.toString();
  }

  Future<void> load({bool append = false}) async {
    final run = ++generation;
    if (mounted) setState(() => busy = true);
    try {
      final data = await widget.repo.client.rpc('mobile_meetings', params: {
        'group_filter': widget.group,
        'list_filter': filter,
        'page_offset': append ? rows.length : 0,
        'newest_first': newest
      });
      final fs = await widget.repo.client
          .from('meeting_favorites')
          .select('meeting_id')
          .eq('user_id', widget.repo.userId);
      if (mounted && run == generation)
        setState(() {
          final next = List<JsonRow>.from(data);
          rows = append ? [...rows, ...next] : next;
          more = next.length == 30;
          favorites = fs.map((e) => e['meeting_id'] as String).toSet();
          error = null;
        });
    } catch (e) {
      if (mounted && run == generation) setState(() => error = meetingError(e));
    } finally {
      if (mounted && run == generation) setState(() => busy = false);
    }
  }

  Future<void> enter(JsonRow m, {bool autoJoin = true}) async {
    final start = DateTime.tryParse(m['starts_at']?.toString() ?? '');
    if (start != null && start.isAfter(DateTime.now())) {
      notice(context,
          'This meeting starts ${DateFormat.yMMMd().add_jm().format(start.toLocal())}');
      return;
    }
    await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => MeetingRoomPage(
                repo: widget.repo, meetingId: m['id'], autoJoin: autoJoin)));
    await load();
  }

  Future<void> join() async => perform(context, () async {
        final id = await widget.repo.joinInvite(inviteText.text);
        final m = await widget.repo.client
            .from('meetings')
            .select()
            .eq('id', id)
            .single();
        if (mounted) await enter(m);
      });
  Future<void> newMeeting(String kind) async {
    final values = await formDialog(
        context,
        kind == 'room'
            ? 'Create room'
            : kind == 'scheduled'
                ? 'Schedule meeting'
                : 'Instant meeting',
        ['Meeting title']);
    if (values == null || !mounted) return;
    DateTime? start;
    int repeat = 0;
    if (kind == 'scheduled') {
      final date = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime.now(),
          lastDate: DateTime.now().add(const Duration(days: 730)));
      if (date == null || !mounted) return;
      final time =
          await showTimePicker(context: context, initialTime: TimeOfDay.now());
      if (time == null || !mounted) return;
      start = DateTime(date.year, date.month, date.day, time.hour, time.minute);
      if (!start.isAfter(DateTime.now())) {
        notice(context, 'Choose a future date and time.');
        return;
      }
      repeat = await showDialog<int>(
              context: context,
              builder: (c) =>
                  SimpleDialog(title: const Text('Repeat meeting'), children: [
                    for (final entry in {
                      0: 'Does not repeat',
                      1: 'Every day',
                      7: 'Every week'
                    }.entries)
                      SimpleDialogOption(
                          onPressed: () => Navigator.pop(c, entry.key),
                          child: Text(entry.value))
                  ])) ??
          0;
    }
    if (!mounted) return;
    await perform(context, () async {
      final id = await widget.repo.client.rpc('create_mobile_meeting', params: {
        'title_input': values[0],
        'group_input': widget.group,
        'kind_input': kind,
        'starts_input': start?.toUtc().toIso8601String(),
        'repeat_input': repeat
      });
      await load();
      final meeting = await widget.repo.client
          .from('meetings')
          .select()
          .eq('id', id)
          .single();
      if (mounted) await showMeetingInvite(context, meeting);
      if (kind != 'scheduled' && mounted) await enter(meeting);
    }, success: kind == 'scheduled' ? 'Meeting scheduled.' : null);
  }

  Widget action(String title, String sub, IconData icon, Color color,
          VoidCallback? tap, {bool primary = false}) =>
      Expanded(
          child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: Material(
                  color: primary
                      ? color
                      : color.withOpacity(
                          Theme.of(context).brightness == Brightness.dark
                              ? 0.2
                              : 0.09),
                  borderRadius: BorderRadius.circular(18),
                  child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: tap,
                      child: Opacity(
                          opacity: tap == null ? 0.45 : 1,
                          child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 9, vertical: 16),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Icon(icon,
                                        color: primary ? Colors.white : color,
                                        size: 30),
                                    const SizedBox(height: 12),
                                    Text(title,
                                        style: TextStyle(
                                            fontWeight: FontWeight.w800,
                                            fontSize: 12,
                                            color:
                                                primary ? Colors.white : null)),
                                    const SizedBox(height: 8),
                                    Text(sub,
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: primary
                                                ? Colors.white70
                                                : color))
                                  ])))))));
  Widget meetingCard(JsonRow m) => Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Padding(
          padding: const EdgeInsets.all(14),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.videocam_rounded, color: Colors.blue, size: 30),
              const SizedBox(width: 10),
              Expanded(
                  child: Text(m['title'],
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 17))),
              IconButton(
                  tooltip: 'Favorite',
                  onPressed: () => perform(context, () async {
                        if (favorites.contains(m['id'])) {
                          await widget.repo.client
                              .from('meeting_favorites')
                              .delete()
                              .eq('user_id', widget.repo.userId)
                              .eq('meeting_id', m['id']);
                        } else {
                          await widget.repo.client
                              .from('meeting_favorites')
                              .upsert({
                            'user_id': widget.repo.userId,
                            'meeting_id': m['id']
                          });
                        }
                        await load();
                      }),
                  icon: Icon(
                      favorites.contains(m['id'])
                          ? Icons.star
                          : Icons.star_border,
                      color: Colors.amber))
            ]),
            Text(
                '${m['meeting_kind'] ?? 'instant'} · ${m['ended_at'] == null ? 'Open' : 'Ended'}',
                style: Theme.of(context).textTheme.bodySmall),
            Text(DateFormat.yMMMd().add_jm().format(
                DateTime.parse(m['starts_at'] ?? m['created_at']).toLocal())),
            const SizedBox(height: 6),
            SelectableText('Meeting ID: ${m['invite_code']}',
                style: const TextStyle(fontSize: 11)),
            Wrap(
                spacing: 8,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  if (m['ended_at'] == null)
                    FilledButton(
                        onPressed: () => enter(m), child: const Text('Join')),
                  if (m['ended_at'] == null)
                    TextButton.icon(
                        onPressed: () => showMeetingInvite(context, m),
                        icon: const Icon(Icons.link, size: 18),
                        label: const Text('Invite / Share')),
                  if (attendance || m['host_id'] == widget.repo.userId)
                    TextButton(
                        onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => AttendancePage(
                                    repo: widget.repo, meeting: m))),
                        child: const Text('Attendance')),
                  PopupMenuButton<String>(
                      onSelected: (choice) => perform(context, () async {
                            if (choice == 'end') {
                              if (!await confirm(context, 'End meeting?',
                                  'This ends the current meeting for everyone.'))
                                return;
                              await widget.repo.client.rpc('end_p2p_meeting',
                                  params: {'meeting': m['id']});
                            } else {
                              await widget.repo.client
                                  .from('meeting_history_hidden')
                                  .upsert({
                                'user_id': widget.repo.userId,
                                'meeting_id': m['id']
                              });
                            }
                            await load();
                          }),
                      itemBuilder: (_) => [
                            const PopupMenuItem(
                                value: 'delete', child: Text('Delete history')),
                            if (m['host_id'] == widget.repo.userId &&
                                m['ended_at'] == null)
                              const PopupMenuItem(
                                  value: 'end', child: Text('End meeting'))
                          ])
                ])
          ])));
  @override
  Widget build(BuildContext context) => RefreshIndicator(
      onRefresh: load,
      child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            Container(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
                decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                  Theme.of(context).colorScheme.surface,
                  Theme.of(context)
                      .colorScheme
                      .primaryContainer
                      .withOpacity(.55)
                ])),
                child: Row(children: [
                  Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                        Text('Meetings',
                            style: TextStyle(
                                fontSize: 34,
                                fontWeight: FontWeight.w900,
                                color: Theme.of(context).colorScheme.primary)),
                        const SizedBox(height: 8),
                        const Text('A place to connect and learn, live.')
                      ])),
                  Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primaryContainer,
                          borderRadius: BorderRadius.circular(24)),
                      child: Icon(Icons.video_camera_front_rounded,
                          size: 52,
                          color: Theme.of(context).colorScheme.primary))
                ])),
            Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      action(
                          'Instant\nMeeting',
                          'Start now',
                          Icons.videocam,
                          Colors.blue,
                          create ? () => newMeeting('instant') : null,
                          primary: true),
                      action(
                          'Schedule\nMeeting',
                          'Plan ahead',
                          Icons.groups,
                          Colors.deepPurple,
                          create ? () => newMeeting('scheduled') : null),
                      action(
                          'Join with\ninvite',
                          'Use code/link',
                          Icons.event_available,
                          Colors.green,
                          () => inviteFocus.requestFocus()),
                      action(
                          'Create\nRoom',
                          'Custom room',
                          Icons.add_circle,
                          Colors.orange,
                          create ? () => newMeeting('room') : null)
                    ])),
            if (!create)
              const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                      'You can join an invite. Meeting creation is controlled by your group/admin permissions.',
                      style: TextStyle(fontSize: 11))),
            Card(
                margin: const EdgeInsets.all(16),
                child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Row(children: [
                      Expanded(
                          child: TextField(
                              controller: inviteText,
                              focusNode: inviteFocus,
                              decoration: const InputDecoration(
                                  prefixIcon: Icon(Icons.link),
                                  hintText: 'Meeting link or invite code…'),
                              onSubmitted: (_) => join())),
                      const SizedBox(width: 8),
                      FilledButton(onPressed: join, child: const Text('Join'))
                    ]))),
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(children: [
                  const Expanded(
                      child: Text('Recent Meetings',
                          style: TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 20))),
                  PopupMenuButton<String>(
                      initialValue: newest ? 'new' : 'old',
                      onSelected: (v) {
                        newest = v == 'new';
                        load();
                      },
                      itemBuilder: (_) => [
                            const PopupMenuItem(
                                value: 'new', child: Text('Newest first')),
                            const PopupMenuItem(
                                value: 'old', child: Text('Oldest first'))
                          ],
                      child: Text(newest ? 'Newest first ⌄' : 'Oldest first ⌄'))
                ])),
            SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Row(children: [
                  for (final e in {
                    'all': 'All',
                    'recurring': 'Recurring',
                    'scheduled': 'Scheduled',
                    'favorites': 'Favorites'
                  }.entries)
                    Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                            label: Text(e.value),
                            selected: filter == e.key,
                            onSelected: (_) {
                              setState(() => filter = e.key);
                              load();
                            }))
                ])),
            
            if (error != null)
              Padding(
                  padding: const EdgeInsets.all(20),
                  child: TextButton(
                      onPressed: load,
                      child: Text('Could not load meetings. Retry\n$error'))),
            if (rows.isEmpty && !busy && error == null)
              Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 36, horizontal: 24),
                  child: Column(children: [
                    Icon(Icons.video_collection_rounded,
                        size: 88,
                        color: Theme.of(context).colorScheme.primaryContainer),
                    const SizedBox(height: 20),
                    const Text('No meetings yet',
                        style: TextStyle(
                            fontSize: 23, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    const Text(
                        'Start an instant meeting, join with a link,\nor schedule a meeting to see it here.',
                        textAlign: TextAlign.center),
                    if (create)
                      Padding(
                          padding: const EdgeInsets.only(top: 24),
                          child: FilledButton.icon(
                              onPressed: () => newMeeting('instant'),
                              icon: const Icon(Icons.videocam),
                              label: const Text('Start Instant Meeting')))
                  ])),
            ...rows.map(meetingCard),
            if (more && !busy && rows.isNotEmpty)
              TextButton(
                  onPressed: () => load(append: true),
                  child: const Text('Load more')),
            if (rows.isNotEmpty)
              TextButton(
                  onPressed: () => perform(context, () async {
                        if (!await confirm(context, 'Clear all history?',
                            'Only your meeting list is cleared.')) return;
                        await widget.repo.client.rpc('clear_meeting_history',
                            params: {'group_filter': widget.group});
                        await load();
                      }),
                  child: const Text('Clear all history'))
          ]));
}

class AttendancePage extends StatelessWidget {
  const AttendancePage({super.key, required this.repo, required this.meeting});
  final EduRepository repo;
  final JsonRow meeting;
  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: Text('Attendance · ${meeting['title']}'), actions: [
        IconButton(
            tooltip: 'Export CSV',
            icon: const Icon(Icons.download_outlined),
            onPressed: () => perform(context, () async {
                  final csv = await repo.attendanceCsv(meeting['id']);
                  await Share.shareXFiles([
                    XFile.fromData(Uint8List.fromList(utf8.encode(csv)),
                        mimeType: 'text/csv', name: 'attendance.csv')
                  ], sharePositionOrigin: const Rect.fromLTWH(0, 0, 100, 100));
                }))
      ]),
      body: PagedList(
          load: (o) => repo.page('meeting_attendance',
              filter: 'meeting_id',
              value: meeting['id'],
              offset: o,
              order: 'joined_at',
              select: '*,profiles(full_name)'),
          builder: (r) => Card(
              child: ListTile(
                  title: Text(r['profiles']['full_name']),
                  subtitle: Text(
                      'Joined: ${r['joined_at']}\nLeft: ${r['left_at'] ?? 'Open / check last heartbeat'}\nLast heartbeat: ${r['last_seen_at']}\nDevice session: ${r['connection_id']?.toString().substring(0, 8) ?? '—'}'),
                  trailing: Text('${r['duration_seconds'] ?? '—'} sec')))));
}
