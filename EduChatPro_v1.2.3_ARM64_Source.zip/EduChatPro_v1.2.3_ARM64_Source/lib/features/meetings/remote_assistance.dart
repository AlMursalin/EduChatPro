import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

enum AssistanceState { idle, requested, active }

/// Native module contract. The shipped runner does NOT register this channel.
/// A trusted receiver UI must call allow() for each short-lived session.
class WindowsAssistance extends ChangeNotifier {
  static const channel = MethodChannel('educhat/windows_assistance');
  AssistanceState state = AssistanceState.idle;
  String? requestId;
  Future<bool> get supported async {
    if (kIsWeb || defaultTargetPlatform != TargetPlatform.windows) return false;
    try {
      return await channel.invokeMethod<bool>('isSupported') ?? false;
    } on MissingPluginException {
      return false;
    }
  }

  Future<void> request(String id) async {
    if (!await supported) {
      throw UnsupportedError(
          'The Windows native control module is not installed. No remote control is available.');
    }
    requestId = id;
    state = AssistanceState.requested;
    notifyListeners();
  }

  Future<void> allow({required bool explicitConsent}) async {
    if (!explicitConsent || state != AssistanceState.requested) {
      throw StateError(
          'A pending request and explicit local permission are required.');
    }
    await channel.invokeMethod<void>('allow', {'requestId': requestId});
    state = AssistanceState.active;
    notifyListeners();
  }

  Future<void> deny() async {
    requestId = null;
    state = AssistanceState.idle;
    notifyListeners();
  }

  Future<void> stop() async {
    try {
      if (state == AssistanceState.active) {
        await channel.invokeMethod<void>('stop');
      }
    } finally {
      requestId = null;
      state = AssistanceState.idle;
      notifyListeners();
    }
  }
}
