import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../services/local_recording.dart';
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart' as rtc;
import 'package:flutter_background/flutter_background.dart';
import 'package:uuid/uuid.dart';
import '../../config/app_config.dart';
import '../../services/edu_repository.dart';
import '../../services/supabase_webrtc_backend.dart';
import '../../shared/widgets.dart';
import '../../shared/meeting_invite.dart';

class MeetingRoomPage extends StatefulWidget {
  static String? activeMeetingId;
  const MeetingRoomPage({
    super.key,
    required this.repo,
    required this.meetingId,
    this.autoJoin = false,
    this.startWithMic = true,
    this.startWithCamera = false,
    this.callTitle,
  });
  final EduRepository repo;
  final String meetingId;
  final bool autoJoin;
  final bool startWithMic;
  final bool startWithCamera;
  final String? callTitle;

  @override
  State<MeetingRoomPage> createState() => _MeetingRoomPageState();
}

class _MeetingRoomPageState extends State<MeetingRoomPage> {
  final String connectionId = const Uuid().v4();
  late final SupabaseWebRtcBackend backend;
  Timer? heartbeat;
  bool expandedVideo=false;
  bool busy = false;
  bool joined = false;
  bool lowBandwidth = false;
  String? focusedPeer;
  final screenPeers=<String>{};
  final pointerAllowed=<String>{};
  final pointerGrants=<String>{};
  String? pointerTarget;
  Timer? pointerTimer;
  bool speaker = true;
  bool leaving = false;
  bool pointerMode = false;
  Offset? pointer;
  String? error;
  final List<String> chat = [];
  final webRecorder = createLocalMeetingRecorder();
  rtc.MediaRecorder? nativeRecorder;
  bool recording = false;
  String? recordingPath;
  String? meetingTitle;

  @override
  void initState() {
    super.initState();
    MeetingRoomPage.activeMeetingId = widget.meetingId;
    backend = SupabaseWebRtcBackend(
      widget.repo,
      meetingId: widget.meetingId,
      connectionId: connectionId,
    );
    backend.addListener(_changed);
    backend.onData = _handleData;
    _prepare();
  }

  Future<void> _prepare() async {
    try {
      final meeting = await widget.repo.client
          .from('meetings')
          .select('title')
          .eq('id', widget.meetingId)
          .single();
      meetingTitle = meeting['title'];
      await backend.initialize();
      if (widget.autoJoin && mounted) await join();
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  void _handleData(Map<String, dynamic> data) async {
    final type = data['type']?.toString();
    if (type == 'chat') {
      final text = data['text']?.toString() ?? '';
      if (text.isNotEmpty && text.length <= 1000) {
        chat.add('${data['name'] ?? 'Participant'}: $text');
        if (chat.length > 100) chat.removeAt(0);
      }
    } else if(type=='share-state'){
      final id=(data['owner']??data['from'])?.toString();
      if(id!=null){if(data['active']==true){screenPeers.add(id);focusedPeer=id;}else{screenPeers.remove(id);pointerGrants.remove(id);if(focusedPeer==id)focusedPeer=null;}}
    } else if(type=='pointer-request'&&data['target']==connectionId&&backend.screenEnabled){
      final id=data['from']?.toString();if(id==null||!mounted)return;
      final allow=await confirm(context,'Allow pointer','${data['name']??'A participant'} wants to point on your shared screen.');
      if(allow)pointerAllowed.add(id);else pointerAllowed.remove(id);
      await backend.sendData({'type':'pointer-permission','target':id,'owner':connectionId,'granted':allow});
    } else if(type=='pointer-permission'&&data['target']==connectionId){
      final id=data['owner']?.toString();if(id==null)return;
      if(data['granted']==true){pointerGrants.add(id);pointerTarget=id;pointerMode=true;}else{pointerGrants.remove(id);pointerMode=false;}
    } else if (type == 'pointer') {
      final target=data['target']?.toString(),sender=data['from']?.toString();
      if(target==null||target!=(focusedPeer??screenPeers.firstOrNull))return;
      if(target==connectionId&&sender!=connectionId&&!pointerAllowed.contains(sender))return;
      pointerTimer?.cancel();pointerTimer=Timer(const Duration(seconds:2),(){if(mounted)setState(()=>pointer=null);});
      final x = data['x'];
      final y = data['y'];
      if (x is num && y is num) {
        pointer = Offset(x.toDouble().clamp(0, 1), y.toDouble().clamp(0, 1));
      }
    }
    if (mounted) setState(() {});
  }

  Future<void> join() async {
    if (busy || joined) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      // Acquire audio BEFORE announcing presence/offering SDP.
      await backend.microphone(widget.startWithMic);
      await backend.setSpeaker(speaker);
      if(widget.startWithCamera)await backend.camera(true,lowBandwidth:lowBandwidth);
      await backend.connect();
      try {
        await widget.repo.attendance(widget.meetingId, connectionId);
      } catch (_) {}
      joined = true;

      heartbeat = Timer.periodic(const Duration(seconds: 25), (_) async {
        if (!joined) return;
        try {
          final row = await widget.repo.client
              .from('meetings')
              .select('ended_at')
              .eq('id', widget.meetingId)
              .single();
          if (row['ended_at'] != null) {
            await leave();
            return;
          }
          await widget.repo.attendance(widget.meetingId, connectionId);
        } catch (_) {}
      });
    } catch (e) {
      error = e.toString();
      await backend.disconnect();
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> leave() async {
    if (leaving) return;
    leaving = true;
    heartbeat?.cancel();
    if (recording) {
      try {
        await toggleRecording();
      } catch (_) {}
    }
    try {
      await widget.repo
          .attendance(widget.meetingId, connectionId, leaving: true);
    } catch (_) {}
    if (!kIsWeb &&
        defaultTargetPlatform == TargetPlatform.android &&
        FlutterBackground.isBackgroundExecutionEnabled) {
      try {
        await FlutterBackground.disableBackgroundExecution();
      } catch (_) {}
    }
    try {
      await widget.repo.client.rpc('finish_direct_call',
          params: {'meeting_input': widget.meetingId});
    } catch (_) {}
    await backend.disconnect();
    joined = false;
    if (mounted) Navigator.pop(context);
  }

  Future<void> _run(Future<void> Function() fn) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      await fn();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.toString())));
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> toggleScreen() async {
    final enable = !backend.screenEnabled;
    if (enable && !kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
      final initialized = await FlutterBackground.initialize(
        androidConfig: const FlutterBackgroundAndroidConfig(
          notificationTitle: 'Edu Chat Pro',
          notificationText: 'Screen sharing is active',
          notificationImportance: AndroidNotificationImportance.normal,
        ),
      );
      if (!initialized)
        throw StateError('Android screen-share service could not start.');
      final allowed = await rtc.Helper.requestCapturePermission();
      if (!allowed) return;
      final background = await FlutterBackground.enableBackgroundExecution();
      if (!background)
        throw StateError('Screen-share foreground service could not start.');
    }
    try {
      await backend.shareScreen(enable);
    } catch (_) {
      if (enable &&
          !kIsWeb &&
          defaultTargetPlatform == TargetPlatform.android &&
          FlutterBackground.isBackgroundExecutionEnabled) {
        await FlutterBackground.disableBackgroundExecution();
      }
      rethrow;
    }
    if (!enable &&
        !kIsWeb &&
        defaultTargetPlatform == TargetPlatform.android &&
        FlutterBackground.isBackgroundExecutionEnabled) {
      await FlutterBackground.disableBackgroundExecution();
    }
  }

  Future<void> togglePointer() async {
    if(pointerMode){setState(()=>pointerMode=false);return;}
    final target=backend.screenEnabled?connectionId:(screenPeers.isEmpty?null:screenPeers.first);
    if(target==null){notice(context,'Select a shared screen first.');return;}
    if(target!=connectionId&&!pointerGrants.contains(target)){await backend.sendData({'type':'pointer-request','target':target});if(mounted)notice(context,'Pointer permission requested.');return;}
    setState((){pointerTarget=target;focusedPeer=target;pointerMode=true;});
  }

  Future<void> meetingChat() async {
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Meeting chat'),
        content: SizedBox(
          width: 520,
          child: SingleChildScrollView(
            child: SelectableText(
                chat.isEmpty ? 'No messages yet.' : chat.join('\n\n')),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('Close')),
          FilledButton(
            onPressed: () async {
              Navigator.pop(c);
              final v = await formDialog(
                  context, 'Send meeting message', ['Message']);
              if (v == null || v[0].trim().isEmpty) return;
              final text = v[0].trim();
              if (text.length > 1000) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content:
                            Text('Message must be 1,000 characters or less.')),
                  );
                }
                return;
              }
              await backend.sendData({'type': 'chat', 'text': text});
              chat.add('You: $text');
              if (mounted) setState(() {});
            },
            child: const Text('Write message'),
          )
        ],
      ),
    );
  }

  Future<void> copyInvite() async {
    await perform(context, () async {
      final meeting = await widget.repo.client
          .from('meetings')
          .select()
          .eq('id', widget.meetingId)
          .single();
      if (mounted) await showMeetingInvite(context, meeting);
    });
  }

  Future<void> toggleRecording() async {
    if (recording) {
      if (kIsWeb) {
        await webRecorder.stop();
        await webRecorder.save();
      } else {
        await nativeRecorder?.stop();
      }
      if (mounted) setState(() => recording = false);
      await backend.sendData({
        'type': 'chat',
        'name': backend.displayName,
        'text': 'Recording stopped.'
      });
      if (!kIsWeb && recordingPath != null)
        await Share.shareXFiles([XFile(recordingPath!)],
            sharePositionOrigin: const Rect.fromLTWH(0, 0, 100, 100));
      return;
    }
    if (!await confirm(context, 'Record this call?',
        'Confirm that participants agree. On mobile this saves your camera video locally; use screen recording for a full meeting view.'))
      return;
    if (kIsWeb) {
      await webRecorder.start(
          meetingId: widget.meetingId, participantsConsented: true);
    } else {
      if (!backend.cameraEnabled || backend.cameraTrack == null)
        throw StateError('Turn on your camera before recording.');
      final dir = await getApplicationDocumentsDirectory();
      recordingPath =
          '${dir.path}/EduChat-${DateTime.now().millisecondsSinceEpoch}.mp4';
      nativeRecorder = rtc.MediaRecorder();
      await nativeRecorder!
          .start(recordingPath!, videoTrack: backend.cameraTrack);
    }
    if (mounted) setState(() => recording = true);
    await backend.sendData({
      'type': 'chat',
      'name': backend.displayName,
      'text': 'Started recording with participant consent.'
    });
  }

  void showPeople() => showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF202326),
      builder: (c) => SafeArea(
              child: ListView(shrinkWrap: true, children: [
            ListTile(
                title: Text('${backend.displayName} (You)',
                    style: const TextStyle(color: Colors.white))),
            for (final p in backend.peers.values)
              ListTile(
                  leading:
                      const Icon(Icons.person_outline, color: Colors.white70),
                  title:
                      Text(p.name, style: const TextStyle(color: Colors.white)))
          ])));
  void showDevices() => showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF202326),
      builder: (c) => StatefulBuilder(
          builder: (c, refresh) => SafeArea(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                ListTile(
                    textColor: Colors.white,
                    iconColor: Colors.white,
                    leading: const Icon(Icons.cameraswitch),
                    title: const Text('Switch camera'),
                    onTap: backend.cameraEnabled
                        ? () => _run(backend.switchCamera)
                        : null),
                SwitchListTile(
                    title: const Text('Speaker',
                        style: TextStyle(color: Colors.white)),
                    value: speaker,
                    onChanged: (v) async {
                      await _run(() async {
                        speaker = v;
                        await backend.setSpeaker(v);
                      });
                      refresh(() {});
                    }),
                SwitchListTile(
                    title: const Text('Low bandwidth',
                        style: TextStyle(color: Colors.white)),
                    value: lowBandwidth,
                    onChanged: (v) {
                      setState(() => lowBandwidth = v);
                      refresh(() {});
                    })
              ]))));
  Widget callControl(IconData icon, String label, VoidCallback? action,
          {bool active = false}) =>
      Material(
          color: active ? const Color(0xFF155D55) : const Color(0xFF232628),
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: action,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon,
                        color: action == null ? Colors.white38 : Colors.white,
                        size: 25),
                    const SizedBox(height: 7),
                    Text(label,
                        style: TextStyle(
                            color:
                                action == null ? Colors.white38 : Colors.white,
                            fontSize: 11))
                  ])));

  Widget _videoTile(
      {required String name,
      required rtc.RTCVideoRenderer renderer,
      required bool local, bool sharing=false}) {
    final hasVideo =
        renderer.srcObject?.getVideoTracks().any((t) => t.enabled) ?? false;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (hasVideo)
            rtc.RTCVideoView(renderer,
                mirror: local && !backend.screenEnabled,
                objectFit: sharing?rtc.RTCVideoViewObjectFit.RTCVideoViewObjectFitContain:rtc.RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)
          else
            Container(
              color: Theme.of(context).colorScheme.surfaceContainerHighest,
              alignment: Alignment.center,
              child: CircleAvatar(
                radius: 34,
                child: Text(name.isEmpty ? '?' : name[0].toUpperCase(),
                    style: const TextStyle(fontSize: 28)),
              ),
            ),
          Positioned(
            left: 8,
            bottom: 8,
            child: DecoratedBox(
              decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(8)),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: Text(local ? '$name · You' : name,
                    style: const TextStyle(color: Colors.white)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    if (MeetingRoomPage.activeMeetingId == widget.meetingId)
      MeetingRoomPage.activeMeetingId = null;
    heartbeat?.cancel();
    pointerTimer?.cancel();
    if (recording && !kIsWeb) {
      unawaited(
          nativeRecorder?.stop().then<void>((_) {}).catchError((Object _) {}) ??
              Future<void>.value());
    }
    unawaited(webRecorder.dispose());
    backend.removeListener(_changed);
    backend.dispose();
    if (!kIsWeb &&
        defaultTargetPlatform == TargetPlatform.android &&
        FlutterBackground.isBackgroundExecutionEnabled) {
      unawaited(FlutterBackground.disableBackgroundExecution());
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final peerList = backend.peers.values.toList();
    final count = joined ? peerList.length + 1 : 0;
    return PopScope(
      canPop: !joined,
      onPopInvoked: (didPop) {
        if (!didPop) leave();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF101214),
        appBar: AppBar(
          backgroundColor: const Color(0xFF101214),
          foregroundColor: Colors.white,
          title: Column(children: [
            Text(meetingTitle ?? widget.callTitle ?? 'Meeting',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style:
                    const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            Text('Meeting · ${widget.meetingId.substring(0, 8)}',
                style: const TextStyle(color: Colors.white54, fontSize: 12))
          ]),
          centerTitle: true,
          actions: [
            IconButton(tooltip:'Expand / restore video',onPressed:()=>setState(()=>expandedVideo=!expandedVideo),icon:Icon(expandedVideo?Icons.fullscreen_exit:Icons.fullscreen)),
            IconButton(
                tooltip: 'Invite / Share meeting link',
                onPressed: copyInvite,
                icon: const Icon(Icons.link)),
            IconButton(
                tooltip: 'Close',
                onPressed: leave,
                icon: const Icon(Icons.close)),
            if (joined && MediaQuery.sizeOf(context).width > 700)
              IconButton(
                tooltip: 'Participants',
                onPressed: () => showDialog<void>(
                  context: context,
                  builder: (c) => AlertDialog(
                    title: Text('$count participants'),
                    content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        ListTile(
                            leading: const Icon(Icons.person),
                            title: Text('${backend.displayName} · You')),
                        for (final p in peerList)
                          ListTile(
                            leading: const Icon(Icons.person_outline),
                            title: Text(p.name),
                            subtitle: Text(
                                '${p.platform} · ${p.id.substring(0, p.id.length < 8 ? p.id.length : 8)}'),
                          )
                      ]),
                    ),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.pop(c),
                          child: const Text('Close'))
                    ],
                  ),
                ),
                icon: const Icon(Icons.people_outline),
              ),
          ],
        ),
        body: !joined
            ? Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 520),
                  child: Card(
                    margin: const EdgeInsets.all(20),
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.video_call_outlined, size: 54),
                        const SizedBox(height: 12),
                        const Text(
                            'Camera stays OFF when you join. It only turns on after you press Camera and allow permission.',
                            textAlign: TextAlign.center),
                        if (error != null) ...[
                          const SizedBox(height: 12),
                          SelectableText(error!,
                              style: TextStyle(
                                  color: Theme.of(context).colorScheme.error)),
                        ],
                        const SizedBox(height: 18),
                        FilledButton.icon(
                          onPressed: busy ? null : join,
                          icon: const Icon(Icons.login),
                          label: Text(busy ? 'Connecting…' : 'Join call'),
                        ),
                      ]),
                    ),
                  ),
                ),
              )
            : Column(
                children: [
                  Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                              color: const Color(0xFFB9F6DF),
                              borderRadius: BorderRadius.circular(20)),
                          child: Text(
                              recording
                                  ? '● Recording'
                                  : '● Connected · $count participants',
                              style: const TextStyle(
                                  color: Color(0xFF006D55),
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold)))),
                  if (backend.lastError != null)
                    MaterialBanner(
                      content: Text(backend.lastError!),
                      actions: const [SizedBox.shrink()],
                    ),
                  Expanded(
                    child: LayoutBuilder(
                      builder: (context, box) {
                        final ids=[...peerList.map((p)=>p.id),connectionId];
                        final shares=screenPeers.where(ids.contains).toList();
                        final chosen=ids.contains(focusedPeer)?focusedPeer!:(shares.isNotEmpty?shares.first:(peerList.isNotEmpty?peerList.first.id:connectionId));
                        Widget tile(String id){final self=id==connectionId;final p=self?null:backend.peers[id];return GestureDetector(onTap:()=>setState(()=>focusedPeer=id),child:_videoTile(name:self?backend.displayName:p!.name,renderer:self?backend.localRenderer:p!.renderer,local:self,sharing:self?backend.screenEnabled:screenPeers.contains(id)));}
                        return Stack(children: [
                          Positioned.fill(child:Padding(padding:const EdgeInsets.all(8),child:tile(chosen))),
                          if(ids.length>1)Positioned(right:12,top:12,child:SizedBox(width:box.maxWidth<600?112:180,height:box.maxHeight*.46,child:ListView(children:[for(final id in ids.where((id)=>id!=chosen))SizedBox(height:box.maxWidth<600?145:140,child:tile(id))]))),
                          if (pointerMode)
                            Positioned.fill(
                              child: GestureDetector(
                                behavior: HitTestBehavior.translucent,
                                onTapDown: (d) async {
                                  final pos = Offset(
                                      d.localPosition.dx / box.maxWidth,
                                      d.localPosition.dy / box.maxHeight);
                                  setState(() => pointer = pos);
                                  await backend.sendData({
                                    'type': 'pointer',
                                    'target':pointerTarget,
                                    'x': pos.dx,
                                    'y': pos.dy
                                  });
                                },
                              ),
                            ),
                          if (pointer != null)
                            Positioned(
                              left: pointer!.dx * box.maxWidth,
                              top: pointer!.dy * box.maxHeight,
                              child: const IgnorePointer(
                                  child: Icon(Icons.near_me,
                                      color: Colors.amber, size: 34)),
                            ),
                        ]);
                      },
                    ),
                  ),
                  if(!expandedVideo)SafeArea(
                      top: false,
                      child: Padding(
                          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                          child: Column(children: [
                            GridView.count(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                crossAxisCount:
                                    MediaQuery.sizeOf(context).width < 700
                                        ? 4
                                        : 8,
                                childAspectRatio:
                                    MediaQuery.sizeOf(context).height < 500
                                        ? 2.1
                                        : 1.05,
                                crossAxisSpacing: 9,
                                mainAxisSpacing: 9,
                                children: [
                                  callControl(
                                      backend.micEnabled
                                          ? Icons.mic_none
                                          : Icons.mic_off_outlined,
                                      'Mic',
                                      busy
                                          ? null
                                          : () => _run(() => backend
                                              .microphone(!backend.micEnabled)),
                                      active: backend.micEnabled),
                                  callControl(
                                      backend.cameraEnabled
                                          ? Icons.videocam_outlined
                                          : Icons.videocam_off_outlined,
                                      'Camera',
                                      busy
                                          ? null
                                          : () => _run(() => backend.camera(
                                              !backend.cameraEnabled,
                                              lowBandwidth: lowBandwidth)),
                                      active: backend.cameraEnabled),
                                  callControl(
                                      Icons.desktop_windows_outlined,
                                      backend.screenEnabled
                                          ? 'Stop share'
                                          : 'Share',
                                      busy ? null : () => _run(toggleScreen),
                                      active: backend.screenEnabled),
                                  callControl(
                                      Icons.radio_button_checked,
                                      recording ? 'Stop' : 'Record',
                                      busy ? null : () => _run(toggleRecording),
                                      active: recording),
                                  callControl(
                                      Icons.near_me_outlined,
                                      'Pointer',
                                      togglePointer,
                                      active: pointerMode),
                                  callControl(Icons.people_outline, 'People',
                                      showPeople),
                                  callControl(Icons.chat_bubble_outline, 'Chat',
                                      meetingChat),
                                  callControl(Icons.headset_mic_outlined,
                                      'Devices', showDevices),
                                ]),
                            const SizedBox(height: 12),
                            SizedBox(
                                width: double.infinity,
                                child: FilledButton.icon(
                                    style: FilledButton.styleFrom(
                                        backgroundColor:
                                            const Color(0xFFD92328),
                                        foregroundColor: Colors.white,
                                        minimumSize: const Size(0, 48),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(13))),
                                    onPressed: leave,
                                    icon: const Icon(Icons.call_end),
                                    label: const Text('Leave'))),
                          ])))
                ],
              ),
      ),
    );
  }
}
