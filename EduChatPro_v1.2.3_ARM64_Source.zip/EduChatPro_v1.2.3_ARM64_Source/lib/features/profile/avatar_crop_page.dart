import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;

/// Simple in-app square avatar cropper.
///
/// It uses only Flutter + the already included `image` package, so Android,
/// iOS, Windows and web do not need an extra native cropper plugin.
class AvatarCropPage extends StatefulWidget {
  const AvatarCropPage(
      {super.key, required this.bytes, this.title = 'Adjust profile photo'});
  final Uint8List bytes;
  final String title;

  @override
  State<AvatarCropPage> createState() => _AvatarCropPageState();
}

class _AvatarCropPageState extends State<AvatarCropPage> {
  final TransformationController transform = TransformationController();
  late final img.Image decoded;
  bool initialized = false;
  double viewportSide = 0;
  double baseScale = 1;
  double displayWidth = 0;
  double displayHeight = 0;

  @override
  void initState() {
    super.initState();
    final image = img.decodeImage(widget.bytes);
    if (image == null) {
      throw const FormatException('The selected image could not be decoded.');
    }
    decoded = image;
  }

  void _initializeTransform(double side) {
    if (initialized && (viewportSide - side).abs() < 0.5) return;
    viewportSide = side;
    baseScale = math.max(side / decoded.width, side / decoded.height);
    displayWidth = decoded.width * baseScale;
    displayHeight = decoded.height * baseScale;
    final x = (side - displayWidth) / 2;
    final y = (side - displayHeight) / 2;
    transform.value = Matrix4.identity()..translate(x, y);
    initialized = true;
  }

  Uint8List _crop() {
    final inverse = Matrix4.inverted(transform.value);
    final topLeft = MatrixUtils.transformPoint(inverse, Offset.zero);
    final bottomRight =
        MatrixUtils.transformPoint(inverse, Offset(viewportSide, viewportSide));

    double left = topLeft.dx / baseScale;
    double top = topLeft.dy / baseScale;
    double right = bottomRight.dx / baseScale;
    double bottom = bottomRight.dy / baseScale;

    left = left.clamp(0.0, decoded.width.toDouble()).toDouble();
    top = top.clamp(0.0, decoded.height.toDouble()).toDouble();
    right = right.clamp(0.0, decoded.width.toDouble()).toDouble();
    bottom = bottom.clamp(0.0, decoded.height.toDouble()).toDouble();

    var size = math.min(right - left, bottom - top);
    if (size < 1) {
      throw const FormatException('Move or zoom the image and try again.');
    }
    size = math.min(size, math.min(decoded.width - left, decoded.height - top));

    final x = left.round().clamp(0, decoded.width - 1).toInt();
    final y = top.round().clamp(0, decoded.height - 1).toInt();
    final maxSize = math.min(decoded.width - x, decoded.height - y);
    final s = size.round().clamp(1, maxSize).toInt();
    final cropped = img.copyCrop(decoded, x: x, y: y, width: s, height: s);
    final resized = img.copyResize(cropped, width: 512, height: 512);
    return Uint8List.fromList(img.encodeJpg(resized, quality: 88));
  }

  @override
  void dispose() {
    transform.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(widget.title),
          actions: [
            TextButton(
              onPressed: () {
                try {
                  Navigator.pop(context, _crop());
                } catch (e) {
                  ScaffoldMessenger.of(context)
                      .showSnackBar(SnackBar(content: Text('$e')));
                }
              },
              child: const Text('Use photo'),
            )
          ],
        ),
        body: LayoutBuilder(builder: (context, box) {
          final side =
              math.min(math.min(box.maxWidth - 32, box.maxHeight - 150), 520.0);
          _initializeTransform(math.max(100.0, side).toDouble());
          return Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('Pinch to zoom and drag to position your photo.'),
              const SizedBox(height: 14),
              SizedBox(
                width: viewportSide,
                height: viewportSide,
                child: ClipRect(
                  child: Stack(fit: StackFit.expand, children: [
                    InteractiveViewer(
                      transformationController: transform,
                      constrained: false,
                      minScale: 1,
                      maxScale: 6,
                      boundaryMargin: EdgeInsets.zero,
                      child: SizedBox(
                        width: displayWidth,
                        height: displayHeight,
                        child: Image.memory(widget.bytes, fit: BoxFit.fill),
                      ),
                    ),
                    IgnorePointer(
                      child: CustomPaint(painter: _CropOverlayPainter()),
                    ),
                  ]),
                ),
              ),
              const SizedBox(height: 14),
              TextButton.icon(
                onPressed: () {
                  initialized = false;
                  _initializeTransform(viewportSide);
                  setState(() {});
                },
                icon: const Icon(Icons.restart_alt_rounded),
                label: const Text('Reset position'),
              )
            ]),
          );
        }),
      );
}

class _CropOverlayPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final dim = Paint()..color = Colors.black.withOpacity(.42);
    final full = Path()..addRect(Offset.zero & size);
    final circle = Path()
      ..addOval(Rect.fromCircle(
          center: size.center(Offset.zero), radius: size.shortestSide / 2 - 3));
    canvas.drawPath(Path.combine(PathOperation.difference, full, circle), dim);
    canvas.drawCircle(
        size.center(Offset.zero),
        size.shortestSide / 2 - 3,
        Paint()
          ..color = Colors.white
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
