import '../../theme/theme_controller.dart';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import '../../services/image_utils.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import '../../services/edu_repository.dart';
import '../../services/notification_service.dart';
import '../../shared/widgets.dart';
import '../auth/auth_page.dart';
import '../auth/qr_web_login_page.dart';
import '../../theme/app_theme.dart';
import 'avatar_crop_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage(
      {super.key, required this.repo, required this.notifications});
  final EduRepository repo;
  final NotificationService notifications;
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final name = TextEditingController(), phone = TextEditingController();
  JsonRow? profile;
  String? avatar;
  Object? error;
  bool busy = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final p = await widget.repo.profile();
      String? url;
      if (p['avatar_path'] != null) {
        url = await widget.repo.client.storage
            .from('avatars')
            .createSignedUrl(p['avatar_path'], 300);
      }
      if (mounted) {
        setState(() {
          profile = p;
          name.text = p['full_name'];
          phone.text = p['phone'] ?? '';
          avatar = url;
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = e);
    }
  }

  @override
  void dispose() {
    name.dispose();
    phone.dispose();
    super.dispose();
  }

  Future<void> photo() async {
    await perform(context, () async {
      final picked = await FilePicker.platform
          .pickFiles(type: FileType.image, withData: true);
      if (picked == null) return;
      final f = picked.files.single;
      if (f.size > 10 * 1024 * 1024 || f.bytes == null) {
        throw FormatException('Choose an image under 10 MB.');
      }
      final cropped = await Navigator.push<Uint8List>(
          context,
          MaterialPageRoute(
              fullscreenDialog: true,
              builder: (_) => AvatarCropPage(bytes: f.bytes!)));
      if (cropped == null) return;
      final data = await compute(thumbnail, cropped);
      final path = '${widget.repo.userId}/${Uuid().v4()}.jpg';
      await widget.repo.client.storage.from('avatars').uploadBinary(path, data,
          fileOptions: FileOptions(contentType: 'image/jpeg'));
      final old = profile?['avatar_path'];
      await widget.repo
          .update('profiles', widget.repo.userId, {'avatar_path': path});
      if (old != null) {
        await widget.repo.client.storage.from('avatars').remove([old]);
      }
      await load();
    });
  }

  @override
  Widget build(BuildContext context) =>
      ListView(padding: EdgeInsets.all(24), children: [
        const ThemePicker(),
        if (widget.notifications.android)
          ListTile(
              leading: const Icon(Icons.call),
              title: const Text('Incoming call screen'),
              subtitle:
                  const Text('Allow calls to appear over the lock screen'),
              onTap: () => perform(context, () async {
                    await widget.notifications.enablePush();
                    await NotificationService.native
                        .invokeMethod('callPermission');
                  })),
        PageHeader('Your profile', 'Make yourself at home.'),
        if (error != null) Text('$error'),
        if (profile == null)
          TextButton(onPressed: load, child: Text('Load profile'))
        else
          Center(
              child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: 600),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Center(
                            child: Container(
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color:
                                        Theme.of(context).colorScheme.surface,
                                    border: Border.all(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary,
                                        width: 2)),
                                child: CircleAvatar(
                                    radius: 48,
                                    backgroundImage: avatar == null
                                        ? null
                                        : NetworkImage(avatar!),
                                    child: avatar == null
                                        ? Icon(Icons.person_outline, size: 42)
                                        : null))),
                        TextButton(
                            onPressed: photo,
                            child: Text('Change profile photo')),
                        SizedBox(height: 24),
                        TextField(
                            controller: name,
                            maxLength: 100,
                            decoration:
                                InputDecoration(labelText: 'Full name')),
                        SizedBox(height: 16),
                        TextField(
                            controller: phone,
                            maxLength: 30,
                            keyboardType: TextInputType.phone,
                            decoration:
                                InputDecoration(labelText: 'Phone (optional)')),
                        SizedBox(height: 16),
                        SelectableText(
                            'Email: ${widget.repo.client.auth.currentUser?.email}\nUser ID: ${widget.repo.userId}\nJoined: ${profile!['created_at']}\nStatus: ${profile!['status']}'),
                        SizedBox(height: 24),
                        FilledButton(
                            onPressed: busy
                                ? null
                                : () async {
                                    setState(() => busy = true);
                                    await perform(context, () async {
                                      await widget.repo.update(
                                          'profiles', widget.repo.userId, {
                                        'full_name': name.text.trim(),
                                        'phone': phone.text.trim()
                                      });
                                    }, success: 'Profile saved.');
                                    if (mounted) setState(() => busy = false);
                                  },
                            child: Text('Save profile')),
                        TextButton(
                            onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => PasswordPage())),
                            child: Text('Change password')),
                        if (!kIsWeb) ...[
                          SizedBox(height: 8),
                          OutlinedButton.icon(
                              onPressed: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) =>
                                          QrWebLoginPage(repo: widget.repo))),
                              icon: Icon(Icons.qr_code_scanner_rounded),
                              label: Text('Scan QR to sign in on web')),
                        ],
                        OutlinedButton(
                            onPressed: () => perform(
                                context, widget.notifications.enablePush,
                                success: 'Push notifications enabled.'),
                            child: Text('Enable push notifications'))
                      ])))
      ]);
}
