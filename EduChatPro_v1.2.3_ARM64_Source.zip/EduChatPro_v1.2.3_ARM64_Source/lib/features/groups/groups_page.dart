import 'package:flutter/material.dart';
import '../../services/edu_repository.dart';
import '../../services/live_refresh.dart';
import '../../shared/widgets.dart';
import '../../shared/group_avatar.dart';
import '../../shared/user_avatar.dart';
import 'group_detail_page.dart';
import '../direct_chat/direct_people_page.dart';
import '../direct_chat/direct_chat_page.dart';

class GroupsPage extends StatefulWidget {
  const GroupsPage({super.key, required this.repo});
  final EduRepository repo;
  @override
  State<GroupsPage> createState() => _GroupsPageState();
}

class _GroupsPageState extends State<GroupsPage> {
  final list = GlobalKey<PagedListState>();
  LiveRefresh? live;
  @override
  void initState() {
    super.initState();
    live = LiveRefresh(widget.repo.client, () async {
      await list.currentState?.refresh();
    }, tables: [
      'groups',
      'group_messages',
      'direct_messages',
      'chat_pins',
      'profiles'
    ]);
  }

  @override
  void dispose() {
    live?.dispose();
    super.dispose();
  }

  Future<void> pin(JsonRow row) async {
    await perform(context, () async {
      final q = widget.repo.client.from('chat_pins');
      if (row['pinned'] == true) {
        await q
            .delete()
            .eq('user_id', widget.repo.userId)
            .eq('thread_kind', row['thread_kind'])
            .eq('thread_id', row['thread_id']);
      } else {
        await q.upsert({
          'user_id': widget.repo.userId,
          'thread_kind': row['thread_kind'],
          'thread_id': row['thread_id']
        });
      }
      await list.currentState?.refresh();
    });
  }

  Future<void> open(JsonRow row) async {
    await perform(context, () async {
      if (row['thread_kind'] == 'group') {
        final group = await widget.repo.client
            .from('groups')
            .select()
            .eq('id', row['thread_id'])
            .single();
        if (mounted)
          await Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) =>
                      GroupDetailPage(repo: widget.repo, group: group)));
      } else if (mounted) {
        await Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => DirectChatPage(
                    repo: widget.repo,
                    otherUserId: row['thread_id'],
                    otherName: row['name'] ?? 'User',
                    otherAvatarPath: row['avatar_path'])));
      }
      if (mounted) await list.currentState?.refresh();
    });
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        PageHeader('Chats', 'Groups and private conversations together',
            actions: [
              OutlinedButton.icon(
                  icon: const Icon(Icons.edit_square),
                  label: const Text('New chat'),
                  onPressed: () async {
                    await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) =>
                                DirectPeoplePage(repo: widget.repo)));
                    if (mounted) await list.currentState?.refresh();
                  }),
              FilledButton.icon(
                  icon: const Icon(Icons.group_add_outlined),
                  label: const Text('New group'),
                  onPressed: () async {
                    final v = await formDialog(
                        context, 'Create group', ['Group name', 'Description']);
                    if (v != null && mounted)
                      await perform(context, () async {
                        await widget.repo
                            .add('groups', {'name': v[0], 'description': v[1]});
                        await list.currentState?.refresh();
                      });
                  })
            ]),
        Expanded(
            child: PagedList(
                key: list,
                      cacheKey: '${widget.repo.userId}/threads',
                load: (offset) async => List<JsonRow>.from(await widget.repo.client.rpc('mobile_chat_threads',
                    params: {'page_offset': offset})),
                empty: 'Start a private chat or create a group to begin.',
                builder: (row) => Card(
                    child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        leading: row['thread_kind'] == 'group'
                            ? GroupAvatar(
                                repo: widget.repo, path: row['avatar_path'])
                            : UserAvatar(
                                repo: widget.repo,
                                userId: row['thread_id'],
                                path: row['avatar_path'],
                                name: row['name']),
                        title: Text(row['name'] ?? 'Chat',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text('${row['thread_kind'] == 'group' ? 'Group · ' : ''}${row['preview'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis),
                        trailing: IconButton(tooltip: row['pinned'] == true ? 'Unpin chat' : 'Pin chat', icon: Icon(row['pinned'] == true ? Icons.push_pin : Icons.push_pin_outlined, color: row['pinned'] == true ? Theme.of(context).colorScheme.primary : null), onPressed: () => pin(row)),
                        onLongPress: () => pin(row),
                        onTap: () => open(row)))))
      ]);
}
