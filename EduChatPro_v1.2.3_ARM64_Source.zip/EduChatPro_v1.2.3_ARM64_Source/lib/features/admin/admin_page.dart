import 'package:flutter/material.dart';
import '../../services/edu_repository.dart';
import '../../shared/widgets.dart';

class AdminPage extends StatefulWidget {
  const AdminPage({super.key, required this.repo, required this.role});
  final EduRepository repo;
  final String role;
  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  JsonRow? stats;
  Object? error;
  final accounts = GlobalKey<PagedListState>();
  bool moderate = false;
  bool get superAdmin => widget.role == 'super_admin';
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final m = await widget.repo.allowed('forum.moderate');
      final s = superAdmin
          ? JsonRow.from(await widget.repo.client.rpc('dashboard_stats'))
          : null;
      if (mounted) {
        setState(() {
          stats = s;
          moderate = m;
          error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = e);
    }
  }

  Future<void> edit(JsonRow user) async {
    final role = await widget.repo.client
        .from('user_roles')
        .select('role')
        .eq('user_id', user['id'])
        .single();
    if (role['role'] == 'super_admin') {
      if (mounted) {
        notice(context, 'Super Admin changes require trusted database access.');
      }
      return;
    }
    final current = await widget.repo.client
        .from('assistant_admin_permissions')
        .select('permission')
        .eq('user_id', user['id']);
    final selected = Set<String>.from(current.map((e) => e['permission']));
    bool enabled = user['status'] == 'active',
        assistant = role['role'] == 'assistant_admin';
    if (!mounted) return;
    final save = await showDialog<bool>(
        context: context,
        builder: (c) => StatefulBuilder(
            builder: (c, set) => AlertDialog(
                    title: Text('Access · ${user['full_name']}'),
                    content: SizedBox(
                        width: 480,
                        child: SingleChildScrollView(
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                              SwitchListTile(
                                  title: const Text('Account enabled'),
                                  value: enabled,
                                  onChanged: (v) => set(() => enabled = v)),
                              SwitchListTile(
                                  title: const Text('Assistant Admin'),
                                  value: assistant,
                                  onChanged: (v) => set(() => assistant = v)),
                              for (final p in [
                                'groups.manage',
                                'members.manage',
                                'files.manage',
                                'meetings.create',
                                'forum.moderate',
                                'announcements.create',
                                'attendance.read'
                              ])
                                CheckboxListTile(
                                    title: Text(p),
                                    value: selected.contains(p),
                                    onChanged: assistant
                                        ? (v) => set(() {
                                              if (v!) {
                                                selected.add(p);
                                              } else {
                                                selected.remove(p);
                                              }
                                            })
                                        : null)
                            ]))),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.pop(c, false),
                          child: const Text('Cancel')),
                      FilledButton(
                          onPressed: () => Navigator.pop(c, true),
                          child: const Text('Save access'))
                    ])));
    if (save == true) {
      await widget.repo.client.rpc('admin_account', params: {
        'target': user['id'],
        'new_role': assistant ? 'assistant_admin' : 'student',
        'enabled': enabled,
        'permissions': selected.toList()
      });
      await accounts.currentState?.refresh();
      await load();
    }
  }

  Future<void> sessions(JsonRow user) async {
    final sessions = List<JsonRow>.from(await widget.repo.client
        .rpc('admin_sessions', params: {'target': user['id']}));
    if (!mounted) return;
    await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
                title: const Text('Assistant sessions'),
                content: SizedBox(
                    width: 500,
                    child: ListView(shrinkWrap: true, children: [
                      for (final session in sessions)
                        ListTile(
                            title: Text(session['created_at']),
                            subtitle: Text(session['session_id']),
                            trailing: IconButton(
                                icon: const Icon(Icons.logout),
                                onPressed: () => perform(c, () async {
                                      final result = await widget
                                          .repo.client.functions
                                          .invoke('admin-users', body: {
                                        'action': 'revoke',
                                        'target': user['id'],
                                        'session_id': session['session_id']
                                      });
                                      if (result.status >= 400) {
                                        throw StateError(
                                            result.data.toString());
                                      }
                                      if (c.mounted) Navigator.pop(c);
                                    })))
                    ])),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(c),
                      child: const Text('Close')),
                  FilledButton(
                      onPressed: () async {
                        if (await confirm(c, 'Revoke all devices?',
                                'The assistant must sign in again.') &&
                            c.mounted) {
                          await perform(c, () async {
                            final result = await widget.repo.client.functions
                                .invoke('admin-users', body: {
                              'action': 'revoke',
                              'target': user['id']
                            });
                            if (result.status >= 400) {
                              throw StateError(result.data.toString());
                            }
                            if (c.mounted) Navigator.pop(c);
                          });
                        }
                      },
                      child: const Text('Force logout all devices'))
                ]));
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
      length: superAdmin ? 4 : 1,
      child: Column(children: [
        PageHeader(
            'Administration',
            superAdmin
                ? 'Manage your learning community'
                : 'Your delegated administration tools',
            actions: [
              TextButton(
                  onPressed: () async {
                    final values = await formDialog(
                        context,
                        'Admin announcement',
                        ['Message (up to 500 characters)']);
                    if (values != null && context.mounted) {
                      await perform(context, () async {
                        await widget.repo.client.rpc('admin_announcement',
                            params: {'message': values[0]});
                      }, success: 'Announcement sent.');
                    }
                  },
                  child: const Text('Send announcement')),
              IconButton(onPressed: load, icon: const Icon(Icons.refresh))
            ]),
        TabBar(isScrollable: true, tabs: [
          if (superAdmin) ...[
            const Tab(text: 'Overview'),
            const Tab(text: 'Accounts'),
            const Tab(text: 'Audit history')
          ],
          const Tab(text: 'Moderation')
        ]),
        Expanded(
            child: TabBarView(children: [
          if (superAdmin) ...[
            ListView(padding: const EdgeInsets.all(24), children: [
              if (error != null) Text('$error'),
              if (stats == null)
                const Text('Loading dashboard…')
              else
                Wrap(
                    spacing: 16,
                    runSpacing: 16,
                    children: stats!.entries
                        .map((e) => SizedBox(
                            width: 230,
                            child: Card(
                                child: Padding(
                                    padding: const EdgeInsets.all(24),
                                    child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text('${e.value}',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .headlineLarge),
                                          const SizedBox(height: 10),
                                          Text(e.key)
                                        ])))))
                        .toList()),
              const SizedBox(height: 20),
              const Text(
                  'Active counts use recent app heartbeats. Tracked storage excludes avatars, orphan objects and provider overhead.')
            ]),
            Column(children: [
              Padding(
                  padding: const EdgeInsets.all(16),
                  child: FilledButton.icon(
                      onPressed: () async {
                        final v = await formDialog(context,
                            'Invite Assistant Admin', ['Email', 'Full name']);
                        if (v != null && context.mounted) {
                          await perform(context, () async {
                            final response = await widget.repo.client.functions
                                .invoke('admin-users', body: {
                              'action': 'invite',
                              'email': v[0],
                              'name': v[1]
                            });
                            if (response.status >= 400) {
                              throw StateError(response.data.toString());
                            }
                            await accounts.currentState?.refresh();
                          },
                              success:
                                  'Invitation sent. Assign permissions after account creation.');
                        }
                      },
                      icon: const Icon(Icons.person_add_outlined),
                      label: const Text('Invite Assistant Admin'))),
              Expanded(
                  child: PagedList(
                      key: accounts,
                      load: (o) => widget.repo.page('profiles', offset: o),
                      builder: (u) => ListTile(
                          title: Text(u['full_name']),
                          subtitle: Text('${u['status']} · ${u['id']}'),
                          trailing: PopupMenuButton<String>(
                              onSelected: (a) => perform(context, () async {
                                    if (a == 'edit') await edit(u);
                                    if (a == 'sessions') await sessions(u);
                                    if (a == 'reset') {
                                      final response = await widget
                                          .repo.client.functions
                                          .invoke('admin-users', body: {
                                        'action': 'reset',
                                        'target': u['id']
                                      });
                                      if (response.status >= 400) {
                                        throw StateError(
                                            response.data.toString());
                                      }
                                      if (context.mounted) {
                                        notice(context,
                                            'Secure reset email requested.');
                                      }
                                    }
                                  }),
                              itemBuilder: (_) => const [
                                    PopupMenuItem(
                                        value: 'edit',
                                        child: Text('Role and permissions')),
                                    PopupMenuItem(
                                        value: 'sessions',
                                        child:
                                            Text('Revoke assistant sessions')),
                                    PopupMenuItem(
                                        value: 'reset',
                                        child:
                                            Text('Send assistant reset email'))
                                  ]))))
            ]),
            PagedList(
                load: (o) => widget.repo.page('admin_audit_logs', offset: o),
                builder: (a) => Card(
                    child: ListTile(
                        leading: const Icon(Icons.verified_user_outlined),
                        title: Text('${a['actor_name']} · ${a['action']}'),
                        subtitle: SelectableText(
                            '${a['resource']} · ${a['created_at']}\n${a['metadata']}')))),
          ],
          moderate
              ? PagedList(
                  load: (o) => widget.repo.page('forum_reports', offset: o),
                  builder: (r) => Card(
                      child: ListTile(
                          title: Text(r['reason']),
                          subtitle: SelectableText(
                              'Post: ${r['post_id']}\n${r['resolved'] ? 'Resolved' : 'Open report'}'),
                          trailing: PopupMenuButton<String>(
                              onSelected: (a) => perform(context, () async {
                                    if (a == 'resolve') {
                                      await widget.repo.update('forum_reports',
                                          r['id'], {'resolved': true});
                                    } else if (await confirm(
                                        context,
                                        'Remove reported post?',
                                        'This deletes the post and its comments.')) {
                                      await widget.repo.client.rpc(
                                          'delete_post',
                                          params: {'post': r['post_id']});
                                    }
                                    if (context.mounted) {
                                      notice(context,
                                          'Moderation action saved. Refresh to see changes.');
                                    }
                                  }),
                              itemBuilder: (_) => const [
                                    PopupMenuItem(
                                        value: 'resolve',
                                        child: Text('Resolve report')),
                                    PopupMenuItem(
                                        value: 'delete',
                                        child: Text('Remove post'))
                                  ]))))
              : const Center(
                  child: Text(
                      'Group and meeting tools are available in their sections according to your permissions.'))
        ]))
      ]));
}
