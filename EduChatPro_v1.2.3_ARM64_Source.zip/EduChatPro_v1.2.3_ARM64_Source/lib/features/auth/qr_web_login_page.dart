import 'dart:async';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../../services/edu_repository.dart';

class QrWebLoginPage extends StatefulWidget {
  const QrWebLoginPage({super.key, required this.repo});
  final EduRepository repo;

  @override
  State<QrWebLoginPage> createState() => _QrWebLoginPageState();
}

class _QrWebLoginPageState extends State<QrWebLoginPage>
    with WidgetsBindingObserver {
  final controller = MobileScannerController(
    autoStart: false,
    cameraResolution: const Size(1280, 720),
    formats: const [BarcodeFormat.qrCode],
    detectionSpeed: DetectionSpeed.normal,
    facing: CameraFacing.back,
  );
  bool busy = false, starting = false;
  String? error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => startCamera());
  }

  String cameraError(MobileScannerException e) => e.errorCode ==
          MobileScannerErrorCode.permissionDenied
      ? 'Allow Camera permission in Android Settings > Apps > Edu Chat Pro > Permissions, then tap Retry.'
      : 'Camera unavailable. Close other camera apps and tap Retry.';

  Future<void> startCamera() async {
    if (!mounted || busy || starting || controller.value.isRunning) return;
    starting = true;
    try {
      await controller.start();
    } on MobileScannerException catch (e) {
      if (mounted) setState(() => error = cameraError(e));
    } catch (_) {
      if (mounted) setState(() => error = 'Camera could not start. Tap Retry.');
    } finally {
      starting = false;
    }
  }

  Future<void> stopCamera() async {
    try {
      await controller.stop();
    } catch (_) {}
  }

  Future<void> retry() async {
    if (busy) return;
    await stopCamera();
    if (!mounted) return;
    setState(() => error = null);
    await startCamera();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !busy && error == null) {
      unawaited(startCamera());
    } else if (state == AppLifecycleState.inactive && !starting) {
      unawaited(stopCamera());
    }
  }

  Future<void> handle(BarcodeCapture capture) async {
    if (!mounted || busy || error != null) return;
    String? value;
    for (final barcode in capture.barcodes) {
      final raw = barcode.rawValue;
      if (raw != null && raw.isNotEmpty) {
        value = raw;
        break;
      }
    }
    if (value == null) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await stopCamera();
      await widget.repo.approveWebQrLogin(value);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content:
              Text('Web login approved. Your computer is signing in now.')));
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        busy = false;
        error = e
            .toString()
            .replaceFirst('FormatException: ', '')
            .replaceFirst('Bad state: ', '');
      });
      // Explicit retry avoids re-approving an expired code repeatedly.
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    unawaited(controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Scan web login QR'), actions: [
          IconButton(
              tooltip: 'Flashlight',
              icon: const Icon(Icons.flash_on),
              onPressed: busy
                  ? null
                  : () async {
                      try {
                        await controller.toggleTorch();
                      } catch (_) {}
                    })
        ]),
        body: Stack(children: [
          MobileScanner(
              controller: controller,
              onDetect: handle,
              errorBuilder: (context, e, _) => Center(
                  child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(cameraError(e),
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white))))),
          Positioned.fill(
              child: IgnorePointer(
                  child: Center(
                      child: Container(
                          width: 250,
                          height: 250,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: Theme.of(context).colorScheme.surface,
                                  width: 3),
                              borderRadius: BorderRadius.circular(24)))))),
          Positioned(
              left: 16,
              right: 16,
              bottom: 28,
              child: SafeArea(
                  child: Card(
                      color: Colors.black.withOpacity(.76),
                      child: Padding(
                          padding: const EdgeInsets.all(16),
                          child:
                              Column(mainAxisSize: MainAxisSize.min, children: [
                            Text(
                                busy
                                    ? 'Approving login…'
                                    : 'Point your camera at the QR code shown on the Edu Chat Pro website.',
                                textAlign: TextAlign.center,
                                style: const TextStyle(color: Colors.white)),
                            if (error != null) ...[
                              const SizedBox(height: 8),
                              Text(error!,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                      color: Colors.orangeAccent)),
                              TextButton(
                                  onPressed: retry,
                                  child: const Text('Retry scan'))
                            ]
                          ])))))
        ]),
      );
}
