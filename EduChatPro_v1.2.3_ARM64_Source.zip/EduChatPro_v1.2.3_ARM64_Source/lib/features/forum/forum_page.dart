import '../../shared/group_invite_action.dart';
import '../../services/live_refresh.dart';
import 'package:file_picker/file_picker.dart';
import '../../shared/social_widgets.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import '../../services/edu_repository.dart';
import '../../shared/widgets.dart';
import '../../shared/user_avatar.dart';

String _postDate(dynamic value) {
  final date = DateTime.tryParse(value?.toString() ?? '');
  return date == null ? '' : DateFormat.yMMMd().add_jm().format(date.toLocal());
}

class ForumPage extends StatefulWidget {
  const ForumPage({super.key, required this.repo});
  final EduRepository repo;
  @override
  State<ForumPage> createState() => _ForumPageState();
}

class _ForumPageState extends State<ForumPage> {
  final list = GlobalKey<PagedListState>();
  LiveRefresh? live;
  @override
  void dispose() {
    live?.dispose();
    super.dispose();
  }

  Set<String> mine = {};
  bool moderate = false, superAdmin = false;
  @override
  void initState() {
    super.initState();
    loadPermissions();
    live = LiveRefresh(widget.repo.client, () async {
      await loadPermissions();
      await list.currentState?.refresh();
    }, tables: ['forum_posts']);
  }

  Future<void> loadPermissions() async {
    await perform(context, () async {
      final ids = await widget.repo.client.rpc('my_post_ids');
      final m = await widget.repo.allowed('forum.moderate'),
          s = await widget.repo.allowed('super');
      if (mounted) {
        setState(() {
          mine = Set<String>.from(ids);
          moderate = m;
          superAdmin = s;
        });
      }
    });
  }

  Future<void> compose({JsonRow? post}) async {
    final saved = await showDialog<bool>(
        context: context,
        builder: (_) => SocialComposer(repo: widget.repo, post: post));
    if (saved == true) {
      await loadPermissions();
      await list.currentState?.refresh();
    }
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        PageHeader(
            'Community Forum', 'Share an update with everyone on Edu Chat Pro.',
            actions: [
              IconButton(
                  onPressed: () => list.currentState?.refresh(),
                  icon: const Icon(Icons.refresh)),
              FilledButton.icon(
                  onPressed: compose,
                  icon: const Icon(Icons.edit_outlined),
                  label: const Text('Create post'))
            ]),
        Expanded(
            child: PagedList(
                key: list,
                      cacheKey: '${widget.repo.userId}/forum',
                empty:
                    'No posts yet. Share the first update with your community.',
                load: (o) => widget.repo.forumPage(offset: o),
                builder: (p) => Card(
                    margin: const EdgeInsets.only(bottom: 16),
                    child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(children: [
                                if (p['anonymous'] == true)
                                  const CircleAvatar(
                                    backgroundColor: Color(0xFFE9EDEF),
                                    child: Icon(Icons.person_outline_rounded),
                                  )
                                else
                                  UserAvatar(
                                    repo: widget.repo,
                                    userId: p['public_author_id'],
                                    path: p['profiles']?['avatar_path'],
                                    name: p['profiles']?['full_name'],
                                  ),
                                const SizedBox(width: 12),
                                Expanded(
                                    child: Text(
                                        p['anonymous'] == true
                                            ? 'Anonymous'
                                            : p['profiles']?['full_name'] ??
                                                'Student',
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w700))),
                                PopupMenuButton<String>(
                                    onSelected: (action) =>
                                        perform(context, () async {
                                          if (action == 'edit') {
                                            await compose(post: p);
                                            return;
                                          }
                                          if (action == 'delete' &&
                                              await confirm(
                                                  context,
                                                  'Delete discussion?',
                                                  'Comments will also be deleted.')) {
                                            await widget.repo.client.rpc(
                                                'delete_post',
                                                params: {'post': p['id']});
                                            await list.currentState?.refresh();
                                          }
                                          if (action == 'report') {
                                            if (!context.mounted) return;
                                            final v = await formDialog(
                                                context,
                                                'Report discussion',
                                                ['Description of concern']);
                                            if (v != null) {
                                              await widget.repo.add(
                                                  'forum_reports', {
                                                'post_id': p['id'],
                                                'reason': v[0]
                                              });
                                            }
                                          }
                                          if (action == 'identify') {
                                            final owner = await widget
                                                .repo.client
                                                .rpc('identify_post',
                                                    params: {'post': p['id']});
                                            if (context.mounted) {
                                              showDialog<void>(
                                                  context: context,
                                                  builder: (c) => AlertDialog(
                                                          title: const Text(
                                                              'Responsible account'),
                                                          content: SelectableText(owner.toString()),
                                                          actions: [
                                                            TextButton(
                                                                onPressed: () =>
                                                                    Navigator
                                                                        .pop(c),
                                                                child:
                                                                    const Text(
                                                                        'Close'))
                                                          ]));
                                            }
                                          }
                                        }),
                                    itemBuilder: (_) => [
                                          if (mine.contains(p['id']))
                                            const PopupMenuItem(
                                                value: 'edit',
                                                child: Text('Edit')),
                                          if (mine.contains(p['id']) ||
                                              moderate)
                                            const PopupMenuItem(
                                                value: 'delete',
                                                child: Text('Delete')),
                                          const PopupMenuItem(
                                              value: 'report',
                                              child: Text('Report')),
                                          if (superAdmin)
                                            const PopupMenuItem(
                                                value: 'identify',
                                                child: Text('Identify account'))
                                        ])
                              ]),
                              const SizedBox(height: 16),
                              Text(_postDate(p['created_at']),
                                  style: Theme.of(context).textTheme.bodySmall),
                              const SizedBox(height: 10),
                              Text(p['body']?.toString() ?? '',
                                  maxLines: 6, overflow: TextOverflow.ellipsis),
                              GroupInviteAction(
                                  text: p['body']?.toString() ?? ''),
                              if (p['image_path'] != null)
                                ForumImage(
                                    repo: widget.repo, path: p['image_path']),
                              ReactionBar(repo: widget.repo, post: p['id']),
                              const SizedBox(height: 16),
                              TextButton.icon(
                                  onPressed: () => Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (_) => DiscussionPage(
                                              repo: widget.repo,
                                              post: p,
                                              moderate: moderate))),
                                  icon: const Icon(Icons.chat_bubble_outline),
                                  label: const Text('Comments'))
                            ])))))
      ]);
}

class DiscussionPage extends StatefulWidget {
  const DiscussionPage(
      {super.key,
      required this.repo,
      required this.post,
      required this.moderate});
  final EduRepository repo;
  final JsonRow post;
  final bool moderate;
  @override
  State<DiscussionPage> createState() => _DiscussionPageState();
}

class _DiscussionPageState extends State<DiscussionPage> {
  final comment = TextEditingController(), list = GlobalKey<PagedListState>();
  LiveRefresh? live;
  @override
  void initState() {
    super.initState();
    live = LiveRefresh(widget.repo.client, () async {
      await list.currentState?.refresh();
    },
        tables: ['forum_comments'],
        filterColumn: 'post_id',
        filterValue: widget.post['id']);
  }

  String? parent;
  PlatformFile? attachment;
  bool busy = false;
  @override
  void dispose() {
    live?.dispose();
    comment.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: Text(widget.post['title']?.toString() ?? 'Post')),
      body: Column(children: [
        Flexible(
            flex: 1,
            child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(children: [
                  SelectableText(widget.post['body']),
                  if (widget.post['image_path'] != null)
                    ForumImage(
                        repo: widget.repo, path: widget.post['image_path']),
                  ReactionBar(repo: widget.repo, post: widget.post['id'])
                ]))),
        const Divider(),
        Expanded(
            flex: 2,
            child: PagedList(
                key: list,
                load: (o) =>
                    widget.repo.forumPage(offset: o, postId: widget.post['id']),
                builder: (c) => Card(
                    child: ListTile(
                        leading: UserAvatar(
                          repo: widget.repo,
                          userId: c['author_id'],
                          path: c['profiles']?['avatar_path'],
                          name: c['profiles']?['full_name'],
                          radius: 18,
                        ),
                        title: Text(c['profiles']?['full_name'] ?? 'Member'),
                        subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                  '${c['parent_id'] != null ? '↳ Reply\n' : ''}${c['body'] ?? ''}'),
                              if (c['image_path'] is String)
                                ForumImage(
                                    repo: widget.repo, path: c['image_path'])
                            ]),
                        onTap: () => setState(() => parent = c['id']),
                        trailing: c['author_id'] == widget.repo.userId ||
                                widget.moderate
                            ? IconButton(
                                icon: const Icon(Icons.delete_outline),
                                onPressed: () async {
                                  if (await confirm(context, 'Delete comment?',
                                          'Replies to this comment will also be removed.') &&
                                      context.mounted) {
                                    await perform(context, () async {
                                      await widget.repo.deleteForumComment(c);
                                      await list.currentState?.refresh();
                                    });
                                  }
                                })
                            : null)))),
        if (parent != null)
          ListTile(
              title: const Text('Replying to selected comment'),
              trailing: IconButton(
                  onPressed: () => setState(() => parent = null),
                  icon: const Icon(Icons.close))),
        if (attachment?.bytes != null)
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(children: [
                Expanded(
                    child: ['mp4', 'mov', 'webm']
                            .contains(attachment!.extension?.toLowerCase())
                        ? ListTile(
                            leading: const Icon(Icons.video_file),
                            title: Text(attachment!.name))
                        : Image.memory(attachment!.bytes!,
                            height: 90, fit: BoxFit.contain)),
                IconButton(
                    tooltip: 'Remove image',
                    onPressed:
                        busy ? null : () => setState(() => attachment = null),
                    icon: const Icon(Icons.close))
              ])),
        SafeArea(
            top: false,
            child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  IconButton(
                      tooltip: 'Attach photo / video',
                      icon: const Icon(Icons.add_photo_alternate_outlined),
                      onPressed: busy
                          ? null
                          : () async {
                              await perform(context, () async {
                                final picked = await FilePicker.platform
                                    .pickFiles(
                                        type: FileType.custom,
                                        allowedExtensions: [
                                          'jpg',
                                          'jpeg',
                                          'png',
                                          'webp',
                                          'mp4',
                                          'mov',
                                          'webm'
                                        ],
                                        withData: true);
                                if (picked == null || !mounted) return;
                                final file = picked.files.single;
                                if (file.size > 10 * 1024 * 1024 ||
                                    file.bytes == null)
                                  throw const FormatException(
                                      'Choose a photo or video under 10 MB.');
                                setState(() => attachment = file);
                              });
                            }),
                  Expanded(
                      child: TextField(
                          controller: comment,
                          maxLength: 4000,
                          decoration: const InputDecoration(
                              hintText: 'Add to the conversation…'))),
                  IconButton.filled(
                      onPressed: busy
                          ? null
                          : () async {
                              if (comment.text.trim().isEmpty &&
                                  attachment == null) return;
                              setState(() => busy = true);
                              await perform(context, () async {
                                await widget.repo.addForumComment(
                                    postId: widget.post['id'],
                                    body: comment.text,
                                    parentId: parent,
                                    imageName: attachment?.name,
                                    imageBytes: attachment?.bytes);
                                attachment = null;
                                comment.clear();
                                parent = null;
                                await list.currentState?.refresh();
                              });
                              if (mounted) setState(() => busy = false);
                            },
                      icon: const Icon(Icons.send))
                ])))
      ]));
}
