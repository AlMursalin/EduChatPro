import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/edu_repository.dart';
import 'widgets.dart';

const voiceChannel = MethodChannel('educhat/media');

class VoiceNote {
  VoiceNote(this.bytes, this.durationMs);
  final Uint8List bytes;
  final int durationMs;
}

Future<VoiceNote?> recordVoice(BuildContext context) => showDialog<VoiceNote>(
    context: context,
    barrierDismissible: false,
    builder: (_) => const VoiceRecorderDialog());

class VoiceRecorderDialog extends StatefulWidget {
  const VoiceRecorderDialog({super.key});
  @override
  State<VoiceRecorderDialog> createState() => _VoiceRecorderDialogState();
}

class _VoiceRecorderDialogState extends State<VoiceRecorderDialog> {
  Timer? timer;
  int seconds = 0;
  bool ready = false, stopping = false;
  String? error;
  @override
  void initState() {
    super.initState();
    start();
  }

  Future<void> start() async {
    try {
      await voiceChannel.invokeMethod('record');
      if (!mounted) {
        await voiceChannel.invokeMethod('cancelRecord');
        return;
      }
      setState(() => ready = true);
      timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() => seconds++);
        if (seconds >= 119) stop();
      });
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  Future<void> stop() async {
    if (!ready || stopping) return;
    setState(() => stopping = true);
    timer?.cancel();
    try {
      final data =
          await voiceChannel.invokeMapMethod<String, dynamic>('stopRecord');
      if (mounted)
        Navigator.pop(context,
            VoiceNote(data!['bytes'] as Uint8List, data['duration_ms'] as int));
    } catch (e) {
      if (mounted)
        setState(() {
          error = e.toString();
          ready = false;
          stopping = false;
        });
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    unawaited(voiceChannel.invokeMethod('cancelRecord'));
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
          title: const Text('Voice message'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.mic,
                color: Theme.of(context).colorScheme.primary, size: 48),
            const SizedBox(height: 12),
            Text(error ??
                (ready
                    ? 'Recording ${seconds ~/ 60}:${(seconds % 60).toString().padLeft(2, '0')}'
                    : 'Allow microphone access…')),
            const SizedBox(height: 12),
            const Text('Up to 2 minutes. Tap Send when finished.')
          ]),
          actions: [
            TextButton(
                onPressed: stopping ? null : () => Navigator.pop(context),
                child: const Text('Cancel')),
            FilledButton(
                onPressed: ready && !stopping ? stop : null,
                child: const Text('Send'))
          ]);
}

class VoicePlayer extends StatefulWidget {
  const VoicePlayer(
      {super.key,
      required this.repo,
      required this.bucket,
      required this.path,
      this.durationMs = 0});
  final EduRepository repo;
  final String bucket, path;
  final int durationMs;
  @override
  State<VoicePlayer> createState() => _VoicePlayerState();
}

class _VoicePlayerState extends State<VoicePlayer> {
  Timer? timer;
  String? url;
  bool playing = false, busy = false;
  int position = 0, duration = 0;
  @override
  void initState() {
    super.initState();
    duration = widget.durationMs;
  }

  Future<void> toggle() async {
    if (busy) return;
    setState(() => busy = true);
    await perform(context, () async {
      if (playing) {
        await voiceChannel.invokeMethod('pause');
        setState(() => playing = false);
      } else {
        url ??= await widget.repo.client.storage
            .from(widget.bucket)
            .createSignedUrl(widget.path, 3600);
        final d = await voiceChannel.invokeMethod<int>('play', {'url': url});
        if (!mounted) return;
        setState(() {
          playing = true;
          duration = d ?? duration;
        });
        timer?.cancel();
        timer = Timer.periodic(const Duration(milliseconds: 400), (_) async {
          try {
            final state =
                await voiceChannel.invokeMapMethod<String, dynamic>('status');
            if (mounted)
              setState(() {
                playing = state?['url'] == url && state?['playing'] == true;
                position = state?['url'] == url
                    ? (state?['position'] as int? ?? 0)
                    : 0;
              });
            if (!playing) timer?.cancel();
          } catch (_) {
            timer?.cancel();
          }
        });
      }
    });
    if (mounted) setState(() => busy = false);
  }

  @override
  void dispose() {
    timer?.cancel();
    if (playing) unawaited(voiceChannel.invokeMethod('pause'));
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => SizedBox(
      width: 230,
      child: Row(children: [
        IconButton.filled(
            tooltip: playing ? 'Pause voice message' : 'Play voice message',
            onPressed: busy ? null : toggle,
            icon: Icon(playing ? Icons.pause : Icons.play_arrow)),
        const SizedBox(width: 8),
        Expanded(
            child: LinearProgressIndicator(
                value: duration > 0 ? (position / duration).clamp(0, 1) : 0,
                minHeight: 5)),
        const SizedBox(width: 8),
        Text(
            '${(duration ~/ 1000) ~/ 60}:${((duration ~/ 1000) % 60).toString().padLeft(2, '0')}',
            style: const TextStyle(fontSize: 12))
      ]));
}
