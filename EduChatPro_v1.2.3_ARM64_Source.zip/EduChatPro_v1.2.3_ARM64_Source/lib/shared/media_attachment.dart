import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/edu_repository.dart';
import 'stored_image.dart';
import 'widgets.dart';

class MediaAttachment extends StatelessWidget {
  const MediaAttachment(
      {super.key,
      required this.repo,
      required this.bucket,
      required this.path,
      this.name = 'Attachment',
      this.mime = ''});
  final EduRepository repo;
  final String bucket, path, name, mime;
  static const channel = MethodChannel('educhat/files');
  bool get video =>
      mime.startsWith('video/') ||
      RegExp(r'\.(mp4|mov|webm|m4v)$', caseSensitive: false).hasMatch(path);
  bool get image =>
      mime.startsWith('image/') ||
      RegExp(r'\.(jpg|jpeg|png|webp)$', caseSensitive: false).hasMatch(path);
  String get filename => name == 'Attachment' ? path.split('/').last : name;
  Future<void> download(BuildContext context) async =>
      perform(context, () async {
        final url =
            await repo.client.storage.from(bucket).createSignedUrl(path, 3600);
        final saved = await channel.invokeMethod<bool>('download', {
          'url': url,
          'name': filename,
          'mime': mime.isNotEmpty
              ? mime
              : video
                  ? 'video/mp4'
                  : image
                      ? 'image/jpeg'
                      : 'application/octet-stream'
        });
        if (saved == true && context.mounted)
          notice(context, 'Downloaded successfully.');
      });
  Future<void> open(BuildContext context) async {
    if (video) {
      await perform(context, () async {
        final url =
            await repo.client.storage.from(bucket).createSignedUrl(path, 3600);
        await channel.invokeMethod('video', {'url': url, 'name': filename});
      });
    } else if (image) {
      await Navigator.push(
          context,
          MaterialPageRoute(
              builder: (c) => Scaffold(
                  appBar: AppBar(
                      title: Text(filename,
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      actions: [
                        IconButton(
                            icon: const Icon(Icons.download),
                            onPressed: () => download(c))
                      ]),
                  body: Center(
                      child: InteractiveViewer(
                          minScale: .5,
                          maxScale: 5,
                          child: StoredImage(
                              repo: repo,
                              bucket: bucket,
                              path: path,
                              fit: BoxFit.contain,
                              decodeWidth: 2400))))));
    } else {
      await download(context);
    }
  }

  @override
  Widget build(BuildContext context) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (image)
              InkWell(
                  onTap: () => open(context),
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: StoredImage(
                          repo: repo,
                          bucket: bucket,
                          path: path,
                          width: 240,
                          height: 170,
                          fit: BoxFit.cover))),
            if (video)
              InkWell(
                  onTap: () => open(context),
                  child: Container(
                      width: 240,
                      height: 140,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primaryContainer,
                          borderRadius: BorderRadius.circular(12)),
                      child: const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.play_circle_fill, size: 58),
                            Text('Play video')
                          ]))),
            Wrap(children: [
              TextButton.icon(
                  onPressed: () => open(context),
                  icon: Icon(image
                      ? Icons.zoom_in
                      : video
                          ? Icons.play_arrow
                          : Icons.description_outlined),
                  label: Text(image
                      ? 'View photo'
                      : video
                          ? 'Watch video'
                          : filename)),
              IconButton(
                  tooltip: 'Download',
                  onPressed: () => download(context),
                  icon: const Icon(Icons.download_rounded))
            ])
          ]);
}
