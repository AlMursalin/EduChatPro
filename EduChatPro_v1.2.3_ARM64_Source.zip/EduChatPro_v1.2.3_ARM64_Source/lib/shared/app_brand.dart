import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class AppLogo extends StatelessWidget {
  const AppLogo({super.key, this.size = 44});
  final double size;

  @override
  Widget build(BuildContext context) => ClipRRect(
      borderRadius: BorderRadius.circular(size * .22),
      child: Image.asset('assets/ecp-logo.png',
          width: size,
          height: size,
          cacheWidth: (size * 3).round(),
          fit: BoxFit.cover));
}

class AppBrand extends StatelessWidget {
  const AppBrand({super.key, this.compact = false, this.light = false});
  final bool compact;
  final bool light;

  @override
  Widget build(BuildContext context) =>
      Row(mainAxisSize: MainAxisSize.min, children: [
        AppLogo(size: compact ? 38 : 44),
        if (!compact) ...[
          SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Edu Chat Pro',
                style: TextStyle(
                    fontSize: 21,
                    height: 1,
                    fontWeight: FontWeight.w900,
                    color: light
                        ? Colors.white
                        : Theme.of(context).colorScheme.onSurface)),
            SizedBox(height: 5),
            Text('Connect • Learn • Meet',
                style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: light
                        ? Colors.white70
                        : Theme.of(context).colorScheme.onSurfaceVariant)),
          ])
        ]
      ]);
}
