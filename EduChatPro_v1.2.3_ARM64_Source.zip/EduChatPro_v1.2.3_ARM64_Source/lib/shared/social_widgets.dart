import 'media_attachment.dart';
import 'stored_image.dart';
import '../services/live_refresh.dart';
import '../services/image_utils.dart';
import 'package:flutter/foundation.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:uuid/uuid.dart';
import '../services/edu_repository.dart';
import 'widgets.dart';

class ChatEmpty extends StatelessWidget {
  const ChatEmpty({super.key, this.group = true});
  final bool group;
  @override
  Widget build(BuildContext context) => Center(
      child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
                width: 140,
                height: 110,
                decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(42)),
                child: Icon(Icons.forum_rounded,
                    size: 72, color: Theme.of(context).colorScheme.primary)),
            const SizedBox(height: 24),
            Text('No messages yet',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            Text(
                group
                    ? 'Start the conversation with your group'
                    : 'Say hello and start a conversation',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall),
          ])));
}

class MemberPicker extends StatefulWidget {
  const MemberPicker({super.key, required this.repo, required this.group});
  final EduRepository repo;
  final String group;
  @override
  State<MemberPicker> createState() => _MemberPickerState();
}

class _MemberPickerState extends State<MemberPicker> {
  final search = TextEditingController();
  final selected = <String, JsonRow>{};
  List<JsonRow> rows = [];
  Timer? timer;
  int generation = 0;
  bool busy = false, loading = true;
  String? error;
  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    timer?.cancel();
    search.dispose();
    super.dispose();
  }

  Future<void> load() async {
    final current = ++generation;
    setState(() => loading = true);
    try {
      final result = await widget.repo.client.rpc('search_group_candidates',
          params: {
            'group_id_input': widget.group,
            'name_query': search.text.trim()
          });
      if (mounted && current == generation)
        setState(() {
          rows = List<JsonRow>.from(result);
          loading = false;
          error = null;
        });
    } catch (e) {
      if (mounted && current == generation)
        setState(() {
          error = e.toString();
          loading = false;
        });
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
          title: const Text('Add group members'),
          content: SizedBox(
              width: 440,
              height: 400,
              child: Column(children: [
                TextField(
                    controller: search,
                    decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        hintText: 'Search registered users'),
                    onChanged: (_) {
                      generation++;
                      timer?.cancel();
                      timer = Timer(const Duration(milliseconds: 250), load);
                    }),
                Align(
                    alignment: Alignment.centerLeft,
                    child: Text('${selected.length} selected')),
                if (selected.isNotEmpty)
                  SizedBox(
                      height: 40,
                      child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: selected.values
                              .map((p) => Padding(
                                  padding: const EdgeInsets.only(right: 4),
                                  child: InputChip(
                                      label: Text(p['full_name']),
                                      onDeleted: () => setState(
                                          () => selected.remove(p['id'])))))
                              .toList())),
                
                if (error != null) Text(error!),
                Expanded(
                    child: ListView(children: [
                  for (final p in rows)
                    CheckboxListTile(
                        value: selected.containsKey(p['id']),
                        title: Text(p['full_name']),
                        subtitle: Text(p['id'].toString().substring(0, 8)),
                        onChanged: (v) => setState(() {
                              if (v == true) {
                                selected[p['id']] = p;
                              } else {
                                selected.remove(p['id']);
                              }
                            })),
                  if (rows.isEmpty && !loading)
                    const Padding(
                        padding: EdgeInsets.all(24),
                        child: Text('No matching users.'))
                ]))
              ])),
          actions: [
            TextButton(
                onPressed: busy ? null : () => Navigator.pop(context, false),
                child: const Text('Cancel')),
            FilledButton(
                onPressed: busy || selected.isEmpty
                    ? null
                    : () async {
                        setState(() => busy = true);
                        try {
                          await widget.repo.client.rpc('add_group_members',
                              params: {
                                'group_id_input': widget.group,
                                'user_ids': selected.keys.toList()
                              });
                          if (context.mounted) Navigator.pop(context, true);
                        } catch (e) {
                          if (mounted)
                            setState(() {
                              busy = false;
                              error = e.toString();
                            });
                        }
                      },
                child: Text(busy ? 'Adding…' : 'Add selected'))
          ]);
}

class GroupAttachment extends StatefulWidget {
  const GroupAttachment(
      {super.key,
      required this.repo,
      required this.file,
      required this.canDelete,
      required this.onDeleted});
  final EduRepository repo;
  final JsonRow file;
  final bool canDelete;
  final VoidCallback onDeleted;
  @override
  State<GroupAttachment> createState() => _GroupAttachmentState();
}

class _GroupAttachmentState extends State<GroupAttachment> {
  @override
  Widget build(BuildContext context) =>
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        MediaAttachment(
            repo: widget.repo,
            bucket: 'group-files',
            path: widget.file['object_path'],
            name: widget.file['name'],
            mime: widget.file['mime_type'] ?? ''),
        if (widget.canDelete)
          TextButton(
              onPressed: () => perform(context, () async {
                    if (!await confirm(context, 'Remove file?',
                        'Delete this attachment from the group?')) return;
                    await widget.repo.deleteFiles([widget.file]);
                    widget.onDeleted();
                  }),
              child: const Text('Remove file'))
      ]);
}

class ForumImage extends StatelessWidget {
  const ForumImage({super.key, required this.repo, required this.path});
  final EduRepository repo;
  final String path;
  @override
  Widget build(BuildContext context) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: MediaAttachment(repo: repo, bucket: 'forum-images', path: path));
}

const reactions = {
  'like': '👍',
  'love': '❤️',
  'care': '🥰',
  'haha': '😂',
  'wow': '😮',
  'sad': '😢',
  'angry': '😡'
};

class ReactionBar extends StatefulWidget {
  const ReactionBar({super.key, required this.repo, required this.post});
  final EduRepository repo;
  final String post;
  @override
  State<ReactionBar> createState() => _ReactionBarState();
}

class _ReactionBarState extends State<ReactionBar> {
  LiveRefresh? live;
  @override
  void dispose() {
    live?.dispose();
    super.dispose();
  }

  Map<String, dynamic> counts = {};
  String? mine, error;
  bool busy = false;
  @override
  void initState() {
    super.initState();
    load();
    live = LiveRefresh(widget.repo.client, load,
        tables: ['forum_reactions'],
        filterColumn: 'post_id',
        filterValue: widget.post);
  }

  Future<void> load() async {
    try {
      dynamic data;
      try {
        data = await widget.repo.client
            .rpc('forum_reaction_summary', params: {'post_input': widget.post});
      } on PostgrestException catch (e) {
        if (e.code != 'PGRST202' && e.code != '42883') rethrow;
        // Older servers may have the table but not the aggregate RPC.
        final totals = <String, int>{};
        String? selected;
        var offset = 0;
        while (true) {
          final rows = await widget.repo.client
              .from('forum_reactions')
              .select('reaction,user_id')
              .eq('post_id', widget.post)
              .order('user_id')
              .range(offset, offset + 499);
          for (final row in rows) {
            final key = row['reaction'] as String;
            totals[key] = (totals[key] ?? 0) + 1;
            if (row['user_id'] == widget.repo.userId) selected = key;
          }
          if (rows.length < 500) break;
          offset += rows.length;
        }
        data = {'counts': totals, 'mine': selected};
      }
      if (mounted)
        setState(() {
          counts = Map<String, dynamic>.from(data['counts'] ?? {});
          mine = data['mine'];
          error = null;
        });
    } catch (e) {
      if (mounted)
        setState(() => error = e is PostgrestException &&
                (e.code == 'PGRST205' || e.code == '42P01')
            ? 'Reactions need the Forum database update.'
            : 'Could not load reactions. Tap to retry.');
    }
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        if (error != null) TextButton(onPressed: load, child: Text(error!)),
        Wrap(
            spacing: 4,
            children: reactions.entries
                .map((r) => ChoiceChip(
                    label: Text('${r.value} ${counts[r.key] ?? 0}'),
                    selected: mine == r.key,
                    onSelected: busy || error != null
                        ? null
                        : (_) async {
                            setState(() => busy = true);
                            await perform(context, () async {
                              if (mine == r.key) {
                                await widget.repo.client
                                    .from('forum_reactions')
                                    .delete()
                                    .eq('post_id', widget.post)
                                    .eq('user_id', widget.repo.userId);
                              } else {
                                await widget.repo.client
                                    .from('forum_reactions')
                                    .upsert({
                                  'post_id': widget.post,
                                  'user_id': widget.repo.userId,
                                  'reaction': r.key
                                });
                              }
                              await load();
                            });
                            if (mounted) setState(() => busy = false);
                          }))
                .toList())
      ]);
}

class SocialComposer extends StatefulWidget {
  const SocialComposer({super.key, required this.repo, this.post});
  final EduRepository repo;
  final JsonRow? post;
  @override
  State<SocialComposer> createState() => _SocialComposerState();
}

class _SocialComposerState extends State<SocialComposer> {
  late final TextEditingController body;
  PlatformFile? image;
  bool busy = false, anonymous = false, remove = false;
  String? error;
  @override
  void initState() {
    super.initState();
    body = TextEditingController(text: widget.post?['body'] ?? '');
    anonymous = widget.post?['anonymous'] == true;
  }

  @override
  void dispose() {
    body.dispose();
    super.dispose();
  }

  Future<void> save() async {
    if (body.text.trim().isEmpty) {
      setState(() => error = 'Write a description first.');
      return;
    }
    setState(() => busy = true);
    String? uploaded;
    bool saved = false;
    try {
      String? path = remove ? null : widget.post?['image_path'];
      if (image != null) {
        final ext = image!.extension?.toLowerCase();
        final mime = {
          'jpg': 'image/jpeg',
          'jpeg': 'image/jpeg',
          'png': 'image/png',
          'webp': 'image/webp',
          'mp4': 'video/mp4',
          'mov': 'video/quicktime',
          'webm': 'video/webm'
        }[ext];
        if (mime == null || image!.bytes == null || image!.size > 10485760)
          throw const FormatException(
              'Choose a photo or MP4/MOV/WebM video under 10 MB.');
        final video = mime.startsWith('video/');
        uploaded =
            '${const Uuid().v4()}/${const Uuid().v4()}.${video ? ext : 'jpg'}';
        await widget.repo.client.storage.from('forum-images').uploadBinary(
            uploaded,
            video ? image!.bytes! : await compute(feedImage, image!.bytes!),
            fileOptions: FileOptions(contentType: video ? mime : 'image/jpeg'));
        path = uploaded;
      }
      await widget.repo.saveForumPost(
          postId: widget.post?['id'],
          body: body.text.trim(),
          anonymous: anonymous,
          imagePath: path,
          changesImage:
              image != null || (remove && widget.post?['image_path'] != null));
      saved = true;
      final old = widget.post?['image_path'];
      if (old != null && old != path) {
        try {
          await widget.repo.client.storage.from('forum-images').remove([old]);
        } catch (_) {}
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (uploaded != null && !saved) {
        try {
          await widget.repo.client.storage
              .from('forum-images')
              .remove([uploaded]);
        } catch (_) {/* Preserve the original posting error. */}
      }
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
          title: Text(widget.post == null ? 'Create post' : 'Edit post'),
          content: SizedBox(
              width: 520,
              child: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(
                    controller: body,
                    minLines: 4,
                    maxLines: 8,
                    maxLength: 10000,
                    decoration: const InputDecoration(
                        hintText: 'What would you like to share?')),
                if (image?.bytes != null)
                  (['mp4', 'mov', 'webm']
                          .contains(image!.extension?.toLowerCase())
                      ? ListTile(
                          leading: const Icon(Icons.video_file),
                          title: Text(image!.name))
                      : Image.memory(image!.bytes!, height: 160)),
                if (image == null &&
                    !remove &&
                    widget.post?['image_path'] != null)
                  ForumImage(
                      repo: widget.repo, path: widget.post!['image_path']),
                Wrap(children: [
                  TextButton.icon(
                      onPressed: busy
                          ? null
                          : () async {
                              final f = await FilePicker.platform.pickFiles(
                                  type: FileType.custom,
                                  allowedExtensions: [
                                    'jpg',
                                    'jpeg',
                                    'png',
                                    'webp',
                                    'mp4',
                                    'mov',
                                    'webm'
                                  ],
                                  withData: true);
                              if (f != null && mounted)
                                setState(() {
                                  image = f.files.single;
                                  remove = false;
                                });
                            },
                      icon: const Icon(Icons.add_photo_alternate_outlined),
                      label: const Text('Add photo / video')),
                  TextButton(
                      onPressed: () => setState(() {
                            image = null;
                            remove = true;
                          }),
                      child: const Text('Remove media'))
                ]),
                SwitchListTile(
                    value: anonymous,
                    onChanged: (v) => setState(() => anonymous = v),
                    title: const Text('Post anonymously')),
                if (error != null)
                  Text(error!,
                      style:
                          TextStyle(color: Theme.of(context).colorScheme.error))
              ]))),
          actions: [
            TextButton(
                onPressed: busy ? null : () => Navigator.pop(context),
                child: const Text('Cancel')),
            FilledButton(
                onPressed: busy ? null : save,
                child: Text(busy ? 'Posting…' : 'Post'))
          ]);
}

Future<void> pickChatEmoji(
    BuildContext context, TextEditingController controller) async {
  final emoji = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
          title: const Text('Choose emoji'),
          content: Wrap(
              children: ['😊', '👍', '❤️', '🎉', '📚', '✅', '👋', '😂']
                  .map((e) => TextButton(
                      onPressed: () => Navigator.pop(c, e),
                      child: Text(e, style: const TextStyle(fontSize: 26))))
                  .toList())));
  if (emoji != null) {
    controller.text += emoji;
    controller.selection =
        TextSelection.collapsed(offset: controller.text.length);
  }
}
