import 'package:flutter/material.dart';
import '../services/group_links.dart';
import '../config/app_config.dart';

class GroupInviteAction extends StatelessWidget {
  const GroupInviteAction({super.key, required this.text});
  final String text;
  @override
  Widget build(BuildContext context) {
    Uri? invite;
    for (final match in RegExp(r'https://[^\s<>]+').allMatches(text)) {
      final uri = Uri.tryParse(match.group(0)!);
      if (uri != null &&
          uri.host == Uri.parse(AppConfig.appUrl).host &&
          uri.queryParameters.containsKey('group_invite')) {
        invite = uri;
        break;
      }
    }
    if (invite == null) return const SizedBox.shrink();
    return TextButton.icon(
        icon: const Icon(Icons.group_add_outlined),
        label: const Text('Join invited group'),
        onPressed: () => GroupLinks.accept(invite!));
  }
}
