import 'dart:convert';
import 'dart:async';
import 'social_widgets.dart';
import 'package:flutter/material.dart';
import '../services/edu_repository.dart';
import '../theme/app_theme.dart';

void notice(BuildContext context, Object message) {
  final messenger = ScaffoldMessenger.maybeOf(context);
  if (messenger == null) return;
  messenger
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message.toString())));
}

Future<void> perform(BuildContext context, Future<void> Function() action,
    {String? success}) async {
  try {
    await action();
    if (context.mounted && success != null) notice(context, success);
  } catch (e) {
    if (context.mounted) notice(context, e);
  }
}

Future<bool> confirm(BuildContext context, String title, String body) async =>
    await showDialog<bool>(
        context: context,
        builder: (context) =>
            AlertDialog(title: Text(title), content: Text(body), actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: Text('Cancel')),
              FilledButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: Text('Confirm'))
            ])) ??
    false;

Future<List<String>?> formDialog(
    BuildContext context, String title, List<String> labels,
    {List<String>? initial}) async {
  final controllers = List.generate(
      labels.length, (i) => TextEditingController(text: initial?[i] ?? ''));
  final key = GlobalKey<FormState>();
  final result = await showDialog<List<String>>(
      context: context,
      builder: (context) => AlertDialog(
              title: Text(title),
              content: SizedBox(
                  width: 440,
                  child: Form(
                      key: key,
                      child: SingleChildScrollView(
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: List.generate(
                                  labels.length,
                                  (i) => Padding(
                                      padding: EdgeInsets.only(bottom: 16),
                                      child: TextFormField(
                                          controller: controllers[i],
                                          decoration: InputDecoration(
                                              labelText: labels[i]),
                                          maxLines:
                                              labels[i].contains('Description')
                                                  ? 4
                                                  : 1,
                                          validator: (v) =>
                                              (v ?? '').trim().isEmpty
                                                  ? 'Required'
                                                  : null))))))),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text('Cancel')),
                FilledButton(
                    onPressed: () {
                      if (key.currentState!.validate()) {
                        Navigator.pop(context,
                            controllers.map((c) => c.text.trim()).toList());
                      }
                    },
                    child: Text('Save'))
              ]));
  // Dialog route may still animate; dispose controllers after that transition.
  Future<void>.delayed(Duration(milliseconds: 400), () {
    for (final c in controllers) {
      c.dispose();
    }
  });
  return result;
}

class PageHeader extends StatelessWidget {
  const PageHeader(this.title, this.subtitle,
      {super.key, this.actions = const []});
  final String title, subtitle;
  final List<Widget> actions;
  @override
  Widget build(BuildContext context) => Padding(
      padding: EdgeInsets.fromLTRB(24, 28, 24, 20),
      child: LayoutBuilder(builder: (context, constraints) {
        final compact = constraints.maxWidth < 620;
        final heading = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title, style: Theme.of(context).textTheme.headlineMedium),
              SizedBox(height: 6),
              Text(subtitle, style: Theme.of(context).textTheme.bodyMedium)
            ]);
        if (compact) {
          return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                heading,
                if (actions.isNotEmpty) ...[
                  SizedBox(height: 16),
                  Wrap(spacing: 10, runSpacing: 10, children: actions)
                ]
              ]);
        }
        return Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Expanded(child: heading),
          if (actions.isNotEmpty)
            Wrap(spacing: 10, runSpacing: 10, children: actions)
        ]);
      }));
}

class PagedList extends StatefulWidget {
  const PagedList(
      {super.key,
      required this.load,
      required this.builder,
      this.reverse = false,
      this.cacheKey,
      this.empty = 'Nothing here yet.'});
  final Future<List<JsonRow>> Function(int offset) load;
  final Widget Function(JsonRow row) builder;
  final String empty;
  final String? cacheKey;
  final bool reverse;
  @override
  State<PagedList> createState() => PagedListState();
}

class PagedListState extends State<PagedList> with WidgetsBindingObserver {
  static final snapshots = <String, List<JsonRow>>{};
  final rows = <JsonRow>[];
  Future<void>? activeRefresh;
  bool refreshQueued = false;
  void remember() {
    final key = widget.cacheKey;
    if (key == null) return;
    snapshots.remove(key);
    snapshots[key] = List.of(rows);
    while (snapshots.length > 24) snapshots.remove(snapshots.keys.first);
  }

  bool busy = false, more = true;
  Object? error;
  int generation = 0;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    rows.addAll(snapshots[widget.cacheKey] ?? const <JsonRow>[]);
    refresh();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) unawaited(refresh());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> refresh() {
    if (activeRefresh != null) {
      refreshQueued = true;
      return activeRefresh!;
    }
    if (busy) {
      refreshQueued = true;
      return Future.value();
    }
    activeRefresh = _refresh().whenComplete(() {
      activeRefresh = null;
      if (refreshQueued && mounted) {
        refreshQueued = false;
        unawaited(refresh());
      }
    });
    return activeRefresh!;
  }

  Future<void> _refresh() async {
    if (!mounted) return;
    if (busy) {
      refreshQueued = true;
      return;
    }
    final current = ++generation;
    busy = true;
    try {
      final result = <JsonRow>[];
      final target = rows.length < 30 ? 30 : rows.length;
      var hasMore = true;
      while (result.length < target && hasMore) {
        final page = await widget.load(result.length);
        result.addAll(page);
        hasMore = page.length == EduRepository.pageSize;
      }
      if (mounted && current == generation) {
        busy = false;
        final changed = jsonEncode(rows) != jsonEncode(result) ||
            error != null ||
            more != hasMore;
        if (changed)
          setState(() {
            rows
              ..clear()
              ..addAll(result);
            more = hasMore;
            error = null;
          });
        remember();
      }
    } catch (e) {
      if (mounted && current == generation) setState(() => error = e);
    } finally {
      busy = false;
    }
  }

  Future<void> next() async {
    if (busy || !more) return;
    final current = generation;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final result = await widget.load(rows.length);
      if (mounted && current == generation) {
        setState(() {
          rows.addAll(result);
          remember();
          more = result.length == EduRepository.pageSize;
        });
      }
    } catch (e) {
      if (mounted && current == generation) setState(() => error = e);
    } finally {
      if (mounted && current == generation) setState(() => busy = false);
      if (refreshQueued && mounted) {
        refreshQueued = false;
        unawaited(refresh());
      }
    }
  }

  @override
  Widget build(BuildContext context) => rows.isEmpty &&
          !busy &&
          error == null &&
          widget.empty == 'No messages yet'
      ? const ChatEmpty()
      : RefreshIndicator(
          onRefresh: refresh,
          child: ListView.builder(
              reverse: widget.reverse,
              padding: EdgeInsets.fromLTRB(24, 0, 24, 28),
              physics: AlwaysScrollableScrollPhysics(),
              itemCount: rows.length + 1,
              itemBuilder: (context, index) {
                if (index < rows.length)
                  return KeyedSubtree(
                      key: ValueKey(rows[index]['id'] ??
                          '${rows[index]['thread_kind']}/${rows[index]['thread_id'] ?? index}'),
                      child: widget.builder(rows[index]));
                return Padding(
                    padding: EdgeInsets.all(20),
                    child: Column(children: [
                      if (error != null) ...[
                        Container(
                            padding: EdgeInsets.all(16),
                            decoration: BoxDecoration(
                                color: Color(0xFFFFF3F4),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: Color(0xFFFFD9DE))),
                            child: Text('Could not load: $error',
                                style: TextStyle(color: AppColors.danger))),
                        TextButton(onPressed: refresh, child: Text('Retry'))
                      ] else if (busy)
                        const SizedBox.shrink()
                      else if (rows.isEmpty &&
                          widget.empty == 'No messages yet')
                        const ChatEmpty()
                      else if (rows.isEmpty)
                        Padding(
                            padding: EdgeInsets.symmetric(vertical: 30),
                            child: Column(children: [
                              Icon(Icons.inbox_outlined,
                                  size: 42,
                                  color: Theme.of(context)
                                      .colorScheme
                                      .onSurfaceVariant),
                              SizedBox(height: 12),
                              Text(widget.empty, textAlign: TextAlign.center)
                            ]))
                      else if (more)
                        OutlinedButton(
                            onPressed: next, child: Text('Load more'))
                    ]));
              }));
}
