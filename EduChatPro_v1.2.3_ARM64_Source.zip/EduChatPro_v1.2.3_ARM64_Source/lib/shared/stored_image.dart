import 'dart:async';
import 'package:flutter/foundation.dart';
import '../services/image_utils.dart';
import 'dart:io';
import 'dart:typed_data';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/material.dart';
import '../services/edu_repository.dart';

class MediaCache {
  static final pending = <String, Future<Uint8List>>{};
  static final hot = <String, Uint8List>{};
  static int hotBytes = 0;
  static void remember(String key, Uint8List bytes) {
    final old = hot.remove(key);
    if (old != null) hotBytes -= old.length;
    if (bytes.length > 2 * 1024 * 1024) return;
    hot[key] = bytes;
    hotBytes += bytes.length;
    while (hotBytes > 12 * 1024 * 1024 || hot.length > 100) {
      hotBytes -= hot.remove(hot.keys.first)!.length;
    }
  }

  static Future<void> store(
      EduRepository repo, String bucket, String path, Uint8List bytes) async {
    final key = '${repo.userId}/$bucket/$path';
    remember(key, bytes);
    try {
      final dir = Directory(
          '${(await getApplicationSupportDirectory()).path}/ecp-images/${repo.userId}');
      await dir.create(recursive: true);
      await File('${dir.path}/${sha256.convert(utf8.encode(key))}.img')
          .writeAsBytes(bytes, flush: false);
      unawaited(trim(dir));
    } catch (_) {} // A cache write failure must not turn a successful upload into an error.
  }

  static Future<Uint8List> get(EduRepository repo, String bucket, String path,
      {bool force = false}) {
    final key = '${repo.userId}/$bucket/$path';
    final cached = hot.remove(key);
    if (cached != null) {
      if (!force) {
        hot[key] = cached;
        return Future.value(cached);
      }
      hotBytes -= cached.length;
    }
    return pending.putIfAbsent(
        key,
        () => _load(repo, bucket, path, key, force).then((bytes) {
              remember(key, bytes);
              return bytes;
            }).whenComplete(() => pending.remove(key)));
  }

  static Future<Uint8List> _load(EduRepository repo, String bucket, String path,
      String key, bool force) async {
    final dir = Directory(
        '${(await getApplicationSupportDirectory()).path}/ecp-images/${repo.userId}');
    await dir.create(recursive: true);
    final file = File('${dir.path}/${sha256.convert(utf8.encode(key))}.img');
    if (!force && await file.exists()) {
      try {
        final bytes = await file.readAsBytes();
        if (bytes.isNotEmpty) return bytes;
      } catch (_) {}
    }
    var bytes = await repo.client.storage.from(bucket).download(path);
    if ((bucket == 'avatars' || bucket == 'group-images') &&
        bytes.length > 45000) bytes = await compute(thumbnail, bytes);
    if (bytes.length <= 10485760) {
      await file.writeAsBytes(bytes, flush: false);
      unawaited(trim(dir));
    }
    return bytes;
  }

  static DateTime? lastTrim;
  static Future<void> trim(Directory dir) async {
    if (lastTrim != null &&
        DateTime.now().difference(lastTrim!) < const Duration(minutes: 10))
      return;
    lastTrim = DateTime.now();
    try {
      final entries =
          await dir.list().where((e) => e is File).cast<File>().toList();
      final stats = <File, FileStat>{};
      for (final f in entries) {
        stats[f] = await f.stat();
      }
      entries.sort((a, b) => stats[a]!.modified.compareTo(stats[b]!.modified));
      var total = stats.values.fold<int>(0, (n, s) => n + s.size);
      for (final f in entries) {
        if (total <= 60 * 1024 * 1024) break;
        total -= stats[f]!.size;
        await f.delete();
      }
    } catch (_) {}
  }

  static Future<void> clear() async {
    pending.clear();
    hot.clear();
    hotBytes = 0;
    final dir = Directory(
        '${(await getApplicationSupportDirectory()).path}/ecp-images');
    if (await dir.exists()) await dir.delete(recursive: true);
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
  }
}

class StoredImage extends StatefulWidget {
  const StoredImage(
      {super.key,
      required this.repo,
      required this.bucket,
      required this.path,
      this.width,
      this.height,
      this.fit = BoxFit.cover,
      this.placeholder = const Icon(Icons.image_outlined),
      this.decodeWidth = 900});
  final EduRepository repo;
  final String bucket, path;
  final double? width, height;
  final BoxFit fit;
  final Widget placeholder;
  final int decodeWidth;
  @override
  State<StoredImage> createState() => _StoredImageState();
}

class _StoredImageState extends State<StoredImage> {
  late Future<Uint8List> future;
  void load({bool force = false}) {
    future =
        MediaCache.get(widget.repo, widget.bucket, widget.path, force: force);
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void didUpdateWidget(StoredImage old) {
    super.didUpdateWidget(old);
    if (old.path != widget.path ||
        old.bucket != widget.bucket ||
        old.repo.userId != widget.repo.userId) load();
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<Uint8List>(
      initialData: MediaCache
          .hot['${widget.repo.userId}/${widget.bucket}/${widget.path}'],
      future: future,
      builder: (context, s) => s.hasData
          ? Image.memory(s.data!,
              width: widget.width,
              height: widget.height,
              fit: widget.fit,
              cacheWidth: widget.decodeWidth,
              gaplessPlayback: true,
              errorBuilder: (_, __, ___) => widget.placeholder)
          : SizedBox(
              width: widget.width,
              height: widget.height,
              child: Center(
                  child: s.hasError
                      ? IconButton(
                          tooltip: 'Retry image',
                          icon: const Icon(Icons.refresh),
                          onPressed: () => setState(() => load(force: true)))
                      : widget.placeholder)));
}
