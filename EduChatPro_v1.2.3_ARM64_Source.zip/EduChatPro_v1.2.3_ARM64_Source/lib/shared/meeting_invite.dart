import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../config/app_config.dart';
import '../services/edu_repository.dart';
import 'widgets.dart';

Future<void> showMeetingInvite(BuildContext context, JsonRow meeting) async {
  final code = meeting['invite_code']?.toString();
  if (code == null || code.isEmpty) {
    notice(context, 'This meeting has no invite code.');
    return;
  }
  if (meeting['ended_at'] != null) {
    notice(context,
        'This meeting has ended. Create a new meeting to invite people.');
    return;
  }
  final link = Uri.parse(AppConfig.appUrl)
      .replace(queryParameters: {'invite': code}, fragment: '').toString();
  await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
              title: const Text('Meeting invite link'),
              content: SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    Text(meeting['title']?.toString() ?? 'Edu Chat Pro meeting',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    SelectableText(link),
                    const SizedBox(height: 12),
                    SelectableText('Meeting code: $code'),
                    const SizedBox(height: 12),
                    Text(meeting['group_id'] == null
                        ? 'Open this link to join on the web as a guest without an account, or paste it into the app’s Join box.'
                        : 'The host allows guests to join this meeting through the web link. Guests do not get access to group chats or files.')
                  ])),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(c),
                    child: const Text('Close')),
                TextButton.icon(
                    icon: const Icon(Icons.copy),
                    label: const Text('Copy link'),
                    onPressed: () => perform(c, () async {
                          await Clipboard.setData(ClipboardData(text: link));
                        }, success: 'Meeting link copied')),
                FilledButton.icon(
                    icon: const Icon(Icons.share),
                    label: const Text('Share'),
                    onPressed: () => perform(c, () async {
                          await Share.share(
                              '${meeting['title'] ?? 'Edu Chat Pro meeting'}\n$link',
                              subject: 'Edu Chat Pro meeting',
                              sharePositionOrigin:
                                  const Rect.fromLTWH(0, 0, 100, 100));
                        }))
              ]));
}
