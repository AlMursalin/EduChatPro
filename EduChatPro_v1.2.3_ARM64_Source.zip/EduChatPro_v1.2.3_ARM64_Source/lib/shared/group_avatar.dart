import 'stored_image.dart';
import 'package:flutter/material.dart';
import '../services/edu_repository.dart';

class GroupAvatar extends StatelessWidget {
  const GroupAvatar(
      {super.key, required this.repo, required this.path, this.radius = 22});
  final EduRepository repo;
  final String? path;
  final double radius;
  @override
  Widget build(BuildContext context) => CircleAvatar(
      radius: radius,
      backgroundColor: Theme.of(context).colorScheme.primaryContainer,
      child: path == null || path!.isEmpty
          ? const Icon(Icons.groups_rounded)
          : ClipOval(
              child: StoredImage(
                  key: ValueKey(path),
                  repo: repo,
                  bucket: 'group-images',
                  path: path!,
                  width: radius * 2,
                  height: radius * 2,
                  decodeWidth: 160,
                  placeholder: const Icon(Icons.groups_rounded))));
}
