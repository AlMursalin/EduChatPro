import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ThemeController {
  static final mode = ValueNotifier<ThemeMode>(ThemeMode.system);
  static const storage = FlutterSecureStorage();
  static Future<void> load() async {
    try {
      final saved = await storage.read(key: 'ecp_theme');
      mode.value = ThemeMode.values
          .firstWhere((m) => m.name == saved, orElse: () => ThemeMode.system);
    } catch (_) {}
  }

  static Future<void> set(ThemeMode value) async {
    mode.value = value;
    await storage.write(key: 'ecp_theme', value: value.name);
  }
}

class ThemePicker extends StatelessWidget {
  const ThemePicker({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
      valueListenable: ThemeController.mode,
      builder: (context, mode, _) => ListTile(
          leading: const Icon(Icons.dark_mode_outlined),
          title: const Text('Appearance'),
          trailing: DropdownButton<ThemeMode>(
              value: mode,
              items: const [
                DropdownMenuItem(
                    value: ThemeMode.system, child: Text('System')),
                DropdownMenuItem(value: ThemeMode.light, child: Text('Light')),
                DropdownMenuItem(value: ThemeMode.dark, child: Text('Dark'))
              ],
              onChanged: (v) {
                if (v != null) ThemeController.set(v);
              })));
}
