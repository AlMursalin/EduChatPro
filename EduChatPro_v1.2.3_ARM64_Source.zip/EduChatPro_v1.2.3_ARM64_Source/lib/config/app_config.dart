import 'dart:convert';

abstract final class AppConfig {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL',
      defaultValue: 'https://xaqctutviuxwjuqjuidx.supabase.co');
  static const supabaseKey = String.fromEnvironment('SUPABASE_ANON_KEY',
      defaultValue: 'sb_publishable_QEgk7l8liSUYgoo8Wgfbog_LFb7MkNI');

  static const _configuredAppUrl = String.fromEnvironment('APP_URL',
      defaultValue: 'https://nextechdigitalacademy.is-best.net');
  static const _configuredAuthRedirect = String.fromEnvironment(
      'AUTH_REDIRECT_URL',
      defaultValue: 'https://nextechdigitalacademy.is-best.net');

  /// On web, falling back to the current origin prevents copied meeting links
  /// from accidentally pointing at localhost after deployment.
  static String get appUrl =>
      _configuredAppUrl.isNotEmpty ? _configuredAppUrl : Uri.base.origin;

  static String get authRedirect => _configuredAuthRedirect.isNotEmpty
      ? _configuredAuthRedirect
      : Uri.base.origin;

  static bool get configured =>
      supabaseUrl.startsWith('https://') &&
      !supabaseUrl.contains('YOUR_PROJECT') &&
      isPublicKey(supabaseKey);

  static bool isPublicKey(String key) {
    if (key.startsWith('sb_publishable_')) return key.length > 20;
    try {
      final parts = key.split('.');
      if (parts.length != 3) return false;
      final claims = jsonDecode(
          utf8.decode(base64Url.decode(base64Url.normalize(parts[1]))));
      return claims['role'] == 'anon';
    } catch (_) {
      return false;
    }
  }
}
