abstract interface class LocalMeetingRecorder {
  bool get supported;
  bool get isRecording;

  /// On web this records a user-selected screen/window/tab locally. When the
  /// browser exposes tab/system audio it is mixed with the local microphone.
  Future<void> start(
      {required String meetingId, required bool participantsConsented});

  Future<void> stop();

  /// Saves/downloads the recording locally and returns the generated filename.
  Future<String> save();

  Future<void> dispose();
}
