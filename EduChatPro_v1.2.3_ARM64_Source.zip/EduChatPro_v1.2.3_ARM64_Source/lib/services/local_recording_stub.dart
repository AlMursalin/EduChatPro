import 'local_recording_base.dart';

LocalMeetingRecorder createPlatformRecorder() => UnsupportedLocalRecorder();

class UnsupportedLocalRecorder implements LocalMeetingRecorder {
  @override
  bool get supported => false;

  @override
  bool get isRecording => false;

  @override
  Future<void> start(
      {required String meetingId, required bool participantsConsented}) async {
    throw UnsupportedError(
        'Local meeting recording is not available on this platform build.');
  }

  @override
  Future<void> stop() async {
    throw UnsupportedError('No recording is active.');
  }

  @override
  Future<String> save() async {
    throw UnsupportedError('No recording file exists.');
  }

  @override
  Future<void> dispose() async {}
}
