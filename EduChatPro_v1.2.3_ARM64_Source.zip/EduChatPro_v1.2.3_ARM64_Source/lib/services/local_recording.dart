export 'local_recording_base.dart';

import 'local_recording_base.dart';
import 'local_recording_stub.dart'
    if (dart.library.html) 'local_recording_web.dart';

LocalMeetingRecorder createLocalMeetingRecorder() => createPlatformRecorder();
