import 'dart:async';
import 'package:flutter/widgets.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// One debounced refresh on resume and on authorized database events.
class LiveRefresh with WidgetsBindingObserver {
  LiveRefresh(this.client, this.onRefresh,
      {required List<String> tables,
      String? filterColumn,
      String? filterValue}) {
    WidgetsBinding.instance.addObserver(this);
    channel = client.channel('live-${DateTime.now().microsecondsSinceEpoch}');
    for (final table in tables) {
      channel!.onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: table,
          filter: filterColumn == null
              ? null
              : PostgresChangeFilter(
                  type: PostgresChangeFilterType.eq,
                  column: filterColumn,
                  value: filterValue!),
          callback: (_) => request());
    }
    channel!.subscribe((status, error) {
      if (status == RealtimeSubscribeStatus.subscribed) request();
    });
  }
  final SupabaseClient client;
  final Future<void> Function() onRefresh;
  RealtimeChannel? channel;
  Timer? timer;
  bool disposed = false, running = false, again = false;
  void request() {
    timer?.cancel();
    timer = Timer(const Duration(milliseconds: 350), () => _run());
  }

  Future<void> _run() async {
    if (disposed) return;
    if (running) {
      again = true;
      return;
    }
    running = true;
    try {
      await onRefresh();
    } catch (_) {
    } finally {
      running = false;
      if (again && !disposed) {
        again = false;
        request();
      }
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) request();
  }

  void dispose() {
    disposed = true;
    timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    if (channel != null) unawaited(client.removeChannel(channel!));
  }
}
