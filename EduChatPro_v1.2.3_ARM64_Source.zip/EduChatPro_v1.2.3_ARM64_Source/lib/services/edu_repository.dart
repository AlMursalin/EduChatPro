import 'package:flutter/foundation.dart';
import 'image_utils.dart';
import 'dart:convert';
import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import '../core/validation.dart';

typedef JsonRow = Map<String, dynamic>;

/// All access is subject to server-side RLS. UI permissions are convenience only.
class EduRepository {
  EduRepository(this.client);
  final SupabaseClient client;
  String get userId => client.auth.currentUser!.id;
  static const pageSize = 30;

  Future<void> sendMedia(
      {String? group,
      String? other,
      required Uint8List bytes,
      required String name,
      required String mime,
      int durationMs = 0}) async {
    if (bytes.isEmpty || bytes.length > 10485760)
      throw const FormatException('Choose a file under 10 MB.');
    final bucket = group == null ? 'direct-files' : 'group-files';
    final path = group == null
        ? '$userId/$other/${const Uuid().v4()}/$name'
        : '$group/${const Uuid().v4()}/$name';
    await client.storage
        .from(bucket)
        .uploadBinary(path, bytes, fileOptions: FileOptions(contentType: mime));
    try {
      if (group != null) {
        final file = await client
            .from('group_files')
            .insert({
              'group_id': group,
              'uploaded_by': userId,
              'name': name,
              'object_path': path,
              'size_bytes': bytes.length,
              'mime_type': mime
            })
            .select()
            .single();
        try {
          await client.from('group_messages').insert({
            'group_id': group,
            'sender_id': userId,
            'body':
                mime.startsWith('audio/') ? 'Voice message' : 'Shared a file',
            'file_id': file['id'],
            'duration_ms': durationMs
          });
        } catch (_) {
          await client.from('group_files').delete().eq('id', file['id']);
          rethrow;
        }
      } else {
        await client.rpc('send_direct_attachment', params: {
          'other': other,
          'path_input': path,
          'name_input': name,
          'mime_input': mime,
          'size_input': bytes.length,
          'duration_input': durationMs
        });
      }
    } catch (_) {
      await client.storage.from(bucket).remove([path]);
      rethrow;
    }
  }

  Future<void> addForumComment(
      {required String postId,
      required String body,
      String? parentId,
      String? imageName,
      Uint8List? imageBytes}) async {
    String? path;
    try {
      if (imageBytes != null) {
        final extension = imageName?.split('.').last.toLowerCase();
        final mime = {
          'jpg': 'image/jpeg',
          'jpeg': 'image/jpeg',
          'png': 'image/png',
          'webp': 'image/webp',
          'mp4': 'video/mp4',
          'mov': 'video/quicktime',
          'webm': 'video/webm'
        }[extension];
        if (mime == null ||
            imageBytes.isEmpty ||
            imageBytes.length > 10 * 1024 * 1024) {
          throw const FormatException('Choose a photo or video under 10 MB.');
        }
        final video = mime.startsWith('video/');
        path =
            '$userId/comments/${const Uuid().v4()}.${video ? extension : 'jpg'}';
        await client.storage.from('forum-images').uploadBinary(
            path, video ? imageBytes : await compute(feedImage, imageBytes),
            fileOptions: FileOptions(contentType: video ? mime : 'image/jpeg'));
      }
      await add('forum_comments', {
        'post_id': postId,
        'author_id': userId,
        'body': body.trim(),
        'parent_id': parentId,
        if (path != null) 'image_path': path,
      });
    } catch (_) {
      if (path != null) {
        try {
          await client.storage.from('forum-images').remove([path]);
        } catch (_) {}
      }
      rethrow;
    }
  }

  Future<void> deleteForumComment(JsonRow comment) async {
    await remove('forum_comments', comment['id']);
    final path = comment['image_path'];
    if (path is String) {
      try {
        await client.storage.from('forum-images').remove([path]);
      } catch (_) {}
    }
  }

  /// Read posts independently of optional profile relationships. A missing or
  /// inaccessible author profile must not prevent the community feed loading.
  Future<List<JsonRow>> forumPage({int offset = 0, String? postId}) async {
    final rows = await page(postId == null ? 'forum_posts' : 'forum_comments',
        offset: offset,
        filter: postId == null ? null : 'post_id',
        value: postId);
    final authorKey = postId == null ? 'public_author_id' : 'author_id';
    final ids = rows
        .where((r) => r['anonymous'] != true)
        .map((r) => r[authorKey])
        .whereType<String>()
        .toSet()
        .toList();
    final authors = <String, JsonRow>{};
    if (ids.isNotEmpty) {
      try {
        final profiles = await client
            .from('profiles')
            .select('id,full_name,avatar_path')
            .inFilter('id', ids);
        for (final profile in profiles) {
          authors[profile['id'] as String] = profile;
        }
      } on PostgrestException {
        // Author metadata is optional; post access is still controlled by RLS.
      }
    }
    return rows.map((r) => {...r, 'profiles': authors[r[authorKey]]}).toList();
  }

  Future<void> saveForumPost(
      {String? postId,
      required String body,
      required bool anonymous,
      String? imagePath,
      bool changesImage = false}) async {
    try {
      await client.rpc('save_social_post', params: {
        'post': postId,
        'body_text': body,
        'is_anonymous': anonymous,
        'image_path_input': imagePath,
      });
    } on PostgrestException catch (e) {
      // Fall back only for an absent RPC, never for denied access or validation.
      if (e.code != 'PGRST202' && e.code != '42883') rethrow;
      if (changesImage) {
        throw const FormatException(
            'Image posts need the Forum database update. You can still publish a text post.');
      }
      await client.rpc('save_post', params: {
        'post': postId,
        'title_text': String.fromCharCodes(body.runes.take(160)),
        'body_text': body,
        'is_anonymous': anonymous,
      });
    }
  }

  Future<List<JsonRow>> page(String table,
      {String? filter,
      Object? value,
      int offset = 0,
      String order = 'created_at',
      String select = '*'}) async {
    final columns = table == 'profiles' && select == '*'
        ? 'id,full_name,avatar_path,status,created_at,updated_at,last_active_at'
        : select;
    var query = client.from(table).select(columns);
    if (filter != null && value != null) query = query.eq(filter, value);
    final ordered = query
        .order(order, ascending: false)
        .order(table == 'group_members' ? 'user_id' : 'id', ascending: false);
    return List<JsonRow>.from(
        await ordered.range(offset, offset + pageSize - 1));
  }

  Future<JsonRow> profile() async =>
      JsonRow.from(await client.rpc('my_profile'));
  Future<String> role() async => (await client
      .from('user_roles')
      .select('role')
      .eq('user_id', userId)
      .single())['role'] as String;
  Future<bool> allowed(String permission) async =>
      await client.rpc('has_permission', params: {'p': permission}) as bool;
  Future<void> add(String table, JsonRow row) async {
    await client.from(table).insert(row);
  }

  Future<void> update(String table, String id, JsonRow row,
      {String key = 'id'}) async {
    await client.from(table).update(row).eq(key, id);
  }

  Future<void> remove(String table, String id) async {
    await client.from(table).delete().eq('id', id);
  }

  Future<void> heartbeat() async {
    await client.rpc('touch_active');
  }

  Future<JsonRow> uploadFile(String group, String name, Uint8List bytes) async {
    if (bytes.isEmpty || bytes.length > 10 * 1024 * 1024) {
      throw const FormatException('Choose a file between 1 byte and 10 MB.');
    }
    var safeName = Validation.safeFileName(name);
    var mime = Validation.mimeTypes[safeName.split('.').last.toLowerCase()];
    if (mime == null) {
      throw const FormatException('This file type is not allowed.');
    }
    if (mime.startsWith('image/')) {
      bytes = await compute(feedImage, bytes);
      mime = 'image/jpeg';
      safeName = '${safeName.split('.').first}.jpg';
    }
    final path = '$group/${const Uuid().v4()}/$safeName';
    await client.storage
        .from('group-files')
        .uploadBinary(path, bytes, fileOptions: FileOptions(contentType: mime));
    try {
      return JsonRow.from(await client
          .from('group_files')
          .insert({
            'group_id': group,
            'name': safeName,
            'object_path': path,
            'size_bytes': bytes.length,
            'mime_type': mime
          })
          .select()
          .single());
    } catch (_) {
      await client.storage.from('group-files').remove([path]);
      rethrow;
    }
  }

  Future<void> deleteFiles(List<JsonRow> files) async {
    // Storage first; if the metadata delete fails, retrying is safe.
    for (final file in files) {
      await client.storage
          .from('group-files')
          .remove([file['object_path'] as String]);
      await remove('group_files', file['id'] as String);
    }
  }

  Future<void> deleteAllFiles(String group) async {
    while (true) {
      final files = await page('group_files', filter: 'group_id', value: group);
      if (files.isEmpty) return;
      await deleteFiles(files);
    }
  }

  Future<String> signedFile(String path) =>
      client.storage.from('group-files').createSignedUrl(path, 60);
  Future<String> createMeeting(String title, {String? group}) async {
    final row = await client
        .from('meetings')
        .insert({'title': title, 'group_id': group})
        .select()
        .single();
    return row['id'] as String;
  }

  /// Accepts either a raw invite UUID or a full Edu Chat Pro invite URL.
  Future<String> joinInvite(String input) async {
    final match = RegExp(
            r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}')
        .firstMatch(input.trim());
    if (match == null) {
      throw const FormatException(
          'Enter a valid Edu Chat Pro meeting invite link or code.');
    }
    return await client.rpc('join_invite', params: {'code': match.group(0)})
        as String;
  }

  /// Attendance is tracked per connection, not just per account. This allows
  /// the same account to stay in the same meeting from a phone and laptop at
  /// the same time without one device closing the other device's attendance.
  Future<void> attendance(String id, String connectionId,
      {bool leaving = false}) async {
    try {
      await client.rpc('attendance_heartbeat', params: {
        'meeting': id,
        'connection': connectionId,
        'leaving': leaving,
      });
    } on PostgrestException catch (e) {
      // Backward compatibility with older Edu Chat Pro databases that still expose
      // attendance_heartbeat(meeting, leaving). A missing attendance upgrade
      // must never tear down an otherwise working audio/video call.
      final message = e.message.toLowerCase();
      if (e.code == 'PGRST202' ||
          message.contains('function') ||
          message.contains('connection')) {
        await client.rpc('attendance_heartbeat', params: {
          'meeting': id,
          'leaving': leaving,
        });
        return;
      }
      rethrow;
    }
  }

  /// Approves a one-time web QR login request scanned by this already
  /// authenticated mobile app. No password or access token is placed in the QR.
  Future<void> approveWebQrLogin(String raw) async {
    dynamic decoded;
    try {
      decoded = Uri.decodeComponent(raw);
    } catch (_) {
      decoded = raw;
    }
    Map<String, dynamic> data;
    try {
      data = Map<String, dynamic>.from(jsonDecode(decoded as String));
    } catch (_) {
      throw const FormatException(
          'This is not an Edu Chat Pro web login QR code.');
    }
    if (data['type'] != 'educhat_web_login' ||
        data['session_id'] is! String ||
        data['secret'] is! String) {
      throw const FormatException(
          'This is not an Edu Chat Pro web login QR code.');
    }
    final payload = {
      'action': 'approve',
      'session_id': data['session_id'],
      'secret': data['secret'],
    };
    var endpoint = 'qr-auth-link';
    var refreshed = false;
    FunctionResponse result;
    while (true) {
      try {
        final session = client.auth.currentSession;
        if (session == null)
          throw StateError('Sign in to the mobile app first.');
        result = await client.functions.invoke(endpoint,
            body: payload,
            headers: {'Authorization': 'Bearer ${session.accessToken}'});
        break;
      } on FunctionException catch (e) {
        final details = e.details;
        final code = details is Map ? details['code']?.toString() : null;
        // Only switch names when the function itself is absent, never when a
        // server rejects a QR session. Both versions use the same session table.
        if (e.status == 404 &&
            code == 'NOT_FOUND' &&
            endpoint == 'qr-auth-link') {
          endpoint = 'qr-login';
          continue;
        }
        if (e.status == 401 && !refreshed) {
          refreshed = true;
          await client.auth.refreshSession();
          continue;
        }
        if (e.status == 410 || e.status == 409) {
          throw StateError(
              'This QR expired or was already used. Generate a new QR on your computer and tap Retry scan.');
        }
        if (e.status == 401)
          throw StateError(
              'Your login expired. Sign in again, then scan a new QR.');
        if (e.status == 404 && code == 'NOT_FOUND') {
          throw StateError(
              'The QR login service is not deployed on the server.');
        }
        final message =
            details is Map ? details['error'] ?? details['message'] : null;
        throw StateError(message?.toString() ??
            'Could not approve web login. Check your connection and scan a fresh QR.');
      }
    }
    if (result.status < 200 || result.status >= 300) {
      final message = result.data is Map ? result.data['error'] : null;
      throw StateError(message?.toString() ?? 'Could not approve web login.');
    }
  }

  Future<String> attendanceCsv(String meeting) async {
    final lines = <String>[
      'Name,User ID,Connection ID,Meeting ID,Join time,Leave time,Duration seconds,Last heartbeat'
    ];
    var offset = 0;
    while (true) {
      final rows = await page('meeting_attendance',
          filter: 'meeting_id',
          value: meeting,
          offset: offset,
          order: 'joined_at',
          select: '*,profiles(full_name)');
      for (final row in rows) {
        lines.add([
          row['profiles']?['full_name'],
          row['user_id'],
          row['connection_id'],
          row['meeting_id'],
          row['joined_at'],
          row['left_at'],
          row['duration_seconds'],
          row['last_seen_at']
        ].map(Validation.csvCell).join(','));
      }
      if (rows.length < pageSize) break;
      offset += rows.length;
    }
    return '\uFEFF${lines.join('\r\n')}';
  }
}
