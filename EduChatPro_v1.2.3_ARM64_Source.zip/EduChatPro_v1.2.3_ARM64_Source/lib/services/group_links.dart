import 'dart:async';
import 'package:app_links/app_links.dart';
import 'package:flutter/foundation.dart';
import '../config/app_config.dart';

class GroupLinks {
  static final pending = ValueNotifier<String?>(null);
  static final _links = AppLinks();
  static StreamSubscription<Uri>? _subscription;
  static Future<void> initialize() async {
    _subscription ??= _links.uriLinkStream.listen(accept, onError: (_) {});
    try {
      final uri = await _links.getInitialLink();
      if (uri != null) accept(uri);
    } catch (_) {}
  }

  static void accept(Uri uri) {
    final trusted = uri.scheme == 'educhat' && uri.host == 'group' ||
        uri.scheme == 'https' && uri.host == Uri.parse(AppConfig.appUrl).host;
    if (!trusted) return;
    final code =
        uri.queryParameters['group_invite'] ?? uri.queryParameters['token'];
    if (code != null &&
        RegExp(r'^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$')
            .hasMatch(code)) pending.value = code;
  }
}
