// Deprecated compatibility file retained so older imports fail gracefully in IDE search.
// EduChat Pro V7 uses SupabaseWebRtcBackend from supabase_webrtc_backend.dart.
export 'supabase_webrtc_backend.dart';
