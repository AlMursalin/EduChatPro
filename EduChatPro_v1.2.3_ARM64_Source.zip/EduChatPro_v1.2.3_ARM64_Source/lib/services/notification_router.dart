import 'package:flutter/material.dart';
import 'edu_repository.dart';
import '../features/direct_chat/direct_chat_page.dart';
import '../features/groups/group_detail_page.dart';
import '../features/forum/forum_page.dart';
import '../features/meetings/meeting_room_page.dart';

Future<void> openNotificationDestination(
    BuildContext context, EduRepository repo, JsonRow n) async {
  final kind = n['kind']?.toString() ?? '', id = n['resource_id']?.toString();
  if (id == null || kind == 'call_cancel') return;
  Widget? page;
  if (kind == 'direct_message') {
    final m = await repo.client
        .from('direct_messages')
        .select('sender_id,recipient_id')
        .eq('id', id)
        .maybeSingle();
    if (m == null) throw StateError('This message is no longer available.');
    final other =
        m['sender_id'] == repo.userId ? m['recipient_id'] : m['sender_id'];
    final p = await repo.client
        .from('profiles')
        .select('id,full_name,avatar_path')
        .eq('id', other)
        .single();
    page = DirectChatPage(
        repo: repo,
        otherUserId: other,
        otherName: p['full_name'] ?? 'User',
        otherAvatarPath: p['avatar_path']);
  } else if ([
    'group_invite',
    'group_messages',
    'group_message',
    'announcement',
    'group_files'
  ].contains(kind)) {
    final g =
        await repo.client.from('groups').select().eq('id', id).maybeSingle();
    if (g == null)
      throw StateError('This group is no longer available to your account.');
    page = GroupDetailPage(repo: repo, group: g);
  } else if ([
    'direct_call_audio',
    'direct_call_video',
    'group_call',
    'meetings',
    'missed_call'
  ].contains(kind)) {
    final m =
        await repo.client.from('meetings').select().eq('id', id).maybeSingle();
    if (m == null || m['ended_at'] != null)
      throw StateError('This call has ended.');
    page = MeetingRoomPage(
        repo: repo, meetingId: id, autoJoin: true, startWithMic: true);
  } else if (['forum', 'forum_post', 'forum_reaction', 'forum_comments']
      .contains(kind)) {
    final post = await repo.client
        .from('forum_posts')
        .select()
        .eq('id', id)
        .maybeSingle();
    if (post != null)
      page = DiscussionPage(repo: repo, post: post, moderate: false);
  }
  if (n['id'] != null)
    await repo.update('notifications', n['id'],
        {'read_at': DateTime.now().toUtc().toIso8601String()});
  if (context.mounted && page != null)
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page!));
}
