import 'dart:async';
import '../shared/stored_image.dart';
import 'package:flutter/foundation.dart';
import 'edu_repository.dart';
import 'live_refresh.dart';

/// Share one subscription and batch lookup across all visible author avatars.
class ProfilePhotos extends ChangeNotifier {
  ProfilePhotos._(this.repo) : ownerId = repo.userId {
    live = LiveRefresh(repo.client, refresh, tables: ['profiles']);
  }
  static final Map<String, ProfilePhotos> _stores = {};
  static ProfilePhotos acquire(EduRepository repo, String id) {
    final store = _stores.putIfAbsent(repo.userId, () => ProfilePhotos._(repo));
    store.refs[id] = (store.refs[id] ?? 0) + 1;
    if(!store.profiles.containsKey(id))store.live.request();
    return store;
  }

  final EduRepository repo;
  final String ownerId;
  final refs = <String, int>{};
  final profiles = <String, JsonRow>{};
  late LiveRefresh live;
  bool closed = false;
  Future<void> refresh() async {
    final ids = refs.keys.toList();
    for (var start = 0; start < ids.length; start += 80) {
      final rows = await repo.client
          .from('profiles')
          .select('id,avatar_path,full_name')
          .inFilter('id', ids.skip(start).take(80).toList());
      if (closed) return;
      var changed = false;
      for (final row in rows) {
        final id = row['id'] as String;
        final old = profiles[id];
        if (old == null ||
            old['avatar_path'] != row['avatar_path'] ||
            old['full_name'] != row['full_name']) {
          profiles[id] = row;
          final path = row['avatar_path'] as String?;
          if (path != null && path.isNotEmpty)
            unawaited(MediaCache.get(repo, 'avatars', path)
                .then<void>((_) {})
                .catchError((Object _) {}));
          changed = true;
        }
      }
      if (changed) notifyListeners();
    }
  }

  void release(String id) {
    final count = (refs[id] ?? 1) - 1;
    if (count > 0) {
      refs[id] = count;
    } else {
      refs.remove(id);
    }
    if (refs.isEmpty) {
      closed = true;
      live.dispose();
      if (identical(_stores[ownerId], this)) _stores.remove(ownerId);
      dispose();
    }
  }
}
