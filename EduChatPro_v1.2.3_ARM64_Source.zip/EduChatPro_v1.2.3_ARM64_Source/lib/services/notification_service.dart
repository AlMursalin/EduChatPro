import '../firebase_options.dart';
import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'edu_repository.dart';

const pushOptions = DefaultFirebaseOptions.android;
bool get hasPushOptions => true;

@pragma('vm:entry-point')
Future<void> eduBackgroundMessage(RemoteMessage message) async {
  if (Firebase.apps.isEmpty)
    await Firebase.initializeApp(options: hasPushOptions ? pushOptions : null);
  // Android displays notification payloads while the app is closed. Never store
  // a service-account key or use privileged Supabase credentials in this app.
}

Future<bool> initializePush() async {
  if (!kIsWeb &&
      defaultTargetPlatform != TargetPlatform.android &&
      defaultTargetPlatform != TargetPlatform.iOS) return false;
  if (Firebase.apps.isEmpty) {
    try {
      await Firebase.initializeApp(
          options: hasPushOptions ? pushOptions : null);
    } catch (_) {
      return false;
    }
  }
  await FirebaseMessaging.instance.setAutoInitEnabled(true);
  FirebaseMessaging.onBackgroundMessage(eduBackgroundMessage);
  return true;
}

Future<NotificationSettings>? _permissionRequest;
Future<NotificationSettings> requestPushPermission() {
  return _permissionRequest ??= FirebaseMessaging.instance
      .requestPermission(alert: true, badge: true, sound: true)
      .whenComplete(() => _permissionRequest = null);
}

class NotificationService {
  NotificationService(this.repo) : ownerId = repo.userId;
  final EduRepository repo;
  final String ownerId;
  static const native = MethodChannel('educhat/notifications');
  StreamSubscription<String>? refresh;
  StreamSubscription<RemoteMessage>? opened, foreground;
  String? token;
  bool disposed = false, unregistering = false;
  bool registering = false;
  Timer? retryTimer;
  DateTime? lastRegistration;
  final seen = <String>{};
  bool get android =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

  Future<void> resume(
      {required void Function(Map<String, dynamic>) onOpen}) async {
    if (android) {
      native.setMethodCallHandler((call) async {
        if (!disposed &&
            call.method == 'notificationTap' &&
            call.arguments is Map)
          onOpen(Map<String, dynamic>.from(call.arguments as Map));
      });
      final initial =
          await native.invokeMapMethod<String, dynamic>('initialNotification');
      if (initial != null && !disposed) onOpen(initial);
    }
    if (!await initializePush()) {
      if (android && !disposed)
        await native.invokeMethod<void>('requestPermission');
      return;
    }
    if (disposed) return;
    await opened?.cancel();
    await foreground?.cancel();
    opened = FirebaseMessaging.onMessageOpenedApp.listen((m) {
      if (!disposed) onOpen(m.data);
    });
    foreground = FirebaseMessaging.onMessage.listen((m) {
      if ([
        'direct_call_audio',
        'direct_call_video',
        'group_call',
        'call_cancel'
      ].contains(m.data['kind'])) return;
      unawaited(showNotification({
        'id': m.data['notification_id'] ?? m.messageId,
        'kind': m.data['kind'],
        'resource_id': m.data['resource_id'],
        'title': m.notification?.body ?? 'New Edu Chat Pro update',
      }));
    });
    final initial = await FirebaseMessaging.instance.getInitialMessage();
    if (initial != null && !disposed) onOpen(initial.data);
    await enablePush();
  }

  Future<void> showNotification(JsonRow row) async {
    if (!android || disposed) return;
    final id = row['id']?.toString();
    if (id == null || seen.contains(id)) return;
    seen.add(id);
    if (seen.length > 256) seen.remove(seen.first);
    final kind = row['kind']?.toString() ?? '';
    if (['direct_call_audio', 'direct_call_video', 'group_call', 'call_cancel']
        .contains(kind)) return;
    try {
      await native.invokeMethod<bool>('show', {
        'id': id,
        'title': 'Edu Chat Pro',
        'body': row['title']?.toString() ?? 'New update',
        'call': kind == 'direct_call_audio' ||
            kind == 'direct_call_video' ||
            kind == 'meetings',
      });
    } catch (_) {
      seen.remove(id);
    }
  }

  Future<void> enablePush() async {
    if (!await initializePush())
      throw StateError('Firebase could not initialize.');
    final permission = await requestPushPermission();
    if (permission.authorizationStatus == AuthorizationStatus.denied)
      throw StateError('Allow notifications in your phone settings.');
    refresh ??= FirebaseMessaging.instance.onTokenRefresh.listen((t) async {
      if (disposed) return;
      try {
        await save(t);
        token = t;
        lastRegistration = DateTime.now();
      } catch (_) {
        _retryLater();
      }
    });
    await retryRegistration(force: true);
  }

  void _retryLater() {
    retryTimer?.cancel();
    if (!disposed)
      retryTimer = Timer(
          const Duration(seconds: 30), () => retryRegistration(force: true));
  }

  Future<void> retryRegistration({bool force = false}) async {
    if (disposed || unregistering || registering) return;
    if (!force &&
        lastRegistration != null &&
        DateTime.now().difference(lastRegistration!).inMinutes < 10) return;
    registering = true;
    try {
      if (!await initializePush())
        throw StateError('Notification service unavailable.');
      final permission =
          await FirebaseMessaging.instance.getNotificationSettings();
      if (permission.authorizationStatus == AuthorizationStatus.denied) return;
      final value = await FirebaseMessaging.instance
          .getToken()
          .timeout(const Duration(seconds: 15));
      if (value == null) throw StateError('Waiting for a notification token.');
      await save(value);
      token = value;
      lastRegistration = DateTime.now();
      retryTimer?.cancel();
    } catch (_) {
      _retryLater();
    } finally {
      registering = false;
    }
  }

  Future<void> save(String value) async {
    if (disposed ||
        unregistering ||
        repo.client.auth.currentUser?.id != ownerId) return;
    await repo.client.from('device_tokens').upsert({
      'user_id': ownerId,
      'token': value,
      'platform': kIsWeb ? 'web' : defaultTargetPlatform.name,
    });
  }

  Future<void> unregister() async {
    unregistering = true;
    retryTimer?.cancel();
    await refresh?.cancel();
    try {
      if (token == null && Firebase.apps.isNotEmpty)
        token = await FirebaseMessaging.instance.getToken();
      if (token != null)
        await repo.client
            .from('device_tokens')
            .delete()
            .eq('user_id', ownerId)
            .eq('token', token!);
    } finally {
      // Revoking the FCM token also prevents future alerts when database cleanup
      // cannot complete due to a network outage during sign-out.
      if (Firebase.apps.isNotEmpty) {
        try {
          await FirebaseMessaging.instance.deleteToken();
        } catch (_) {}
      }
      if (android) {
        try {
          await native.invokeMethod<void>('clear');
        } catch (_) {}
      }
    }
  }

  void dispose() {
    disposed = true;
    retryTimer?.cancel();
    refresh?.cancel();
    opened?.cancel();
    foreground?.cancel();
    if (android) native.setMethodCallHandler(null);
  }
}
