import 'dart:typed_data';
import 'package:image/image.dart' as img;

/// Normalize camera orientation and bound crop-preview memory off the UI thread.
Uint8List cropPreview(Uint8List bytes) {
  final source = img.decodeImage(bytes);
  if (source == null)
    throw const FormatException('Choose a supported JPG, PNG or WebP image.');
  var image = img.bakeOrientation(source);
  if (image.width > 1600 || image.height > 1600) {
    image = image.width >= image.height
        ? img.copyResize(image, width: 1600)
        : img.copyResize(image, height: 1600);
  }
  return Uint8List.fromList(img.encodeJpg(image, quality: 95));
}

/// Decode and re-encode rather than trusting an uploaded file's extension.
Uint8List thumbnail(Uint8List bytes) {
  final decoded = img.decodeImage(bytes);
  if (decoded == null) throw const FormatException('Invalid image');
  return Uint8List.fromList(
      img.encodeJpg(img.copyResize(decoded, width: 256), quality: 76));
}

Uint8List feedImage(Uint8List bytes) {
  final decoded = img.decodeImage(bytes);
  if (decoded == null) throw const FormatException('Invalid image');
  var image = img.bakeOrientation(decoded);
  if (image.width > 1280 || image.height > 1280)
    image = image.width >= image.height
        ? img.copyResize(image, width: 1280)
        : img.copyResize(image, height: 1280);
  return Uint8List.fromList(img.encodeJpg(image, quality: 82));
}
