import 'dart:html' as html;
import 'dart:js_util' as js_util;
import 'dart:web_audio' as web_audio;
import 'dart:async';

import 'local_recording_base.dart';

LocalMeetingRecorder createPlatformRecorder() => BrowserMeetingRecorder();

/// Browser-local screen recorder.
///
/// The browser itself asks which screen/window/tab may be captured. When the
/// selected surface exposes audio (for example a Chrome tab with "share tab
/// audio" enabled), that audio is mixed with the local microphone. Browsers do
/// not expose every system-audio source on every OS, so remote audio capture is
/// dependent on what the selected surface provides.
class BrowserMeetingRecorder implements LocalMeetingRecorder {
  html.MediaStream? _displayStream;
  html.MediaStream? _microphoneStream;
  html.MediaStream? _recordingStream;
  html.MediaRecorder? _recorder;
  web_audio.AudioContext? _audioContext;
  final List<html.Blob> _chunks = <html.Blob>[];
  Completer<void>? _stopped;
  String? _meetingId;
  String _mimeType = 'video/webm';
  bool _recording = false;

  @override
  bool get supported {
    final devices = html.window.navigator.mediaDevices;
    return devices != null &&
        js_util.hasProperty(devices, 'getDisplayMedia') &&
        js_util.hasProperty(html.window, 'MediaRecorder');
  }

  @override
  bool get isRecording => _recording;

  @override
  Future<void> start(
      {required String meetingId, required bool participantsConsented}) async {
    if (!participantsConsented) {
      throw StateError('Participant recording consent is required.');
    }
    if (!supported) {
      throw UnsupportedError(
          'Screen recording is not supported by this browser. Use a current Chrome, Edge, or another browser with Screen Capture and MediaRecorder support.');
    }
    if (_recording) return;

    await _releaseStreams();
    _chunks.clear();
    _meetingId = meetingId;

    final devices = html.window.navigator.mediaDevices!;
    try {
      final promise =
          js_util.callMethod<Object>(devices, 'getDisplayMedia', <Object>[
        js_util.jsify(<String, Object>{
          'video': <String, Object>{
            'frameRate': <String, int>{'ideal': 15, 'max': 30}
          },
          // The browser may ignore this for surfaces that cannot expose
          // system/tab audio.
          'audio': true,
        }) as Object
      ]);
      _displayStream = await js_util.promiseToFuture<html.MediaStream>(promise);
    } catch (e) {
      throw StateError(
          'Screen recording was cancelled or blocked by the browser. On a public site, use HTTPS. Details: $e');
    }

    // Microphone is optional. If permission is denied we still preserve the
    // screen/tab capture instead of throwing away the whole recording.
    try {
      _microphoneStream = await devices.getUserMedia(<String, Object>{
        'audio': <String, bool>{
          'echoCancellation': true,
          'noiseSuppression': true,
          'autoGainControl': true,
        },
        'video': false,
      });
    } catch (_) {
      _microphoneStream = null;
    }

    final combined = html.MediaStream();
    for (final track in _displayStream!.getVideoTracks()) {
      combined.addTrack(track);
    }

    final hasDisplayAudio = _displayStream!.getAudioTracks().isNotEmpty;
    final hasMicrophoneAudio =
        _microphoneStream?.getAudioTracks().isNotEmpty ?? false;

    if (hasDisplayAudio || hasMicrophoneAudio) {
      try {
        final context = web_audio.AudioContext();
        final destination = context.createMediaStreamDestination();
        if (hasDisplayAudio) {
          context
              .createMediaStreamSource(_displayStream!)
              .connectNode(destination);
        }
        if (hasMicrophoneAudio) {
          context
              .createMediaStreamSource(_microphoneStream!)
              .connectNode(destination);
        }
        await context.resume();
        _audioContext = context;
        final mixed = destination.stream;
        if (mixed != null) {
          for (final track in mixed.getAudioTracks()) {
            combined.addTrack(track);
          }
        }
      } catch (_) {
        // If WebAudio mixing is unavailable, keep any display audio the browser
        // supplied. This still gives a useful local screen recording.
        for (final track in _displayStream!.getAudioTracks()) {
          combined.addTrack(track);
        }
      }
    }

    if (combined.getVideoTracks().isEmpty) {
      await _releaseStreams();
      throw StateError('The browser did not provide a screen video track.');
    }
    _recordingStream = combined;

    _mimeType = _bestMimeType();
    final options = _mimeType.isEmpty
        ? null
        : <String, Object>{
            'mimeType': _mimeType,
            'videoBitsPerSecond': 2500000,
          };
    final recorder = options == null
        ? html.MediaRecorder(combined)
        : html.MediaRecorder(combined, options);
    _recorder = recorder;
    _stopped = Completer<void>();

    recorder.addEventListener('dataavailable', (html.Event event) {
      if (event is html.BlobEvent) {
        final blob = event.data;
        if (blob != null && blob.size > 0) _chunks.add(blob);
      }
    });
    recorder.addEventListener('stop', (html.Event _) {
      _recording = false;
      final done = _stopped;
      if (done != null && !done.isCompleted) done.complete();
    });
    recorder.addEventListener('error', (html.Event _) {
      _recording = false;
      final done = _stopped;
      if (done != null && !done.isCompleted) {
        done.completeError(StateError('The browser stopped the recording.'));
      }
    });

    // If the user clicks "Stop sharing" in the browser's own UI, stop the
    // recording cleanly as well.
    for (final track in _displayStream!.getVideoTracks()) {
      track.onEnded.listen((_) {
        if (_recording) unawaited(stop());
      });
    }

    recorder.start(1000);
    _recording = true;
  }

  String _bestMimeType() {
    const candidates = <String>[
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm',
    ];
    for (final type in candidates) {
      if (html.MediaRecorder.isTypeSupported(type)) return type;
    }
    return '';
  }

  @override
  Future<void> stop() async {
    final recorder = _recorder;
    if (recorder == null) return;
    if (_recording && recorder.state != 'inactive') {
      recorder.stop();
      try {
        await _stopped?.future.timeout(const Duration(seconds: 10));
      } finally {
        _recording = false;
      }
    }
    await _releaseStreams(keepChunks: true);
  }

  @override
  Future<String> save() async {
    if (_recording) {
      throw StateError('Stop the recording before saving it.');
    }
    if (_chunks.isEmpty) {
      throw StateError('No recorded video is available to save.');
    }

    final type = _mimeType.isEmpty ? 'video/webm' : _mimeType;
    final blob = html.Blob(_chunks, type);
    final safeMeeting = (_meetingId ?? 'meeting').replaceAll(':', '-');
    final timestamp = DateTime.now()
        .toIso8601String()
        .replaceAll(':', '-')
        .replaceAll('.', '-');
    final filename = 'Edu Chat Pro_${safeMeeting}_$timestamp.webm';
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..download = filename
      ..style.display = 'none';
    html.document.body?.append(anchor);
    anchor.click();
    anchor.remove();
    html.Url.revokeObjectUrl(url);
    _chunks.clear();
    return filename;
  }

  Future<void> _releaseStreams({bool keepChunks = false}) async {
    for (final track in _recordingStream?.getTracks() ?? const []) {
      track.stop();
    }
    for (final track in _displayStream?.getTracks() ?? const []) {
      track.stop();
    }
    for (final track in _microphoneStream?.getTracks() ?? const []) {
      track.stop();
    }
    _recordingStream = null;
    _displayStream = null;
    _microphoneStream = null;
    final context = _audioContext;
    _audioContext = null;
    if (context != null) {
      try {
        await context.close();
      } catch (_) {}
    }
    if (!keepChunks) _chunks.clear();
  }

  @override
  Future<void> dispose() async {
    if (_recording) {
      try {
        await stop();
      } catch (_) {}
    } else {
      await _releaseStreams(keepChunks: false);
    }
  }
}
