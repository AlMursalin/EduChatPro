import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../shared/app_brand.dart';

/// Finish first-launch permission prompts before login/home listeners start.
class StartupPermissionGate extends StatefulWidget {
  const StartupPermissionGate({super.key, required this.child});
  final Widget child;
  @override
  State<StartupPermissionGate> createState() => _StartupPermissionGateState();
}

class _StartupPermissionGateState extends State<StartupPermissionGate> {
  bool complete = false;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => request());
  }

  Future<void> request() async {
    try {
      if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android)
        await const MethodChannel('educhat/notifications')
            .invokeMethod('startupPermissions');
    } catch (_) {/* A denied/unavailable permission never prevents login. */}
    if (mounted) setState(() => complete = true);
  }

  @override
  Widget build(BuildContext context) => complete
      ? widget.child
      : const Scaffold(
          body: SafeArea(
              child: Center(
                  child: Padding(
                      padding: EdgeInsets.all(28),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        AppLogo(size: 80),
                        SizedBox(height: 24),
                        Text('Welcome to Edu Chat Pro',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 23, fontWeight: FontWeight.w800)),
                        SizedBox(height: 14),
                        Text(
                            'Allow notifications for messages and calls, microphone for voice, camera for video, and nearby devices for Bluetooth headsets.',
                            textAlign: TextAlign.center),
                        SizedBox(height: 20),
                        CircularProgressIndicator()
                      ])))));
}
