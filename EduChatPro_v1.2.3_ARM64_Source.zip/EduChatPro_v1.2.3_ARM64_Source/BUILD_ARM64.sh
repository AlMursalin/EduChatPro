#!/usr/bin/env bash
set -euo pipefail
flutter pub get
flutter build apk --release --split-per-abi --target-platform android-arm64
printf '\nARM64 APK: build/app/outputs/flutter-apk/app-arm64-v8a-release.apk\n'
