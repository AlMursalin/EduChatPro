package com.nextechdigitalacademy.educhat_pro

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.util.Base64
import android.webkit.*
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.StandardMessageCodec
import io.flutter.plugin.platform.PlatformView
import io.flutter.plugin.platform.PlatformViewFactory
import io.flutter.plugin.common.BinaryMessenger
import org.json.JSONObject
import org.json.JSONArray
import java.io.ByteArrayInputStream

class WebWorkspaceFactory(private val activity:MainActivity, private val messenger:BinaryMessenger):PlatformViewFactory(StandardMessageCodec.INSTANCE){
 override fun create(context:android.content.Context,id:Int,args:Any?):PlatformView {
  return WebWorkspace(activity,messenger,id,args as? Map<*,*> ?: emptyMap<Any,Any>()).also{activity.workspace=it}
 }
}
class WebWorkspace(private val activity:MainActivity,messenger:BinaryMessenger,id:Int,args:Map<*,*>):PlatformView {
 private val origin="https://appassets.androidplatform.net"
 private val web=WebView(activity)
 private val channel=MethodChannel(messenger,"educhat/workspace/$id")
 private var session=JSONObject(args["session"] as? String ?: "{}").toString()
 private var chooser:ValueCallback<Array<Uri>>?=null
 private var permission:PermissionRequest?=null
 private var saveBytes:ByteArray?=null
 private var saveResult:MethodChannel.Result?=null
 init {
  web.setBackgroundColor(Color.rgb(246,250,255))
  web.settings.apply {javaScriptEnabled=true;domStorageEnabled=true;databaseEnabled=true;allowFileAccess=false;allowContentAccess=true;mediaPlaybackRequiresUserGesture=false;setSupportMultipleWindows(false);javaScriptCanOpenWindowsAutomatically=false;mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW;cacheMode=WebSettings.LOAD_DEFAULT;textZoom=100}
  web.webViewClient=object:WebViewClient(){
   override fun shouldInterceptRequest(view:WebView,request:WebResourceRequest):WebResourceResponse? {
    if(request.url.scheme!="https"||request.url.host!="appassets.androidplatform.net")return null
    val path=request.url.path?.removePrefix("/").orEmpty().ifEmpty{"index.html"}
    if(path.contains(".."))return WebResourceResponse("text/plain","utf-8",403,"Forbidden",emptyMap(),ByteArrayInputStream(byteArrayOf()))
    return try {var bytes=activity.assets.open("flutter_assets/assets/webapp/$path").use{it.readBytes()}
     if(path=="index.html") {val injection="<script>window.EDU_NATIVE_SESSION="+session.replace("<","\\u003c")+";</script>";bytes=String(bytes,Charsets.UTF_8).replace("<head>","<head>"+injection).toByteArray()}
     val mime=when(path.substringAfterLast('.')){"html"->"text/html";"js"->"application/javascript";"css"->"text/css";"svg"->"image/svg+xml";"png"->"image/png";"webmanifest"->"application/manifest+json";else->"application/octet-stream"}
     WebResourceResponse(mime,"utf-8",200,"OK",mapOf("Access-Control-Allow-Origin" to origin,"Content-Security-Policy" to "frame-src 'none'; object-src 'none'"),ByteArrayInputStream(bytes))
    }catch(_:Exception){WebResourceResponse("text/plain","utf-8",404,"Not found",emptyMap(),ByteArrayInputStream(byteArrayOf()))}
   }
   override fun shouldOverrideUrlLoading(view:WebView,r:WebResourceRequest):Boolean {
    if(r.url.scheme=="https"&&r.url.host=="appassets.androidplatform.net")return false
    if(r.isForMainFrame)external(r.url);return true
   }
  }
  web.webChromeClient=object:WebChromeClient(){
   override fun onJsPrompt(v:WebView,url:String,message:String,defaultValue:String?,result:JsPromptResult):Boolean {
    if(!url.startsWith("$origin/")||!message.startsWith("ECP_NATIVE:"))return false
    try{val p=JSONObject(message.removePrefix("ECP_NATIVE:"));val requestId=p.getString("id");val method=p.getString("method");val data=p.optJSONObject("data")?:JSONObject();result.confirm("");
     val map=mutableMapOf<String,Any?>();data.keys().forEach{k->map[k]=data.opt(k).let{if(it==JSONObject.NULL)null else it}}
     channel.invokeMethod(method,map,object:MethodChannel.Result{
      override fun success(value:Any?){respond(requestId,value,null)}
      override fun error(code:String,message:String?,details:Any?){respond(requestId,null,message?:code)}
      override fun notImplemented(){respond(requestId,null,"This action is unavailable")}
     });return true
    }catch(e:Exception){result.cancel();return true}
   }
   override fun onPermissionRequest(request:PermissionRequest){activity.runOnUiThread{
    if(request.origin.toString().trimEnd('/')!=origin){request.deny();return@runOnUiThread}
    val needs=mutableListOf<String>();if(request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE))needs.add(Manifest.permission.RECORD_AUDIO);if(request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE))needs.add(Manifest.permission.CAMERA)
    if(needs.isEmpty()){request.deny();return@runOnUiThread}
    if(needs.all{activity.checkSelfPermission(it)==PackageManager.PERMISSION_GRANTED})request.grant(request.resources.filter{it==PermissionRequest.RESOURCE_AUDIO_CAPTURE||it==PermissionRequest.RESOURCE_VIDEO_CAPTURE}.toTypedArray())
    else{permission?.deny();permission=request;activity.requestPermissions(needs.toTypedArray(),885)}
   }}
   override fun onPermissionRequestCanceled(request:PermissionRequest){if(permission===request)permission=null}
   override fun onShowFileChooser(v:WebView,callback:ValueCallback<Array<Uri>>,params:FileChooserParams):Boolean {
    chooser?.onReceiveValue(null);chooser=callback
    return try{activity.startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*";val accept=params.acceptTypes.filter{it.contains('/')};if(accept.isNotEmpty())putExtra(Intent.EXTRA_MIME_TYPES,accept.toTypedArray());putExtra(Intent.EXTRA_ALLOW_MULTIPLE,params.mode==FileChooserParams.MODE_OPEN_MULTIPLE)},883);true}catch(_:Exception){chooser?.onReceiveValue(null);chooser=null;false}
   }
  }
  web.setDownloadListener{url,_,disposition,mime,_->channel.invokeMethod("download",mapOf("url" to url,"name" to URLUtil.guessFileName(url,disposition,mime),"mime" to mime))}
  channel.setMethodCallHandler{call,result->when(call.method){
   "evaluate"->{web.evaluateJavascript(call.argument<String>("code")?:"",null);result.success(null)}
   "back"->{
    web.evaluateJavascript("(function(){try{return !!(window.EduMobileBack&&window.EduMobileBack());}catch(e){return false;}})()") { value ->
     result.success(value?.trim()?.equals("true",ignoreCase=true)==true)
    }
   }
   "session"->{session=call.argument<String>("json")?:"{}";web.evaluateJavascript("window.EduNativeSession&&window.EduNativeSession($session)",null);result.success(null)}
   "saveBytes"->{if(saveResult!=null){result.error("busy","Finish the current save first",null)}else{try{val data=call.argument<String>("base64")?:"";if(data.length>30000000)throw Exception("This file is too large for local export");saveBytes=Base64.decode(data,Base64.DEFAULT);saveResult=result;activity.startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type=call.argument<String>("mime")?:"application/octet-stream";putExtra(Intent.EXTRA_TITLE,call.argument<String>("name")?:"attachment")},884)}catch(e:Exception){saveResult=null;saveBytes=null;result.error("save",e.message,null)}}}
   "pause"->{web.onPause();result.success(null)}
   "resume"->{web.onResume();result.success(null)}
   else->result.notImplemented()
  }}
  web.loadUrl("$origin/")
 }
 // Android JSONObject.put does not recursively convert MethodChannel Maps.
 // Explicit conversion preserves objects/arrays instead of stringifying them.
 private fun jsonValue(value:Any?):Any = when(value){
  null -> JSONObject.NULL
  is Map<*,*> -> JSONObject().apply{value.forEach{(key,item)->put(key.toString(),jsonValue(item))}}
  is Iterable<*> -> JSONArray().apply{value.forEach{put(jsonValue(it))}}
  is Boolean,is Number,is String -> value
  else -> value.toString()
 }
 private fun respond(id:String,value:Any?,error:String?){activity.runOnUiThread{if(web.url?.startsWith("$origin/")==true){val payload=JSONObject().put("id",id).put("value",jsonValue(value)).put("error",error?:JSONObject.NULL);web.evaluateJavascript("window.EduNativeReply&&window.EduNativeReply($payload)",null)}}}
 private fun external(uri:Uri){if(uri.scheme in listOf("https","http","mailto","tel"))try{activity.startActivity(Intent(Intent.ACTION_VIEW,uri))}catch(_:Exception){}}
 fun permissionResult(){val p=permission?:return;permission=null;val allowed=p.resources.filter{(it==PermissionRequest.RESOURCE_AUDIO_CAPTURE&&activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)||(it==PermissionRequest.RESOURCE_VIDEO_CAPTURE&&activity.checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)};if(allowed.size==p.resources.size)p.grant(allowed.toTypedArray())else p.deny()}
 fun activityResult(code:Int,status:Int,data:Intent?):Boolean {
  if(code==883){val values=if(status==Activity.RESULT_OK){data?.clipData?.let{c->Array(c.itemCount){c.getItemAt(it).uri}}?:data?.data?.let{arrayOf(it)}}else null;chooser?.onReceiveValue(values);chooser=null;return true}
  if(code!=884)return false
  val result=saveResult;val bytes=saveBytes;saveResult=null;saveBytes=null
  if(status!=Activity.RESULT_OK||data?.data==null||bytes==null){result?.success(false);return true}
  val uri=data.data!!;Thread{try{val output=activity.contentResolver.openOutputStream(uri)?:throw Exception("Cannot save here");output.use{it.write(bytes)};activity.runOnUiThread{result?.success(true)}}catch(e:Exception){activity.runOnUiThread{result?.error("save",e.message,null)}}}.start();return true
 }
 override fun getView()=web
 override fun dispose(){chooser?.onReceiveValue(null);permission?.deny();saveResult?.success(false);channel.setMethodCallHandler(null);web.stopLoading();web.destroy();if(activity.workspace===this)activity.workspace=null}
}
