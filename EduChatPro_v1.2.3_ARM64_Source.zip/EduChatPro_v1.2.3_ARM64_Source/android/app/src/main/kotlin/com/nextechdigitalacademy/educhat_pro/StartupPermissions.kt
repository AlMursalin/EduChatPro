package com.nextechdigitalacademy.educhat_pro

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import io.flutter.plugin.common.MethodChannel

class StartupPermissions(private val activity:Activity){
 private var pending:MethodChannel.Result?=null
 private val prefs get()=activity.getSharedPreferences("ecp_startup_permissions",Activity.MODE_PRIVATE)
 fun request(result:MethodChannel.Result){
  if(prefs.getBoolean("completed_v2",false)){result.success(null);return}
  if(pending!=null){result.error("busy","Permission setup is already open",null);return}
  pending=result
  val permissions=mutableListOf(Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO)
  if(Build.VERSION.SDK_INT>=31)permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
  if(Build.VERSION.SDK_INT>=33)permissions.add(Manifest.permission.POST_NOTIFICATIONS)
  val missing=permissions.filter{activity.checkSelfPermission(it)!=PackageManager.PERMISSION_GRANTED}
  if(missing.isEmpty())fullScreen() else activity.requestPermissions(missing.toTypedArray(),804)
 }
 fun permissionResult(code:Int):Boolean{if(code!=804)return false;notificationSettingsOrFullScreen();return true}
 private fun notificationSettingsOrFullScreen(){
  if(pending==null)return
  if(Build.VERSION.SDK_INT>=33&&activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
   AlertDialog.Builder(activity).setTitle("Allow message and call notifications")
    .setMessage("Edu Chat Pro needs Android notification permission to show message pop-ups and incoming calls while the app is in the background.")
    .setPositiveButton("Open settings"){_,_->try{activity.startActivityForResult(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,activity.packageName),806)}catch(_:Exception){fullScreen()}}
    .setNegativeButton("Not now"){_,_->fullScreen()}.setOnCancelListener{fullScreen()}.show()
  }else fullScreen()
 }
 private fun fullScreen(){
  if(pending==null)return
  val manager=activity.getSystemService(Activity.NOTIFICATION_SERVICE) as NotificationManager
  if(Build.VERSION.SDK_INT>=34&&!manager.canUseFullScreenIntent()){
   AlertDialog.Builder(activity).setTitle("Incoming call screen")
    .setMessage("Allow Edu Chat Pro to show incoming calls over the lock screen. Android will open this app’s call-screen setting.")
    .setPositiveButton("Open setting"){_,_->try{activity.startActivityForResult(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:${activity.packageName}")),805)}catch(_:Exception){finish()}}
    .setNegativeButton("Not now"){_,_->finish()}.setOnCancelListener{finish()}.show()
  }else finish()
 }
 fun activityResult(code:Int):Boolean{
  if(code==806){fullScreen();return true}
  if(code!=805)return false
  finish();return true
 }
 private fun finish(){prefs.edit().putBoolean("completed_v2",true).apply();val result=pending;pending=null;result?.success(null)}
}
