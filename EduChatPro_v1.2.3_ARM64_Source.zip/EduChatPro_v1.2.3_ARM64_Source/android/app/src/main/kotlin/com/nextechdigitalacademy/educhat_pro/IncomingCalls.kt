package com.nextechdigitalacademy.educhat_pro

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.*
import android.graphics.Color
import android.widget.*
import com.google.firebase.messaging.RemoteMessage
import io.flutter.plugins.firebase.messaging.FlutterFirebaseMessagingService

object IncomingCalls {
 const val CHANNEL="ecp_incoming_calls_v2"
 fun show(context:Context,notificationId:String,callTag:String,title:String,expires:Long=System.currentTimeMillis()+60000){
  if(expires<=System.currentTimeMillis())return
  if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return
  val nm=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  if(Build.VERSION.SDK_INT>=26){
   val ch=NotificationChannel(CHANNEL,"Incoming calls",NotificationManager.IMPORTANCE_HIGH)
   ch.description="Incoming Edu Chat Pro audio and video calls"
   ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build())
   ch.enableVibration(true);ch.lockscreenVisibility=Notification.VISIBILITY_PRIVATE
   nm.createNotificationChannel(ch)
  }
  fun pending(action:String):PendingIntent {
   val intent=Intent(context,MainActivity::class.java).apply{
    flags=Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
    putExtra("ec_notification_id",notificationId);putExtra("ec_call_tag",callTag);putExtra("ec_call_action",action)
   }
   return PendingIntent.getActivity(context,(notificationId+action).hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  }
  val full=Intent(context,IncomingCallActivity::class.java).apply{
   flags=Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
   putExtra("ec_notification_id",notificationId);putExtra("ec_call_tag",callTag);putExtra("caller_title",title);putExtra("expires",expires)
  }
  val screen=PendingIntent.getActivity(context,(callTag+"screen").hashCode(),full,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  val builder=if(Build.VERSION.SDK_INT>=26)Notification.Builder(context,CHANNEL)else Notification.Builder(context)
  builder.setSmallIcon(R.drawable.ic_notification).setContentTitle("Incoming Edu Chat call").setContentText(title).setContentIntent(screen).setCategory(Notification.CATEGORY_CALL).setVisibility(Notification.VISIBILITY_PRIVATE).setOngoing(true).setAutoCancel(false).setOnlyAlertOnce(false)
  if(!MainActivity.foreground)builder.setFullScreenIntent(screen,true)
  if(Build.VERSION.SDK_INT>=26)builder.setTimeoutAfter(expires-System.currentTimeMillis())
  if(Build.VERSION.SDK_INT>=31)builder.setStyle(Notification.CallStyle.forIncomingCall(Person.Builder().setName(title).setImportant(true).build(),pending("decline"),pending("answer")))
  else {builder.addAction(Notification.Action.Builder(null,"Decline",pending("decline")).build());builder.addAction(Notification.Action.Builder(null,"Answer",pending("answer")).build());builder.setPriority(Notification.PRIORITY_MAX).setDefaults(Notification.DEFAULT_ALL)}
  val notification=builder.build();notification.flags=notification.flags or Notification.FLAG_INSISTENT
  nm.notify(callTag,0,notification)
 }
 fun cancel(context:Context,callTag:String){
  if(callTag.isBlank())return
  (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(callTag,0)
  context.sendBroadcast(Intent("${context.packageName}.CALL_FINISHED").setPackage(context.packageName).putExtra("id",callTag))
 }
}
// Render data pushes natively; receiving a message does not require Flutter,
// the WebView, or an open realtime connection.
object BackgroundMessages {
 fun show(context:Context,id:String,title:String){
  if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return
  val nm=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  if(Build.VERSION.SDK_INT>=26){val ch=NotificationChannel(MainActivity.MESSAGE_CHANNEL,"Messages and updates",NotificationManager.IMPORTANCE_HIGH).apply{description="Chat messages and Edu Chat Pro updates";enableVibration(true);setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build())};nm.createNotificationChannel(ch)}
  val intent=Intent(context,MainActivity::class.java).apply{flags=Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP;putExtra("ec_notification_id",id)}
  val tap=PendingIntent.getActivity(context,id.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  val b=if(Build.VERSION.SDK_INT>=26)Notification.Builder(context,MainActivity.MESSAGE_CHANNEL)else Notification.Builder(context)
  b.setSmallIcon(R.drawable.ic_notification).setContentTitle("Edu Chat Pro").setContentText(title).setStyle(Notification.BigTextStyle().bigText(title)).setContentIntent(tap).setAutoCancel(true).setOnlyAlertOnce(true).setVisibility(Notification.VISIBILITY_PRIVATE).setCategory(Notification.CATEGORY_MESSAGE)
  if(Build.VERSION.SDK_INT<26)b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
  nm.notify(id,0,b.build())
 }
}
// Receive call payloads at the Android broadcast entry point, before a Dart
// background isolate starts. Flutter's receiver can bypass onMessageReceived.
class EduPushReceiver:io.flutter.plugins.firebase.messaging.FlutterFirebaseMessagingReceiver(){
 override fun onReceive(context:Context,intent:Intent){
  val extras=intent.extras
  if(extras!=null){
   val message=RemoteMessage(extras);val d=message.data;val id=d["notification_id"]
   if(id!=null){
    if(d["kind"]=="call_cancel")IncomingCalls.cancel(context,d["call_notification_id"]?:d["resource_id"]?:id)
    else if(d["kind"] in listOf("direct_call_audio","direct_call_video","group_call")){
     val expiry=d["expires_at_ms"]?.toLongOrNull()?:message.sentTime+60000
     IncomingCalls.show(context,id,d["resource_id"]?:id,d["title"]?:"Incoming call",expiry)
    }else BackgroundMessages.show(context,id,d["title"]?:message.notification?.body?:"New Edu Chat Pro update")
    // This notification is handled completely by native Android. Do not start
    // a Dart background isolate merely to display the same notification twice.
    return
   }
  }
  super.onReceive(context,intent)
 }
}
class EduMessagingService:FlutterFirebaseMessagingService()
class IncomingCallActivity:Activity(){
 private val handler=Handler(Looper.getMainLooper())
 private val finished=object:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){if(i.getStringExtra("id")==intent.getStringExtra("ec_call_tag"))finish()}}
 override fun onCreate(state:Bundle?){super.onCreate(state)
  if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true)}else window.addFlags(0x00080000 or 0x00200000)
  if(Build.VERSION.SDK_INT>=33)registerReceiver(finished,IntentFilter("$packageName.CALL_FINISHED"),RECEIVER_NOT_EXPORTED)else registerReceiver(finished,IntentFilter("$packageName.CALL_FINISHED"))
  val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=android.view.Gravity.CENTER;setPadding(40,60,40,60);setBackgroundColor(Color.rgb(12,25,40))}
  layout.addView(TextView(this).apply{text="Edu Chat Pro";textSize=22f;setTextColor(Color.CYAN);gravity=17})
  layout.addView(TextView(this).apply{text=intent.getStringExtra("caller_title")?:"Incoming call";textSize=28f;setTextColor(Color.WHITE);gravity=17;setPadding(0,50,0,80)})
  for(action in listOf("answer","decline")){layout.addView(Button(this).apply{text=if(action=="answer")"Answer" else "Decline";setOnClickListener{act(action)}},LinearLayout.LayoutParams(-1,140).apply{bottomMargin=24})}
  setContentView(layout);handler.postDelayed({finish()},(intent.getLongExtra("expires",System.currentTimeMillis()+60000)-System.currentTimeMillis()).coerceIn(1,60000))
 }
 private fun act(action:String){val id=intent.getStringExtra("ec_notification_id")?:return;val tag=intent.getStringExtra("ec_call_tag")?:id;IncomingCalls.cancel(this,tag);startActivity(Intent(this,MainActivity::class.java).apply{flags=Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP;putExtra("ec_notification_id",id);putExtra("ec_call_tag",tag);putExtra("ec_call_action",action)});finish()}
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);try{unregisterReceiver(finished)}catch(_:Exception){};super.onDestroy()}
}
