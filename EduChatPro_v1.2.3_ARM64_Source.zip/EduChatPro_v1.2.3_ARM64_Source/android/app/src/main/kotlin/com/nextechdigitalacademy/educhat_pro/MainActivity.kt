package com.nextechdigitalacademy.educhat_pro

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    var workspace:WebWorkspace?=null
    companion object {
        @Volatile var foreground=false
        const val MESSAGE_CHANNEL="ecp_messages_v2"
        const val CALL_CHANNEL="ecp_calls_v2"
    }
    override fun onResume(){super.onResume();foreground=true}
    override fun onPause(){foreground=false;super.onPause()}
    private val startupPermissions by lazy { StartupPermissions(this) }
    private val files by lazy { MediaFiles(this) }
    private val voice by lazy { VoiceMedia(this) }
    private var alerts: MethodChannel? = null
    private val manager get() = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
    private fun channels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val messageSound=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val callSound=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            manager.createNotificationChannel(NotificationChannel(MESSAGE_CHANNEL, "Messages and updates", NotificationManager.IMPORTANCE_HIGH).apply {
                description="Chat messages and Edu Chat Pro updates"
                enableVibration(true)
                setSound(messageSound,AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build())
            })
            manager.createNotificationChannel(NotificationChannel(CALL_CHANNEL, "Calls and meetings", NotificationManager.IMPORTANCE_HIGH).apply {
                description="Call and meeting alerts"
                enableVibration(true)
                setSound(callSound,AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build())
            })
        }
    }
    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        channels()
        engine.platformViewsController.registry.registerViewFactory("educhat/workspace",WebWorkspaceFactory(this,engine.dartExecutor.binaryMessenger))
        files.attach(MethodChannel(engine.dartExecutor.binaryMessenger,"educhat/files"))
        voice.attach(MethodChannel(engine.dartExecutor.binaryMessenger,"educhat/media"))
        alerts = MethodChannel(engine.dartExecutor.binaryMessenger, "educhat/notifications")
        alerts!!.setMethodCallHandler { call, result ->
            when (call.method) {
                "startupPermissions" -> startupPermissions.request(result)
                "requestPermission" -> {
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 501)
                    }
                    result.success(null)
                }
                "initialNotification" -> {
                    result.success(intent.getStringExtra("ec_notification_id")?.let{mapOf("notification_id" to it,"action" to (intent.getStringExtra("ec_call_action")?:"open"),"call_tag" to (intent.getStringExtra("ec_call_tag")?:""))})
                    intent.removeExtra("ec_notification_id")
                    intent.removeExtra("ec_call_tag")
                    intent.removeExtra("ec_call_action")
                }
                "dismissCall" -> { IncomingCalls.cancel(this,call.argument<String>("id")?:"");result.success(null) }
                "callPermission" -> { if(Build.VERSION.SDK_INT>=34&&!manager.canUseFullScreenIntent())startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,android.net.Uri.parse("package:$packageName")));result.success(null) }
                "clear" -> { manager.cancelAll(); result.success(null) }
                "show" -> {
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        result.success(false)
                    } else {
                        val id = call.argument<String>("id") ?: ""
                        val title = call.argument<String>("title") ?: "Edu Chat Pro"
                        val body = call.argument<String>("body") ?: "New update"
                        val isCall = call.argument<Boolean>("call") == true
                        val target = Intent(this, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                            putExtra("ec_notification_id", id)
                        }
                        val tap = PendingIntent.getActivity(this, id.hashCode(), target, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, if(isCall) CALL_CHANNEL else MESSAGE_CHANNEL) else Notification.Builder(this)
                        builder.setSmallIcon(R.drawable.ic_notification).setContentTitle(title)
                            .setContentText(body).setStyle(Notification.BigTextStyle().bigText(body))
                            .setContentIntent(tap).setAutoCancel(true).setOnlyAlertOnce(true)
                            .setVisibility(Notification.VISIBILITY_PRIVATE)
                            .setCategory(if(isCall) Notification.CATEGORY_CALL else Notification.CATEGORY_MESSAGE)
                        if(Build.VERSION.SDK_INT < 26) builder.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
                        if(isCall && Build.VERSION.SDK_INT >= 26) builder.setTimeoutAfter(60000)
                        manager.notify(id, 0, builder.build())
                        result.success(true)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);startupPermissions.permissionResult(requestCode);if(requestCode==885)workspace?.permissionResult();if(requestCode==702)voice.permission(grantResults.isNotEmpty()&&grantResults[0]==PackageManager.PERMISSION_GRANTED)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){if(workspace?.activityResult(requestCode,resultCode,data)==true)return;if(!startupPermissions.activityResult(requestCode)&&!files.activityResult(requestCode,resultCode,data))super.onActivityResult(requestCode,resultCode,data)}
    override fun onDestroy(){voice.dispose();super.onDestroy()}
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val id = intent.getStringExtra("ec_notification_id")
        if(id != null) {
            val callTag=intent.getStringExtra("ec_call_tag")
            if(!callTag.isNullOrBlank())IncomingCalls.cancel(this,callTag)
            alerts?.invokeMethod("notificationTap", mapOf("notification_id" to id,"action" to (intent.getStringExtra("ec_call_action")?:"open"),"call_tag" to (callTag?:"")))
            intent.removeExtra("ec_notification_id")
            intent.removeExtra("ec_call_tag")
            intent.removeExtra("ec_call_action")
        }
    }
}
