package com.nextechdigitalacademy.educhat_pro
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import io.flutter.plugin.common.MethodChannel
import java.net.HttpURLConnection
import java.net.URL

class MediaFiles(private val activity:Activity){
 private var pending:MethodChannel.Result?=null
 private var url:String?=null
 fun attach(channel:MethodChannel){channel.setMethodCallHandler{call,result->
  val source=call.argument<String>("url")?:""
  if(!source.startsWith("https://")){result.error("url","A secure media URL is required",null);return@setMethodCallHandler}
  when(call.method){
   "video"->{activity.startActivity(Intent(activity,MediaPreviewActivity::class.java).putExtra("url",source).putExtra("name",call.argument<String>("name")));result.success(null)}
   "download"->{if(pending!=null){result.error("busy","A download is already running",null)}else{
    pending=result;url=source
    try{activity.startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type=call.argument<String>("mime")?:"application/octet-stream";putExtra(Intent.EXTRA_TITLE,call.argument<String>("name")?:"attachment")},803)}catch(e:Exception){pending=null;result.error("save",e.message,null)}
   }}
   else->result.notImplemented()
  }
 }}
 fun activityResult(code:Int,status:Int,data:Intent?):Boolean{
  if(code!=803)return false
  val result=pending?:return true
  val source=url;val uri=data?.data
  if(status!=Activity.RESULT_OK||uri==null||source==null){pending=null;result.success(false);return true}
  Thread{
   var connection:HttpURLConnection?=null
   try{
    connection=URL(source).openConnection() as HttpURLConnection
    connection.connectTimeout=15000;connection.readTimeout=60000
    if(connection.responseCode !in 200..299)throw IllegalStateException("Download expired or unavailable. Try again.")
    connection.inputStream.use{input->val output=activity.contentResolver.openOutputStream(uri)?:throw IllegalStateException("Cannot save to this location");output.use{input.copyTo(it,65536)}}
    activity.runOnUiThread{pending=null;result.success(true)}
   }catch(e:Exception){try{android.provider.DocumentsContract.deleteDocument(activity.contentResolver,uri)}catch(_:Exception){};activity.runOnUiThread{pending=null;result.error("download",e.message,null)}}
   finally{connection?.disconnect()}
  }.start()
  return true
 }
}
class MediaPreviewActivity:Activity(){
 private lateinit var video:VideoView
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(android.graphics.Color.BLACK)}
  layout.addView(Button(this).apply{text="‹ Back to conversation";setOnClickListener{finish()}})
  val box=FrameLayout(this);video=VideoView(this)
  box.addView(video,FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));layout.addView(box,LinearLayout.LayoutParams(-1,0,1f));setContentView(layout)
  val controller=MediaController(this);controller.setAnchorView(video);video.setMediaController(controller)
  video.setVideoURI(Uri.parse(intent.getStringExtra("url")))
  video.setOnPreparedListener{video.start()}
  video.setOnErrorListener{_,_,_->Toast.makeText(this,"This video could not play. Download it or use MP4/H.264.",Toast.LENGTH_LONG).show();true}
 }
 override fun onPause(){video.pause();super.onPause()}
 override fun onDestroy(){video.stopPlayback();super.onDestroy()}
}
