package com.nextechdigitalacademy.educhat_pro
import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import io.flutter.plugin.common.MethodChannel
import java.io.File

class VoiceMedia(private val activity:MainActivity){
 private var recorder:MediaRecorder?=null;private var file:File?=null;private var started=0L
 private var player:MediaPlayer?=null;private var currentUrl="";private var permissionResult:MethodChannel.Result?=null
 fun attach(channel:MethodChannel){channel.setMethodCallHandler{call,result->try{when(call.method){
  "record"->{if(activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){permissionResult=result;activity.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),702)}else start(result)}
  "stopRecord"->{val r=recorder;recorder=null;if(r==null)result.error("record","No recording",null)else{try{r.stop();val bytes=file!!.readBytes();result.success(mapOf("bytes" to bytes,"duration_ms" to (System.currentTimeMillis()-started).toInt()))}finally{r.release();file?.delete()}}}
  "cancelRecord"->{cancel();result.success(null)}
  "play"->{player?.release();val url=call.argument<String>("url")!!;currentUrl=url;val m=MediaPlayer();player=m;m.setDataSource(url);var responded=false;m.setOnPreparedListener{it.start();if(!responded){responded=true;result.success(it.duration)}};m.setOnErrorListener{_,_,_->if(!responded){responded=true;result.error("audio","Could not play recording",null)};true};m.prepareAsync()}
  "pause"->{player?.pause();result.success(null)}
  "resume"->{player?.start();result.success(null)}
  "status"->{result.success(mapOf("url" to currentUrl,"playing" to (player?.isPlaying?:false),"position" to (player?.currentPosition?:0),"duration" to (player?.duration?:0)))}
  else->result.notImplemented()
 }}catch(e:Exception){result.error("media",e.message,null)}}}
 private fun start(result:MethodChannel.Result){try{cancel();file=File.createTempFile("voice-",".m4a",activity.cacheDir);val r=if(Build.VERSION.SDK_INT>=31)MediaRecorder(activity)else MediaRecorder();recorder=r;r.setAudioSource(MediaRecorder.AudioSource.MIC);r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);r.setAudioEncodingBitRate(48000);r.setAudioSamplingRate(24000);r.setMaxDuration(120000);r.setOutputFile(file!!.absolutePath);r.prepare();r.start();started=System.currentTimeMillis();result.success(null)}catch(e:Exception){cancel();result.error("record",e.message,null)}}
 fun permission(granted:Boolean){val result=permissionResult?:return;permissionResult=null;if(granted)start(result)else result.error("permission","Allow microphone access to send voice messages",null)}
 fun cancel(){try{recorder?.stop()}catch(_:Exception){};recorder?.release();recorder=null;file?.delete()}
 fun dispose(){cancel();player?.release();player=null}
}
