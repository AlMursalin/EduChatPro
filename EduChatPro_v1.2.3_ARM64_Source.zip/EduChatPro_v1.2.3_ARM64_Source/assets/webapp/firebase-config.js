// Public Firebase web config only. Never put a service account/private key here.
self.EDU_FIREBASE = {
  enabled: false,
  config: { apiKey: '', authDomain: '', projectId: '', messagingSenderId: '', appId: '' },
  vapidKey: ''
};
