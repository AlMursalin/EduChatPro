(()=>{
  'use strict';
  const isAndroidNative=!!window.EduNative;
  if(!isAndroidNative)return;

  const q=(s,r=document)=>r.querySelector(s);
  const qa=(s,r=document)=>[...r.querySelectorAll(s)];
  const page=()=>q('#page');
  const messageLog=()=>q('#message-log')||q('#dm-log')||q('#chat-log')||q('.ws-message-log')||q('.chat-log');
  const composerInput=()=>q('#message-input')||q('#dm-text')||q('#chat-input');
  let keyboardActive=false, previousKeyboardActive=false, raf=0, settleTimers=[];

  function clearSettle(){for(const t of settleTimers)clearTimeout(t);settleTimers=[];}
  function atChatBottom(log){return !log || (log.scrollHeight-log.scrollTop-log.clientHeight)<160;}
  function scrollChatBottom(force=false){
    const log=messageLog();
    if(!log)return;
    if(!force&&!atChatBottom(log))return;
    cancelAnimationFrame(raf);
    raf=requestAnimationFrame(()=>{log.scrollTop=log.scrollHeight;});
  }
  function settleBottom(){
    clearSettle();
    scrollChatBottom(true);
    for(const ms of [45,110,220,360])settleTimers.push(setTimeout(()=>scrollChatBottom(true),ms));
  }
  function updateViewport(){
    const vv=window.visualViewport;
    const height=vv?.height||window.innerHeight;
    const top=vv?.offsetTop||0;
    document.documentElement.style.setProperty('--ecp-native-vh',`${Math.round(height)}px`);
    document.documentElement.style.setProperty('--ecp-native-vtop',`${Math.round(top)}px`);
    const active=document.activeElement;
    previousKeyboardActive=keyboardActive;
    keyboardActive=!!(vv&&window.innerHeight-vv.height>120&&active&&/^(INPUT|TEXTAREA)$/.test(active.tagName));
    document.documentElement.classList.toggle('ecp-keyboard-open',keyboardActive);
    if(active===composerInput()&&(keyboardActive||previousKeyboardActive!==keyboardActive))settleBottom();
    if(previousKeyboardActive&&!keyboardActive)setTimeout(()=>scrollChatBottom(true),80);
  }

  document.addEventListener('focusin',e=>{
    if(e.target===composerInput()){
      document.documentElement.classList.add('ecp-chat-input-focus');
      settleBottom();
    }
  },true);
  document.addEventListener('focusout',e=>{
    if(e.target===composerInput()){
      document.documentElement.classList.remove('ecp-chat-input-focus');
      clearSettle();
      setTimeout(()=>{updateViewport();scrollChatBottom(true);},40);
    }
  },true);

  window.visualViewport?.addEventListener('resize',updateViewport,{passive:true});
  window.visualViewport?.addEventListener('scroll',updateViewport,{passive:true});
  window.addEventListener('resize',updateViewport,{passive:true});
  new MutationObserver(()=>{
    const input=composerInput();
    if(input&&document.activeElement===input)settleBottom();
  }).observe(document.documentElement,{subtree:true,childList:true});
  updateViewport();

  function clickFirst(selectors,root=document){
    for(const s of selectors){const el=q(s,root);if(el){el.click();return true;}}
    return false;
  }

  // Called by Flutter/Android when system Back is pressed. Keep navigation inside
  // the app first, matching Messenger: keyboard -> dialog -> conversation list -> app exit.
  window.EduMobileBack=()=>{
    const active=document.activeElement;
    if(active&&/^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName)&&
       (keyboardActive||document.documentElement.classList.contains('ecp-chat-input-focus'))){
      active.blur();
      return true;
    }

    const modal=q('#modal-root .modal');
    if(modal){
      if(clickFirst(['[data-close]','[data-no]','#crop-cancel'],modal))return true;
      window.EduUI?.closeModal?.();
      return true;
    }

    const openDialog=qa('dialog[open]').at(-1);
    if(openDialog){
      const decline=q('[data-decline]',openDialog);
      if(decline){decline.click();return true;}
      try{openDialog.close();openDialog.remove();}catch{}
      return true;
    }

    const root=page();
    if(root?.classList.contains('panels-open')){
      q('#forum-panel-close',root)?.click();
      root.classList.remove('panels-open');
      return true;
    }
    if(root?.classList.contains('conversation-open')){
      const back=q('#back-chats',root);
      if(back)back.click(); else root.classList.remove('conversation-open');
      return true;
    }
    // Legacy group/direct chat pages used by parts of the current web bundle.
    // On phones Back always returns to the unified Chats list, never exits.
    const groupBack=q('#back-groups',root);
    if(groupBack&&(q('#group-body',root)||root?.classList.contains('chat-workspace'))){
      if(typeof window.navigate==='function')window.navigate('chats'); else groupBack.click();
      return true;
    }
    if(root?.classList.contains('messenger-page')&&root.classList.contains('direct-workspace')){
      if(typeof window.navigate==='function'){window.navigate('chats');return true;}
      const back=q('#dm-back',root);
      if(back){back.click();return true;}
    }
    return false;
  };
})();
