/* Private, account-scoped image cache. Versioned object paths invalidate photos. */
window.EduPhotos=(()=>{
 const hot=new Map(),pending=new Map();let epoch=0,trimWork=Promise.resolve();
 const cacheName='ecp-private-photos-v1';
 async function requestKey(key){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(key));return new URL('/__ecp_photo__/'+[...new Uint8Array(bytes)].map(v=>v.toString(16).padStart(2,'0')).join(''),location.origin).href}
 async function trim(cache){const keys=await cache.keys();let total=0;for(let i=keys.length-1;i>=0;i--){const r=await cache.match(keys[i]);total+=Number(r?.headers.get('x-ecp-size')||0);if(total>60*1024*1024||i<keys.length-250)await cache.delete(keys[i])}}
 async function get(sb,user,bucket,path){const key=user+'/'+bucket+'/'+path;if(hot.has(key))return hot.get(key);if(pending.has(key))return pending.get(key);const generation=epoch;
 const task=(async()=>{let cache,url,blob;try{cache=await caches.open(cacheName);url=await requestKey(key);const saved=await cache.match(url);if(saved)blob=await saved.blob()}catch{}
 if(!blob){const result=await sb.storage.from(bucket).download(path);if(result.error)throw result.error;blob=result.data;if(cache&&url&&generation===epoch){try{await cache.put(url,new Response(blob,{headers:{'Content-Type':blob.type,'x-ecp-size':String(blob.size)}}));trimWork=trimWork.then(()=>trim(cache)).catch(()=>{})}catch{}}}
 if(generation!==epoch)throw new Error('Session changed');const object=URL.createObjectURL(blob);hot.set(key,object);while(hot.size>200){const oldest=hot.keys().next().value;URL.revokeObjectURL(hot.get(oldest));hot.delete(oldest)}return object;
 })().finally(()=>pending.delete(key));pending.set(key,task);return task;
 }
 async function clear(){epoch++;for(const url of hot.values())URL.revokeObjectURL(url);hot.clear();pending.clear();try{await caches.delete(cacheName)}catch{}}
 return {get,clear};
})();
