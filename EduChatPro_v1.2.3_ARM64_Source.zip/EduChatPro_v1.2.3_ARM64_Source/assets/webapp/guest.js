(()=>{'use strict';
const U=window.EduUI, cfg=window.EDUCHAT_CONFIG;
const code=U.inviteCode(new URL(location.href).searchParams.get('invite')||'');
const status=document.querySelector('#guest-status'),form=document.querySelector('#guest-form'),button=document.querySelector('#guest-join');
document.querySelector('#account-login').href=`/?invite=${encodeURIComponent(code||'')}&login=1`;
let client=null,busy=false,meetingOpen=false,captchaToken='';
if(!code){status.textContent='This meeting link is invalid. Ask the host for a new invite link.';button.disabled=true;return;}
// Optional Turnstile integration when Supabase Auth CAPTCHA is enabled.
if(cfg.GUEST_TURNSTILE_SITE_KEY){const s=document.createElement('script');s.src='https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';s.onload=()=>window.turnstile.render('#guest-captcha',{sitekey:cfg.GUEST_TURNSTILE_SITE_KEY,callback:t=>captchaToken=t,'expired-callback':()=>captchaToken=''});document.head.appendChild(s);}
form.addEventListener('submit',async e=>{e.preventDefault();if(busy||meetingOpen)return;busy=true;button.disabled=true;status.textContent='Connecting…';
try{
 const name=document.querySelector('#guest-name').value.trim();if(!name)throw new Error('Enter your name.');
 if(!client)client=window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_PUBLISHABLE_KEY,{auth:{persistSession:false,autoRefreshToken:true,detectSessionInUrl:false,storageKey:'ecp-guest-in-memory'}});
 const current=await client.auth.getSession();
 if(!current.data.session){const result=await client.auth.signInAnonymously({options:captchaToken?{captchaToken}:undefined});if(result.error)throw result.error;}
 const joined=await client.rpc('join_guest_meeting',{code,guest_name:name});if(joined.error)throw joined.error;
 status.textContent='';
 meetingOpen=true; await window.EduMeeting.open(client,joined.data,{guest:true,autoJoin:true,profile:{full_name:`${name} (Guest)`},onExit:()=>{meetingOpen=false;status.textContent='You left the meeting. You can join again while it is open.';button.disabled=false;}});
}catch(error){meetingOpen=false;const message=error?.message||String(error);status.textContent=/anonymous.*(disabled|not allowed)/i.test(message)?'Guest joining is not enabled yet. Please contact the meeting host.':message;}
finally{busy=false;button.disabled=meetingOpen;}
});
})();

