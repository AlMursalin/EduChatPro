window.EDUCHAT_CONFIG = Object.freeze({
  SUPABASE_URL: 'https://xaqctutviuxwjuqjuidx.supabase.co',
  SUPABASE_PUBLISHABLE_KEY: 'sb_publishable_QEgk7l8liSUYgoo8Wgfbog_LFb7MkNI',
  APP_NAME: 'Edu Chat Pro',
  PAGE_SIZE: 30,
  // Optional public Turnstile site key when Auth CAPTCHA is enabled.
  GUEST_TURNSTILE_SITE_KEY: '',

  // EduChat first tries LiveKit (best for bigger classes). If the token/SFU is
  // not configured or temporarily unavailable, the web client automatically
  // falls back to encrypted browser-to-browser WebRTC for small meetings.
  LIVEKIT_REQUIRED: false,
  P2P_FALLBACK: true,

  // Free STUN is enough on many normal home/mobile networks. For the highest
  // reliability across restrictive NAT/firewalls, add your own TURN server
  // here later. Do not put private API secrets in this browser file.
  ICE_SERVERS: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' }
  ],

  APP_ORIGIN: window.location.origin,
  PUBLIC_WEB_URL: 'https://nextechdigitalacademy.is-best.net',
});

