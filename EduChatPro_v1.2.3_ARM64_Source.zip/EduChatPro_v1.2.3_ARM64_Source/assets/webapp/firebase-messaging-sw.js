/* Firebase is used only as a push transport. */
importScripts('./firebase-config.js');
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const id=event.notification.data?.FCM_MSG?.data?.notification_id || event.notification.data?.notification_id || '';
  const target=new URL('/', self.location.origin);if(id)target.searchParams.set('notification',id);
  event.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(async windows=>{
    for(const client of windows){if(new URL(client.url).origin===target.origin){await client.navigate(target.href);return client.focus();}}
    return clients.openWindow(target.href);
  }));
});
if(self.EDU_FIREBASE?.enabled){
 importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js','https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');
 firebase.initializeApp(self.EDU_FIREBASE.config);
 firebase.messaging(); // FCM handles display of notification payloads in the background.
}
