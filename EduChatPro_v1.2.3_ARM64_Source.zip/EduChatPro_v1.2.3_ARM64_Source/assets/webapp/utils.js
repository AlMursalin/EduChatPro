(() => {
  'use strict';
  const U = {};
  const q = (s, root=document) => root.querySelector(s);
  const qa = (s, root=document) => [...root.querySelectorAll(s)];
  const esc = (v='') => String(v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const attr = esc;
  const fmtDate = v => {
    if (!v) return '—';
    try { return new Intl.DateTimeFormat(undefined,{dateStyle:'medium',timeStyle:'short'}).format(new Date(v)); }
    catch { return String(v); }
  };
  const fmtBytes = n => {
    n = Number(n || 0); if (!Number.isFinite(n)) return '0 B';
    const units=['B','KB','MB','GB']; let i=0;
    while(n>=1024&&i<units.length-1){n/=1024;i++;}
    return `${n.toFixed(i?1:0)} ${units[i]}`;
  };
  const uuid = () => crypto.randomUUID ? crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const r=Math.random()*16|0,v=c==='x'?r:(r&3|8);return v.toString(16)});
  const shortId = id => String(id||'').slice(0,8);
  const isUuid = s => /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(s||''));
  const inviteCode = input => String(input||'').match(/[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/i)?.[0] || null;
  const safeName = name => String(name||'file').replace(/[\\/:*?"<>|\x00-\x1F]/g,'_').replace(/\s+/g,' ').trim().slice(0,160) || 'file';
  const driveUrl = v => {
    try { const u=new URL(v); return u.protocol==='https:' && u.hostname==='drive.google.com' && /\/drive\/(u\/\d+\/)?folders\/[A-Za-z0-9_-]+/.test(u.pathname); }
    catch { return false; }
  };
  const toast = (msg, type='') => {
    const root=q('#toast-root'); if(!root)return;
    const el=document.createElement('div'); el.className=`toast ${type}`; el.textContent=String(msg);
    root.appendChild(el); setTimeout(()=>el.remove(), type==='error'?7000:4000);
  };
  const errorText = e => {
    if (!e) return 'Unknown error';
    if (typeof e === 'string') return e;
    return e.message || e.error_description || e.details || e.hint || JSON.stringify(e);
  };
  async function guard(fn, {success=null, silent=false}={}) {
    try { const r=await fn(); if(success)toast(success,'ok'); return r; }
    catch(e){ console.error(e); if(!silent)toast(errorText(e),'error'); throw e; }
  }
  const modalRoot=()=>q('#modal-root');
  function closeModal(){ const r=modalRoot(); if(r)r.innerHTML=''; }
  function modal({title='',body='',actions='',wide=false,onOpen=null,closeOnBackdrop=true}){
    const r=modalRoot();
    r.innerHTML=`<div class="modal-backdrop" data-modal-bg><section class="modal" style="${wide?'width:min(900px,100%)':''}"><h2>${esc(title)}</h2><div class="modal-body">${body}</div><div class="modal-actions">${actions||'<button class="btn ghost" data-close>Close</button>'}</div></section></div>`;
    q('[data-close]',r)?.addEventListener('click',closeModal);
    if(closeOnBackdrop)q('[data-modal-bg]',r)?.addEventListener('click',e=>{if(e.target===e.currentTarget)closeModal()});
    if(onOpen)onOpen(r);
    return q('.modal',r);
  }
  function confirmBox(title,body,confirm='Confirm'){
    return new Promise(resolve=>{
      const r=modal({title,body:`<p>${esc(body)}</p>`,actions:`<button class="btn ghost" data-no>Cancel</button><button class="btn danger" data-yes>${esc(confirm)}</button>`,closeOnBackdrop:false});
      q('[data-no]',r).onclick=()=>{closeModal();resolve(false)};
      q('[data-yes]',r).onclick=()=>{closeModal();resolve(true)};
    });
  }
  function promptBox({title,fields,submit='Save',note=''}){
    return new Promise(resolve=>{
      const inputs=fields.map((f,i)=>{
        if(f.type==='checkbox')return `<label class="switch field"><input id="pf${i}" type="checkbox" ${f.value?'checked':''}><span>${esc(f.label)}</span></label>`;
        if(f.type==='textarea')return `<div class="field"><label for="pf${i}">${esc(f.label)}</label><textarea id="pf${i}" class="textarea" maxlength="${f.max||10000}" placeholder="${attr(f.placeholder||'')}">${esc(f.value||'')}</textarea></div>`;
        if(f.type==='select')return `<div class="field"><label for="pf${i}">${esc(f.label)}</label><select id="pf${i}" class="select">${(f.options||[]).map(o=>`<option value="${attr(o.value)}" ${String(o.value)===String(f.value)?'selected':''}>${esc(o.label)}</option>`).join('')}</select></div>`;
        return `<div class="field"><label for="pf${i}">${esc(f.label)}</label><input id="pf${i}" class="input" type="${attr(f.type||'text')}" value="${attr(f.value||'')}" maxlength="${f.max||254}" placeholder="${attr(f.placeholder||'')}" ${f.required===false?'':'required'}></div>`;
      }).join('');
      const r=modal({title,body:`<form id="prompt-form">${inputs}${note?`<p class="hint">${esc(note)}</p>`:''}</form>`,actions:`<button class="btn ghost" data-no>Cancel</button><button class="btn primary" data-yes>${esc(submit)}</button>`,closeOnBackdrop:false});
      const done=ok=>{
        if(!ok){closeModal();resolve(null);return}
        const form=q('#prompt-form',r); if(!form.reportValidity())return;
        const vals=fields.map((f,i)=>f.type==='checkbox'?q(`#pf${i}`,r).checked:q(`#pf${i}`,r).value.trim());
        closeModal();resolve(vals);
      };
      q('[data-no]',r).onclick=()=>done(false); q('[data-yes]',r).onclick=()=>done(true);
      q('#prompt-form',r).onsubmit=e=>{e.preventDefault();done(true)};
    });
  }
  function download(name,data,type='text/plain;charset=utf-8'){
    const blob=data instanceof Blob?data:new Blob([data],{type});
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
  }
  const csvCell = v => `"${String(v??'').replace(/"/g,'""').replace(/^([=+\-@])/,'\'$1')}"`;
  function makeCsv(rows,headers){return '\uFEFF'+[headers.map(csvCell).join(','),...rows.map(r=>headers.map(h=>csvCell(r[h])).join(','))].join('\r\n')}
  function setBusy(el,busy,label='Working…'){ if(!el)return; if(busy){el.dataset.old=el.textContent;el.textContent=label;el.disabled=true}else{el.textContent=el.dataset.old||el.textContent;el.disabled=false} }
  async function copy(text){await navigator.clipboard.writeText(text);toast('Copied to clipboard.','ok')}
  async function browserNotify(title,body){
    if(!('Notification'in window))return;
    if(Notification.permission==='default')return;
    if(Notification.permission==='granted'&&document.visibilityState!=='visible')new Notification(title,{body,icon:'icons/Icon-192.png'});
  }
  async function requestNotifications(){
    if(!('Notification'in window))throw new Error('Browser notifications are not supported here.');
    const p=await Notification.requestPermission(); if(p!=='granted')throw new Error('Notification permission was not granted.'); toast('Browser notifications enabled.','ok');
  }
  function routeInvite(){
    const u=new URL(location.href); return window.EDU_ENTRY?.invite || u.searchParams.get('invite') || (u.hash.match(/[?&]invite=([0-9a-f-]{36})/i)?.[1]||null);
  }
  function clearInvite(){if(window.EDU_ENTRY)window.EDU_ENTRY.invite=null;window.eduCleanAddress?.()}
  function debounce(fn,ms=300){let t;return(...a)=>{clearTimeout(t);t=setTimeout(()=>fn(...a),ms)}}
  function sleep(ms){return new Promise(r=>setTimeout(r,ms))}
  async function timeout(p,ms,msg='Operation timed out'){let t;return Promise.race([p,new Promise((_,rej)=>t=setTimeout(()=>rej(new Error(msg)),ms))]).finally(()=>clearTimeout(t))}

  const ICONS = {
    plus:'<path d="M12 5v14M5 12h14"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 2v6M17 2v6M3 11h18m-13 5 2 2 4-4"/>',
    link:'<path d="m10 13 4-4M8 16l-1 1a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0M16 8l1-1a4 4 0 0 1 6 6l-4 4a4 4 0 0 1-6 0"/>',
    groups:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    forum:'<path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 8h8M8 12h5"/>',
    meeting:'<rect x="3" y="5" width="13" height="14" rx="2"/><path d="m16 10 5-3v10l-5-3z"/>',
    bell:'<path d="M18 8a6 6 0 1 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
    user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/>',
    mic:'<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 17v5M8 22h8"/>',
    camera:'<path d="M15 10l4.5-3v10L15 14z"/><rect x="3" y="5" width="12" height="14" rx="2"/>',
    share:'<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 21h8M12 16v5"/>',
    record:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/>',
    pointer:'<path d="m5 3 6 16 2-6 6-2z"/><path d="m13 13 5 5"/>',
    people:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/>',
    chat:'<path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/>',
    headset:'<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><path d="M18 19c0 2-2 3-4 3h-2"/><rect x="3" y="13" width="4" height="6" rx="2"/><rect x="17" y="13" width="4" height="6" rx="2"/>',
    phone:'<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13 1 .37 2 .72 2.94a2 2 0 0 1-.45 2.11L8.09 10.06a16 16 0 0 0 6 6l1.29-1.29a2 2 0 0 1 2.11-.45c.94.35 1.93.59 2.94.72A2 2 0 0 1 22 16.92z"/>',
    logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
    edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    send:'<path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/>',
    settings:'<path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"/><path d="m9 3 1-2h4l1 2 3 2 2 1v4l-2 2 1 3-1 3-3 1-2 2h-4l-2-2-3-1-1-3 1-3-2-2V6l2-1z"/>',
    maximize:'<path d="M8 3H3v5M16 3h5v5M21 16v5h-5M3 16v5h5"/>',
    cloud:'<path d="M7 18h11a4 4 0 0 0 1-8 7 7 0 0 0-13-1 5 5 0 0 0 1 9z"/>',
    chart:'<path d="M5 20V10h3v10zM11 20V4h3v16zM17 20v-7h3v7z"/>',
    file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',
    drive:'<path d="M7 3h10l5 9-5 9H7l-5-9z"/><path d="M7 3l5 9 5-9M2 12h10l5 9"/>',
    back:'<path d="m15 18-6-6 6-6"/>',
    close:'<path d="M18 6 6 18M6 6l12 12"/>',
    photo:'<path d="M14.5 4 16 7h3a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h3l1.5-3z"/><circle cx="12" cy="13" r="3"/>'
  };
  function icon(name, cls='') { return `<svg class="ui-icon ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name]||ICONS.chat}</svg>`; }

  Object.assign(U,{q,qa,esc,attr,fmtDate,fmtBytes,uuid,shortId,isUuid,inviteCode,safeName,driveUrl,toast,errorText,guard,modal,closeModal,confirmBox,promptBox,download,csvCell,makeCsv,setBusy,copy,browserNotify,requestNotifications,routeInvite,clearInvite,debounce,sleep,timeout,icon});
  window.EduUI=U;
})();
