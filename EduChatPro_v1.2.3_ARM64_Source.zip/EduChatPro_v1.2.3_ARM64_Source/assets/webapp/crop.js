window.EduCrop=async file=>{
 const U=window.EduUI;if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>10485760)throw new Error('Choose JPG, PNG or WebP under 10 MB.');
 const url=URL.createObjectURL(file),img=new Image();try{await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(new Error('Cannot read this photo.'));img.src=url});
 return await new Promise(resolve=>{
 const r=U.modal({title:'Adjust photo',body:'<p class="hint">Drag to position. Use the slider to zoom.</p><canvas id="crop-canvas" width="320" height="320" style="width:min(320px,100%);touch-action:none;display:block;margin:auto;border-radius:16px"></canvas><label>Zoom<input id="crop-zoom" type="range" min="1" max="4" step="0.01" value="1" style="width:100%"></label>',actions:'<button class="btn ghost" id="crop-cancel">Cancel</button><button class="btn primary" id="crop-save">Use photo</button>',closeOnBackdrop:false});
 const canvas=U.q('#crop-canvas',r),ctx=canvas.getContext('2d'),base=Math.max(320/img.naturalWidth,320/img.naturalHeight);let zoom=1,x=0,y=0,drag;
 const draw=()=>{const w=img.naturalWidth*base*zoom,h=img.naturalHeight*base*zoom;x=Math.max(-(w-320)/2,Math.min((w-320)/2,x));y=Math.max(-(h-320)/2,Math.min((h-320)/2,y));ctx.fillStyle='#fff';ctx.fillRect(0,0,320,320);ctx.drawImage(img,(320-w)/2+x,(320-h)/2+y,w,h)};
 canvas.onpointerdown=e=>{canvas.setPointerCapture(e.pointerId);drag={x:e.clientX,y:e.clientY}};canvas.onpointermove=e=>{if(!drag)return;const scale=320/canvas.getBoundingClientRect().width;x+=(e.clientX-drag.x)*scale;y+=(e.clientY-drag.y)*scale;drag={x:e.clientX,y:e.clientY};draw()};canvas.onpointerup=canvas.onpointercancel=()=>drag=null;
 U.q('#crop-zoom',r).oninput=e=>{zoom=Number(e.target.value);draw()};U.q('#crop-cancel',r).onclick=()=>{U.closeModal();resolve(null)};U.q('#crop-save',r).onclick=()=>{const small=document.createElement('canvas');small.width=small.height=256;small.getContext('2d').drawImage(canvas,0,0,256,256);small.toBlob(blob=>{U.closeModal();resolve(blob)},'image/jpeg',.76)};draw();
 });}finally{URL.revokeObjectURL(url)}
};

window.EduCoverCrop=async file=>{
 const U=window.EduUI;if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>10485760)throw new Error('Choose JPG, PNG or WebP under 10 MB.');
 const url=URL.createObjectURL(file),img=new Image();try{await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(new Error('Cannot read this cover photo.'));img.src=url});
 return await new Promise(resolve=>{
  const CW=900,CH=300,r=U.modal({title:'Adjust cover photo',wide:true,body:'<p class="hint">Drag to position the cover like Facebook. Use the slider to zoom.</p><canvas id="cover-canvas" width="900" height="300" style="width:100%;max-width:900px;aspect-ratio:3/1;touch-action:none;display:block;margin:auto;border-radius:16px"></canvas><label>Zoom<input id="cover-zoom" type="range" min="1" max="4" step="0.01" value="1" style="width:100%"></label>',actions:'<button class="btn ghost" id="cover-cancel">Cancel</button><button class="btn primary" id="cover-save">Use cover</button>',closeOnBackdrop:false});
  const canvas=U.q('#cover-canvas',r),ctx=canvas.getContext('2d'),base=Math.max(CW/img.naturalWidth,CH/img.naturalHeight);let zoom=1,x=0,y=0,drag;
  const draw=()=>{const w=img.naturalWidth*base*zoom,h=img.naturalHeight*base*zoom;x=Math.max(-(w-CW)/2,Math.min((w-CW)/2,x));y=Math.max(-(h-CH)/2,Math.min((h-CH)/2,y));ctx.fillStyle='#111';ctx.fillRect(0,0,CW,CH);ctx.drawImage(img,(CW-w)/2+x,(CH-h)/2+y,w,h)};
  canvas.onpointerdown=e=>{canvas.setPointerCapture(e.pointerId);drag={x:e.clientX,y:e.clientY}};canvas.onpointermove=e=>{if(!drag)return;const scale=CW/canvas.getBoundingClientRect().width;x+=(e.clientX-drag.x)*scale;y+=(e.clientY-drag.y)*scale;drag={x:e.clientX,y:e.clientY};draw()};canvas.onpointerup=canvas.onpointercancel=()=>drag=null;
  U.q('#cover-zoom',r).oninput=e=>{zoom=Number(e.target.value);draw()};U.q('#cover-cancel',r).onclick=()=>{U.closeModal();resolve(null)};U.q('#cover-save',r).onclick=()=>canvas.toBlob(blob=>{U.closeModal();resolve(blob)},'image/jpeg',.82);draw();
 });}finally{URL.revokeObjectURL(url)}
};

// Crop is a child dialog during first-login setup. Preserve that dialog and its handlers.
(() => {
 const crop=window.EduCrop;let busy=false;
 window.EduCrop=async file=>{
  if(busy)return null;
  busy=true;const root=document.querySelector('#modal-root'),previous=document.createDocumentFragment();
  if(root)while(root.firstChild)previous.append(root.firstChild);
  try{return await crop(file);}
  finally{if(root){root.replaceChildren();root.append(previous);}busy=false;}
 };
})();
