(() => {
  'use strict';
  const paths = {
    home:'<path d="m3 11 9-8 9 8v10h-6v-7H9v7H3V11Z"/>',
    search:'<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/>',
    menu:'<path d="M5 6h14M5 12h14M5 18h14"/>',
    more:'<circle cx="12" cy="4" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="20" r="1"/>',
    settings:'<path d="m9 3 6 0 1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1 1-3Z"/><circle cx="12" cy="12" r="3"/>',
    bookmark:'<path d="M6 3h12v19l-6-5-6 5V3Z"/>',
    moon:'<path d="M19 17A9 9 0 0 1 9 3a9 9 0 1 0 10 14Z"/>',
    check:'<path d="m4 12 5 5L21 5"/>',
    doublecheck:'<path d="m1 12 5 5L18 5m-7 10 2 2L25 5"/>',
    back:'<path d="m14 4-8 8 8 8M6 12h16"/>',
    chevron:'<path d="m9 5 7 7-7 7"/>',
    cloud:'<path d="M6 18a5 5 0 0 1-1-10 7 7 0 0 1 13-1 5 5 0 0 1 0 11H6Z"/>',
    smile:'<circle cx="12" cy="12" r="9"/><path d="M8 14q4 5 8 0M8 8h.01M16 8h.01"/>',
    paperclip:'<path d="m9 16 8-8a3 3 0 0 0-4-4L4 13a5 5 0 0 0 7 7L21 10M8 13l6-6"/>',
    send:'<path d="m3 3 19 9-19 9 4-9-4-9Zm4 9h15"/>',
    trash:'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7"/>',
    sliders:'<path d="M4 6h16M7 12h10M10 18h4"/>',
    at:'<circle cx="11" cy="12" r="4"/><path d="M15 8v8c9 1 8-14-3-14A10 10 0 1 0 18 20"/>',
    megaphone:'<path d="M3 10v6h5l11 5V3L8 10H3Zm5 6 2 6h4l-2-5M8 10v6"/>',
    list:'<path d="M9 5h12M9 12h12M9 19h12M3 4h2v2H3zM3 11h2v2H3zM3 18h2v2H3z"/>',
    flame:'<path d="M12 2c4 6-3 7 3 11 2-2 3-4 3-4 9 14-15 19-13 4 0-4 5-7 7-11Z"/>',
    question:'<circle cx="12" cy="12" r="9"/><path d="M9 9c0-4 7-4 6 0-1 2-3 1-3 5M12 17h.01"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8" cy="8" r="2"/><path d="m3 17 6-5 4 3 4-5 4 7"/>',
    chart:'<path d="M3 12h4v9H3zM10 3h4v18h-4zM17 8h4v13h-4z"/>',
    like:'<path d="M8 21H3V10h5m0 11h10l3-10H14l1-7-3-2-4 8v11Z"/>',
    share:'<path d="m14 3 8 8-8 8v-5C6 13 3 20 3 20c0-12 4-12 11-12V3Z"/>',
    trending:'<path d="m3 18 6-7 4 3 8-10M15 4h6v6"/>',
    trophy:'<path d="M7 3h10v7a5 5 0 0 1-10 0V3Zm0 2H3v3a5 5 0 0 0 5 5m9-8h4v3a5 5 0 0 1-5 5M12 15v6M7 21h10"/>',
    bulb:'<path d="M8 17c0-4-3-4-3-8a7 7 0 0 1 14 0c0 4-3 4-3 8H8Zm1 4h6M12 17v-7"/>',
    ban:'<circle cx="12" cy="12" r="9"/><path d="m6 6 12 12"/>',

    school:'<path d="m2 9 10-5 10 5-10 5-10-5Z"/><path d="M6 11v6c4 3 8 3 12 0v-6M22 9v7"/>',
    chat:'<path d="M21 11a8 8 0 0 1-8 8H5l-3 3V11a8 8 0 0 1 8-8h3a8 8 0 0 1 8 8Z"/><path d="M7 8h9M7 12h6"/>',
    video:'<rect x="3" y="5" width="12" height="14" rx="3"/><path d="m15 10 6-4v12l-6-4"/>',
    mic:'<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2M12 19v3M8 22h8"/>',
    screen:'<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4m-4-11 4-4 4 4M12 6v8"/>',
    record:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>',
    pointer:'<path d="m5 3 14 9-7 1-3 7-4-17Z"/>',
    people:'<circle cx="9" cy="7" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M16 4a3 3 0 0 1 0 6M18 14a5 5 0 0 1 3 5v2"/>',
    headphones:'<path d="M3 14v-3a9 9 0 0 1 18 0v3"/><rect x="3" y="12" width="4" height="9" rx="2"/><rect x="17" y="12" width="4" height="9" rx="2"/>',
    phone:'<path d="M3 15c5-5 13-5 18 0l-2 4-4-2v-3H9v3l-4 2-2-4Z"/>',
    bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
    user:'<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/>',
    shield:'<path d="m12 2 9 4v6c0 5-9 10-9 10S3 17 3 12V6l9-4Z"/><path d="m8 12 3 3 5-6"/>',
    folder:'<path d="M3 6V4h7l2 3h9v13H3V6Z"/>',
    file:'<path d="M5 2h9l5 5v15H5V2Z"/><path d="M14 2v6h5M8 12h8M8 16h8"/>',
    pin:'<path d="m8 3 8 0-1 7 4 4H5l4-4-1-7ZM12 14v8"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>',
    plus:'<path d="M12 4v16M4 12h16"/>',
    refresh:'<path d="M20 7v5h-5M4 17v-5h5M6 6a8 8 0 0 1 14 6M4 12a8 8 0 0 0 14 6"/>',
    volume:'<path d="m3 9 5 0 5-5v16l-5-5H3V9ZM17 8a6 6 0 0 1 0 8M20 5a10 10 0 0 1 0 14"/>'
  };
  window.EduIcons = name => `<svg class="edu-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${paths[name] || paths.file}</svg>`;
})();

;
(() => {
  // Decode and re-encode user photos, limiting dimensions and stripping metadata.
  async function compress(file) {
    if (!['image/jpeg','image/png','image/webp'].includes(file.type) || file.size>10485760)
      throw new Error('Choose a JPG, PNG or WebP image up to 10 MB.');
    const url=URL.createObjectURL(file),img=new Image();
    try {
      await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(new Error('This image could not be read.'));img.src=url;});
      const scale=Math.min(1,640/Math.max(img.naturalWidth,img.naturalHeight));
      const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
      const ctx=canvas.getContext('2d');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
      const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',.82));
      if(!blob||blob.size>1048576)throw new Error('Image could not be compressed below 1 MB.');return blob;
    } finally {URL.revokeObjectURL(url);}
  }
  window.EduImages={compress};
})();

;
(() => {
 'use strict';
 const W=window.EduWorkspace=window.EduWorkspace||{cleanups:[],pending:null};
 W.dispose=()=>{window.EduUI.closeModal();for(const fn of W.cleanups.splice(0)){try{fn();}catch{}}};
 W.rich=value=>window.EduUI.esc(value||'').replace(/\*\*([^]+?)\*\*/g,'<strong>$1</strong>').replace(/==([^]+?)==/g,'<mark>$1</mark>');
 W.icon=(name)=>window.EduIcons(name);
 W.run=(fn)=>async(...args)=>{try{return await fn(...args);}catch(e){window.EduUI.toast(window.EduUI.errorText(e),'error');}};
 W.data=r=>{if(r.error)throw r.error;return r.data;};
 W.time=v=>v?new Intl.DateTimeFormat(undefined,{hour:'numeric',minute:'2-digit'}).format(new Date(v)):'';
 W.date=v=>new Intl.DateTimeFormat(undefined,{dateStyle:'medium'}).format(new Date(v));
 W.avatar=(name,path=null,bucket='avatars',extra='')=>`<span class="ws-avatar ${extra}">${path?`<img alt="${window.EduUI.attr(name||'Profile')}" data-photo="${window.EduUI.attr(path)}" data-bucket="${bucket}" loading="lazy">`:window.EduUI.esc((name||'?').trim().slice(0,1).toUpperCase())}</span>`;
 const photoCache=new Map();
 W.photos=async(root,sb)=>{for(const img of root.querySelectorAll('[data-photo]')){const key=img.dataset.bucket+'/'+img.dataset.photo;try{let saved=photoCache.get(key);if(!saved||saved.expires<Date.now()){const r=W.data(await sb.storage.from(img.dataset.bucket).createSignedUrl(img.dataset.photo,900));saved={url:r.signedUrl,expires:Date.now()+800000};photoCache.set(key,saved);}if(img.isConnected)img.src=saved.url;}catch{img.alt='Profile';}}};
 W.button=(icon,label,attrs='',className='ws-icon-btn')=>`<button class="${className}" title="${label}" aria-label="${label}" ${attrs}>${W.icon(icon)}</button>`;
 W.watch=(sb,tables,callback)=>{let timer;const channel=sb.channel('workspace-'+crypto.randomUUID());for(const table of tables)channel.on('postgres_changes',{event:'*',schema:'public',table},()=>{clearTimeout(timer);timer=setTimeout(()=>Promise.resolve(callback()).catch(e=>window.EduUI.toast(e.message,'error')),200);});channel.subscribe();W.cleanups.push(()=>{clearTimeout(timer);sb.removeChannel(channel);});return channel;};
 W.upload=async(sb,bucket,prefix,file)=>{
  if(!file.size||file.size>10485760)throw new Error('Choose a file between 1 byte and 10 MB.');
  let upload=file,mime=file.type||({pdf:'application/pdf',zip:'application/zip',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}[file.name.split('.').pop().toLowerCase()]);
  if(mime?.startsWith('image/')){upload=await window.EduImages.compress(file);mime='image/jpeg';}
  const allowed=['image/jpeg','image/png','image/webp','application/pdf','application/zip','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','audio/webm','audio/ogg','audio/mp4','video/mp4','video/webm','video/quicktime'];
  mime=mime?.split(';')[0];if(!allowed.includes(mime))throw new Error('This file type is not supported.');
  const path=prefix+'/'+crypto.randomUUID()+'/'+window.EduUI.safeName(file.name);W.data(await sb.storage.from(bucket).upload(path,upload,{contentType:mime}));return {attachment_path:path,attachment_name:file.name,attachment_mime:mime};
 };
 W.attachment=(m,bucket)=>{if(!m.attachment_path&&m.image_path)m={...m,attachment_path:m.image_path,attachment_name:'Post media',attachment_mime:/\.(mp4|webm|mov)$/i.test(m.image_path)?'video/mp4':'image/jpeg'},bucket='forum-images';else if(m.attachment_path&&!m.attachment_mime)m={...m,attachment_name:m.file_name||'Attachment',attachment_mime:m.mime_type||'application/octet-stream'},bucket=m.thread_id?'direct-files':'group-files';return !m.attachment_path?'':`<div class="ws-attachment" data-file-path="${window.EduUI.attr(m.attachment_path)}" data-file-bucket="${bucket}">${m.attachment_mime?.startsWith('image/')?`<img alt="${window.EduUI.attr(m.attachment_name||'Attachment')}" data-photo="${window.EduUI.attr(m.attachment_path)}" data-bucket="${bucket}" loading="lazy">`:m.attachment_mime?.startsWith('video/')?'<video controls preload="metadata"></video>':m.attachment_mime?.startsWith('audio/')?'<audio controls preload="none"></audio>':W.icon('file')}<button class="ws-file-open">${window.EduUI.esc(m.attachment_name||'Open attachment')}</button></div>`;};
 W.files=(root,sb)=>{for(const el of root.querySelectorAll('[data-file-path]')){el.querySelector('.ws-file-open').onclick=W.run(async()=>{const link=W.data(await sb.storage.from(el.dataset.fileBucket).createSignedUrl(el.dataset.filePath,300));window.open(link.signedUrl,'_blank','noopener');});const audio=el.querySelector('audio,video');if(audio)sb.storage.from(el.dataset.fileBucket).createSignedUrl(el.dataset.filePath,600).then(r=>{if(!r.error&&audio.isConnected)audio.src=r.data.signedUrl;});}};
 W.shell=(c)=>{
  const {S,U,navigate}=c;const links=[['chats','chat','Chats'],['groups','people','Groups'],['meetings','video','Calls'],['contacts','user','Contacts'],['saved','bookmark','Saved'],['forum','home','Forum'],['notifications','bell','Notifications'],['profile','settings','Settings']];if(c.isAdmin())links.push(['admin','shield','Admin']);
  document.querySelector('#app').innerHTML=`<div class="ws-shell"><aside class="ws-rail"><a class="ws-logo" href="#" aria-label="EduChat home">${W.icon('school')}<small>EC</small></a><nav>${links.map(([id,icon,title])=>`<button data-nav="${id}" title="${title}" aria-label="${title}">${W.icon(icon)}<span>${title}</span></button>`).join('')}</nav><button class="ws-account" title="Your profile">${W.avatar(S.profile?.full_name,S.profile?.avatar_path)}<i></i></button></aside><div class="ws-main"><header class="ws-topbar">${W.button('menu','Toggle sidebar','id="ws-menu"')}<b>Edu Chat Pro</b><span class="spacer"></span>${W.button('bell','Notifications','data-nav="notifications"')}${W.button('moon','Toggle dark mode','id="ws-theme"')}<button class="ws-user" title="Profile">${W.avatar(S.profile?.full_name,S.profile?.avatar_path)}</button><button class="ws-signout">Sign out</button></header><main id="page" class="ws-page"></main></div></div>`;
  U.qa('[data-nav]').forEach(b=>b.onclick=()=>{W.inboxFilter=b.dataset.nav==='chats'?'direct':null;return navigate(b.dataset.nav);});U.q('.ws-logo').onclick=e=>{e.preventDefault();navigate('chats');};U.q('.ws-account').onclick=U.q('.ws-user').onclick=()=>navigate('profile');U.q('.ws-signout').onclick=W.run(()=>c.sb.auth.signOut());
  U.q('#ws-menu').onclick=()=>document.querySelector('.ws-shell').classList.toggle('rail-expanded');
  let dark=false;try{dark=localStorage.getItem('educhat-theme')==='dark';}catch{}document.body.classList.toggle('ws-dark',dark);
  U.q('#ws-theme').onclick=()=>{document.body.classList.toggle('ws-dark');try{localStorage.setItem('educhat-theme',document.body.classList.contains('ws-dark')?'dark':'light');}catch{}};W.photos(document.querySelector('.ws-shell'),c.sb);
 };
 W.openChat=(c,kind,id)=>{W.pending={kind,id};return c.navigate(kind==='group'?'groups':'people');};
})();

;
(() => {
 'use strict';const W=window.EduWorkspace;
 W.chat=async(c,initial='all')=>{
  const {sb,S,U}=c,root=U.q('#page');let closed=false,threads=[],selected=null,filter=initial==='groups'?'group':initial==='direct'?'direct':'all',view=initial==='saved'?'saved':'all',search='',offset=0,messages=[],messageSearch='',messageOffset=0,profiles={},receipts=[],reactions=[],generation=0,listGeneration=0,attached=null,recorder=null,recordStream=null,recordChunks=[],pollBusy=false,messageRequest=0,lastListQuery='';
  const myId=S.user.id,run=W.run;W.cleanups.push(()=>{closed=true;generation++;if(recorder?.state==='recording')recorder.stop();recordStream?.getTracks().forEach(t=>t.stop());});
  root.className='content workspace-v3 ws-page ws-chat-page';root.innerHTML=`<div class="ws-inbox"><section class="ws-chat-list"><div class="ws-list-heading"><h1>Chats</h1><span class="spacer"></span>${W.button('search','Search people and groups','id="focus-search"')}${W.button('plus','New conversation','id="new-chat"','ws-icon-btn blue')}</div><div class="ws-tabs" id="inbox-tabs"><button data-filter="all" class="active">All</button><button data-filter="group">Groups</button><button data-view="unread">Unread</button><button data-view="favorite">Favorites</button></div><div class="ws-chat-search">${W.icon('search')}<input id="chat-search" placeholder="Search chats, groups, people…" aria-label="Search chats, groups, people">${W.button('sliders','Filter individual chats','id="direct-filter"')}</div><div class="ws-thread-scroll"><div id="thread-list"></div><button id="thread-more" class="ws-more">Load more conversations</button><div id="people-results"></div></div></section><section class="ws-conversation"><div class="ws-chat-empty">${W.icon('chat')}<h2>Your conversations</h2><p>Choose a chat or group to start messaging.</p></div></section><aside class="ws-chat-details"><div class="ws-chat-empty">${W.icon('people')}<p>Conversation details appear here.</p></div></aside></div>`;
  const conv=U.q('.ws-conversation',root),details=U.q('.ws-chat-details',root);
  function activateTabs(){U.qa('#inbox-tabs button',root).forEach(b=>b.classList.toggle('active',b.dataset.view?view===b.dataset.view:view==='all'&&filter===b.dataset.filter));U.q('#direct-filter').classList.toggle('active',filter==='direct');}
  async function loadList(append=false){
   const ticket=++listGeneration,key=JSON.stringify([search,filter,view]),count=!append&&key===lastListQuery?Math.max(1,Math.ceil(offset/60)):1,args={search_text:search,kind_filter:filter,view_filter:view==='saved'?'all':view};let data=[];for(let page=0;page<count;page++){const batch=W.data(await sb.rpc('chat_inbox',{...args,page_offset:append?offset:page*60}));if(closed||ticket!==listGeneration)return;data.push(...batch);if(batch.length<60)break;}lastListQuery=key;if(closed||ticket!==listGeneration)return;
   if(!append){threads=[];offset=0;}threads.push(...data);offset+=data.length;
   U.q('#thread-more',root).hidden=data.length===0||data.length%60!==0;const list=U.q('#thread-list',root);
   list.innerHTML=threads.length?threads.map(t=>`<button class="ws-thread ${selected?.id===t.id?'selected':''}" data-thread="${t.id}" data-kind="${t.kind}">${W.avatar(t.name,t.avatar_path,t.kind==='group'?'group-images':'avatars',t.kind==='group'?'group-avatar':'')}<span class="ws-thread-copy"><span class="ws-thread-title"><b>${U.esc(t.name)}</b><time>${W.time(t.last_at)}</time></span><span class="ws-thread-description">${U.esc(t.description||'')}</span><span class="ws-thread-preview">${U.esc(t.preview||'Start a conversation')}<span class="spacer"></span>${t.pinned?W.icon('pin'):''}${Number(t.unread)?`<i class="ws-unread">${Number(t.unread)>99?'99+':t.unread}</i>`:''}</span></span></button>`).join(''):'<div class="ws-empty">No conversations match this filter.</div>';
   U.qa('[data-thread]',list).forEach(b=>b.onclick=run(()=>select(threads.find(t=>t.id===b.dataset.thread&&t.kind===b.dataset.kind))));W.photos(list,sb);activateTabs();
  }
  async function peopleSearch(query){const target=U.q('#people-results',root);if(!query.trim()){target.innerHTML='';return;}const people=W.data(await sb.from('profiles').select('id,full_name,avatar_path').eq('status','active').neq('id',myId).ilike('full_name','%'+query.trim()+'%').order('full_name').limit(20));if(closed||query!==search)return;target.innerHTML=`<h4 class="ws-section-label">People</h4>`+people.map(p=>`<button class="ws-thread" data-person="${p.id}">${W.avatar(p.full_name,p.avatar_path)}<b>${U.esc(p.full_name)}</b>${W.icon('plus')}</button>`).join('');U.qa('[data-person]',target).forEach(b=>b.onclick=run(()=>startDirect(b.dataset.person)));W.photos(target,sb);}
  async function startDirect(id){const thread=W.data(await sb.rpc('start_direct_chat',{other_user:id}));search='';U.q('#chat-search').value='';filter='all';view='all';await loadList();let item=threads.find(t=>t.id===thread);if(!item){const p=W.data(await sb.from('profiles').select('id,full_name,avatar_path').eq('id',id).single());item={id:thread,kind:'direct',peer_id:id,name:p.full_name,avatar_path:p.avatar_path};}await select(item);}
  U.q('#chat-search').oninput=U.debounce(run(async e=>{search=e.target.value;await Promise.all([loadList(),peopleSearch(search)]);}),250);
  U.q('#focus-search').onclick=()=>U.q('#chat-search').focus();U.q('#new-chat').onclick=()=>{const r=U.modal({title:'New conversation',body:'<p>Find a person or create a class group.</p>',actions:'<button class="btn primary" id="find-person">Find a person</button>'+'<button class="btn" id="create-chat-group">Create group</button>'+'<button class="btn" data-close>Close</button>'});U.q('#find-person',r).onclick=()=>{U.closeModal();U.q('#chat-search').focus();U.q('#people-results').innerHTML='<p class="ws-empty">Type a person’s name above, then select them to start a private chat.</p>';};U.q('#create-chat-group',r)?.addEventListener('click',run(async()=>{const values=await U.promptBox({title:'Create group',fields:[{label:'Group name',max:120},{label:'Description',type:'textarea',required:false,max:2000}],submit:'Create'});if(!values)return;const g=W.data(await sb.from('groups').insert({name:values[0],description:values[1],created_by:myId}).select().single());filter='group';view='all';search='';U.q('#chat-search').value='';await loadList();await select({...g,kind:'group',avatar_path:g.image_path});}));};
  U.q('#direct-filter').onclick=run(async()=>{filter=filter==='direct'?'all':'direct';view='all';await loadList();});
  U.qa('#inbox-tabs button').forEach(b=>b.onclick=run(async()=>{if(b.dataset.view)view=b.dataset.view;else{filter=b.dataset.filter;view='all';}await loadList();}));U.q('#thread-more').onclick=run(()=>loadList(true));
  async function select(item){if(!item)return;if(recorder?.state==='recording')recorder.stop();selected=item;messageSearch='';messageOffset=0;messages=[];attached=null;const ticket=++generation;root.classList.add('conversation-open');
   conv.innerHTML=`<header class="ws-conversation-header">${W.button('back','Back to chats','id="back-chats"','ws-icon-btn mobile-only')}${W.avatar(item.name,item.avatar_path,item.kind==='group'?'group-images':'avatars')}<div class="ws-heading-copy"><h2>${U.esc(item.name)}</h2><p id="chat-subtitle">${U.esc(item.description||'Direct conversation')}</p></div><span class="spacer"></span>${W.button('search','Search messages','id="message-search-toggle"')}${W.button('video','Start video call','id="chat-video"')}${W.button('phone','Start audio call','id="chat-audio"')}${item.kind==='group'?W.button('megaphone','Group announcements','id="group-announcements"'):''}${W.button('more','Conversation details','id="show-details"')}</header><div class="ws-message-search" hidden><input id="message-search" placeholder="Search messages in this conversation…" aria-label="Search messages">${W.button('close','Clear message search','id="close-message-search"')}</div><div class="ws-message-log" id="message-log"><button class="ws-more" id="older-messages">Load older messages</button><div id="message-content"></div></div><form class="ws-composer" id="ws-send"><div id="attachment-preview" hidden></div><div class="ws-composer-row">${W.button('smile','Insert emoji','type="button" id="insert-emoji"')}${W.button('paperclip','Attach a file or photo','type="button" id="attach-file"')}<input id="chat-file" type="file" hidden><textarea id="message-input" rows="1" maxlength="4000" placeholder="Type a message…" title="Mention someone with @Full Name" aria-label="Message"></textarea>${W.button('mic','Record voice message','type="button" id="voice-record"')}<button class="ws-icon-btn blue send" type="submit" aria-label="Send message">${W.icon('send')}</button></div></form>`;
   S.group=item.kind==='group'?item:null;S.direct=item.kind==='direct'?item.peer_id:null;const canSend=item.kind==='direct'||item.allow_member_messaging||item.created_by===myId||c.can('groups.manage');U.q('#message-input').disabled=!canSend;U.q('#ws-send button[type="submit"]').disabled=!canSend;U.q('#attach-file').disabled=U.q('#voice-record').disabled=!canSend;if(!canSend)U.q('#message-input').placeholder='Group messaging is paused by an administrator.';
   U.q('#back-chats').onclick=()=>root.classList.remove('conversation-open');U.q('#show-details').onclick=()=>{root.classList.remove('details-hidden');root.classList.toggle('details-open');};
   U.q('#message-search-toggle').onclick=()=>{U.q('.ws-message-search').hidden=false;U.q('#message-search').focus();};U.q('#close-message-search').onclick=run(async()=>{messageSearch='';messages=[];U.q('#message-search').value='';U.q('.ws-message-search').hidden=true;await loadMessages(false);});
   U.q('#message-search').oninput=U.debounce(run(async e=>{messageSearch=e.target.value;messages=[];await loadMessages(false);}),250);
   U.q('#older-messages').onclick=run(()=>loadMessages(true));U.q('#message-log').onscroll=U.debounce(()=>markSeen().catch(()=>{}),200);
   U.q('#group-announcements')?.addEventListener('click',run(async()=>{const group=selected,rows=W.data(await sb.from('group_messages').select('*').eq('group_id',group.id).eq('is_announcement',true).order('created_at',{ascending:false}).limit(100)),allowed=c.can('announcements.create')||group.created_by===myId,r=U.modal({title:'Group announcements',body:rows.map(m=>`<article class="ws-card"><p>${U.esc(m.body)}</p><small>${U.fmtDate(m.created_at)}</small></article>`).join('')||'<p>No announcements yet.</p>',actions:`${allowed?'<button class="btn primary" id="new-announcement">Post announcement</button>':''}<button class="btn" data-close>Close</button>`});U.q('#new-announcement',r)?.addEventListener('click',run(async()=>{const values=await U.promptBox({title:'Post announcement',fields:[{label:'Announcement',type:'textarea',max:4000}],submit:'Post'});if(!values?.[0]?.trim())return;W.data(await sb.from('group_messages').insert({group_id:group.id,sender_id:myId,body:values[0].trim(),is_announcement:true}));if(selected?.id===group.id)await loadMessages(false,true);}));}));
   U.q('#insert-emoji').onclick=()=>{const input=U.q('#message-input'),r=U.modal({title:'Choose emoji',body:`<div class="ws-emoji-options">${['😊','👍','❤️','🎉','📚','✅','👋','😂','🙏','😮','💡','👏','🔥','🤝','💯','⭐','🤔','😢','😍','🎓','📌','✨','🙌','💪'].map(e=>`<button type="button" data-pick-emoji="${e}">${e}</button>`).join('')}</div>`});U.qa('[data-pick-emoji]',r).forEach(b=>b.onclick=()=>{input.setRangeText(b.dataset.pickEmoji,input.selectionStart,input.selectionEnd,'end');U.closeModal();input.focus();});};U.q('#attach-file').onclick=()=>U.q('#chat-file').click();U.q('#chat-file').onchange=e=>{attached=e.target.files[0]||null;showAttachment();};
   U.q('#message-input').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();U.q('#ws-send').requestSubmit();}};U.q('#ws-send').onsubmit=run(send);
   U.q('#voice-record').onclick=run(async()=>{if(recorder?.state==='recording'){recorder.stop();return;}if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)throw new Error('Voice recording requires HTTPS and a supported browser.');recordStream=await navigator.mediaDevices.getUserMedia({audio:true});if(closed||ticket!==generation){recordStream.getTracks().forEach(t=>t.stop());return;}recordChunks=[];try{recorder=new MediaRecorder(recordStream);}catch(e){recordStream.getTracks().forEach(t=>t.stop());throw e;}const recordingStarted=Date.now(),activeRecorder=recorder,activeStream=recordStream,chunks=recordChunks;recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};recorder.onstop=()=>{clearTimeout(timeout);activeStream.getTracks().forEach(t=>t.stop());if(closed||ticket!==generation)return;const mime=activeRecorder.mimeType.split(';')[0];attached=new File(chunks,['voice-',Date.now(),mime==='audio/mp4'?'.m4a':mime==='audio/ogg'?'.ogg':'.webm'].join(''),{type:mime});attached.durationMs=Math.min(120000,Date.now()-recordingStarted);showAttachment();U.q('#voice-record').classList.remove('recording');};recorder.start();U.q('#voice-record').classList.add('recording');const timeout=setTimeout(()=>{if(activeRecorder.state==='recording')activeRecorder.stop();},120000);W.cleanups.push(()=>clearTimeout(timeout));});
   U.q('#chat-video').onclick=run(()=>call(false));U.q('#chat-audio').onclick=run(()=>call(true));
   await Promise.all([loadMessages(false),renderDetails()]);W.photos(conv,sb);if(ticket===generation){await loadList();if(W.pendingPanel){const target=W.pendingPanel;W.pendingPanel=null;root.classList.remove('details-hidden');root.classList.add('details-open');await panel(target);}}
  }
  function showAttachment(){const p=U.q('#attachment-preview');p.hidden=!attached;p.innerHTML=attached?`${W.icon('file')} ${U.esc(attached.name)} <button type="button" id="remove-attachment" aria-label="Remove attachment">×</button>`:'';U.q('#remove-attachment')?.addEventListener('click',()=>{attached=null;showAttachment();});}
  async function send(e){e.preventDefault();const input=U.q('#message-input'),button=U.q('#ws-send button[type="submit"]'),item=selected,ticket=generation;const body=input.value.trim();if(button.disabled||(!body&&!attached))return;button.disabled=true;let file,inserted=false;
   try{if(attached)await c.sendAttachment(item,attached,body);else{const row={body,sender_id:myId};row[item.kind==='group'?'group_id':'thread_id']=item.id;W.data(await sb.from(item.kind==='group'?'group_messages':'direct_messages').insert(row));}inserted=true;if(ticket!==generation||closed)return;input.value='';attached=null;showAttachment();messageSearch='';U.q('#message-search').value='';U.q('.ws-message-search').hidden=true;await loadMessages(false,true);await loadList();}
   catch(e){if(file&&!inserted)await sb.storage.from('chat-files').remove([file.attachment_path]);throw e;}finally{if(button.isConnected)button.disabled=false;}
  }
  async function loadMessages(older=false,forceBottom=false){if(!selected||closed)return;const item=selected,ticket=generation,request=++messageRequest;const scroll=U.q('#message-log'),height=scroll.scrollHeight,top=scroll.scrollTop,wasBottom=height-scroll.clientHeight-top<100;
   const table=item.kind==='group'?'group_messages':'direct_messages',key=item.kind==='group'?'group_id':'thread_id';let query=sb.from(table).select('*').eq(key,item.id);if(messageSearch)query=query.ilike('body','%'+messageSearch+'%');
   const start=older?messageOffset:0,size=older?50:Math.max(50,messages.length),data=W.data(await query.order('created_at',{ascending:false}).order('id',{ascending:false}).range(start,start+size-1));if(closed||ticket!==generation||request!==messageRequest)return;
   if(!older){messages=data.reverse();messageOffset=data.length;}else{messages=[...data.reverse(),...messages];messageOffset+=data.length;}
   const ids=messages.map(m=>m.sender_id);receipts=W.data(await sb.from('chat_receipts').select('*').eq('kind',item.kind).eq('thread_id',item.id));profiles=await c.namesFor([...ids,...receipts.map(r=>r.user_id)]);
   if(closed||ticket!==generation||request!==messageRequest)return;const enriched=await c.hydrateAttachments(messages);if(closed||ticket!==generation||request!==messageRequest)return;messages=enriched;reactions=messages.length?W.data(await sb.from('chat_reactions').select('*').eq('kind',item.kind).eq('thread_id',item.id).in('message_id',messages.map(m=>m.id))):[];if(closed||ticket!==generation||request!==messageRequest)return;
   U.q('#older-messages').hidden=data.length<size;paintMessages();if(older)scroll.scrollTop=scroll.scrollHeight-height+top;else if(wasBottom||forceBottom||top===0)scroll.scrollTop=scroll.scrollHeight;await markSeen();
  }
  function paintMessages(){const box=U.q('#message-content');let day='';box.innerHTML=messages.length?messages.map(m=>{
   const mine=m.sender_id===myId,name=profiles[m.sender_id]?.full_name||'Member',seen=receipts.filter(r=>r.user_id!==m.sender_id&&new Date(r.last_read_at)>=new Date(m.created_at)),mySeen=seen.some(r=>r.user_id!==myId),date=W.date(m.created_at);let sep='';if(date!==day){day=date;sep=`<div class="ws-day"><span>${date}</span></div>`;}
   const rr=reactions.filter(r=>r.message_id===m.id),emojis=[...new Set(rr.map(r=>r.emoji))];return sep+`<article class="ws-message ${mine?'mine':''}" data-message="${m.id}">${!mine?W.avatar(name,profiles[m.sender_id]?.avatar_path):''}<div class="ws-message-stack"><div class="ws-bubble">${!mine?`<b class="ws-sender">${U.esc(name)}</b>`:''}<div class="ws-message-body">${m.is_announcement?'<strong class="ws-announcement-label">Announcement</strong>':''}${U.esc(m.body)}</div>${W.attachment(m,'chat-files')}<div class="ws-message-stamp"><time>${W.time(m.created_at)}</time>${mine?`<span class="ws-ticks ${mySeen?'seen':''}" title="${mySeen?'Seen':'Sent'}">${W.icon(mySeen?'doublecheck':'check')}</span>`:''}<button class="ws-message-menu" title="Message actions" aria-label="Message actions" data-message-menu="${m.id}">⋯</button></div></div><div class="ws-message-reactions">${emojis.map(emoji=>`<button data-react="${m.id}" data-emoji="${emoji}" class="${rr.some(r=>r.user_id===myId&&r.emoji===emoji)?'selected':''}">${emoji} ${rr.filter(r=>r.emoji===emoji).length}</button>`).join('')}</div>${selected.kind==='group'&&seen.length?`<div class="ws-seen-people" aria-label="Seen by ${U.attr(seen.map(r=>profiles[r.user_id]?.full_name||'Member').join(', '))}">${seen.slice(0,8).map(r=>`<span title="Seen by ${U.attr(profiles[r.user_id]?.full_name||'Member')}">${W.avatar(profiles[r.user_id]?.full_name,profiles[r.user_id]?.avatar_path)}</span>`).join('')}${seen.length>8?`<small>+${seen.length-8}</small>`:''}</div>`:''}</div></article>`;
   }).join(''):'<div class="ws-empty">'+(messageSearch?'No matching messages.':'Say hello to start this conversation.')+'</div>';
   W.photos(box,sb);W.files(box,sb);c.linkGroupInvites(box);U.qa('[data-react]',box).forEach(b=>b.onclick=run(()=>react(b.dataset.react,b.dataset.emoji)));U.qa('[data-message-menu]',box).forEach(b=>b.onclick=()=>messageMenu(messages.find(m=>m.id===b.dataset.messageMenu)));
  }
  async function react(id,emoji){const mine=reactions.find(r=>r.message_id===id&&r.user_id===myId);if(mine?.emoji===emoji)W.data(await sb.from('chat_reactions').delete().eq('kind',selected.kind).eq('message_id',id).eq('user_id',myId));else W.data(await sb.from('chat_reactions').upsert({kind:selected.kind,thread_id:selected.id,message_id:id,user_id:myId,emoji}));await loadMessages(false);}
  function messageMenu(m){const r=U.modal({title:'Message',body:`<div class="ws-emoji-options">${['👍','❤️','🎉','😂','🙏','😮'].map(e=>`<button data-emoji="${e}">${e}</button>`).join('')}</div>`,actions:`<button class="btn" id="quote-msg">Reply</button><button class="btn" id="save-msg">Save</button>${m.sender_id===myId||selected.kind==='group'&&c.can('groups.manage')?'<button class="btn danger" id="delete-msg">Delete</button>':''}<button class="btn" data-close>Close</button>`});U.qa('[data-emoji]',r).forEach(b=>b.onclick=run(async()=>{await react(m.id,b.dataset.emoji);U.closeModal();}));U.q('#quote-msg',r).onclick=()=>{U.q('#message-input').value='↪ '+m.body.slice(0,250)+'\n';U.closeModal();U.q('#message-input').focus();};U.q('#save-msg',r).onclick=run(async()=>{W.data(await sb.from('saved_messages').upsert({kind:selected.kind,thread_id:selected.id,message_id:m.id,user_id:myId}));U.toast('Message saved.','ok');U.closeModal();});U.q('#delete-msg',r)?.addEventListener('click',run(async()=>{U.closeModal();if(!await U.confirmBox('Delete message','Delete this message?','Delete'))return;W.data(await sb.from(selected.kind==='group'?'group_messages':'direct_messages').delete().eq('id',m.id));await loadMessages(false);}));}
  let marking=false;async function markSeen(){if(marking||closed||!selected||!messages.length||messageSearch||document.visibilityState!=='visible'||!document.hasFocus())return;const log=U.q('#message-log');if(!log||log.scrollHeight-log.clientHeight-log.scrollTop>100)return;const newest=messages[messages.length-1],mine=receipts.find(r=>r.user_id===myId);if(mine&&new Date(mine.last_read_at)>=new Date(newest.created_at))return;marking=true;try{W.data(await sb.rpc('mark_chat_read',{k:selected.kind,t:selected.id,message:newest.id}));receipts=receipts.filter(r=>r.user_id!==myId);receipts.push({user_id:myId,last_read_at:newest.created_at});await loadList();}finally{marking=false;}}
  const onFocus=()=>markSeen().catch(()=>{});window.addEventListener('focus',onFocus);document.addEventListener('visibilitychange',onFocus);W.cleanups.push(()=>{window.removeEventListener('focus',onFocus);document.removeEventListener('visibilitychange',onFocus);});
  async function renderDetails(){if(!selected)return;const item=selected,ticket=generation;let count=2;if(item.kind==='group'){const result=await sb.from('group_members').select('*',{count:'exact',head:true}).eq('group_id',item.id);if(result.error)throw result.error;count=result.count;}if(closed||ticket!==generation)return;
   U.q('#chat-subtitle').textContent=item.kind==='group'?`${item.description||'Group conversation'} · ${count} members`:'Private conversation';
   details.innerHTML=`${W.button('close','Close details','id="close-details"')}<div class="ws-details-profile">${W.avatar(item.name,item.avatar_path,item.kind==='group'?'group-images':'avatars')}<h2>${U.esc(item.name)}</h2><p>${U.esc(item.description||'Private conversation')}</p><p>${item.kind==='group'?count+' members':'Only you and '+U.esc(item.name)}</p></div><div class="ws-details-nav">${[['chat','Chat'],['file','Files'],['people','Members'],['video','Meetings'],...(item.kind==='group'?[['cloud','Google Drive']]:[]),['settings','Settings']].map(([icon,label])=>`<button data-panel="${label}" class="${label==='Chat'?'active':''}">${W.icon(icon)}${label}${W.icon('chevron')}</button>`).join('')}</div><div id="details-panel"></div>`;
   U.q('#close-details').onclick=()=>{root.classList.remove('details-open');root.classList.add('details-hidden');};U.qa('[data-panel]',details).forEach(b=>b.onclick=run(()=>panel(b.dataset.panel)));W.photos(details,sb);
  }
  async function panel(name){U.qa('[data-panel]',details).forEach(b=>b.classList.toggle('active',b.dataset.panel===name));const out=U.q('#details-panel');out.innerHTML='';if(name==='Chat')return;
   if(name==='Files'){let off=0;const load=async()=>{const data=W.data(await sb.from(selected.kind==='group'?'group_messages':'direct_messages').select('*').eq(selected.kind==='group'?'group_id':'thread_id',selected.id).not('attachment_path','is',null).order('created_at',{ascending:false}).range(off,off+29));out.innerHTML=data.map(m=>W.attachment(m,'chat-files')).join('')||'<p>No shared attachments.</p>';out.insertAdjacentHTML('beforeend','<button class="btn small" id="files-more">Next attachments</button>');U.q('#files-more',out).disabled=data.length<30;U.q('#files-more',out).onclick=run(async()=>{off+=30;await load();});W.files(out,sb);W.photos(out,sb);};await load();if(selected.kind==='group'){out.insertAdjacentHTML('beforeend','<button class="btn small" id="group-files-open">Group file manager</button>');U.q('#group-files-open').onclick=run(()=>legacyPanel('files'));}return;}
   if(name==='Members'){if(selected.kind==='group'){await legacyPanel('members');return;}const people=await c.namesFor([myId,selected.peer_id]);out.innerHTML=Object.values(people).map(p=>`<div class="ws-member">${W.avatar(p.full_name,p.avatar_path)}${U.esc(p.full_name)}</div>`).join('');W.photos(out,sb);return;}
   if(name==='Meetings'){if(selected.kind==='group'){await legacyPanel('meetings');return;}out.innerHTML='<button class="btn primary" id="details-call">Start video meeting</button>';U.q('#details-call').onclick=run(()=>call(false));return;}
   if(name==='Google Drive'){await legacyPanel('drive');return;}
   if(name==='Settings'){out.innerHTML=`<label class="ws-setting"><input id="favorite-chat" type="checkbox" ${selected.favorite?'checked':''}>Favorite conversation</label><label class="ws-setting"><input id="pin-chat" type="checkbox" ${selected.pinned?'checked':''}>Pin conversation</label>`;for(const [id,key]of[['favorite-chat','favorite'],['pin-chat','pinned']])U.q('#'+id,out).onchange=run(async e=>{const value=e.target.checked;W.data(await sb.from('chat_preferences').upsert({kind:selected.kind,thread_id:selected.id,user_id:myId,favorite:!!selected.favorite,pinned:!!selected.pinned,[key]:value}));selected[key]=value;await loadList();});if(selected.kind==='group'){out.insertAdjacentHTML('beforeend','<button class="btn" id="group-settings-open">Group settings</button>');U.q('#group-settings-open').onclick=run(()=>legacyPanel('settings'));}}
  }
  async function legacyPanel(tab){const g=W.data(await sb.from('groups').select('*').eq('id',selected.id).single());U.q('#details-panel').innerHTML='<div id="group-body"></div>';await c.groupPanel(g,tab);}
  async function call(audio){await c.startCall(selected,audio);}
  const refresh=async()=>{if(pollBusy||closed)return;pollBusy=true;try{await loadList();if(selected)await loadMessages(false);}finally{pollBusy=false;}};
  W.watch(sb,['group_messages','direct_messages','direct_threads','chat_receipts','chat_preferences','chat_reactions','group_members','groups'],refresh);const timer=setInterval(()=>{if(document.visibilityState==='visible')refresh().catch(()=>{});},20000);W.cleanups.push(()=>clearInterval(timer));
  await loadList();if(W.pending){const pending=W.pending;W.pending=null;let item=threads.find(t=>t.id===pending.id&&t.kind===pending.kind);if(!item&&pending.kind==='group'){const g=W.data(await sb.from('groups').select('*').eq('id',pending.id).single());item={...g,kind:'group',avatar_path:g.image_path};}if(!item&&pending.kind==='direct'){const t=W.data(await sb.from('direct_threads').select('*').eq('id',pending.id).single()),peer=t.user_a===myId?t.user_b:t.user_a,p=W.data(await sb.from('profiles').select('id,full_name,avatar_path').eq('id',peer).single());item={id:t.id,kind:'direct',peer_id:peer,name:p.full_name,avatar_path:p.avatar_path};}if(item)await select(item);}else if(threads.length&&!matchMedia('(max-width:800px)').matches)await select(threads[0]);if(initial==='contacts')U.q('#new-chat').click();
 };
})();

;
(() => {
 'use strict';const W=window.EduWorkspace;
 W.forum=async(c,startFilter='all')=>{
  const {sb,S,U}=c,root=U.q('#page');let filter=startFilter,search='',sort='latest',offset=0,posts=[],closed=false,version=0,lastQuery='';W.cleanups.push(()=>{closed=true;});root.className='content workspace-v3 ws-page ws-standard-page';
  root.innerHTML=`<div class="ws-page-heading"><div><h1>Community Forum</h1><p>Share updates, discussions, questions, and announcements with everyone on Edu Chat Pro.</p></div><button id="new-forum-post" class="ws-primary">${W.icon('plus')} New post</button></div><div class="ws-filterbar ws-forum-filters"><div class="ws-tabs">${[['all','list','All Posts'],['popular','flame','Popular'],['question','question','Questions'],['announcement','megaphone','Announcements']].map(([f,icon,label])=>`<button data-forum-filter="${f}">${W.icon(icon)}${label}</button>`).join('')}</div><label class="ws-search">${W.icon('search')}<input id="forum-search" placeholder="Search posts, people, or topics…" aria-label="Search posts, people, or topics"></label><select id="forum-sort" aria-label="Sort forum"><option value="latest">Latest</option><option value="popular">Popular</option><option value="oldest">Oldest</option></select></div><div class="ws-forum-layout"><section class="ws-forum-feed"><div class="ws-card ws-post-composer">${W.avatar(S.profile.full_name,S.profile.avatar_path)}<div><button class="ws-composer-prompt" data-compose="discussion">Share something with the community…</button><div class="ws-compose-tools">${[['photo','image','Photo'],['poll','chart','Poll'],['file','paperclip','File'],['question','question','Question']].map(([type,icon,label])=>`<button data-compose="${type}">${W.icon(icon)}${label}</button>`).join('')}</div></div></div><div id="forum-posts"></div><button class="ws-more" id="forum-more">Load more posts</button></section><aside id="forum-sidebar" class="ws-right-column"></aside></div>`;
  const panelsButton=document.createElement('button');panelsButton.className='ws-secondary ws-panels-toggle';panelsButton.textContent='Side panel';panelsButton.setAttribute('aria-expanded','false');root.querySelector('.ws-page-heading').appendChild(panelsButton);panelsButton.onclick=()=>{root.classList.toggle('panels-open');panelsButton.setAttribute('aria-expanded',String(root.classList.contains('panels-open')));};
  async function load(append=false){const ticket=++version,key=JSON.stringify([search,filter,sort]),count=!append&&key===lastQuery?Math.max(1,Math.ceil(offset/20)):1,args={search_text:search,filter_name:filter,sort_name:sort};let data=[];for(let page=0;page<count;page++){const batch=W.data(await sb.rpc('forum_feed',{...args,page_offset:append?offset:page*20}));if(closed||ticket!==version)return;data.push(...batch);if(batch.length<20)break;}lastQuery=key;if(closed||ticket!==version)return;if(!append){posts=[];offset=0;}posts.push(...data);offset+=data.length;U.q('#forum-more').hidden=data.length===0||data.length%20!==0;U.qa('[data-forum-filter]').forEach(b=>b.classList.toggle('active',b.dataset.forumFilter===filter));const list=U.q('#forum-posts');list.innerHTML=posts.length?posts.map(postCard).join(''):'<div class="ws-card ws-empty">No discussions match this filter. Start a new post or change the search.</div>';wirePosts(list);W.photos(root,sb);W.files(list,sb);}
  function postCard(p){const author=p.anonymous?'Anonymous':p.author_name||'Member',role=p.anonymous?'':p.author_role==='super_admin'?'Instructor':p.author_role==='assistant_admin'?'Moderator':'Student',counts=p.poll_counts||{},total=Object.values(counts).reduce((a,b)=>a+Number(b),0);return `<article class="ws-card ws-post" data-post="${p.id}"><header>${W.avatar(author,p.anonymous?null:p.avatar_path)}<div><b>${U.esc(author)}</b>${role?`<span class="ws-role ${role.toLowerCase()}">${role}</span>`:''}<p>${U.fmtDate(p.created_at)}${p.tags?.length?' · '+U.esc(p.tags.join(' · ')):''}</p></div><span class="spacer"></span>${W.button('more','Post options',`data-post-menu="${p.id}"`)}</header><h3>${W.icon(p.category==='question'?'question':p.attachment_path?'image':'chat')}${U.esc(p.title)}</h3><div class="ws-post-body">${W.rich(p.body)}</div>${W.attachment(p,'forum-media')}${p.category==='poll'&&p.poll_options?`<div class="ws-poll">${p.poll_options.map((option,i)=>`<button data-vote="${p.id}" data-choice="${i}" class="${p.my_vote===i?'chosen':''}" style="--vote:${total?Math.round(Number(counts[i]||0)/total*100):0}%"><span>${U.esc(option)}</span><b>${counts[i]||0} ${p.my_vote===i?'✓':''}</b></button>`).join('')}<small>${total} votes · Select an option to vote or change your vote</small></div>`:''}<div class="ws-post-counts"><span>${Number(p.reactions)?'👍 ❤️ 🎉':''} ${p.reactions||0}</span><span class="spacer"></span><button data-comment="${p.id}">${p.comments||0} comments</button><span>${p.shares||0} shares</span></div><footer><button data-like="${p.id}" class="${p.my_reaction?'active':''}">${W.icon('like')}${p.my_reaction||'Like'}</button><button data-comment="${p.id}">${W.icon('chat')}Comment</button><button data-share="${p.id}">${W.icon('share')}Share</button><button data-save-post="${p.id}" class="${p.saved?'active':''}">${W.icon('bookmark')}${p.saved?'Saved':'Save'}</button></footer></article>`;}
  function wirePosts(list){U.qa('[data-like]',list).forEach(b=>b.onclick=W.run(async()=>{const p=posts.find(x=>x.id===b.dataset.like);if(p.my_reaction)W.data(await sb.from('forum_reactions').delete().eq('post_id',p.id).eq('user_id',S.user.id));else W.data(await sb.from('forum_reactions').upsert({post_id:p.id,user_id:S.user.id,emoji:'👍'}));await load();}));U.qa('[data-comment]',list).forEach(b=>b.onclick=W.run(()=>comments(posts.find(x=>x.id===b.dataset.comment))));U.qa('[data-share]',list).forEach(b=>b.onclick=W.run(async()=>{const url=new URL(location.href);url.search='';url.hash='';url.searchParams.set('post',b.dataset.share);await U.copy(url.href);W.data(await sb.from('forum_shares').upsert({post_id:b.dataset.share,user_id:S.user.id}));await load();}));U.qa('[data-save-post]',list).forEach(b=>b.onclick=W.run(async()=>{const p=posts.find(x=>x.id===b.dataset.savePost);if(p.saved)W.data(await sb.from('forum_saved').delete().eq('post_id',p.id).eq('user_id',S.user.id));else W.data(await sb.from('forum_saved').upsert({post_id:p.id,user_id:S.user.id}));await load();}));U.qa('[data-vote]',list).forEach(b=>b.onclick=W.run(async()=>{W.data(await sb.rpc('vote_forum',{p:b.dataset.vote,option_index:Number(b.dataset.choice)}));await load();}));U.qa('[data-post-menu]',list).forEach(b=>b.onclick=()=>postMenu(posts.find(p=>p.id===b.dataset.postMenu)));}
  async function compose(type='discussion',existing=null){let id=existing?.id||null,attachment=null,stored=existing?.attachment_path?{attachment_path:existing.attachment_path,attachment_name:existing.attachment_name,attachment_mime:existing.attachment_mime}:null;const category=existing?.category||(type==='question'||type==='poll'?type:'discussion');const r=U.modal({title:existing?'Edit post':'New community post',wide:true,closeOnBackdrop:false,body:`<form id="forum-compose"><label class="field">Title<input id="post-title" class="input" maxlength="160" value="${U.attr(existing?.title||'')}" required></label><label class="field">Description</label><div class="ws-format-tools"><button type="button" data-format="**" aria-label="Bold selected text"><strong>B</strong> Bold</button><button type="button" data-format="==" aria-label="Highlight selected text"><mark>Highlight</mark></button></div><label class="field"><textarea id="post-body" class="textarea" maxlength="10000" required>${U.esc(existing?.body||'')}</textarea></label><div class="ws-form-row"><label class="field">Category<select id="post-category" class="select"><option value="discussion">Discussion</option><option value="question">Question</option><option value="poll">Poll</option>${c.can('announcements.create')?'<option value="announcement">Announcement</option>':''}</select></label><label class="field">Topics (comma separated)<input id="post-tags" class="input" maxlength="400" value="${U.attr((existing?.tags||[]).join(', '))}" placeholder="webdev, resources"></label></div><label class="field" id="poll-field">Poll options (one per line, 2–6)<textarea id="post-poll" class="textarea" maxlength="726">${U.esc((existing?.poll_options||[]).join('\n'))}</textarea></label><label class="ws-setting"><input id="post-anonymous" type="checkbox" ${existing?.anonymous?'checked':''}>Post anonymously</label><p class="ws-small">Your identity is hidden from other users. Super Admin identification is audited.</p><label class="ws-secondary">${W.icon('paperclip')} ${type==='photo'?'Choose photo':'Attach photo or file'}<input id="post-file" type="file" ${type==='photo'?'accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime"':''} hidden></label><span id="post-file-label">${U.esc(stored?.attachment_name||'')}</span><p id="compose-error" class="danger-text" role="alert"></p></form>`,actions:'<button class="btn" data-close>Cancel</button><button class="btn primary" id="publish-post">Publish</button>'});
   U.qa('[data-format]',r).forEach(b=>b.onclick=()=>{const t=U.q('#post-body',r),a=t.selectionStart,z=t.selectionEnd,token=b.dataset.format,chosen=t.value.slice(a,z)||'text';t.setRangeText(token+chosen+token,a,z,'select');t.focus();t.setSelectionRange(a+token.length,a+token.length+chosen.length);});U.q('#post-category',r).value=category;const pollVisibility=()=>U.q('#poll-field',r).hidden=U.q('#post-category',r).value!=='poll';pollVisibility();U.q('#post-category',r).onchange=pollVisibility;U.q('#post-file',r).onchange=e=>{attachment=e.target.files[0]||null;U.q('#post-file-label',r).textContent=attachment?.name||stored?.attachment_name||'';};
   U.q('#publish-post',r).onclick=async()=>{const form=U.q('#forum-compose',r);if(!form.reportValidity())return;const button=U.q('#publish-post',r);button.disabled=true;U.q('#compose-error',r).textContent='';try{const cat=U.q('#post-category',r).value,options=U.q('#post-poll',r).value.split('\n').map(x=>x.trim()).filter(Boolean),tags=U.q('#post-tags',r).value.split(',').map(x=>x.trim().replace(/^#/, '').slice(0,40)).filter(Boolean);if(tags.length>8)throw new Error('Use up to 8 topics.');if(cat==='poll'&&(options.length<2||options.length>6||options.some(x=>x.length>120)))throw new Error('A poll needs 2–6 options, each up to 120 characters.');
    id=W.data(await sb.rpc('save_post',{post:id,title_text:U.q('#post-title',r).value.trim(),body_text:U.q('#post-body',r).value.trim(),is_anonymous:U.q('#post-anonymous',r).checked}));if(attachment){if(/^(image|video)\//.test(attachment.type)){const path=await c.uploadForumMedia(attachment);try{W.data(await sb.rpc('ec_r4_set_forum_media',{post_input:id,path_input:path}));}catch(error){await sb.storage.from('forum-images').remove([path]);throw error;}stored=null;}else stored=await W.upload(sb,'forum-media',id,attachment);attachment=null;}
    const changedPoll=cat==='poll'&&JSON.stringify(options)!==JSON.stringify(existing?.poll_options);W.data(await sb.rpc('set_forum_details',{p:id,category_name:cat,post_tags:tags,poll_options:changedPoll?options:null,file_path:stored?.attachment_path||null,file_name:stored?.attachment_name||null,file_mime:stored?.attachment_mime||null}));U.closeModal();U.toast('Post published.','ok');await Promise.all([load(),sidebar()]);
   }catch(e){if(!U.q('#compose-error',r)){U.toast(U.errorText(e),'error');return;}U.q('#compose-error',r).textContent=(id?'Post text was saved. Finish the remaining details by retrying: ':'')+U.errorText(e);}finally{button.disabled=false;}};
  }
  async function comments(post){let off=0,all=[],reply=null;const r=U.modal({title:'Discussion',wide:true,body:`<h3>${U.esc(post.title)}</h3><p class="ws-post-body">${W.rich(post.body)}</p><div id="ws-comments"></div><button id="comments-more" class="ws-more">More comments</button><form id="comment-form" class="ws-comment-form"><p id="reply-to" hidden></p><textarea id="comment-body" class="textarea" maxlength="4000" placeholder="Write a comment…"></textarea><label class="btn">Photo / video<input id="comment-media" type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime"></label><button class="btn primary">Post comment</button></form>`});
   const loadComments=async(reset=false)=>{if(reset){all=[];off=0;}const data=W.data(await sb.from('forum_comments').select('*').eq('post_id',post.id).order('created_at').order('id').range(off,off+39));if(!r.isConnected)return;all.push(...data);off+=data.length;const names=await c.namesFor(all.map(x=>x.author_id));U.q('#comments-more',r).hidden=data.length<40;U.q('#ws-comments',r).innerHTML=all.map(comment=>`<article class="ws-comment ${comment.parent_id?'reply':''}">${W.avatar(names[comment.author_id]?.full_name,names[comment.author_id]?.avatar_path)}<div><b>${U.esc(names[comment.author_id]?.full_name||'Member')}</b><time>${W.time(comment.created_at)}</time>${comment.parent_id?'<small>Reply</small>':''}<p>${W.rich(comment.body)}</p>${W.attachment(comment,'forum-media')}<button class="text-btn" data-reply="${comment.id}">Reply</button>${comment.author_id===S.user.id?`<button class="text-btn" data-edit-comment="${comment.id}">Edit</button>`:''}${comment.author_id===S.user.id||c.can('forum.moderate')?`<button class="text-btn danger-text" data-delete-comment="${comment.id}">Delete</button>`:''}</div></article>`).join('')||'<p>No comments yet.</p>';W.photos(r,sb);W.files(r,sb);
    U.qa('[data-reply]',r).forEach(b=>b.onclick=()=>{reply=b.dataset.reply;const label=U.q('#reply-to',r);label.hidden=false;label.textContent='Replying to '+(names[all.find(x=>x.id===reply).author_id]?.full_name||'Member')+' — click to cancel';label.onclick=()=>{reply=null;label.hidden=true;};U.q('#comment-body',r).focus();});
    U.qa('[data-delete-comment]',r).forEach(b=>b.onclick=W.run(async()=>{if(!window.confirm('Delete this comment and its replies?'))return;W.data(await sb.from('forum_comments').delete().eq('id',b.dataset.deleteComment));await loadComments(true);await load();}));U.qa('[data-edit-comment]',r).forEach(b=>b.onclick=W.run(async()=>{const comment=all.find(x=>x.id===b.dataset.editComment),body=window.prompt('Edit comment',comment.body);if(!body?.trim())return;W.data(await sb.from('forum_comments').update({body:body.trim()}).eq('id',comment.id).eq('author_id',S.user.id));await loadComments(true);}));};
   U.q('#comments-more',r).onclick=W.run(()=>loadComments());U.q('#comment-form',r).onsubmit=W.run(async e=>{e.preventDefault();const input=U.q('#comment-body',r),picker=U.q('#comment-media',r),button=U.q('#comment-form button',r),file=picker.files[0];if(button.disabled||(!input.value.trim()&&!file))return;button.disabled=true;let path,saved=false;try{if(file)path=await c.uploadForumMedia(file);W.data(await sb.from('forum_comments').insert({post_id:post.id,author_id:S.user.id,parent_id:reply,body:input.value.trim(),...(path?{image_path:path}:{})}));saved=true;input.value='';picker.value='';}catch(error){if(path&&!saved)await sb.storage.from('forum-images').remove([path]);throw error;}finally{button.disabled=false;}reply=null;U.q('#reply-to',r).hidden=true;await loadComments(true);await load();});await loadComments();
  }
  function postMenu(p){const r=U.modal({title:'Post options',body:`<div class="ws-emoji-options">${['👍','❤️','🎉','😂','🙏','😮'].map(e=>`<button data-post-emoji="${e}">${e}</button>`).join('')}</div>`,actions:`${p.mine?'<button class="btn" id="edit-post">Edit</button>':''}${p.mine||c.can('forum.moderate')?'<button class="btn danger" id="delete-post">Delete</button>':''}${p.anonymous&&c.isSuper()?'<button class="btn" id="identify-post">Identify author</button>':''}<button class="btn" id="report-post">Report</button><button class="btn" data-close>Close</button>`});U.qa('[data-post-emoji]',r).forEach(b=>b.onclick=W.run(async()=>{W.data(await sb.from('forum_reactions').upsert({post_id:p.id,user_id:S.user.id,emoji:b.dataset.postEmoji}));U.closeModal();await load();}));U.q('#edit-post',r)?.addEventListener('click',()=>compose(p.category,p));U.q('#delete-post',r)?.addEventListener('click',W.run(async()=>{U.closeModal();if(!await U.confirmBox('Delete discussion','Delete this post and its comments?','Delete'))return;W.data(await sb.rpc('delete_post',{post:p.id}));await Promise.all([load(),sidebar()]);}));U.q('#identify-post',r)?.addEventListener('click',W.run(async()=>{const id=W.data(await sb.rpc('identify_post',{post:p.id})),people=await c.namesFor([id]);U.modal({title:'Author — audited lookup',body:`<p>${U.esc(people[id]?.full_name||'Member')}</p><code>${U.esc(id)}</code>`});}));U.q('#report-post',r).onclick=W.run(async()=>{const values=await U.promptBox({title:'Report post',fields:[{label:'Reason',type:'textarea',max:2000}],submit:'Report'});if(!values)return;const result=await sb.from('forum_reports').insert({post_id:p.id,reporter_id:S.user.id,reason:values[0]});if(result.error?.code==='23505'){U.toast('You already reported this post.','ok');return;}W.data(result);U.toast('Report submitted.','ok');});}
  async function sidebar(){const data=W.data(await sb.rpc('forum_sidebar'));if(closed)return;const box=U.q('#forum-sidebar');function rules(list){return list.map(x=>`<div class="ws-rule"><span class="ws-rule-icon">${W.icon(x.icon)}</span><div><b>${U.esc(x.title)}</b><p>${U.esc(x.body)}</p></div></div>`).join('');}function topics(list){return list.map((x,i)=>`<button class="ws-topic" data-topic="${U.attr(x.tag)}"><i>${i+1}</i><span><b>${U.esc(x.tag)}</b><small>${x.posts} posts</small></span><em>#${U.esc(x.tag)}</em></button>`).join('')||'<p class="ws-small">Topics appear when posts include tags.</p>';}function contributors(list){return list.map((p,i)=>`<button class="ws-contributor" data-author="${U.attr(p.full_name)}">${W.avatar(p.full_name,p.avatar_path)}<b>${U.esc(p.full_name)}</b><span>${p.points} points</span><i>${i<3?'♛':''}</i></button>`).join('')||'<p class="ws-small">Contributors appear after publishing.</p>';}
   box.innerHTML=`<button type="button" class="ws-panel-close" id="forum-panel-close" aria-label="Close forum side panel">${W.icon('close')}<span>Close</span></button><section class="ws-card"><header><h3>${W.icon('shield')}Forum Rules</h3><button class="text-btn" data-view-all="rules">View all</button></header>${rules((data.rules||[]).slice(0,4))}</section><section class="ws-card"><header><h3>${W.icon('trending')}Trending Topics</h3><button class="text-btn" data-view-all="topics">View all</button></header>${topics((data.topics||[]).slice(0,5))}</section><section class="ws-card"><header><h3>${W.icon('trophy')}Top Contributors</h3><button class="text-btn" data-view-all="contributors">View all</button></header>${contributors((data.contributors||[]).slice(0,3))}<small class="ws-small">10 points per public post. Anonymous posts are excluded.</small></section>`;
   const wire=target=>{U.qa('[data-topic],[data-author]',target).forEach(b=>b.onclick=W.run(async()=>{search=b.dataset.topic||b.dataset.author;U.q('#forum-search').value=search;filter='all';await load();if(target!==box)U.closeModal();}));W.photos(target,sb);};U.q('#forum-panel-close',box)?.addEventListener('click',()=>{root.classList.remove('panels-open');panelsButton.setAttribute('aria-expanded','false');});wire(box);U.qa('[data-view-all]',box).forEach(b=>b.onclick=()=>{const key=b.dataset.viewAll,r=U.modal({title:{rules:'Forum rules',topics:'Trending topics',contributors:'Top contributors'}[key],body:({rules,topics,contributors}[key])(data[key]||[]),wide:true});wire(r);});
  }
  U.q('#new-forum-post').onclick=()=>compose();U.qa('[data-compose]').forEach(b=>b.onclick=()=>compose(b.dataset.compose));U.qa('[data-forum-filter]').forEach(b=>b.onclick=W.run(async()=>{filter=b.dataset.forumFilter;await load();}));U.q('#forum-search').oninput=U.debounce(W.run(async e=>{search=e.target.value;await load();}),250);U.q('#forum-sort').onchange=W.run(async e=>{sort=e.target.value;await load();});U.q('#forum-more').onclick=W.run(()=>load(true));W.watch(sb,['forum_posts','forum_comments','forum_reactions','forum_votes','forum_saved'],async()=>{await load();await sidebar();});await Promise.all([load(),sidebar()]);
  if(W.pendingPost){const id=W.pendingPost;W.pendingPost=null;const p=W.data(await sb.from('forum_posts').select('*').eq('id',id).single());await comments(p);}
 };
 W.saved=async c=>{const {U,sb}=c,root=U.q('#page');root.className='content workspace-v3 ws-page ws-standard-page';let offset=0,closed=false;W.cleanups.push(()=>{closed=true;});root.innerHTML='<div class="ws-page-heading"><div><h1>Saved</h1><p>Your bookmarked messages and community posts.</p></div><button class="ws-primary" id="saved-forum">Saved posts</button></div><div id="saved-chat-list" class="ws-saved-list"></div><button class="ws-more" id="saved-more">Load more messages</button>';const load=async()=>{const rows=W.data(await sb.rpc('saved_chat_messages',{page_offset:offset}));if(closed)return;const list=U.q('#saved-chat-list');if(!offset&&!rows.length)list.innerHTML='<div class="ws-card ws-empty">No saved messages yet.</div>';offset+=rows.length;list.insertAdjacentHTML('beforeend',rows.map(r=>`<article class="ws-card"><h3>${U.esc(r.name)}</h3><p>${U.esc(r.body)}</p><button class="btn" data-open-saved="${r.thread_id}" data-kind="${r.kind}">Open chat</button><button class="btn ghost" data-remove-saved="${r.message_id}" data-kind="${r.kind}">Unsave</button></article>`).join(''));U.q('#saved-more').hidden=rows.length<40;U.qa('[data-open-saved]').forEach(b=>b.onclick=()=>W.openChat(c,b.dataset.kind,b.dataset.openSaved));U.qa('[data-remove-saved]').forEach(b=>b.onclick=W.run(async()=>{W.data(await sb.from('saved_messages').delete().eq('user_id',c.S.user.id).eq('kind',b.dataset.kind).eq('message_id',b.dataset.removeSaved));b.closest('article').remove();}));};U.q('#saved-forum').onclick=()=>{W.dispose();W.forum(c,'saved').catch(e=>U.toast(e.message,'error'));};U.q('#saved-more').onclick=W.run(load);await load();};
})();

;
(() => {
 'use strict';const W=window.EduWorkspace;
 W.notifications=async c=>{
  const {sb,S,U}=c,root=U.q('#page');let filter='all',query='',oldest=false,offset=0,rows=[],closed=false,version=0,lastQuery='';W.cleanups.push(()=>{closed=true;});root.className='content workspace-v3 ws-page ws-standard-page';
  root.innerHTML=`<div class="ws-page-heading"><div><h1>Notifications</h1><p>Calls, messages, announcements, and community updates.</p></div><div class="ws-heading-actions"><button class="ws-primary" data-enable-notify>${W.icon('bell')} Enable notifications</button><button class="ws-secondary" id="read-all">${W.icon('check')} Mark all as read</button><button class="ws-secondary danger-text" id="clear-notifications">${W.icon('trash')} Clear</button></div></div><div class="ws-notification-layout"><section class="ws-notification-main"><div class="ws-filterbar"><label class="ws-search">${W.icon('search')}<input id="notification-search" placeholder="Search notifications…"></label><div class="ws-tabs">${[['all','All'],['unread','Unread'],['mentions','@ Mentions'],['system','System']].map(([f,label])=>`<button data-notification-filter="${f}">${label} <span data-count="${f}"></span></button>`).join('')}</div><select id="notification-sort" aria-label="Sort notifications"><option value="newest">Newest first</option><option value="oldest">Oldest first</option></select></div><div class="ws-notification-scroll"><div id="notification-list"></div><button class="ws-more" id="notification-more">Load more</button></div></section><aside class="ws-right-column"><section class="ws-card ws-notify-promo"><div class="ws-bell-art">${W.icon('bell')}</div><h2>Stay in the loop</h2><p>Get notified about important messages, calls, and updates from your classes and communities.</p><button class="ws-primary" data-enable-notify>${W.icon('bell')} Enable notifications</button><p class="ws-small" id="notification-permission"></p></section><section class="ws-card"><h3>Notification types</h3>${[['messages','chat','Messages'],['calls','phone','Calls'],['mentions','at','Mentions'],['community','people','Community'],['system','settings','System']].map(([f,icon,label])=>`<button class="ws-type-row" data-notification-filter="${f}">${W.icon(icon)}${label}<span data-count="${f}">0</span></button>`).join('')}</section></aside></div>`;
  const panelsButton=document.createElement('button');panelsButton.className='ws-secondary ws-panels-toggle';panelsButton.textContent='Side panel';panelsButton.setAttribute('aria-expanded','false');root.querySelector('.ws-page-heading').appendChild(panelsButton);panelsButton.onclick=()=>{root.classList.toggle('panels-open');panelsButton.setAttribute('aria-expanded',String(root.classList.contains('panels-open')));};
  async function load(append=false){const v=++version,key=JSON.stringify([query,filter,oldest]),count=!append&&key===lastQuery?Math.max(1,Math.ceil(offset/40)):1,args={search_text:query,filter_name:filter,oldest_first:oldest};let data=[];for(let page=0;page<count;page++){const batch=W.data(await sb.rpc('notification_feed',{...args,page_offset:append?offset:page*40}));if(closed||v!==version)return;data.push(...batch);if(batch.length<40)break;}lastQuery=key;const counts=W.data(await sb.rpc('notification_counts'));if(closed||v!==version)return;if(!append){rows=[];offset=0;}rows.push(...data);offset+=data.length;U.q('#notification-more').hidden=data.length===0||data.length%40!==0;U.qa('[data-count]',root).forEach(el=>el.textContent=counts[el.dataset.count]||0);U.qa('[data-notification-filter]',root).forEach(b=>b.classList.toggle('active',b.dataset.notificationFilter===filter));const list=U.q('#notification-list');list.innerHTML=rows.length?rows.map(n=>`<article class="ws-notification ${!n.read_at?'unread':''}"><span class="ws-read-dot"></span><span class="ws-notification-icon ${n.category}">${W.icon(({messages:'file',calls:'phone',mentions:'at',community:'smile',system:'megaphone'})[n.category])}</span><div class="ws-notification-copy"><h3>${U.esc(n.title)}</h3><p>${U.esc(n.body||({group_files:'A file was shared in your group.',group_messages:'Open your group conversation.',meetings:'A group meeting is starting.',forum:'Someone replied to your discussion.'}[n.kind])||'An update from EduChat.')}</p></div><time title="${U.attr(U.fmtDate(n.created_at))}">${W.date(n.created_at)===W.date(new Date())?W.time(n.created_at):W.date(n.created_at)}</time><button class="ws-open" data-open-notification="${n.id}">Open</button>${W.button('more','Notification options',`data-notification-menu="${n.id}"`)}</article>`).join(''):'<div class="ws-card ws-empty">You’re all caught up. No notifications match this filter.</div>';U.qa('[data-open-notification]',list).forEach(b=>b.onclick=W.run(()=>open(rows.find(n=>n.id===b.dataset.openNotification))));U.qa('[data-notification-menu]',list).forEach(b=>b.onclick=()=>menu(rows.find(n=>n.id===b.dataset.notificationMenu)));}
  async function read(n,yes=true){W.data(await sb.from('notifications').update({read_at:yes?new Date().toISOString():null}).eq('id',n.id).eq('user_id',S.user.id));}
  async function open(n){if(!n.target_kind){await c.openNotification(n);return;}await read(n);const target=n.target_id||n.resource_id;if(n.target_kind==='group'){await W.openChat(c,'group',target);return;}if(n.target_kind==='direct'){await W.openChat(c,'direct',target);return;}if(n.target_kind==='meeting'){const m=W.data(await sb.from('meetings').select('*').eq('id',target).single());if(m.ended_at)throw new Error('This meeting has ended.');await c.openMeeting(m);await load();return;}if(n.target_kind==='forum'||['forum','community'].includes(n.kind)){W.pendingPost=target;await c.navigate('forum');return;}if(['group_messages','group_files','meetings'].includes(n.kind)){await W.openChat(c,'group',target);return;}await load();U.modal({title:n.title,body:`<p>${U.esc(n.body||'System notification')}</p><p>${U.fmtDate(n.created_at)}</p>`});}
  function menu(n){const r=U.modal({title:'Notification options',body:`<p>${U.esc(n.title)}</p>`,actions:`<button class="btn" id="toggle-read">${n.read_at?'Mark unread':'Mark read'}</button><button class="btn danger" id="remove-notification">Clear notification</button><button class="btn" data-close>Cancel</button>`});U.q('#toggle-read',r).onclick=W.run(async()=>{await read(n,!n.read_at);U.closeModal();await load();});U.q('#remove-notification',r).onclick=W.run(async()=>{W.data(await sb.from('notifications').delete().eq('id',n.id).eq('user_id',S.user.id));U.closeModal();await load();});}
  function permission(){U.q('#notification-permission').textContent='Notification'in window?'Browser permission: '+Notification.permission:'This browser does not support notifications.';}
  U.qa('[data-enable-notify]',root).forEach(b=>b.onclick=W.run(async()=>{await c.enableAlerts();permission();}));U.q('#read-all').onclick=W.run(async()=>{W.data(await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('user_id',S.user.id).is('read_at',null));await load();});
  U.q('#clear-notifications').onclick=()=>{const r=U.modal({title:'Clear notifications',body:'<p>Choose which notifications to remove from your account.</p>',actions:'<button class="btn" id="clear-read">Clear read</button><button class="btn danger" id="clear-all">Clear all</button><button class="btn" data-close>Cancel</button>'});for(const[id,onlyRead]of[['clear-read',true],['clear-all',false]])U.q('#'+id,r).onclick=W.run(async()=>{U.closeModal();if(!await U.confirmBox('Clear notifications',onlyRead?'Remove all read notifications?':'Remove all your notifications?','Clear'))return;let q=sb.from('notifications').delete().eq('user_id',S.user.id);if(onlyRead)q=q.not('read_at','is',null);W.data(await q);await load();});};
  U.qa('[data-notification-filter]',root).forEach(b=>b.onclick=W.run(async()=>{filter=b.dataset.notificationFilter;await load();}));U.q('#notification-search').oninput=U.debounce(W.run(async e=>{query=e.target.value;await load();}),250);U.q('#notification-sort').onchange=W.run(async e=>{oldest=e.target.value==='oldest';await load();});U.q('#notification-more').onclick=W.run(()=>load(true));W.watch(sb,['notifications'],()=>load());permission();await load();
 };
})();

;
(()=>{if(!document.getElementById('ecp-chat-layout-v118')){const style=document.createElement('style');style.id='ecp-chat-layout-v118';style.textContent=":root{--chat-blue:#087aff;--chat-pane:#f7fbff;--chat-other:#edf3f9;--chat-mine:#d1ecff;--chat-border:#e2edf7;--chat-soft:#eef5fb}\n:root[data-theme=dark]{--chat-blue:#56b2ff;--chat-pane:#0c1824;--chat-other:#182a3b;--chat-mine:#123d57;--chat-border:#243d50;--chat-soft:#152536}\n.main>.content.messenger-page{height:calc(100dvh - 52px);padding:0!important;overflow:hidden;display:block!important}\n.messenger-layout{display:grid;grid-template-columns:minmax(280px,350px) minmax(0,1fr);height:100%;min-height:0;background:var(--surface)}\n#conversation-rail{min-width:0;min-height:0;border-right:1px solid var(--chat-border);display:flex;flex-direction:column;background:var(--surface);padding:20px 0 10px}\n.rail-title{display:flex;align-items:center;justify-content:space-between;padding:0 20px 20px}.rail-title h1{font-size:29px;margin:0;color:var(--text)}.rail-title .icon-btn{border-radius:50%;background:#087aff;color:white;width:44px;height:44px;font-size:28px}\n.chat-filters{display:flex;gap:7px;padding:0 16px 18px;overflow-x:auto}.chat-filters button{border:0;background:var(--chat-soft);color:var(--text);font:inherit;font-size:12px;font-weight:700;border-radius:24px;padding:10px 13px;cursor:pointer;white-space:nowrap}.chat-filters button.selected{background:#087aff;color:white;box-shadow:0 4px 12px #087aff24}\n.rail-search{margin:0 16px 15px;display:flex;gap:10px;align-items:center;border-radius:16px;background:var(--chat-soft);padding:12px;color:var(--muted)}.rail-search span{font-size:23px}.rail-search input{font:inherit;font-size:13px;width:100%;border:0;outline:0;background:transparent;color:var(--text);min-width:0}\n#conversation-rows{flex:1;overflow-y:auto;min-height:0}.conversation{position:relative;margin:0 7px;border-bottom:1px solid var(--chat-border);border-radius:12px}.conversation.selected{background:color-mix(in srgb,var(--chat-blue) 12%,var(--surface));border-left:3px solid var(--chat-blue)}.conversation-main{border:0;display:flex;gap:12px;width:100%;padding:17px 12px 25px;background:transparent;text-align:left;cursor:pointer;color:var(--text);align-items:center}.conversation .avatar{width:52px;height:52px;min-width:52px;border-radius:50%;overflow:hidden;background:var(--chat-soft)}.conversation .avatar img{height:100%;width:100%;object-fit:cover}.conversation .avatar .ui-icon{width:28px;height:28px}.conversation-copy{display:grid;gap:7px;min-width:0;flex:1}.conversation-copy strong{font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.conversation-copy>span{font-size:13px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.conversation-end{align-self:flex-start;display:grid;justify-items:end;gap:12px;font-size:10px;color:var(--muted);white-space:nowrap}.unread-dot{width:11px;height:11px;border-radius:50%;background:#087aff}.conversation-pin{position:absolute;right:16px;bottom:7px;border:0;background:transparent;color:var(--muted);cursor:pointer;padding:2px 5px}.conversation-pin.pinned{color:var(--chat-blue)}.rail-empty{text-align:center;padding:30px 15px;color:var(--muted)}\n#conversation-pane{min-width:0;min-height:0;display:flex;flex-direction:column;overflow:hidden;background:var(--chat-pane)}.choose-conversation{margin:auto;text-align:center;padding:25px;color:var(--muted)}.choose-conversation img{width:80px;height:80px}.choose-conversation h1{color:var(--text);font-size:26px}.direct-heading{padding:17px 22px;margin:0!important;background:var(--surface);border-bottom:1px solid var(--chat-border);min-height:80px;gap:12px}.direct-heading h2{font-size:22px;margin:0}.direct-heading .avatar{width:52px;height:52px}.direct-heading .btn{border:0;background:var(--chat-soft);border-radius:16px}.direct-heading .muted{font-size:13px}.direct-heading #dm-back{display:none}\n#conversation-pane .chat-panel{flex:1;min-height:0;display:flex;flex-direction:column;border:0;border-radius:0;background:transparent;padding:0;margin:0;box-shadow:none}\n.chat-workspace .chat-log,#conversation-pane .chat-log{flex:1;min-height:0;border:0!important;border-radius:22px!important;padding:18px 20px!important;background-color:var(--chat-pane)!important;background-image:url('data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22220%22%20height%3D%22220%22%20viewBox%3D%220%200%20220%20220%22%20fill%3D%22none%22%20stroke%3D%22%2353b7e5%22%20stroke-opacity%3D%22.075%22%20stroke-width%3D%222%22%3E%3Cg%20transform%3D%22translate%2815%2018%29%20rotate%28-12%29%22%3E%3Crect%20width%3D%2226%22%20height%3D%2221%22%20rx%3D%228%22%2F%3E%3Cpath%20d%3D%22M6%2020v7l8-7M7%209h12M7%2014h8%22%2F%3E%3C%2Fg%3E%3Cg%20transform%3D%22translate%28116%2033%29%20rotate%2818%29%22%3E%3Cpath%20d%3D%22m0%2013%2033-13-11%2034-6-16zM16%2018%2033%200%22%2F%3E%3C%2Fg%3E%3Cg%20transform%3D%22translate%2861%20101%29%22%3E%3Ccircle%20cx%3D%2214%22%20cy%3D%2214%22%20r%3D%2215%22%2F%3E%3Cpath%20d%3D%22M8%2011h1m10%200h1M7%2018q7%208%2014%200%22%2F%3E%3C%2Fg%3E%3Cg%20transform%3D%22translate%28161%20131%29%20rotate%2812%29%22%3E%3Cpath%20d%3D%22M0%200h22v28H0zM4%207h14M4%2013h14M4%2019h9%22%2F%3E%3C%2Fg%3E%3Cg%20transform%3D%22translate%288%20171%29%20rotate%28-14%29%22%3E%3Cpath%20d%3D%22m0%209%2017-8%2017%208-17%208zM7%2013v9q10%209%2020%200v-9M34%209v16%22%2F%3E%3C%2Fg%3E%3Cpath%20d%3D%22m187%2028%203%206%207%201-5%205%201%207-6-4-6%204%201-7-5-5%207-1zM119%20190h13m-7-6v12M46%2058h6m-3-3v6%22%2F%3E%3C%2Fsvg%3E%0A')!important;background-size:220px!important;gap:17px!important;overflow-y:auto}\n.chat-workspace .message-row,#conversation-pane .message-row{position:relative;max-width:86%;gap:12px;align-items:flex-start;margin:0;flex-shrink:0}.chat-workspace .message-row .avatar,#conversation-pane .message-row .avatar{width:40px;height:40px;min-width:40px;overflow:hidden;border:3px solid var(--surface);box-shadow:0 2px 6px #1020400a}.chat-workspace .message,#conversation-pane .message{padding:11px 15px!important;border-radius:5px 20px 20px 20px!important;background:var(--chat-other)!important;box-shadow:0 2px 5px #16344b08;color:var(--text);min-width:110px;font-size:15px;font-weight:500;line-height:1.55;max-width:100%}.chat-workspace .message.mine,#conversation-pane .message.mine{background:var(--chat-mine)!important;border-radius:20px 5px 20px 20px!important}.chat-workspace .message .meta,#conversation-pane .message .meta{display:flex;gap:14px;align-items:center;margin-bottom:5px;font-size:11px;color:var(--muted)}.message .meta strong{color:var(--chat-blue);font-size:12px}.message .meta time{font-weight:500;white-space:nowrap}.message .bodytext{white-space:pre-wrap;overflow-wrap:anywhere}.message .danger-text{font-size:10px;opacity:.55;padding:3px 0}.message:hover .danger-text{opacity:1}\n.new-day{margin-top:36px!important}.new-day:before{content:attr(data-day);position:absolute;top:-33px;left:0;white-space:nowrap;border-radius:22px;background:var(--chat-soft);color:var(--muted);padding:4px 12px;font-size:10px}.new-day.mine:before{left:auto;right:0}\n.chat-reactions{display:flex;gap:5px;margin-top:7px;flex-wrap:wrap}.chat-reactions button{border:1px solid var(--chat-border);background:var(--surface);color:var(--text);border-radius:20px;padding:3px 8px;font-size:12px;cursor:pointer}.chat-reactions button:not(.has-reactions){opacity:0;transition:opacity .15s}.message:hover .chat-reactions button,.message:focus-within .chat-reactions button{opacity:1}.chat-reactions button.selected{border-color:var(--chat-blue);color:var(--chat-blue)}\n.chat-workspace .composer,#conversation-pane .composer{margin:0!important;background:var(--surface);padding:12px;border-radius:24px;border:1px solid var(--chat-border);flex-shrink:0}.composer .row{display:flex!important;align-items:center;gap:8px!important}.chat-workspace .composer .input,#conversation-pane .composer .input{background:var(--chat-soft)!important;border:0!important;box-shadow:none!important;height:46px!important;font-size:14px;font-weight:500;border-radius:28px;flex:1;min-width:60px}.composer .btn{height:44px;white-space:nowrap}.composer .attach-button,.composer .emoji-toggle,.composer .voice-button{width:44px!important;min-width:38px;border-radius:50%!important;border:0!important;background:var(--chat-soft)!important;padding:0!important;font-size:22px}.composer .btn.primary{background:#008e98!important;border-radius:25px!important;border:0!important;color:white!important;padding:10px 22px!important}#dm-form .btn.primary{background:#087aff!important}#dm-form .voice-button{order:8}#dm-form .btn.primary{order:9}#dm-form .emoji-toggle{order:0}#dm-attach{order:1}#dm-text{order:2}\n.chat-workspace #group-body{min-height:0;flex:1;display:flex;flex-direction:column}.chat-workspace #group-body.group-conversation{display:grid;grid-template-columns:minmax(0,1fr) 285px;gap:12px}.group-conversation>.chat-panel{min-height:0;margin:0;display:flex;flex-direction:column;padding:0!important;border:0;background:transparent;box-shadow:none}.group-info{padding:17px;overflow-y:auto;min-height:0;border-radius:22px;border:1px solid var(--chat-border);box-shadow:none;background:var(--surface);font-size:13px}.group-info header,.info-section-title{display:flex;align-items:center;justify-content:space-between;gap:8px}.group-info header strong{font-size:16px}.group-info h3{font-size:15px;margin:0}.group-info-title{display:flex;align-items:center;gap:12px;margin:20px 0 12px}.group-info-title>.avatar{width:62px;height:62px;flex-shrink:0;border:1px solid var(--chat-border);overflow:hidden}.group-info .avatar img{width:100%;height:100%;object-fit:cover}.group-info p{color:var(--muted);line-height:1.6}.group-info section{border-top:1px solid var(--chat-border);padding-top:17px;margin-top:17px}.info-member{display:flex;gap:10px;align-items:center;margin-top:13px}.info-member>span:last-child{display:grid;gap:4px}.info-member small{color:var(--muted)}.info-member .avatar{width:37px;height:37px}#info-media-list{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;margin-top:14px}.media-thumb{min-width:0;overflow:hidden;background:var(--chat-soft);color:var(--text);border:0;border-radius:10px;padding:5px;cursor:pointer}.media-thumb img{width:100%;height:54px;object-fit:cover;border-radius:7px}.media-thumb small{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-size:8px}.next-meeting{display:flex;gap:9px;align-items:center;background:var(--chat-soft);border-radius:14px;padding:12px;font-size:11px}.next-meeting>span{display:grid;flex:1;min-width:0}.next-meeting strong{overflow:hidden;text-overflow:ellipsis}.group-hero{border:1px solid var(--chat-border);box-shadow:none!important}.group-hero-icon img{border-radius:50%}.group-hero-icon{border-radius:50%!important}.chat-workspace>#group-tabs{border-color:var(--chat-border)!important}.chat-workspace #older-messages,#dm-older{align-self:center;font-size:10px;margin:3px!important;padding:3px 12px;min-height:20px;height:24px}.media-content img,.media-content video{max-height:220px}.shared-image{border-radius:12px}\n@media(min-width:1400px){.messenger-layout{grid-template-columns:390px minmax(0,1fr)}.chat-workspace #group-body.group-conversation{grid-template-columns:minmax(0,1fr) 315px}}\n@media(max-width:1100px){.group-info{display:none!important}.chat-workspace #group-body.group-conversation{display:flex}.messenger-layout{grid-template-columns:290px minmax(0,1fr)}.chat-workspace .message-row,#conversation-pane .message-row{max-width:93%}.composer #announce{font-size:11px;padding:5px 10px}}\n@media(max-width:760px){.messenger-layout{display:flex}.messenger-page #conversation-rail{width:100%;border:0}.messenger-page.direct-workspace #conversation-rail{display:none}.messenger-page:not(.direct-workspace) #conversation-pane{display:none}#conversation-pane{width:100%}.direct-heading #dm-back{display:block}.direct-heading{padding:10px}.direct-heading h2{font-size:17px}.chat-workspace .chat-log,#conversation-pane .chat-log{padding:12px 8px!important}.message-row .avatar{width:30px!important;height:30px!important;min-width:30px!important}.chat-workspace .message,#conversation-pane .message{font-size:14px;padding:8px 10px!important}.chat-reactions button:not(.has-reactions){opacity:.5}.composer .btn.primary{padding:8px 12px!important}.composer .btn.primary .ui-icon{margin:0}.composer .row{gap:4px!important}.composer .attach-button,.composer .emoji-toggle,.composer .voice-button{width:32px!important;min-width:30px;font-size:19px}.main>.content.messenger-page{height:calc(100dvh - 116px)}.chat-workspace .composer{padding:7px}.group-hero .body{display:block!important}}\n\n/* Deterministic viewport sizing and reference layout refinements. */\nhtml,body{font-family:\"Segoe UI\",Arial,sans-serif;font-weight:500;line-height:1.5}\nbutton,input,textarea,select{font-family:inherit}\n.shell>.main>.workspace-top{box-sizing:border-box;height:58px;min-height:58px;flex:0 0 58px;padding:8px 18px}\n.shell>.main>.content.messenger-page{height:auto!important;flex:1;min-height:0;padding:0!important;overflow:hidden!important}\n.messenger-layout{width:100%;max-width:100%;min-width:0;grid-template-columns:minmax(290px,360px) minmax(0,1fr)}\n#conversation-rail .rail-title h1{display:block;font-size:29px;line-height:1.2;font-weight:750;letter-spacing:-.7px}\n#conversation-rail button{font-family:inherit;text-transform:none;letter-spacing:normal}\n#conversation-rail .conversation-main{font-weight:500;text-align:left;min-width:0}\n#conversation-rail .conversation-copy{overflow:hidden;min-width:0}\n#conversation-rail .conversation-copy strong{font-size:16px;font-weight:750;display:block;max-width:100%}\n#conversation-rail .conversation-copy>span{display:block;width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500;line-height:1.5;max-height:1.5em}\n#conversation-rail .conversation-end time{font-weight:500;font-size:11px}\n#conversation-rail .rail-search input{font-weight:500;line-height:1.4;height:23px;padding:0}\n#conversation-rail .rail-search input::placeholder{font-weight:500}\n.chat-filters button{min-height:38px;padding:9px 14px;font-size:12px;font-weight:650;flex-shrink:0}\n.chat-workspace .group-hero .body{display:grid;grid-template-columns:minmax(130px,1fr) auto;gap:3px 24px}\n.chat-workspace .group-hero h1{font-size:22px;font-weight:750;letter-spacing:-.35px}\n.chat-workspace .group-hero p{font-size:13px;font-weight:500}\n.chat-workspace #group-member-count{font-size:12px;font-weight:500}\n.chat-workspace>#group-tabs{min-height:42px}\n.chat-workspace>#group-tabs button{font-size:13px;font-weight:650;min-height:40px}\n.chat-workspace #group-body.group-conversation{display:grid!important;grid-template-columns:minmax(0,1fr) 300px;grid-template-rows:minmax(0,1fr) auto;gap:12px;overflow:hidden}\n.group-conversation>.chat-panel{grid-column:1;grid-row:1;min-width:0;overflow:hidden;border:1px solid var(--chat-border)!important;border-radius:24px;padding:5px!important;background:var(--surface)}\n.group-conversation>.group-info{grid-column:2;grid-row:1;min-width:0;overflow:auto;padding:18px;border-radius:23px;align-self:stretch}\n.group-conversation>.composer{grid-column:1/-1;grid-row:2;min-width:0;margin:0!important;padding:10px 12px!important;border-radius:25px}\n.group-info .group-info-title{display:flex;gap:13px;align-items:center}\n.group-info .group-info-title>div{min-width:0}.group-info h3{font-size:15px;font-weight:750;line-height:1.4;overflow-wrap:anywhere}\n.group-info header strong{font-size:16px;font-weight:750}.group-info .muted,.group-info p,.info-member small{font-weight:500;font-size:13px;line-height:1.6}.group-info .info-member strong{font-size:12px;font-weight:650;overflow-wrap:anywhere}.group-info .info-member>span:last-child{min-width:0}.group-info .info-member .avatar{flex-shrink:0}.info-section-title .text-btn{font-size:11px;font-weight:600;color:var(--inbox-action)}\n.chat-workspace .chat-log,#conversation-pane .chat-log{height:auto!important;min-height:0;flex:1;overflow:auto!important}\n.chat-workspace .message .meta,#conversation-pane .message .meta{color:var(--muted);font-size:11px;font-weight:500}.chat-workspace .message .meta strong,#conversation-pane .message .meta strong{color:var(--chat-blue);font-size:12px;font-weight:700}\n.chat-workspace .message .bodytext,.chat-workspace .message>div:not(.meta):not(.chat-reactions),#conversation-pane .message .bodytext{font-size:15px;font-weight:500;line-height:1.6;overflow-wrap:anywhere}\n.chat-workspace .composer .input,#conversation-pane .composer .input{font-weight:500;font-size:14px}.composer .input::placeholder{font-weight:500}.composer .btn{font-weight:650}.chat-workspace .chat-empty h2{font-size:27px;font-weight:750}.chat-workspace .chat-empty p{font-size:14px;font-weight:500}\n.direct-heading .body h2{font-size:21px;font-weight:750;letter-spacing:-.4px}.direct-heading .body span{font-weight:500;font-size:13px}#conversation-pane .direct-heading{flex:0 0 auto}#conversation-pane>.chat-panel{min-height:0;overflow:hidden}#conversation-pane .composer{margin:10px 12px!important}\n@media(min-width:1500px){.messenger-layout{grid-template-columns:400px minmax(0,1fr)}.chat-workspace #group-body.group-conversation{grid-template-columns:minmax(0,1fr) 330px}.group-info{padding:20px!important}}\n@media(max-width:1100px){.chat-workspace #group-body.group-conversation{grid-template-columns:minmax(0,1fr)!important}.group-conversation>.group-info{display:none!important}.group-conversation>.composer{grid-column:1}.messenger-layout{grid-template-columns:290px minmax(0,1fr)}}\n@media(max-width:760px){.messenger-layout{display:flex}.shell>.main>.workspace-top{height:52px;min-height:52px;flex-basis:52px;padding:6px 10px}.chat-workspace .group-hero .body{display:block}.chat-workspace .group-hero h1{font-size:18px}.chat-workspace>#group-tabs button{font-size:10px}.chat-workspace #group-body.group-conversation{gap:7px}.group-conversation>.composer{padding:6px!important}.direct-heading .body h2{font-size:17px}.group-conversation .composer .row{flex-wrap:wrap}.chat-workspace .chat-empty h2{font-size:22px}}\n";document.head.appendChild(style)}})();

(() => {

'use strict';

const U=window.EduUI;

const CFG=window.EDUCHAT_CONFIG||{};

let sb=null;

const S={user:null,profile:null,role:'student',permissions:new Set(),page:'groups',group:null,direct:null,channel:null,notificationChannel:null,activeTimer:null};

let qrLoginRun=0;

const PERMS=['groups.manage','members.manage','files.manage','meetings.create','forum.moderate','announcements.create','attendance.read'];

const isAdmin=()=>S.role==='super_admin'||S.role==='assistant_admin';

const isSuper=()=>S.role==='super_admin';

const can=p=>isSuper()||S.permissions.has(p);

const app=()=>U.q('#app');

const boot=()=>U.q('#boot');

function showApp(){boot()?.classList.add('hidden');app()?.classList.remove('hidden')}

function failScreen(message,detail='') { boot()?.classList.add('hidden'); const a=app();a.classList.remove('hidden');a.innerHTML=`<div class="auth-panel" style="min-height:100vh"><div class="card card-pad" style="max-width:720px"><h1>Edu Chat Pro could not start</h1><p>${U.esc(message)}</p>${detail?`<pre class="diag">${U.esc(detail)}</pre>`:''}<p class="hint">Check config.js, browser console, Supabase migrations and internet access to the CDN libraries.</p><button class="btn primary" onclick="location.reload()">Retry</button></div></div>`;}

function must(result,msg='Operation failed'){if(result.error)throw Object.assign(new Error(result.error.message||msg),{code:result.error.code});return result.data}

function pageHead(title,sub='',actions=''){return `<div class="page-head"><div><h1>${U.esc(title)}</h1>${sub?`<p>${U.esc(sub)}</p>`:''}</div><div class="spacer"></div>${actions}</div>`}

function initials(n){return String(n||'U').trim().charAt(0).toUpperCase()||'U'}

function profileMap(rows){return Object.fromEntries((rows||[]).map(x=>[x.id,x]))}

const avatarCache=new Map();

async function namesFor(ids){ids=[...new Set(ids.filter(Boolean))];if(!ids.length)return{};const {data,error}=await sb.from('profiles').select('id,full_name,avatar_path').in('id',ids);if(error)return{};return profileMap(data)}

function avatarHtml(p,size=''){const name=p?.full_name||'User',path=p?.avatar_path||'';return `<span class="avatar ${U.attr(size)}" ${path?`data-avatar-path="${U.attr(path)}"`:''}>${U.esc(initials(name))}</span>`}

async function signedAvatar(path){return path?window.EduPhotos.get(sb,S.user.id,'avatars',path):null}



async function hydrateAvatars(root=document){await Promise.all(U.qa('[data-avatar-path]',root).map(async el=>{if(el.dataset.avatarLoaded==='1'||el.dataset.avatarPending==='1')return;el.dataset.avatarPending='1';try{const url=await signedAvatar(el.dataset.avatarPath);if(!url||!el.isConnected)return;const img=new Image();img.alt='Profile photo';img.decoding='async';img.onload=()=>{if(el.isConnected){el.textContent='';el.append(img);el.dataset.avatarLoaded='1'}el.dataset.avatarPending=''};img.onerror=()=>{el.dataset.avatarPending=''};img.src=url}catch{el.dataset.avatarPending=''}}))}



async function compressAvatar(file){if(!file.type.startsWith('image/'))throw new Error('Choose an image file.');if(file.size>10*1024*1024)throw new Error('Choose an image under 10 MB.');let source,width,height,cleanup=()=>{};if('createImageBitmap'in window){source=await createImageBitmap(file);width=source.width;height=source.height;cleanup=()=>source.close?.()}else{const url=URL.createObjectURL(file);source=await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(new Error('Could not read image.'));img.src=url});width=source.naturalWidth;height=source.naturalHeight;cleanup=()=>URL.revokeObjectURL(url)}const max=720,scale=Math.min(1,max/Math.max(width,height)),w=Math.max(1,Math.round(width*scale)),h=Math.max(1,Math.round(height*scale));const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;canvas.getContext('2d').drawImage(source,0,0,w,h);cleanup();const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('Could not process image.')),'image/jpeg',.82));if(blob.size>1024*1024)throw new Error('The processed photo is still too large. Choose a smaller image.');return blob}

function groupImage(g){return g.image_path?`<img data-group-photo="${U.attr(g.image_path)}" alt="Group photo" loading="lazy">`:U.icon('groups')}

async function hydrateGroupImages(root){await Promise.all(U.qa('[data-group-photo]',root).map(async img=>{if(img.src)return;try{const url=await window.EduPhotos.get(sb,S.user.id,'group-images',img.dataset.groupPhoto);if(img.isConnected){img.decoding='async';img.src=url}}catch{}}))}



async function has(p){if(isSuper())return true;if(S.role==='assistant_admin')return S.permissions.has(p);return false}

function cleanupChannel(){S.pageRefresh=null;S.alertsRefresh=null;S.meetingRefresh=null;if(S.channel){sb.removeChannel(S.channel).catch(()=>{});S.channel=null}}



async function init(){

  try{

    if(!CFG.SUPABASE_URL||!CFG.SUPABASE_PUBLISHABLE_KEY)throw new Error('Supabase URL/key are missing from config.js.');

    if(!window.supabase?.createClient)throw new Error('Supabase browser library did not load.');

    sb=window.supabase.createClient(CFG.SUPABASE_URL,CFG.SUPABASE_PUBLISHABLE_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});

    sb.auth.onAuthStateChange((event,session)=>setTimeout(()=>authChanged(event,session),0));

    const {data,error}=await sb.auth.getSession();window.eduCleanAddress?.();if(error)throw error;

    if(!data.session && U.routeInvite() && !window.EDU_ENTRY?.login){location.replace('guest.html?invite='+encodeURIComponent(U.routeInvite()));return;}

    if(data.session)await enter(data.session.user);else renderAuth();

    showApp();

  }catch(e){console.error(e);failScreen('Startup failed.',U.errorText(e));}

}

async function authChanged(event,session){

  if(event==='PASSWORD_RECOVERY'){renderPasswordRecovery();showApp();return}

  if(!session){leaveSession();renderAuth();showApp();return}

  if(!S.user||S.user.id!==session.user.id)await enter(session.user);

}

function leaveSession(){window.EduWorkspace.dispose();stopDesignRail();window.EduPhotos.clear();mediaUrls.clear();document.querySelector('.permission-banner')?.remove();S.stopNotifications?.();S.stopNotifications=null;avatarCache.clear();document.querySelector('.incoming-call')?.remove();S.direct=null;cleanupChannel();if(S.notificationChannel){sb.removeChannel(S.notificationChannel).catch(()=>{});S.notificationChannel=null}clearInterval(S.activeTimer);Object.assign(S,{user:null,profile:null,role:'student',permissions:new Set(),group:null});}



function renderAuth(tab='login'){

  qrLoginRun++;

  if(window.EDU_ENTRY?.groupInvite)sessionStorage.setItem('ecp-group-invite',window.EDU_ENTRY.groupInvite);

  app().innerHTML=`<div class="auth-shell"><section class="auth-art"><img class="brand-mark" src="ecp-logo.png" alt="Edu Chat Pro"><h1>Learn, talk,<br>meet together.</h1><p>Edu Chat Pro brings WhatsApp-style group communication, files, public discussion and Google-Meet-inspired calls into one learning space.</p></section><section class="auth-panel"><div class="card auth-card"><div class="row" style="margin-bottom:18px"><img class="brand-mark auth-form-logo" src="ecp-logo.png?v=20260923-logo" alt="Edu Chat Pro logo" width="56" height="56"><div><strong style="font-size:20px">Edu Chat Pro</strong><div class="tiny muted">Educational communication</div></div></div><div class="auth-tabs"><button data-tab="login" class="${tab==='login'?'active':''}">Sign in</button><button data-tab="signup" class="${tab==='signup'?'active':''}">Create account</button></div><div id="auth-form"></div></div></section></div>`;

  U.qa('[data-tab]',app()).forEach(b=>b.onclick=()=>renderAuth(b.dataset.tab));

  const f=U.q('#auth-form',app());

  if(tab==='signup')f.innerHTML=`<form id="signup"><div class="field"><label>Full name</label><input class="input" name="name" maxlength="100" required></div><div class="field"><label>Email</label><input class="input" name="email" type="email" required></div><div class="field"><label>Password</label><input class="input" name="password" type="password" minlength="8" required></div><button class="btn primary" style="width:100%">Create account</button><p class="hint">A verification email may be sent depending on your Supabase Auth settings.</p></form>`;

  else f.innerHTML=`<form id="login"><div class="field"><label>Email</label><input class="input" name="email" type="email" required></div><div class="field"><label>Password</label><input class="input" name="password" type="password" required></div><button class="btn primary" style="width:100%">Sign in</button><button type="button" class="btn ghost" style="width:100%;margin-top:9px" id="forgot">Forgot password</button><div class="auth-divider"><span>or</span></div><button type="button" class="btn qr-auth-link-btn" id="qr-auth-link"><span class="qr-icon">▦</span> Sign in with mobile QR</button><p class="hint" style="text-align:center;margin-bottom:0">Already signed in on the Edu Chat Pro mobile app? Scan the QR code to sign in here without typing your email or password.</p></form>`;

  U.q('#signup',f)?.addEventListener('submit',async e=>{e.preventDefault();const b=e.submitter;U.setBusy(b,true);try{const d=new FormData(e.target);const {data,error}=await sb.auth.signUp({email:String(d.get('email')).trim(),password:d.get('password'),options:{data:{full_name:d.get('name')},emailRedirectTo:CFG.PUBLIC_WEB_URL||location.origin}});if(error)throw error;U.toast(data.session?'Account created.':'Check your email to verify your account.','ok');if(!data.session)renderAuth('login')}catch(x){U.toast(U.errorText(x),'error')}finally{U.setBusy(b,false)}});

  U.q('#login',f)?.addEventListener('submit',async e=>{e.preventDefault();const b=e.submitter;U.setBusy(b,true);try{const d=new FormData(e.target);const {error}=await sb.auth.signInWithPassword({email:String(d.get('email')).trim(),password:d.get('password')});if(error)throw error}catch(x){U.toast(U.errorText(x),'error')}finally{U.setBusy(b,false)}});

  U.q('#forgot',f)?.addEventListener('click',async()=>{const v=await U.promptBox({title:'Reset password',fields:[{label:'Email',type:'email'}],submit:'Send reset email'});if(!v)return;try{const {error}=await sb.auth.resetPasswordForEmail(v[0],{redirectTo:CFG.PUBLIC_WEB_URL||location.origin});if(error)throw error;U.toast('Password reset email sent.','ok')}catch(e){U.toast(U.errorText(e),'error')}});

  U.q('#qr-auth-link',f)?.addEventListener('click',startQrWebLogin);

  const guestCode=U.routeInvite();if(guestCode){const guest=document.createElement('a');guest.className='btn primary';guest.style.marginTop='12px';guest.textContent='Join meeting as guest';guest.href='guest.html?invite='+encodeURIComponent(guestCode);f.appendChild(guest);}

}



let qrEndpoint='qr-auth-link';

async function qrRequest(body){let result=await sb.functions.invoke(qrEndpoint,{body});if(result.error?.context?.status===404&&body.action==='create'){qrEndpoint='qr-login';result=await sb.functions.invoke(qrEndpoint,{body})}return result}

async function startQrWebLogin(){

  const button=U.q('#qr-auth-link'); if(button)U.setBusy(button,true,'Creating QR…');

  const run=++qrLoginRun;

  try{

    const created=await qrRequest({action:'create'});

    if(created.error)throw created.error;

    const d=created.data||{};

    if(!d.session_id||!d.secret)throw new Error('QR login service returned an incomplete response.');

    const payload=JSON.stringify({type:'educhat_web_login',version:1,session_id:d.session_id,secret:d.secret,origin:CFG.PUBLIC_WEB_URL||location.origin});

    const r=U.modal({title:'Sign in with your phone',body:`<div class="qr-auth-link-panel"><div id="qr-code" class="qr-code"></div><p><strong>On your phone:</strong> open Edu Chat Pro → Profile → Scan web login QR.</p><p class="hint">For your security this code expires in about 2 minutes and works only once.</p><div id="qr-status" class="qr-status">Waiting for scan…</div></div>`,actions:`<button class="btn ghost" data-close-qr>Cancel</button>`,closeOnBackdrop:false});

    U.q('[data-close-qr]',r).onclick=()=>{qrLoginRun++;U.closeModal()};

    const box=U.q('#qr-code',r);

    if(window.QRCode){new window.QRCode(box,{text:payload,width:224,height:224,colorDark:'#111827',colorLight:'#ffffff',correctLevel:window.QRCode.CorrectLevel.M});}

    else box.innerHTML='<div class="meet-error">QR renderer did not load. Check your internet/CDN access and try again.</div>';

    const status=U.q('#qr-status',r);

    const deadline=d.expires_at?new Date(d.expires_at).getTime():Date.now()+120000;

    while(run===qrLoginRun && Date.now()<deadline && !!U.q('#qr-status',r)){

      await U.sleep(1500);

      if(run!==qrLoginRun||!U.q('#qr-status',r))return;

      const polled=await qrRequest({action:'poll',session_id:d.session_id,secret:d.secret});

      if(polled.error){const msg=await (async()=>{try{return (await polled.error.context?.clone?.().json())?.error||U.errorText(polled.error)}catch{return U.errorText(polled.error)}})();if(/expired/i.test(msg)){status.textContent='QR code expired. Close this window and create a new one.';status.classList.add('error');return}status.textContent='Connection issue: '+msg+' — retrying…';continue;}

      if(polled.data?.status==='approved'&&polled.data?.token_hash){

        status.textContent='Approved on phone. Signing you in…';status.classList.add('ok');

        const verified=await sb.auth.verifyOtp({type:'magiclink',token_hash:polled.data.token_hash});

        if(verified.error)throw verified.error;

        qrRequest({action:'complete',session_id:d.session_id,secret:d.secret}).catch(()=>{});qrLoginRun++;U.closeModal();U.toast('Signed in from your mobile app.','ok');return;

      }

    }

    if(run===qrLoginRun&&status){status.textContent='QR code expired. Close this window and create a new one.';status.classList.add('error');}

  }catch(e){U.toast(`QR login: ${U.errorText(e)}`,'error')}

  finally{if(button&&document.body.contains(button))U.setBusy(button,false)}

}



function renderPasswordRecovery(){app().innerHTML=`<div class="auth-panel" style="min-height:100vh"><div class="card auth-card"><h1>Set a new password</h1><form id="recover"><div class="field"><label>New password</label><input class="input" type="password" name="password" minlength="8" required></div><button class="btn primary">Update password</button></form></div></div>`;U.q('#recover').onsubmit=async e=>{e.preventDefault();try{const {error}=await sb.auth.updateUser({password:new FormData(e.target).get('password')});if(error)throw error;U.toast('Password updated.','ok');await enter((await sb.auth.getUser()).data.user)}catch(x){U.toast(U.errorText(x),'error')}}}



async function enter(user){

  S.user=user;

  try{

    const p=must(await sb.rpc('my_profile'))||{};S.profile=p;

    const role=(await sb.from('user_roles').select('role').eq('user_id',user.id).maybeSingle());if(role.error)throw role.error;S.role=role.data?.role||'student';

    S.permissions=new Set();if(S.role==='assistant_admin'){const r=await sb.from('assistant_admin_permissions').select('permission').eq('user_id',user.id);if(!r.error)(r.data||[]).forEach(x=>S.permissions.add(x.permission));}

    renderShell();offerWebPermissions();await setupNotifications();touchActive();clearInterval(S.activeTimer);S.activeTimer=setInterval(touchActive,60000);

    const groupCode=window.EDU_ENTRY?.groupInvite||sessionStorage.getItem('ecp-group-invite');if(groupCode){await navigate('groups');await acceptGroupInvite(groupCode);return;}

    const invite=U.routeInvite();if(invite){setTimeout(()=>joinByInvite(invite),200)}else {await navigate('forum');const notificationId=window.EDU_ENTRY?.notification||new URLSearchParams(location.search).get('notification');if(notificationId){const result=await sb.from('notifications').select('*').eq('id',notificationId).maybeSingle();if(result.data)await openNotification(result.data);if(window.EDU_ENTRY)window.EDU_ENTRY.notification=null;window.eduCleanAddress?.();}}

  }catch(e){console.error(e);U.toast(U.errorText(e),'error');throw e}

}

async function touchActive(){if(!S.user)return;try{await sb.rpc('touch_active')}catch{}}

function renderShell(){

  try{document.documentElement.dataset.theme=localStorage.getItem('ecp-theme')||'light'}catch{document.documentElement.dataset.theme='light'}

  const nav=[['forum','forum','Home'],['groups','groups','Chats'],['saved','file','Saved'],['meetings','meeting','Calls'],['notifications','bell','Alerts'],['profile','user','Profile']];if(isAdmin())nav.push(['admin','shield','Admin']);

  app().innerHTML=`<div class="shell"><nav class="icon-rail" aria-label="Quick navigation"><button class="rail-logo" id="rail-expand-logo" title="Expand sidebar" aria-label="Expand sidebar" aria-controls="site-sidebar" aria-expanded="false"><img src="ecp-logo.png" alt="Edu Chat Pro"></button><div class="rail-links"><button class="rail-button" id="rail-home" data-nav="forum" title="Forum" aria-label="Forum"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 10 12 3l9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z" fill="currentColor" stroke="none"/></svg></button>${[['groups','groups','Groups'],['people','chat','Personal chats'],['meetings','meeting','Calls and meetings'],['notifications','bell','Notifications'],['profile','user','Profile']].map(n=>`<button class="rail-button" data-nav="${n[0]}" title="${n[2]}" aria-label="${n[2]}">${U.icon(n[1])}</button>`).join('')}<button class="rail-button" id="rail-more" title="Expand sidebar" aria-label="Expand sidebar" aria-controls="site-sidebar" aria-expanded="false"><span aria-hidden="true">•••</span></button></div></nav><aside class="sidebar" id="site-sidebar" inert aria-label="Main navigation"><button id="drawer-close" class="btn drawer-close" aria-label="Close navigation">×</button><div class="brand"><img class="brand-mark" src="ecp-logo.png" alt="Edu Chat Pro"><div><div>Edu Chat Pro</div><div class="tiny muted">Connect • Learn • Meet</div></div></div><nav class="nav">${nav.map(n=>`<button data-nav="${n[0]}">${U.icon(n[1])}<span>${n[2]}</span></button>`).join('')}</nav><div class="sidebar-bottom card"><div class="row">${avatarHtml(S.profile)}<div class="sidebar-user"><strong>${U.esc(S.profile?.full_name||'Student')}</strong><div class="tiny muted">${U.esc(S.role.replaceAll('_',' '))}</div></div></div><button class="btn ghost" id="theme-toggle" style="width:100%">☾ Light / Dark mode</button><button id="logout" class="btn ghost" style="width:100%;margin-top:12px">${U.icon('logout')} Sign out</button></div></aside><button class="drawer-backdrop" aria-label="Close navigation" tabindex="-1" hidden></button><main class="main"><header class="workspace-top"><button class="btn icon-btn" id="sidebar-toggle" aria-label="Open navigation" aria-controls="site-sidebar" aria-expanded="false">☰</button><img class="workspace-logo" src="ecp-logo.png" alt="Edu Chat Pro"><button class="workspace-title workspace-breadcrumb" id="workspace-title" type="button" title="Back to groups">Edu Chat Pro</button><form id="inbox-search-form" class="inbox-search" hidden><span aria-hidden="true">⌕</span><input id="inbox-search" type="search" placeholder="Search in this group…" aria-label="Search messages" maxlength="160" autocomplete="off"><button class="text-btn" aria-label="Submit search">Search</button></form><div class="spacer"></div><button class="btn icon-btn" id="header-alerts" aria-label="Notifications">${U.icon('bell')}</button><button class="btn icon-btn" id="theme-mobile-toggle" aria-label="Toggle dark mode">☾</button></header><div id="page" class="content"></div></main><nav class="mobile-nav">${nav.slice(0,5).map(n=>`<button data-nav="${n[0]}">${U.icon(n[1])}<span>${n[2]}</span></button>`).join('')}</nav></div>`;

  U.qa('[data-nav]',app()).forEach(b=>b.onclick=()=>{setDrawer(false);const mobileChat=matchMedia('(max-width:800px)').matches&&b.dataset.nav==='groups';navigate(mobileChat?'chats':b.dataset.nav)});U.q('#rail-expand-logo').onclick=()=>setDrawer(true);U.q('#rail-more').onclick=()=>setDrawer(true);U.q('#rail-home').onclick=()=>{setDrawer(false);navigate('forum')};U.q('#sidebar-toggle').onclick=()=>setDrawer(!U.q('.shell').classList.contains('drawer-open'));U.q('.drawer-backdrop').onclick=()=>setDrawer(false);U.q('#drawer-close').onclick=()=>setDrawer(false);U.q('#workspace-title').onclick=()=>navigate('groups');U.q('#header-alerts').onclick=()=>navigate('notifications');U.q('#inbox-search-form').onsubmit=e=>{e.preventDefault();searchInbox()};U.q('#theme-toggle').onclick=toggleTheme;U.q('#theme-mobile-toggle').onclick=toggleTheme;U.q('#logout').onclick=async()=>{try{await window.EduPush.unregister(sb,S.user.id);await sb.auth.signOut({scope:'local'})}catch(e){U.toast(U.errorText(e),'error')}};hydrateAvatars(app());

}

function setDrawer(open){const shell=U.q('.shell'),side=U.q('#site-sidebar');if(!shell||!side)return;shell.classList.toggle('drawer-open',open);side.inert=!open;U.q('.main').inert=open;U.q('.icon-rail').inert=open;U.q('#rail-more').setAttribute('aria-expanded',String(open));U.q('#rail-expand-logo').setAttribute('aria-expanded',String(open));U.q('.drawer-backdrop').hidden=!open;U.q('#sidebar-toggle').setAttribute('aria-expanded',String(open));if(open)side.querySelector('button')?.focus();else U.q('#sidebar-toggle').focus()}

document.addEventListener('keydown',e=>{if(e.key==='Escape'&&U.q('.drawer-open'))setDrawer(false)});

function chatLayout(kind=''){if(!kind){stopDesignRail();U.q('#page')?.classList.remove('messenger-page');}const box=U.q('#page');if(!box)return;box.classList.toggle('chat-workspace',!!kind);box.classList.toggle('direct-workspace',kind==='direct');const search=U.q('#inbox-search-form');if(search)search.hidden=!kind;const input=U.q('#inbox-search');if(input){input.value='';input.placeholder=kind==='direct'?'Search this conversation…':'Search in this group…'}const title=U.q('#workspace-title');if(title)title.textContent=kind==='group'?'Groups › '+(S.group?.name||'Chat'):kind==='direct'?'Inbox':'Edu Chat Pro'}

async function searchInbox(){

 const query=U.q('#inbox-search').value.trim(),group=S.group?.id,other=S.direct;if(!query||(!group&&!other))return;

 const r=U.modal({title:'Search messages',wide:true,body:'<div id="search-results" class="stack"></div>',actions:'<button class="btn ghost" data-close>Close</button><button class="btn" id="search-more">Load more</button>'});const results=U.q('#search-results',r),more=U.q('#search-more',r);let offset=0;

 async function load(){U.setBusy(more,true);try{let request=sb.from(group?'group_messages':'direct_messages').select('id,body,sender_id,created_at').ilike('body','%'+query.replace(/[\\%_]/g,c=>'\\'+c)+'%').order('created_at',{ascending:false}).order('id').range(offset,offset+29);if(group)request=request.eq('group_id',group);else request=request.or(`and(sender_id.eq.${S.user.id},recipient_id.eq.${other}),and(sender_id.eq.${other},recipient_id.eq.${S.user.id})`);const rows=must(await request)||[],names=await namesFor(rows.map(m=>m.sender_id));if(!results.isConnected)return;results.insertAdjacentHTML('beforeend',rows.map(m=>`<article class="search-hit"><strong>${U.esc(names[m.sender_id]?.full_name||'Member')}</strong><span class="tiny muted"> · ${U.fmtDate(m.created_at)}</span><p class="bodytext">${U.esc(m.body)}</p></article>`).join(''));if(!offset&&!rows.length)results.textContent='No messages match your search.';offset+=rows.length;more.hidden=rows.length<30}catch(e){U.toast(U.errorText(e),'error')}finally{U.setBusy(more,false)}}more.onclick=load;await load();

}

function toggleTheme(){const theme=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=theme;(()=>{try{localStorage.setItem('ecp-theme',theme)}catch{}})()}

function workspaceContext(){return {sb,S,U,can,isAdmin,isSuper,navigate,openMeeting,namesFor,openNotification,enableAlerts:enableWebAlerts,uploadForumMedia,linkGroupInvites,
 sendAttachment:async(item,file,body)=>{if(item.kind==='group')await sendGroupAttachment(item,file,file.durationMs||0,body);else await sendDirectAttachment(item.peer_id,file,file.durationMs||0,body);},
 hydrateAttachments:async(rows)=>{const ids=rows.filter(m=>m.file_id&&!m.attachment_path).map(m=>m.file_id);if(!ids.length)return rows;const files=must(await sb.from('group_files').select('*').in('id',ids));return rows.map(m=>{const f=files.find(f=>f.id===m.file_id);return f?{...m,attachment_path:f.object_path,file_name:f.name,mime_type:f.mime_type}:m;});},
 startCall:async(item,audio)=>{S.group=item.kind==='group'?item:null;S.direct=item.kind==='direct'?item.peer_id:null;let m;if(item.kind==='direct'){const id=must(await sb.rpc('start_direct_call',{target:item.peer_id,video:!audio}));m=must(await sb.from('meetings').select('*').eq('id',id).single());}else{m=must(await sb.from('meetings').insert({title:(audio?'Audio: ':'Video: ')+item.name,group_id:item.id,host_id:S.user.id}).select().single());}await openMeeting(m,{autoJoin:true});},
 groupPanel:async(g,tab)=>{S.group=g;if(tab==='files')await groupFiles(g);else if(tab==='members')await groupMembers(g);else if(tab==='meetings')await renderMeetings(g);else if(tab==='drive')await groupDrive(g);else await groupSettings(g);}};}
async function navigate(p){window.EduWorkspace.dispose();chatLayout();cleanupChannel();S.page=p;S.group=null;S.direct=null;const box=U.q('#page',app());box.className='content';U.qa('[data-nav]',app()).forEach(x=>x.classList.toggle('active',x.dataset.nav===p));box.innerHTML='<div class="loading">Loading…</div>';try{const c=workspaceContext();if(p==='groups'||p==='people'||p==='chats')await window.EduWorkspace.chat(c,p==='groups'?'groups':p==='people'?'direct':'all');else if(p==='forum')await window.EduWorkspace.forum(c);else if(p==='saved')await window.EduWorkspace.saved(c);else if(p==='meetings')await renderMeetings();else if(p==='notifications')await window.EduWorkspace.notifications(c);else if(p==='profile')await renderProfile();else if(p==='admin'&&isAdmin())await renderAdmin();else await window.EduWorkspace.chat(c,'all');}catch(e){box.innerHTML=`${pageHead('Could not open this page')}<div class="card card-pad"><p class="danger-text">${U.esc(U.errorText(e))}</p><p>If this mentions a missing database function or column, apply the included REVISION4_DATABASE_UPDATE.sql once.</p><button class="btn" onclick="location.reload()">Reload</button></div>`;console.error(e)}}


async function legacyRenderGroups(){

  chatLayout();

  S.direct=null;

  const box=U.q('#page');const actions='<button class="btn ghost" id="private-chats">'+U.icon('chat')+' Private chats</button>'+(can('groups.manage')?'<button class="btn primary" id="new-group">+ New group</button>':'');box.innerHTML=pageHead('Groups','Your classes, files and group conversations.',actions)+'<div id="group-list" class="grid"></div>';

  U.q('#private-chats').onclick=renderPeople;

  if(can('groups.manage'))U.q('#new-group').onclick=async()=>{const v=await U.promptBox({title:'Create group',fields:[{label:'Group name',max:120},{label:'Description',type:'textarea',required:false,max:2000}],submit:'Create'});if(!v)return;try{const {data,error}=await sb.from('groups').insert({name:v[0],description:v[1],created_by:S.user.id}).select().single();if(error)throw error;U.toast('Group created.','ok');await openGroup(data.id)}catch(e){U.toast(U.errorText(e),'error')}};

  const {data,error}=await sb.from('groups').select('*').order('created_at',{ascending:false});if(error)throw error;

  const list=U.q('#group-list');if(!data?.length){list.innerHTML='<div class="card empty"><div class="big">🏫</div>No groups yet.</div>';return}

  list.innerHTML=data.map(g=>`<button class="card group-card" data-group="${g.id}"><div class="group-cover">${groupImage(g)}</div><div class="card-pad" style="text-align:left"><h3>${U.esc(g.name)}</h3><p>${U.esc(g.description||'No description')}</p><span class="badge ${g.allow_member_messaging?'green':'red'}">Member chat ${g.allow_member_messaging?'on':'off'}</span></div></button>`).join('');

  hydrateGroupImages(list);U.qa('[data-group]',list).forEach(b=>b.onclick=()=>openGroup(b.dataset.group));

}

async function oldOpenGroup(id,tab='chat'){stopDesignRail();U.q('#page')?.classList.remove('messenger-page');

  S.direct=null;

  cleanupChannel();const {data:g,error}=await sb.from('groups').select('*').eq('id',id).single();if(error)throw error;S.group=g;chatLayout(tab==='chat'?'group':'');

  const box=U.q('#page');box.innerHTML=`<button class="btn ghost small" id="back-groups">← Groups</button><div class="group-hero"><div class="group-hero-icon">${groupImage(g)}</div><div class="body"><h1>${U.esc(g.name)}</h1><p>${U.esc(g.description||'Group workspace')}</p><span class="muted" id="group-member-count">Private group</span></div><div class="spacer"></div>${can('groups.manage')||g.created_by===S.user.id?'<button class="btn ghost" id="edit-group">'+U.icon('edit')+' Edit group</button>':''}</div><div class="tabs" id="group-tabs">${[['chat','Chat'],['files','Files'],['members','Members'],['meetings','Meetings'],['drive','Google Drive'],['settings','Settings']].map(x=>`<button data-gtab="${x[0]}" class="${tab===x[0]?'active':''}">${U.icon(({chat:'chat',files:'file',members:'groups',meetings:'meeting',drive:'cloud',settings:'settings'})[x[0]])} ${x[1]}</button>`).join('')}</div><div id="group-body"></div>`;

  sb.from('group_members').select('user_id',{count:'exact',head:true}).eq('group_id',id).then(({count,error})=>{const label=U.q('#group-member-count');if(!error&&label&&S.group?.id===id)label.textContent=`${count} members · Private group`});

  hydrateGroupImages(box);if(can('groups.manage')||g.created_by===S.user.id){const photo=U.q('.group-hero-icon',box);photo.setAttribute('role','button');photo.tabIndex=0;photo.title='Change group photo';photo.onclick=()=>changeWebGroupPhoto(g,tab);photo.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();changeWebGroupPhoto(g,tab)}}}U.q('#back-groups').onclick=()=>navigate(matchMedia('(max-width:800px)').matches?'chats':'groups');U.qa('[data-gtab]').forEach(b=>b.onclick=()=>openGroup(id,b.dataset.gtab));

  U.q('#edit-group')?.addEventListener('click',async()=>{const v=await U.promptBox({title:'Edit group',fields:[{label:'Name',value:g.name,max:120},{label:'Description',type:'textarea',value:g.description,required:false,max:2000}],submit:'Save'});if(!v)return;try{const {error}=await sb.from('groups').update({name:v[0],description:v[1]}).eq('id',g.id);if(error)throw error;U.toast('Group updated.','ok');openGroup(id,tab)}catch(e){U.toast(U.errorText(e),'error')}});

  if(tab==='chat')await groupChat(g);else if(tab==='files')await groupFiles(g);else if(tab==='members')await groupMembers(g);else if(tab==='meetings')await renderMeetings(g);else if(tab==='drive')await groupDrive(g);else await groupSettings(g);

}

async function groupChat(g){

  let messageLimit=30,groupLoadGeneration=0,groupSignature='';

  const body=U.q('#group-body');body.innerHTML=`<div class="card card-pad chat-panel"><button type="button" class="btn ghost small" id="older-messages">Load older messages</button><div id="chat-log" class="chat-log"></div><form id="chat-form" class="composer" style="margin-top:12px"><div class="row"><button type="button" class="btn attach-button" id="chat-attach" aria-label="Attach a file">+</button><input type="file" id="chat-file" hidden><input id="chat-input" class="input" maxlength="4000" placeholder="Write to this group…" ${!g.allow_member_messaging&&!can('groups.manage')&&g.created_by!==S.user.id?'disabled':''}><button type="button" class="btn ghost emoji-toggle" id="chat-emoji" aria-label="Choose emoji">☺</button><button class="btn primary" ${!g.allow_member_messaging&&!can('groups.manage')&&g.created_by!==S.user.id?'disabled':''}>${U.icon('send')} Send</button>${(can('announcements.create')||g.created_by===S.user.id)?'<button type="button" class="btn ghost" id="announce">Announcement</button>':''}</div></form>${!g.allow_member_messaging&&!can('groups.manage')&&g.created_by!==S.user.id?'<p class="hint">Group messaging is currently closed by an administrator.</p>':''}</div>`;

  const load=async()=>{const generation=++groupLoadGeneration;const {data,error}=await sb.from('group_messages').select('*,group_files(*)').eq('group_id',g.id).order('created_at',{ascending:false}).limit(messageLimit);if(error)throw error;const rows=(data||[]).reverse(),names=await namesFor(rows.map(x=>x.sender_id));const log=U.q('#chat-log');if(generation!==groupLoadGeneration||!log||S.group?.id!==g.id)return;const signature=JSON.stringify([rows,names]);if(signature===groupSignature){hydrateChatReactions(log,'group');return}groupSignature=signature;const oldHeight=log.scrollHeight,oldTop=log.scrollTop,atBottom=oldHeight-oldTop-log.clientHeight<100;syncMessages(log,rows.length?rows.map(m=>{const mine=m.sender_id===S.user.id,p=names[m.sender_id]||{full_name:mine?(S.profile?.full_name||'You'):'Member'};return `<div data-message-id="${m.id}" data-created="${m.created_at}" data-stamp="${U.attr(JSON.stringify([m,p]))}" class="message-row ${mine?'mine':''}">${avatarHtml(p)}<div class="message ${mine?'mine':''}"><div class="meta">${messageMeta(p.full_name||'Member',m.created_at,mine)} ${m.is_announcement?'• Announcement':''}</div><div>${U.esc(m.body)}</div>${m.group_files?`<button class="btn attachment" data-attachment="${U.attr(m.group_files.object_path)}" data-mime="${U.attr(m.group_files.mime_type)}">📎 ${U.esc(m.group_files.name)}</button>${mine||can('files.manage')||g.created_by===S.user.id?`<button class="text-btn danger-text" data-remove-attachment="${m.group_files.id}" data-path="${U.attr(m.group_files.object_path)}">Remove file</button>`:''}`:''}${(mine||can('groups.manage'))?`<button class="text-btn danger-text" data-del-msg="${m.id}">Delete</button>`:''}</div></div>`}).join(''):'<div class="empty chat-empty"><div class="chat-art">•••</div><h2>No messages yet</h2><p>Be the first to start the conversation in this group!</p><div class="chat-prompts"><span>💡 Share ideas</span><span>❔ Ask questions</span><span>♧ Learn together</span></div></div>');const older=U.q('#older-messages');if(older)older.hidden=rows.length<messageLimit;await hydrateAvatars(log);

    U.qa('[data-attachment]',log).forEach(b=>{const wrap=document.createElement('div');wrap.innerHTML=mediaMarkup('group-files',b.dataset.attachment,b.dataset.mime||'',b.textContent);b.replaceWith(wrap)});await hydrateMedia(log);linkGroupInvites(log);addDayMarkers(log);hydrateChatReactions(log,S.group?'group':'direct');

    U.qa('[data-remove-attachment]',log).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Remove attachment','Delete this file from the group?','Delete'))return;try{must(await sb.storage.from('group-files').remove([b.dataset.path]));must(await sb.from('group_files').delete().eq('id',b.dataset.removeAttachment));await load()}catch(e){U.toast(U.errorText(e),'error')}});

    log.scrollTop=atBottom?log.scrollHeight:oldTop+(log.scrollHeight-oldHeight);U.qa('[data-del-msg]',log).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Delete message','Delete this message?','Delete'))return;const {error}=await sb.from('group_messages').delete().eq('id',b.dataset.delMsg);if(error)U.toast(U.errorText(error),'error');else load()})};

  await load();

  U.q('#older-messages').onclick=async()=>{messageLimit+=30;try{await load()}catch(e){U.toast(U.errorText(e),'error')}};

  U.q('#chat-emoji').onclick=()=>{const r=U.modal({title:'Choose emoji',body:['😊','👍','❤️','🎉','📚','✅','👋','😂'].map(x=>`<button class="btn emoji-choice">${x}</button>`).join('')});U.qa('.emoji-choice',r).forEach(b=>b.onclick=()=>{U.q('#chat-input').value+=b.textContent;U.closeModal();U.q('#chat-input').focus()})};

  U.q('#chat-attach').onclick=()=>U.q('#chat-file').click();

  U.q('#chat-attach').disabled=!g.allow_member_messaging&&!can('groups.manage')&&g.created_by!==S.user.id&&g.created_by!==S.user.id;

  U.q('#chat-file').onchange=async e=>{const file=e.target.files?.[0];if(!file)return;const b=U.q('#chat-attach');b.disabled=true;try{await sendGroupAttachment(g,file);await load()}catch(err){U.toast(U.errorText(err),'error')}finally{b.disabled=false;e.target.value=''}};

  U.q('#chat-form').onsubmit=async e=>{e.preventDefault();const i=U.q('#chat-input'),v=i.value.trim();if(!v)return;const {error}=await sb.from('group_messages').insert({group_id:g.id,sender_id:S.user.id,body:v,is_announcement:false});if(error)U.toast(U.errorText(error),'error');else{i.value='';load()}};

  U.q('#announce')?.addEventListener('click',async()=>{const v=await U.promptBox({title:'Post announcement',fields:[{label:'Announcement',type:'textarea',max:4000}],submit:'Post'});if(!v)return;const {error}=await sb.from('group_messages').insert({group_id:g.id,sender_id:S.user.id,body:v[0],is_announcement:true});if(error)U.toast(U.errorText(error),'error');else load()});

  installGroupInfo(g).catch(()=>{});S.pageRefresh=load;installVoice(U.q('#chat-form'),async(file,duration)=>{await sendGroupAttachment(g,file,duration);await load()});

  S.channel=sb.channel(`group-chat-${g.id}`).on('postgres_changes',{event:'*',schema:'public',table:'group_messages',filter:`group_id=eq.${g.id}`},()=>load()).on('postgres_changes',{event:'*',schema:'public',table:'message_reactions'},()=>{const log=U.q('#chat-log');if(log)hydrateChatReactions(log,'group')}).on('postgres_changes',{event:'*',schema:'public',table:'group_files',filter:`group_id=eq.${g.id}`},()=>{load().catch(()=>{});installGroupInfo(g).catch(()=>{})}).on('postgres_changes',{event:'*',schema:'public',table:'group_members',filter:`group_id=eq.${g.id}`},()=>installGroupInfo(g).catch(()=>{})).subscribe();

}

async function groupFiles(g){

  const body=U.q('#group-body');const allow=can('files.manage')||g.allow_member_messaging||g.created_by===S.user.id;body.innerHTML=`<div class="card card-pad"><div class="row wrap"><div><h3 style="margin:0">Group files</h3><div class="hint">PDF, Office, images and ZIP • up to 10 MB each</div></div><div class="spacer"></div>${allow?'<label class="btn primary">Upload file<input id="file-pick" type="file" hidden></label>':''}${can('files.manage')?'<button class="btn danger" id="delete-all-files">Delete all</button>':''}</div><div id="files-list" class="list" style="margin-top:16px"></div></div>`;

  const load=async()=>{const {data,error}=await sb.from('group_files').select('*').eq('group_id',g.id).order('created_at',{ascending:false});if(error)throw error;const names=await namesFor((data||[]).map(x=>x.uploaded_by));const list=U.q('#files-list');list.innerHTML=data?.length?data.map(f=>`<div class="list-item"><div class="avatar">📄</div><div class="body"><h3>${U.esc(f.name)}</h3><p>${U.fmtBytes(f.size_bytes)} • ${U.esc(names[f.uploaded_by]?.full_name||'Member')} • ${U.fmtDate(f.created_at)}</p></div><button class="btn small" data-open-file="${f.id}">Open</button>${can('files.manage')||f.uploaded_by===S.user.id||g.created_by===S.user.id?`<button class="btn danger small" data-del-file="${f.id}">Delete</button>`:''}</div>`).join(''):'<div class="empty">No files uploaded.</div>';U.qa('[data-open-file]',list).forEach(b=>b.onclick=async()=>{const f=data.find(x=>x.id===b.dataset.openFile);const {data:s,error}=await sb.storage.from('group-files').createSignedUrl(f.object_path,300);if(error)U.toast(U.errorText(error),'error');else (()=>{const a=document.createElement('a');a.href=s.signedUrl;a.target='_blank';a.rel='noopener';a.click()})()});U.qa('[data-del-file]',list).forEach(b=>b.onclick=()=>deleteFile(data.find(x=>x.id===b.dataset.delFile),load))};

  async function deleteFile(f,after){if(!await U.confirmBox('Delete file',`Delete ${f.name}?`,'Delete'))return;try{must(await sb.storage.from('group-files').remove([f.object_path]));must(await sb.from('group_files').delete().eq('id',f.id));U.toast('File deleted.','ok');after()}catch(e){U.toast(U.errorText(e),'error')}}

  await load();

  U.q('#file-pick')?.addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;if(f.size>10485760){U.toast('File must be 10 MB or smaller.','error');return}const allowed=['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','image/jpeg','image/png','image/webp','application/zip'];if(!allowed.includes(f.type)){U.toast('This file type is not allowed.','error');return}const path=`${g.id}/${Date.now()}-${U.uuid()}-${U.safeName(f.name)}`;try{const up=await sb.storage.from('group-files').upload(path,f,{contentType:f.type,upsert:false});if(up.error)throw up.error;const meta=await sb.from('group_files').insert({group_id:g.id,uploaded_by:S.user.id,name:U.safeName(f.name),object_path:path,size_bytes:f.size,mime_type:f.type});if(meta.error){await sb.storage.from('group-files').remove([path]);throw meta.error}U.toast('File uploaded.','ok');load()}catch(x){U.toast(U.errorText(x),'error')}finally{e.target.value=''}});

  U.q('#delete-all-files')?.addEventListener('click',async()=>{if(!await U.confirmBox('Delete all group files','This removes every file in this group. This cannot be undone.','Delete all'))return;const {data}=await sb.from('group_files').select('id,object_path').eq('group_id',g.id);if(!data?.length)return;const rm=await sb.storage.from('group-files').remove(data.map(x=>x.object_path));if(rm.error){U.toast(U.errorText(rm.error),'error');return}const del=await sb.from('group_files').delete().eq('group_id',g.id);if(del.error)U.toast(U.errorText(del.error),'error');else{U.toast('All group files deleted.','ok');load()}});

}

async function groupMembers(g){

  const body=U.q('#group-body');body.innerHTML=`<div class="card card-pad"><div class="row wrap"><h3 style="margin:0">Members</h3><div class="spacer"></div>${(can('members.manage')||g.created_by===S.user.id)?'<button class="btn" id="group-invite-link">Invite link</button><button class="btn primary" id="add-member">+ Add member</button>':''}</div><div id="member-list" class="list" style="margin-top:14px"></div></div>`;

  const load=async()=>{const {data,error}=await sb.from('group_members').select('*').eq('group_id',g.id).order('created_at');if(error)throw error;const names=await namesFor((data||[]).map(x=>x.user_id));const l=U.q('#member-list');l.innerHTML=data?.length?data.map(m=>`<div class="list-item"><div class="avatar">${U.esc(initials(names[m.user_id]?.full_name))}</div><div class="body"><h3>${U.esc(names[m.user_id]?.full_name||'Member')}</h3><p><span class="code">${U.esc(m.user_id)}</span> • joined ${U.fmtDate(m.created_at)}</p></div>${m.user_id!==S.user.id?`<button class="btn small" data-member-chat="${m.user_id}">Message</button><button class="btn small" data-member-audio="${m.user_id}">Audio call</button><button class="btn small" data-member-video="${m.user_id}">Video call</button>`:''}${(can('members.manage')||g.created_by===S.user.id)&&m.user_id!==g.created_by?`<button class="btn danger small" data-remove="${m.user_id}">Remove</button>`:''}</div>`).join(''):'<div class="empty">No members.</div>';U.qa('[data-member-audio],[data-member-video]',l).forEach(b=>b.onclick=window.EduWorkspace.run(()=>workspaceContext().startCall({kind:'direct',peer_id:b.dataset.memberAudio||b.dataset.memberVideo},!!b.dataset.memberAudio)));U.qa('[data-member-chat]',l).forEach(b=>b.onclick=()=>openDirectChat(b.dataset.memberChat));U.qa('[data-remove]',l).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Remove member','Remove this user from the group?','Remove'))return;const {error}=await sb.from('group_members').delete().eq('group_id',g.id).eq('user_id',b.dataset.remove);if(error)U.toast(U.errorText(error),'error');else load()})};await load();

  U.q('#group-invite-link')?.addEventListener('click',()=>shareGroupInvite(g));

  U.q('#add-member')?.addEventListener('click',()=>selectGroupMembers(g,load));

}

async function acceptGroupInvite(code){

 try{if(!await U.confirmBox('Join group','Join the group from this invitation using your current account?','Join group'))return;

 const id=must(await sb.rpc('join_group_invite',{code_input:code}));await openGroup(id,'chat');U.toast('You joined the group.','ok');

 }catch(e){U.toast(U.errorText(e),'error')}finally{sessionStorage.removeItem('ecp-group-invite');if(window.EDU_ENTRY)window.EDU_ENTRY.groupInvite=null;}

}

async function shareGroupInvite(g,rotate=false){

 try{const code=must(await sb.rpc('get_group_invite',{group_input:g.id,rotate_input:rotate})),link=new URL('group.html',location.origin+'/');link.searchParams.set('group_invite',code);

 const r=U.modal({title:'Group invitation link',body:`<p>Share this link in WhatsApp, Messenger or any chat. Valid for 7 days. Recipients sign in to join.</p><input class="input" readonly value="${U.attr(link.href)}">`,actions:'<button class="btn" data-close>Close</button><button class="btn" id="replace-group-link">Replace link</button><button class="btn" id="copy-group-link">Copy</button><button class="btn primary" id="share-group-link">Share</button>'});

 U.q('#copy-group-link',r).onclick=()=>U.copy(link.href);U.q('#replace-group-link',r).onclick=()=>shareGroupInvite(g,true);U.q('#share-group-link',r).onclick=async()=>{try{if(navigator.share)await navigator.share({title:g.name,url:link.href});else await U.copy(link.href)}catch(e){if(e.name!=='AbortError')U.toast(U.errorText(e),'error')}};

 }catch(e){U.toast(U.errorText(e),'error')}

}

async function groupDrive(g){

  const body=U.q('#group-body');const {data,error}=await sb.from('group_drive_links').select('*').eq('group_id',g.id).maybeSingle();if(error)throw error;const url=data?.url||'';body.innerHTML=`<div class="card card-pad"><div class="row"><div class="avatar">☁️</div><div><h2 style="margin:0">Google Drive</h2><p class="muted">Open the Drive folder configured for this group.</p></div></div>${url?`<div class="banner" style="margin-top:15px;word-break:break-all">${U.esc(url)}</div><button class="btn primary" id="open-drive">Open Google Drive</button>`:'<div class="empty">No Google Drive folder has been linked yet.</div>'}${can('groups.manage')?'<button class="btn ghost" id="set-drive">Set / change link</button> <button class="btn danger" id="remove-drive">Remove link</button>':''}</div>`;

  U.q('#open-drive')?.addEventListener('click',()=>window.open(url,'_blank','noopener'));

  U.q('#set-drive')?.addEventListener('click',async()=>{const v=await U.promptBox({title:'Google Drive folder',fields:[{label:'Folder URL',value:url,placeholder:'https://drive.google.com/drive/folders/...'}],submit:'Save'});if(!v)return;if(!U.driveUrl(v[0])){U.toast('Use a Google Drive folder URL.','error');return}const {error}=await sb.from('group_drive_links').update({url:v[0]}).eq('group_id',g.id);if(error)U.toast(U.errorText(error),'error');else groupDrive(g)});

  U.q('#remove-drive')?.addEventListener('click',async()=>{if(!url)return;const {error}=await sb.from('group_drive_links').update({url:null}).eq('group_id',g.id);if(error)U.toast(U.errorText(error),'error');else groupDrive(g)});

}

async function groupSettings(g){

  const body=U.q('#group-body');body.innerHTML=`<div class="card card-pad"><h3>Group settings</h3>${can('groups.manage')||g.created_by===S.user.id?'<button class="btn" id="edit-group-details">Edit name / description</button>':''}${g.created_by!==S.user.id?'<button class="btn danger" id="leave-group">Leave group</button>':''}${can('groups.manage')||g.created_by===S.user.id?'<label class="btn ghost">Change group photo<input id="group-photo" type="file" accept="image/jpeg,image/png,image/webp" hidden></label>':''}<label class="switch"><input id="allow-chat" type="checkbox" ${g.allow_member_messaging?'checked':''} ${can('groups.manage')||g.created_by===S.user.id?'':'disabled'}><span>Allow members to chat and upload permitted files</span></label><p class="hint">When off, regular members can read existing content but cannot send messages or upload files.</p>${can('groups.manage')?'<hr><button class="btn danger" id="delete-group">Delete group</button>':''}</div>`;

  U.q('#edit-group-details')?.addEventListener('click',window.EduWorkspace.run(async()=>{const v=await U.promptBox({title:'Edit group',fields:[{label:'Name',value:g.name,max:120},{label:'Description',type:'textarea',value:g.description||'',max:2000}],submit:'Save'});if(!v?.[0]?.trim())return;must(await sb.from('groups').update({name:v[0].trim(),description:v[1]?.trim()||''}).eq('id',g.id).select('id').single());await openGroup(g.id,'settings');}));
  U.q('#leave-group')?.addEventListener('click',window.EduWorkspace.run(async()=>{if(!await U.confirmBox('Leave group','Leave this group? You will need an invitation to rejoin.','Leave'))return;must(await sb.from('group_members').delete().eq('group_id',g.id).eq('user_id',S.user.id));await navigate('groups');}));
  U.q('#group-photo')?.addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;let path,saved=false;try{const blob=await window.EduCrop(file);if(!blob)return;path=`${g.id}/${U.uuid()}.jpg`;must(await sb.storage.from('group-images').upload(path,blob,{contentType:'image/jpeg'}));must(await sb.from('groups').update({image_path:path}).eq('id',g.id).select('id,image_path').single());saved=true;if(g.image_path&&g.image_path!==path)await sb.storage.from('group-images').remove([g.image_path]);await openGroup(g.id,'settings')}catch(err){if(path&&!saved)await sb.storage.from('group-images').remove([path]);U.toast(U.errorText(err),'error')}});

  U.q('#allow-chat')?.addEventListener('change',async e=>{const {error}=await sb.from('groups').update({allow_member_messaging:e.target.checked}).eq('id',g.id);if(error){e.target.checked=!e.target.checked;U.toast(U.errorText(error),'error')}else{g.allow_member_messaging=e.target.checked;U.toast('Group messaging setting updated.','ok')}});

  U.q('#delete-group')?.addEventListener('click',async()=>{if(!await U.confirmBox('Delete group','This deletes the group, its messages, file metadata, meetings and links. Delete stored files first if you want their objects removed too.','Delete group'))return;const {error}=await sb.from('groups').delete().eq('id',g.id);if(error)U.toast(U.errorText(error),'error');else navigate('groups')});

}



async function joinByInvite(input){

  const code=U.inviteCode(input);if(!code){U.toast('Invalid meeting invite code or link.','error');return}

  try{const {data,error}=await sb.rpc('join_invite',{code});if(error)throw error;U.clearInvite();const m=must(await sb.from('meetings').select('*').eq('id',data).single());await openMeeting(m,{autoJoin:true})}catch(e){U.toast(U.errorText(e),'error');if(S.page!=='meetings')navigate('meetings')}

}

async function openMeeting(m,opts={}){

  if(m.ended_at){U.toast('This meeting has ended.','error');return}

  if(m.starts_at&&Date.parse(m.starts_at)>Date.now()){U.toast('This meeting starts '+U.fmtDate(m.starts_at),'error');return}

  await window.EduMeeting.open(sb,m,{profile:S.profile,autoJoin:!!opts.autoJoin,onExit:()=>{if(S.direct)openDirectChat(S.direct);else if(S.group)openGroup(S.group.id,'meetings');else navigate('meetings')}});

}

async function renderMeetings(group=null){

 const box=group?U.q('#group-body'):U.q('#page'),allowed=can('meetings.create')||group?.created_by===S.user.id;

 box.innerHTML=`<section class="meetings-hub"><header class="meetings-banner"><div><h1>${group?'Group meetings':'Meetings'}</h1><p>A place to connect and learn, live.</p></div><div class="meetings-art" aria-hidden="true">${U.icon('meeting')}</div></header><div class="meeting-actions">${[['instant','Instant Meeting','Start now','meeting'],['scheduled','Schedule Meeting','Plan ahead','people'],['join','Join with invite','Use code/link','calendar'],['room','Create Room','Custom room','plus']].map(([kind,title,sub,icon])=>`<button class="meeting-action ${kind}" data-create-kind="${kind}" ${kind!=='join'&&!allowed?'disabled title="Meeting creation is restricted by your administrator"':''}>${U.icon(icon)}<strong>${title}</strong><span>${sub} <b aria-hidden="true">→</b></span></button>`).join('')}</div><form id="join-form" class="meeting-join"><span aria-hidden="true">${U.icon('link')}</span><input id="join-code" class="input" required aria-label="Meeting link or invite code" placeholder="Meeting link or invite code…"><button class="btn primary">Join</button></form><div class="row wrap history-heading"><h2>Recent Meetings</h2><div class="spacer"></div><select id="meeting-sort" class="select" aria-label="Meeting order"><option value="newest">Newest first</option><option value="oldest">Oldest first</option></select><button id="clear-history" class="btn ghost small">Clear All</button></div><div class="meeting-filters" role="group" aria-label="Filter meetings">${['all','recurring','scheduled','favorites'].map(f=>`<button class="btn ${f==='all'?'primary':''}" data-filter="${f}" aria-pressed="${f==='all'}">${f[0].toUpperCase()+f.slice(1)}</button>`).join('')}</div><div id="meeting-list" class="list" aria-live="polite"></div></section>`;

 const list=U.q('#meeting-list',box);let filter='all',newest=true,pageCount=1,serial=0;

 const alive=()=>list.isConnected;

 const report=e=>{if(alive())U.toast(U.errorText(e),'error')};

 const load=async()=>{

  const request=++serial,rows=[];let lastSize=0;

  try{

   for(let page=0;page<pageCount;page++){const batch=must(await sb.rpc('mobile_meetings',{group_filter:group?.id||null,list_filter:filter,page_offset:page*30,newest_first:newest}))||[];rows.push(...batch);lastSize=batch.length;if(lastSize<30)break}

   const [hosts,favs]=await Promise.all([namesFor(rows.map(m=>m.host_id)),rows.length?sb.from('meeting_favorites').select('meeting_id').eq('user_id',S.user.id).in('meeting_id',rows.map(m=>m.id)):Promise.resolve({data:[]})]);

   const favorites=new Set((must(favs)||[]).map(f=>f.meeting_id));if(!alive()||request!==serial)return;

   list.innerHTML=rows.length?rows.map(m=>{const future=m.starts_at&&Date.parse(m.starts_at)>Date.now();return `<article class="list-item meeting-entry"><div class="avatar">${U.icon('meeting')}</div><div class="body"><h3>${U.esc(m.title)}</h3><p>${U.esc(m.meeting_kind||'instant')} · Host ${U.esc(hosts[m.host_id]?.full_name||'User')} · ${U.fmtDate(m.starts_at||m.created_at)}${m.repeat_days?' · '+(m.repeat_days===1?'Daily':'Weekly'):''} · ${m.ended_at?'Ended':future?'Scheduled':'Ready'}</p><div class="tiny code meeting-id"><span>${U.esc(m.invite_code)}</span><button class="text-btn" data-copy-id="${U.attr(m.invite_code)}" aria-label="Copy meeting code">⧉</button></div></div><div class="meeting-entry-actions">${!m.ended_at?`<button class="btn primary small" data-join-m="${m.id}" ${future?'disabled title="Available at the scheduled time"':''}>Join</button><button class="btn small" data-invite="${m.id}">Invite</button>`:''}<button class="btn small" data-favorite="${m.id}" aria-label="${favorites.has(m.id)?'Remove from':'Add to'} favorites" aria-pressed="${favorites.has(m.id)}">${favorites.has(m.id)?'★':'☆'}</button>${can('attendance.read')||m.host_id===S.user.id?`<button class="btn small" data-att="${m.id}">${U.icon('chart')} Attendance</button>`:''}<details class="history-menu"><summary aria-label="Meeting actions">⋮</summary><button class="btn danger small" data-hide-meeting="${m.id}">Delete history</button>${!m.ended_at&&(m.host_id===S.user.id||isSuper())?`<button class="btn danger small" data-end="${m.id}">End for everyone</button>`:''}</details></div></article>`}).join(''):`<div class="meeting-empty"><div class="meetings-art">${U.icon('meeting')}</div><h2>${filter==='all'?'No meetings yet':'No '+filter+' meetings'}</h2><p>Start an instant meeting, join with a link<br>or schedule a meeting to see it here.</p>${allowed?'<button class="btn primary" id="empty-start">Start Instant Meeting</button>':''}</div>`;

   U.q('#empty-start',list)?.addEventListener('click',()=>create('instant'));

   U.qa('[data-copy-id]',list).forEach(b=>b.onclick=()=>U.copy(b.dataset.copyId));

   U.qa('[data-invite]',list).forEach(b=>b.onclick=()=>showMeetingInvite(rows.find(m=>m.id===b.dataset.invite)));

   U.qa('[data-join-m]',list).forEach(b=>b.onclick=()=>openMeeting(rows.find(m=>m.id===b.dataset.joinM),{autoJoin:true}).catch(report));

   U.qa('[data-att]',list).forEach(b=>b.onclick=()=>showAttendance(rows.find(m=>m.id===b.dataset.att)));

   U.qa('[data-favorite]',list).forEach(b=>b.onclick=async()=>{b.disabled=true;try{must(await (favorites.has(b.dataset.favorite)?sb.from('meeting_favorites').delete().eq('user_id',S.user.id).eq('meeting_id',b.dataset.favorite):sb.from('meeting_favorites').insert({user_id:S.user.id,meeting_id:b.dataset.favorite})));await load()}catch(e){report(e)}finally{b.disabled=false}});

   U.qa('[data-hide-meeting]',list).forEach(b=>b.onclick=async()=>{try{must(await sb.from('meeting_history_hidden').upsert({user_id:S.user.id,meeting_id:b.dataset.hideMeeting}));await load()}catch(e){report(e)}});

   U.qa('[data-end]',list).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('End meeting','End this meeting for everyone?','End meeting'))return;try{must(await sb.rpc('end_p2p_meeting',{meeting:b.dataset.end}));await load()}catch(e){report(e)}});

   if(lastSize===30){const more=document.createElement('button');more.className='btn ghost';more.textContent='Load more meetings';more.onclick=()=>{pageCount++;load()};list.append(more)}

  }catch(e){if(!alive()||request!==serial)return;list.innerHTML=`<div class="card card-pad"><p>${U.esc(['PGRST202','42883','42P01'].includes(e.code)?'Meeting setup is missing. Apply the supplied Supabase SQL, then retry.':U.errorText(e))}</p><button class="btn" id="retry-meetings">Retry</button></div>`;U.q('#retry-meetings',list).onclick=load}

 };

 const create=kind=>{

  if(kind==='join'){U.q('#join-code',box).focus();return}if(!allowed)return;

  const scheduled=kind==='scheduled',r=U.modal({title:scheduled?'Schedule meeting':kind==='room'?'Create room':'Instant meeting',body:`<form id="meeting-create-form"><div class="field"><label for="meeting-title">Meeting title</label><input id="meeting-title" class="input" required maxlength="120" value="${U.attr(group?group.name+' meeting':scheduled?'Scheduled meeting':kind==='room'?'Meeting room':'Instant meeting')}"></div>${scheduled?'<div class="field"><label for="meeting-starts">Date and time (your local time)</label><input type="datetime-local" class="input" id="meeting-starts" required></div><div class="field"><label for="meeting-repeat">Repeat</label><select id="meeting-repeat" class="select"><option value="0">Does not repeat</option><option value="1">Daily</option><option value="7">Weekly</option></select></div>':''}<p class="hint">Share the meeting link to invite participants.</p><button type="submit" class="btn primary">${scheduled?'Schedule meeting':'Create meeting'}</button></form>`});

  U.q('#meeting-create-form',r).onsubmit=async e=>{e.preventDefault();const title=U.q('#meeting-title',r).value.trim(),date=scheduled?new Date(U.q('#meeting-starts',r).value):null;if(!title)return;if(scheduled&&(!Number.isFinite(date.getTime())||date<=new Date())){U.toast('Choose a future date and time.','error');return}U.setBusy(e.submitter,true);try{const id=must(await sb.rpc('create_mobile_meeting',{title_input:title,group_input:group?.id||null,kind_input:kind,starts_input:date?.toISOString()||null,repeat_input:scheduled?Number(U.q('#meeting-repeat',r).value):0})),m=must(await sb.from('meetings').select('*').eq('id',id).single());U.closeModal();await load();showMeetingInvite(m)}catch(err){report(err)}finally{U.setBusy(e.submitter,false)}};

 };

 U.qa('[data-create-kind]',box).forEach(b=>b.onclick=()=>create(b.dataset.createKind));

 U.qa('[data-filter]',box).forEach(b=>b.onclick=()=>{filter=b.dataset.filter;pageCount=1;U.qa('[data-filter]',box).forEach(x=>{x.classList.toggle('primary',x===b);x.setAttribute('aria-pressed',String(x===b))});load()});

 U.q('#meeting-sort',box).onchange=e=>{newest=e.target.value==='newest';pageCount=1;load()};

 U.q('#join-form',box).onsubmit=async e=>{e.preventDefault();U.setBusy(e.submitter,true);try{await joinByInvite(U.q('#join-code',box).value)}finally{U.setBusy(e.submitter,false)}};

 U.q('#clear-history',box).onclick=async()=>{if(!await U.confirmBox('Clear meeting history','Hide all meeting history for your account? Other participants keep their history and attendance.','Clear All'))return;try{must(await sb.rpc('clear_meeting_history',{group_filter:group?.id||null}));pageCount=1;await load()}catch(e){report(e)}};

 await load();if(!alive())return;

 const refresh=U.debounce(()=>{if(alive())load()},300);

 S.channel=sb.channel(`meetings-web-${group?.id||'mine'}-${Date.now()}`).on('postgres_changes',{event:'*',schema:'public',table:'meetings'},refresh).on('postgres_changes',{event:'*',schema:'public',table:'meeting_favorites',filter:`user_id=eq.${S.user.id}`},refresh).on('postgres_changes',{event:'*',schema:'public',table:'meeting_history_hidden',filter:`user_id=eq.${S.user.id}`},refresh).subscribe();

 S.meetingRefresh=()=>{if(alive())refresh()};

}

async function showMeetingInvite(m){

 const link=new URL('/',location.origin);link.searchParams.set('invite',m.invite_code);const future=m.starts_at&&Date.parse(m.starts_at)>Date.now();

 const r=U.modal({title:'Meeting invite',body:`<p>${m.allow_guests===false?'Registered participants can use this link to join.':'Participants can join in their browser using this link. Guest access is available when enabled on the server.'}</p>${m.starts_at?`<p>Starts ${U.fmtDate(m.starts_at)}</p>`:''}<div class="field"><label>Invite link</label><input class="input" readonly value="${U.attr(link.href)}"></div><div class="field"><label>Meeting code</label><input class="input" readonly value="${U.attr(m.invite_code)}"></div>`,actions:`<button class="btn ghost" data-close>Close</button><button class="btn" id="copy-invite">Copy link</button><button class="btn" id="share-invite">Share</button>${!future&&!m.ended_at?'<button class="btn primary" id="start-invite">Join now</button>':''}`});

 U.q('#copy-invite',r).onclick=()=>U.copy(link.href);

 U.q('#share-invite',r).onclick=async()=>{try{if(navigator.share)await navigator.share({title:m.title,text:'Join '+m.title,url:link.href});else await U.copy(link.href)}catch(e){if(e.name!=='AbortError')U.toast(U.errorText(e),'error')}};

 U.q('#start-invite',r)?.addEventListener('click',()=>{U.closeModal();openMeeting(m,{autoJoin:true}).catch(e=>U.toast(U.errorText(e),'error'))});

}



async function showAttendance(m){

  try{const {data,error}=await sb.from('meeting_attendance').select('*').eq('meeting_id',m.id).order('joined_at');if(error)throw error;const names=await namesFor((data||[]).map(x=>x.user_id));const rows=(data||[]).map(x=>({name:names[x.user_id]?.full_name||'User',user_id:x.user_id,device:U.shortId(x.connection_id||x.id),joined:U.fmtDate(x.joined_at),left:x.left_at?U.fmtDate(x.left_at):'Still connected / not closed',duration_seconds:x.duration_seconds??(x.left_at?0:'')}));const html=`<div class="table-wrap"><table><thead><tr><th>Name</th><th>User</th><th>Device/session</th><th>Joined</th><th>Left</th><th>Seconds</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${U.esc(x.name)}</td><td><span class="code">${U.esc(U.shortId(x.user_id))}</span></td><td>${U.esc(x.device)}</td><td>${U.esc(x.joined)}</td><td>${U.esc(x.left)}</td><td>${U.esc(x.duration_seconds)}</td></tr>`).join('')}</tbody></table></div><p class="hint">A single account joining from mobile and laptop appears as two device/session attendance rows.</p>`;const r=U.modal({title:`Attendance — ${m.title}`,body:html,wide:true,actions:'<button class="btn ghost" data-close>Close</button><button class="btn primary" id="csv-att">Download CSV</button>'});U.q('#csv-att',r).onclick=()=>U.download(`attendance-${U.safeName(m.title)}.csv`,U.makeCsv(rows,['name','user_id','device','joined','left','duration_seconds']),'text/csv;charset=utf-8')}catch(e){U.toast(U.errorText(e),'error')}

}



async function renderForum(limit=30){const render= S.forumRender=(S.forumRender||0)+1;

 cleanupChannel();

  const box=U.q('#page');if(!U.q('#forum-list',box))box.innerHTML=pageHead('Community Forum','Share an update with everyone on Edu Chat Pro.','<button class="btn primary" id="new-post">+ New post</button>')+'<div id="forum-list" class="stack"></div>';U.q('#new-post').onclick=()=>editPost(null);

  const ownership=await sb.rpc('my_post_ids');const own=ownership.data||[];

  const {data,error}=await sb.from('forum_posts').select('*').order('created_at',{ascending:false}).order('id',{ascending:false}).limit(limit);if(error)throw error;const names=await namesFor((data||[]).map(x=>x.public_author_id));const list=U.q('#forum-list');if(!list||render!==S.forumRender||S.page!=='forum')return;

  syncMessages(list,data?.length?data.map(p=>{const author=names[p.public_author_id]||{full_name:'User'};return `<article data-message-id="${p.id}" data-stamp="${U.attr(JSON.stringify([p,author,own.includes(p.id)]))}" class="card forum-post"><div class="row">${p.anonymous?'<span class="avatar">?</span>':avatarHtml(author)}<div><strong>${p.anonymous?'Anonymous':U.esc(author.full_name||'User')}</strong><div class="tiny muted">${U.fmtDate(p.created_at)}${p.updated_at!==p.created_at?' • edited':''}</div></div><div class="spacer"></div>${p.anonymous&&isSuper()?`<button class="btn small" data-identify="${p.id}">Identify</button>`:''}</div><div class="bodytext social-body">${U.esc(p.body)}</div>${p.image_path?`<img class="forum-image" data-forum-image="${U.attr(p.image_path)}" alt="Post image" loading="lazy" decoding="async">`:''}<div class="reaction-bar" data-reactions="${p.id}"></div><div class="row wrap" style="margin-top:14px"><button class="btn small" data-open-post="${p.id}">${U.icon('chat')} Comments</button><button class="btn ghost small" data-report="${p.id}">Report</button>${own.includes(p.id)?`<button class="btn ghost small" data-edit-post="${p.id}">${U.icon('edit')} Edit</button>`:''}${own.includes(p.id)||can('forum.moderate')?`<button class="btn danger small" data-del-post="${p.id}">Delete</button>`:''}</div></article>`}).join(''):'<div class="card empty">No forum posts yet.</div>');await hydrateAvatars(list);await hydrateSocial(list);if(data?.length===limit){const more=document.createElement('button');more.className='btn ghost';more.textContent='Load older posts';more.onclick=()=>renderForum(limit+30).catch(e=>U.toast(U.errorText(e),'error'));list.appendChild(more)}

  U.qa('[data-open-post]',list).forEach(b=>b.onclick=()=>openPost(data.find(x=>x.id===b.dataset.openPost)));

  U.qa('[data-edit-post]',list).forEach(b=>b.onclick=()=>editPost(data.find(x=>x.id===b.dataset.editPost)));

  U.qa('[data-del-post]',list).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Delete post','Delete this post and its comments?','Delete'))return;const {error}=await sb.rpc('delete_post',{post:b.dataset.delPost});if(error)U.toast(U.errorText(error),'error');else{const post=data.find(p=>p.id===b.dataset.delPost);if(post?.image_path){const removed=await sb.storage.from('forum-images').remove([post.image_path]);if(removed.error)U.toast('Post deleted. Its image could not be removed from storage.','warn')}renderForum()}});

  U.qa('[data-identify]',list).forEach(b=>b.onclick=async()=>{const {data:id,error}=await sb.rpc('identify_post',{post:b.dataset.identify});if(error)U.toast(U.errorText(error),'error');else{const n=await namesFor([id]);U.modal({title:'Anonymous post identity',body:`<p>Account: <strong>${U.esc(n[id]?.full_name||'User')}</strong></p><p class="code">${U.esc(id)}</p><p class="hint">This lookup is logged in the admin audit history.</p>`})}});

  S.channel=sb.channel('forum-updates').on('postgres_changes',{event:'*',schema:'public',table:'forum_reactions'},payload=>{const id=payload.new?.post_id||payload.old?.post_id;U.qa('[data-reactions]').filter(b=>b.dataset.reactions===id).forEach(hydrateReaction)}).on('postgres_changes',{event:'INSERT',schema:'public',table:'forum_comments'},()=>{const form=U.q('#comment-form');if(form&&!U.q('#comment-text')?.value.trim()&&!U.q('#comment-image')?.files?.length){form.dispatchEvent(new Event('refresh-comments'));return}if(form&&!U.q('#comment-refresh')){const b=document.createElement('button');b.id='comment-refresh';b.type='button';b.className='btn ghost';b.textContent='New comments — refresh';form.before(b);b.onclick=()=>form.dispatchEvent(new Event('refresh-comments'))}}).on('postgres_changes',{event:'*',schema:'public',table:'forum_posts'},()=>{clearTimeout(S.forumTimer);S.forumTimer=setTimeout(()=>{if(S.page==='forum')renderForum(limit).catch(e=>U.toast(U.errorText(e),'error'))},350)}).subscribe();

  S.pageRefresh=()=>renderForum(limit);

  U.qa('[data-report]',list).forEach(b=>b.onclick=async()=>{const v=await U.promptBox({title:'Report post',fields:[{label:'Reason',type:'textarea',max:2000}],submit:'Report'});if(!v)return;const {error}=await sb.from('forum_reports').insert({post_id:b.dataset.report,reporter_id:S.user.id,reason:v[0]});if(error)U.toast(U.errorText(error),'error');else U.toast('Report sent to moderators.','ok')});

}

async function editPost(p){

 const r=U.modal({title:p?'Edit post':'Create post',body:`<textarea id="social-body" class="textarea" maxlength="10000" placeholder="What would you like to share?">${U.esc(p?.body||'')}</textarea><label class="btn ghost">📷 Add photo / video<input type="file" id="social-image" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime" hidden></label><img id="social-preview" class="forum-image hidden" alt="Selected image"><label class="switch"><input type="checkbox" id="social-anonymous" ${p?.anonymous?'checked':''}>Post anonymously</label><button class="btn ghost" id="remove-social-image">Remove image</button>`,actions:'<button class="btn ghost" data-close>Cancel</button><button class="btn primary" id="save-social">Post</button>'});

 let selected=null,remove=false,previewUrl=null;

 if(p?.image_path){const preview=U.q('#social-preview',r);sb.storage.from('forum-images').createSignedUrl(p.image_path,300).then(({data:image})=>{if(image&&preview.isConnected&&!selected&&!remove){if(/\.(mp4|webm|mov)$/i.test(p.image_path)){const v=document.createElement('video');v.id='social-preview';v.className='forum-image';v.controls=true;v.src=image.signedUrl;preview.replaceWith(v)}else{preview.src=image.signedUrl;preview.classList.remove('hidden')}}})}

 U.q('#social-image',r).onchange=e=>{selected=e.target.files?.[0]||null;remove=false;if(previewUrl)URL.revokeObjectURL(previewUrl);if(selected){previewUrl=URL.createObjectURL(selected);let img=U.q('#social-preview',r);const node=document.createElement(selected.type.startsWith('video/')?'video':'img');node.id='social-preview';node.className='forum-image';node.src=previewUrl;if(node.tagName==='VIDEO')node.controls=true;img.replaceWith(node)}};

 U.q('#remove-social-image',r).onclick=()=>{selected=null;remove=true;U.q('#social-image',r).value='';U.q('#social-preview',r).classList.add('hidden')};

 U.q('#save-social',r).onclick=async e=>{const body=U.q('#social-body',r).value.trim();if(!body){U.toast('Write a description first.','error');return}let uploaded=null,saved=false;U.setBusy(e.target,true);try{let path=remove?null:p?.image_path||null;if(selected){uploaded=await uploadForumMedia(selected);path=uploaded}let result=await sb.rpc('save_social_post',{post:p?.id||null,body_text:body,is_anonymous:U.q('#social-anonymous',r).checked,image_path_input:path});if(['PGRST202','42883'].includes(result.error?.code)&&!path&&!p?.image_path)result=await sb.rpc('save_post',{post:p?.id||null,title_text:body.slice(0,160),body_text:body,is_anonymous:U.q('#social-anonymous',r).checked});must(result);saved=true;if(p?.image_path&&p.image_path!==path)await sb.storage.from('forum-images').remove([p.image_path]);if(previewUrl)URL.revokeObjectURL(previewUrl);U.closeModal();await renderForum()}catch(err){if(uploaded&&!saved)await sb.storage.from('forum-images').remove([uploaded]);U.toast(U.errorText(err),'error')}finally{U.setBusy(e.target,false)}};

}

async function openPost(p,limit=50){

 try{

 const rows=must(await sb.from('forum_comments').select('*').eq('post_id',p.id).order('created_at',{ascending:false}).limit(limit))||[],names=await namesFor(rows.map(c=>c.author_id));

 const r=U.modal({title:'Discussion',wide:true,body:`<div class="bodytext">${U.esc(p.body)}</div><div id="comments">${rows.reverse().map(c=>`<article class="comment"><div class="row">${avatarHtml(names[c.author_id])}<strong>${U.esc(names[c.author_id]?.full_name||'User')}</strong><span class="tiny muted">${U.fmtDate(c.created_at)}</span></div><p class="bodytext">${U.esc(c.body)}</p>${c.image_path?`<img class="forum-image" data-forum-image="${U.attr(c.image_path)}" alt="Comment image" loading="lazy">`:''}${c.author_id===S.user.id||can('forum.moderate')?`<button class="btn ghost small" data-cdel="${c.id}">Delete</button>`:''}</article>`).join('')||'<p>No comments yet.</p>'}</div>${rows.length===limit?'<button class="btn ghost" id="more-comments">Load older comments</button>':''}<form id="comment-form" class="stack"><textarea id="comment-text" class="textarea" maxlength="4000" placeholder="Write a comment…"></textarea><label class="btn ghost">Add photo / video<input id="comment-image" type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime" hidden></label><div id="comment-preview"></div><button class="btn primary">Send comment</button></form>`});

 hydrateAvatars(r);hydrateSocial(r);let selected=null,previewUrl;

 U.q('#comment-image',r).onchange=e=>{selected=e.target.files?.[0]||null;if(previewUrl)URL.revokeObjectURL(previewUrl);const box=U.q('#comment-preview',r);box.innerHTML='';if(selected){previewUrl=URL.createObjectURL(selected);const img=document.createElement(selected.type.startsWith('video/')?'video':'img');img.src=previewUrl;img.className='forum-image';if(img.tagName==='VIDEO'){img.controls=true;img.preload='metadata'}box.appendChild(img);const b=document.createElement('button');b.type='button';b.className='btn ghost';b.textContent='Remove photo';b.onclick=()=>{selected=null;box.innerHTML='';U.q('#comment-image',r).value=''};box.appendChild(b)}};

 U.q('#comment-form',r).addEventListener('refresh-comments',()=>{if(selected||U.q('#comment-text',r).value.trim()){U.toast('Send your draft before refreshing comments.','ok');return}openPost(p,limit)});

 U.q('#more-comments',r)?.addEventListener('click',()=>openPost(p,limit+50));

 U.q('#comment-form',r).onsubmit=async e=>{e.preventDefault();const body=U.q('#comment-text',r).value.trim();if(!body&&!selected)return;let path,saved=false;U.setBusy(e.submitter,true);try{if(selected){path=await uploadForumMedia(selected)}must(await sb.from('forum_comments').insert({post_id:p.id,author_id:S.user.id,body,...(path?{image_path:path}:{})}));saved=true;await openPost(p,limit)}catch(err){if(path&&!saved)await sb.storage.from('forum-images').remove([path]);U.toast(U.errorText(err),'error')}finally{U.setBusy(e.submitter,false)}};

 U.qa('[data-cdel]',r).forEach(b=>b.onclick=async()=>{try{const c=rows.find(x=>x.id===b.dataset.cdel);must(await sb.from('forum_comments').delete().eq('id',c.id));if(c.image_path)await sb.storage.from('forum-images').remove([c.image_path]);await openPost(p,limit)}catch(e){U.toast(U.errorText(e),'error')}});

 }catch(e){U.toast(U.errorText(e),'error')}

}



async function setupNotifications(){

 S.stopNotifications?.();

 if('Notification' in window)window.EduPush.resume(sb,S.user.id).catch(()=>{});

 if(S.notificationChannel)sb.removeChannel(S.notificationChannel).catch(()=>{});

 const userId=S.user.id,seen=new Set();let since=new Date().toISOString(),fetching=false;

 const accept=n=>{if(S.user?.id!==userId||seen.has(n.id))return;seen.add(n.id);if(seen.size>500)seen.delete(seen.values().next().value);

  if(n.kind==='call_cancel'){S.cancelledCalls??=new Set();S.cancelledCalls.add(n.resource_id);if(S.cancelledCalls.size>200)S.cancelledCalls.delete(S.cancelledCalls.values().next().value);if(S.incoming?.id===n.resource_id)S.incoming.close();window.EduPush.dismiss(n.resource_id);return}

  if(['direct_call_audio','direct_call_video','group_call'].includes(n.kind)&&Date.now()-Date.parse(n.created_at)>60000)return;

  U.toast(n.title||'New Edu Chat Pro notification','ok');window.EduPush.show(n).catch(()=>{});

  if(['direct_call_audio','direct_call_video','group_call'].includes(n.kind))receiveDirectCall(n);

  window.dispatchEvent(new Event('edu-alerts-updated'));

 };

 const catchUp=async()=>{if(fetching||S.user?.id!==userId||document.hidden)return;fetching=true;const until=new Date().toISOString();try{let offset=0;for(let page=0;page<5;page++){const rows=must(await sb.from('notifications').select('*').eq('user_id',userId).gte('created_at',since).lte('created_at',until).order('created_at').order('id').range(offset,offset+99))||[];if(S.user?.id!==userId)break;rows.forEach(accept);if(rows.length<100){since=until;break}offset+=100}}catch(e){console.warn('Notification sync:',e.message)}finally{fetching=false}};

 S.notificationChannel=sb.channel(`alerts-${userId}`).on('postgres_changes',{event:'INSERT',schema:'public',table:'notifications',filter:`user_id=eq.${userId}`},p=>accept(p.new)).subscribe(status=>{if(status==='SUBSCRIBED')catchUp()});

 const wake=()=>catchUp(),timer=setInterval(wake,45000);document.addEventListener('visibilitychange',wake);window.addEventListener('online',wake);

 S.stopNotifications=()=>{clearInterval(timer);document.removeEventListener('visibilitychange',wake);window.removeEventListener('online',wake);S.incoming?.close();S.cancelledCalls?.clear()};

}

async function enableWebAlerts(){try{const mode=await window.EduPush.enable(sb,S.user.id);U.toast(mode==='push'?'Push notifications enabled.':'Notifications enabled while this website is open.','ok')}catch(e){U.toast(U.errorText(e),'error')}}

async function renderNotifications(){

 const box=U.q('#page');box.innerHTML=pageHead('Notifications','Calls, messages, announcements and community updates.','<button class="btn primary" id="alerts-enable">Enable notifications</button><button class="btn ghost" id="mark-all">Mark all read</button><button class="btn ghost" id="clear-alerts">Clear notifications</button>')+'<p class="hint">Allow browser notifications and keep this website open to receive alerts.</p><div id="alerts" class="list"></div>';

 const list=U.q('#alerts',box);let revision=0;

 const load=async()=>{const rev=++revision;try{const rows=must(await sb.from('notifications').select('*').eq('user_id',S.user.id).neq('kind','call_cancel').order('created_at',{ascending:false}).limit(100))||[];if(!list.isConnected||rev!==revision)return;list.innerHTML=rows.length?rows.map(n=>`<div class="list-item ${n.read_at?'':'unread'}"><div class="avatar">${U.icon(n.kind.includes('call')?'phone':'bell')}</div><div class="body"><h3>${U.esc(n.title)}</h3><p>${U.fmtDate(n.created_at)}</p></div>${n.resource_id?`<button class="btn small" data-open-alert="${n.id}">Open</button>`:''}${!n.read_at?`<button class="btn small" data-read="${n.id}">Read</button>`:''}</div>`).join(''):'<div class="card empty">No notifications.</div>';U.qa('[data-open-alert]',list).forEach(b=>b.onclick=()=>openNotification(rows.find(n=>n.id===b.dataset.openAlert)));U.qa('[data-read]',list).forEach(b=>b.onclick=async()=>{try{must(await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('id',b.dataset.read));await load()}catch(e){U.toast(U.errorText(e),'error')}})}catch(e){if(list.isConnected)U.toast(U.errorText(e),'error')}};

 U.q('#alerts-enable',box).onclick=enableWebAlerts;U.q('#clear-alerts',box).onclick=window.EduWorkspace.run(async()=>{if(!await U.confirmBox('Clear notifications','Remove all your notifications?','Clear'))return;must(await sb.from('notifications').delete().eq('user_id',S.user.id));await load();});

 U.q('#mark-all',box).onclick=async()=>{try{must(await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('user_id',S.user.id).is('read_at',null));await load()}catch(e){U.toast(U.errorText(e),'error')}};

 S.alertsRefresh=load;await load();

}



async function renderProfile(){

  S.profile=must(await sb.rpc('my_profile'))||S.profile;const p=S.profile,box=U.q('#page');

  box.innerHTML=pageHead('Profile','Your photo and information appear in chats, forum posts and meetings.')+`<div class="grid two"><div class="card card-pad profile-card-main"><div class="profile-cover"></div><div class="profile-content"><div class="profile-avatar-wrap"><label class="avatar-button" title="Change profile photo">${avatarHtml(p,'profile-xl')}<span class="avatar-edit">${U.icon('photo')}</span><input id="profile-photo" type="file" accept="image/*" hidden></label></div><h2 class="profile-name">${U.esc(p.full_name)}</h2><div class="profile-email">${U.esc(S.user.email||'')}</div><p class="hint profile-photo-note">Every user can set or change their own profile picture. JPG, PNG or WebP up to 10 MB; it is compressed before upload.</p><div class="field" style="margin-top:20px"><label>Full name</label><input id="prof-name" class="input" maxlength="100" value="${U.attr(p.full_name||'')}"></div><div class="field"><label>Phone (optional)</label><input id="prof-phone" class="input" maxlength="30" value="${U.attr(p.phone||'')}"></div><div class="row wrap"><button class="btn primary" id="save-profile">Save profile</button>${p.avatar_path?'<button class="btn ghost" id="remove-photo">Remove photo</button>':''}</div></div></div><div class="card card-pad"><h3>Account & security</h3><p><b>User ID</b><br><span class="code">${U.esc(S.user.id)}</span></p><p><b>Role</b><br>${U.esc(S.role.replaceAll('_',' '))}</p><button class="btn" id="change-password">Change password</button> <button class="btn ghost" id="enable-notify">Enable browser notifications</button><p class="hint">Passwords are handled by Supabase Auth and are never visible to Edu Chat Pro admins.</p></div></div>`;

  await hydrateAvatars(box);

  U.q('#profile-photo')?.addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;const input=e.target;input.disabled=true;try{U.toast('Preparing profile photo…');const blob=await window.EduCrop(file);if(!blob)return;const path=`${S.user.id}/${U.uuid()}.jpg`;const up=await sb.storage.from('avatars').upload(path,blob,{contentType:'image/jpeg',upsert:false});if(up.error)throw up.error;const old=p.avatar_path||null;const upd=await sb.from('profiles').update({avatar_path:path}).eq('id',S.user.id).select('id,avatar_path').single();if(upd.error){await sb.storage.from('avatars').remove([path]);throw upd.error}if(old)await sb.storage.from('avatars').remove([old]).catch(()=>{});avatarCache.clear();S.profile={...S.profile,avatar_path:path};U.toast('Profile photo updated.','ok');renderShell();await navigate('profile')}catch(err){U.toast(U.errorText(err),'error')}finally{input.disabled=false}});

  U.q('#remove-photo')?.addEventListener('click',async()=>{if(!await U.confirmBox('Remove profile photo','Remove your current profile picture?','Remove'))return;try{const old=S.profile?.avatar_path;const upd=await sb.from('profiles').update({avatar_path:null}).eq('id',S.user.id);if(upd.error)throw upd.error;if(old)await sb.storage.from('avatars').remove([old]);avatarCache.clear();S.profile={...S.profile,avatar_path:null};U.toast('Profile photo removed.','ok');renderShell();await navigate('profile')}catch(e){U.toast(U.errorText(e),'error')}});

  U.q('#save-profile').onclick=async()=>{const full_name=U.q('#prof-name').value.trim(),phone=U.q('#prof-phone').value.trim()||null;if(!full_name){U.toast('Full name is required.','error');return}const {error}=await sb.from('profiles').update({full_name,phone}).eq('id',S.user.id);if(error)U.toast(U.errorText(error),'error');else{S.profile={...S.profile,full_name,phone};U.toast('Profile saved.','ok');renderShell();navigate('profile')}};

  U.q('#change-password').onclick=async()=>{const v=await U.promptBox({title:'Change password',fields:[{label:'New password',type:'password',max:200}],submit:'Update password'});if(!v)return;if(v[0].length<8){U.toast('Use at least 8 characters.','error');return}const {error}=await sb.auth.updateUser({password:v[0]});if(error)U.toast(U.errorText(error),'error');else U.toast('Password changed.','ok')};

  U.q('#enable-notify').onclick=enableWebAlerts;

}



async function renderAdmin(){

  const box=U.q('#page');if(!isAdmin()){box.innerHTML='<div class="card empty">Admin access required.</div>';return}

  if(!isSuper()){

    box.innerHTML=pageHead('Assistant Admin','Your access is controlled by the Super Admin.')+`<div class="card card-pad"><h3>Current permissions</h3><div class="wrap">${PERMS.map(p=>`<span class="badge ${S.permissions.has(p)?'green':''}">${S.permissions.has(p)?'✓':'—'} ${U.esc(p)}</span>`).join('')}</div><p class="hint">Assistant Admin audit history is visible only to the Super Admin.</p></div>`;return;

  }

  const stats=must(await sb.rpc('dashboard_stats'))||{};

  box.innerHTML=pageHead('Super Admin','Users, assistant permissions, storage, moderation and audit history.','<button class="btn primary" id="invite-admin">Invite Assistant Admin</button>')+`<div class="stat-grid">${Object.entries(stats).map(([k,v])=>`<div class="card stat"><div class="muted">${U.esc(k)}</div><div class="value">${k.includes('bytes')?U.fmtBytes(v):U.esc(v)}</div></div>`).join('')}</div><div class="tabs" id="admin-tabs" style="margin-top:20px"><button class="active" data-atab="accounts">Accounts</button><button data-atab="audit">Audit history</button><button data-atab="reports">Forum reports</button><button data-atab="announce">Announcement</button></div><div id="admin-body"></div>`;

  U.q('#invite-admin').onclick=inviteAssistant;U.qa('[data-atab]').forEach(b=>b.onclick=()=>{U.qa('[data-atab]').forEach(x=>x.classList.toggle('active',x===b));adminTab(b.dataset.atab)});await adminTab('accounts');

}

async function adminTab(tab){const box=U.q('#admin-body');box.innerHTML='<div class="loading">Loading…</div>';if(tab==='accounts')return adminAccounts();if(tab==='audit')return adminAudit();if(tab==='reports')return adminReports();if(tab==='announce')return adminAnnouncement()}

async function adminAccounts(){

  const box=U.q('#admin-body');const {data:profiles,error}=await sb.from('profiles').select('id,full_name,status,created_at,last_active_at').order('created_at',{ascending:false}).limit(250);if(error)throw error;const ids=profiles.map(x=>x.id);const {data:roles,error:re}=ids.length?await sb.from('user_roles').select('*').in('user_id',ids):{data:[]};if(re)throw re;const rm=Object.fromEntries((roles||[]).map(x=>[x.user_id,x.role]));

  box.innerHTML=`<div class="card card-pad"><div class="table-wrap"><table><thead><tr><th>User</th><th>Role</th><th>Status</th><th>Last active</th><th>Actions</th></tr></thead><tbody>${profiles.map(p=>`<tr><td><strong>${U.esc(p.full_name)}</strong><br><span class="code">${U.esc(p.id)}</span></td><td>${U.esc((rm[p.id]||'student').replaceAll('_',' '))}</td><td><span class="badge ${p.status==='active'?'green':'red'}">${U.esc(p.status)}</span></td><td>${U.fmtDate(p.last_active_at)}</td><td>${p.id===S.user.id?'<span class="muted">Current Super Admin</span>':`<button class="btn small" data-access="${p.id}">Access</button>${rm[p.id]==='assistant_admin'?` <button class="btn ghost small" data-sessions="${p.id}">Sessions</button> <button class="btn ghost small" data-reset="${p.id}">Reset password</button>`:''}`}</td></tr>`).join('')}</tbody></table></div></div>`;

  U.qa('[data-access]',box).forEach(b=>b.onclick=()=>editAccount(b.dataset.access,profiles.find(x=>x.id===b.dataset.access),rm[b.dataset.access]||'student'));

  U.qa('[data-sessions]',box).forEach(b=>b.onclick=()=>showSessions(b.dataset.sessions,profiles.find(x=>x.id===b.dataset.sessions)));

  U.qa('[data-reset]',box).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Reset Assistant password','Send a password-reset email to this Assistant Admin?','Send reset'))return;const {data,error}=await sb.functions.invoke('admin-users',{body:{action:'reset',target:b.dataset.reset}});if(error||data?.error)U.toast(data?.error||U.errorText(error),'error');else U.toast('Reset email sent.','ok')});

}

async function editAccount(id,p,currentRole){

  let current=[];if(currentRole==='assistant_admin'){const r=await sb.from('assistant_admin_permissions').select('permission').eq('user_id',id);current=(r.data||[]).map(x=>x.permission)}

  const roleHtml=[['student','Student'],['assistant_admin','Assistant Admin']].map(x=>`<option value="${x[0]}" ${currentRole===x[0]?'selected':''}>${x[1]}</option>`).join('');const r=U.modal({title:`Access — ${p.full_name}`,body:`<div class="field"><label>Role</label><select id="acc-role" class="select">${roleHtml}</select></div><label class="switch"><input id="acc-enabled" type="checkbox" ${p.status==='active'?'checked':''}><span>Account enabled</span></label><h4>Assistant permissions</h4><div class="stack">${PERMS.map(x=>`<label class="switch"><input type="checkbox" data-perm="${U.attr(x)}" ${current.includes(x)?'checked':''}><span>${U.esc(x)}</span></label>`).join('')}</div><p class="hint">Super Admin role cannot be assigned from this screen.</p>`,actions:'<button class="btn ghost" data-close>Cancel</button><button class="btn primary" id="save-access">Save access</button>'});

  U.q('#save-access',r).onclick=async()=>{const new_role=U.q('#acc-role',r).value,enabled=U.q('#acc-enabled',r).checked,permissions=U.qa('[data-perm]:checked',r).map(x=>x.dataset.perm);const {error}=await sb.rpc('admin_account',{target:id,new_role,enabled,permissions});if(error)U.toast(U.errorText(error),'error');else{U.closeModal();U.toast('Account access updated.','ok');adminAccounts()}};

}

async function showSessions(id,p){const {data,error}=await sb.rpc('admin_sessions',{target:id});if(error){U.toast(U.errorText(error),'error');return}const r=U.modal({title:`Sessions — ${p.full_name}`,body:`<div class="list">${data?.length?data.map(s=>`<div class="list-item"><div class="body"><b>${U.esc(U.shortId(s.session_id))}</b><p>${U.fmtDate(s.created_at)}</p></div><button class="btn danger small" data-kick="${s.session_id}">Force logout</button></div>`).join(''):'<div class="empty">No active sessions.</div>'}</div>`,actions:'<button class="btn ghost" data-close>Close</button><button class="btn danger" id="kick-all">Force logout all devices</button>'});const kick=async sid=>{const {data:d,error:e}=await sb.functions.invoke('admin-users',{body:{action:'revoke',target:id,session_id:sid||null}});if(e||d?.error)U.toast(d?.error||U.errorText(e),'error');else{U.toast('Access revoked.','ok');U.closeModal()}};U.qa('[data-kick]',r).forEach(b=>b.onclick=()=>kick(b.dataset.kick));U.q('#kick-all',r).onclick=()=>kick(null)}

async function inviteAssistant(){const v=await U.promptBox({title:'Invite Assistant Admin',fields:[{label:'Full name',max:100},{label:'Email',type:'email'}],submit:'Send invitation',note:'The Assistant Admin will receive an email and can set a password through Supabase Auth.'});if(!v)return;const {data,error}=await sb.functions.invoke('admin-users',{body:{action:'invite',name:v[0],email:v[1]}});if(error||data?.error)U.toast(data?.error||U.errorText(error),'error');else{U.toast('Assistant Admin invitation sent.','ok');adminAccounts()}}

async function adminAudit(){const box=U.q('#admin-body');const {data,error}=await sb.from('admin_audit_logs').select('*').order('created_at',{ascending:false}).limit(250);if(error)throw error;box.innerHTML=`<div class="card card-pad"><div class="table-wrap"><table><thead><tr><th>Time</th><th>Admin</th><th>Action</th><th>Resource</th><th>Metadata</th></tr></thead><tbody>${data?.length?data.map(x=>`<tr><td>${U.fmtDate(x.created_at)}</td><td>${U.esc(x.actor_name)}</td><td>${U.esc(x.action)}</td><td>${U.esc(x.resource)}</td><td><span class="code">${U.esc(JSON.stringify(x.metadata||{}))}</span></td></tr>`).join(''):'<tr><td colspan="5">No audit events.</td></tr>'}</tbody></table></div></div>`}

async function adminReports(){const box=U.q('#admin-body');const {data,error}=await sb.from('forum_reports').select('*').order('created_at',{ascending:false}).limit(200);if(error)throw error;const names=await namesFor((data||[]).map(x=>x.reporter_id));box.innerHTML=`<div class="card card-pad"><div class="list">${data?.length?data.map(x=>`<div class="list-item"><div class="body"><h3>${U.esc(x.reason)}</h3><p>Reporter ${U.esc(names[x.reporter_id]?.full_name||'User')} • ${U.fmtDate(x.created_at)} • post ${U.shortId(x.post_id)}</p></div><label class="switch"><input type="checkbox" data-resolve="${x.id}" ${x.resolved?'checked':''}><span>Resolved</span></label></div>`).join(''):'<div class="empty">No reports.</div>'}</div></div>`;U.qa('[data-resolve]',box).forEach(c=>c.onchange=async()=>{const {error}=await sb.from('forum_reports').update({resolved:c.checked}).eq('id',c.dataset.resolve);if(error){c.checked=!c.checked;U.toast(U.errorText(error),'error')}})}

async function adminAnnouncement(){const box=U.q('#admin-body');box.innerHTML=`<div class="card card-pad" style="max-width:720px"><h3>Send app-wide announcement</h3><p class="muted">Creates a notification for every active Edu Chat Pro account.</p><textarea id="admin-msg" class="textarea" maxlength="500" placeholder="Announcement"></textarea><button class="btn primary" id="send-ann" style="margin-top:10px">Send announcement</button></div>`;U.q('#send-ann').onclick=async()=>{const message=U.q('#admin-msg').value.trim();if(!message)return;const {error}=await sb.rpc('admin_announcement',{message});if(error)U.toast(U.errorText(error),'error');else{U.q('#admin-msg').value='';U.toast('Announcement sent.','ok')}}}



// Offline shell caching only. Authentication/data still require network.

if('serviceWorker' in navigator && location.protocol==='https:') navigator.serviceWorker.register('sw.js',{updateViaCache:'none'}).catch(()=>{});

async function selectGroupMembers(g,after){

 const r=U.modal({title:'Add group members',body:'<input class="input" id="member-search" placeholder="Search registered users by name" autocomplete="off"><p id="selected-count" class="hint">0 selected</p><div id="member-results" class="list"></div>',actions:'<button class="btn ghost" data-close>Cancel</button><button class="btn primary" id="confirm-members">Add selected</button>'});

 const selected=new Set();let generation=0,timer;

 async function search(){if(!U.q('#member-search',r))return;const gen=++generation;try{const rows=must(await sb.rpc('search_group_candidates',{group_id_input:g.id,name_query:U.q('#member-search',r).value.trim()}));if(gen!==generation||!r.isConnected)return;const list=U.q('#member-results',r);list.innerHTML=rows.length?rows.map(p=>`<label class="list-item"><input type="checkbox" data-person="${p.id}" ${selected.has(p.id)?'checked':''}>${avatarHtml(p)}<span>${U.esc(p.full_name)}</span></label>`).join(''):'<p class="empty">No matching users.</p>';hydrateAvatars(list);U.qa('[data-person]',list).forEach(c=>c.onchange=()=>{c.checked?selected.add(c.dataset.person):selected.delete(c.dataset.person);U.q('#selected-count',r).textContent=`${selected.size} selected`})}catch(e){U.toast(U.errorText(e),'error')}}

 U.q('#member-search',r).oninput=()=>{generation++;clearTimeout(timer);timer=setTimeout(search,250)};

 U.q('#confirm-members',r).onclick=async e=>{if(!selected.size)return;U.setBusy(e.target,true);try{must(await sb.rpc('add_group_members',{group_id_input:g.id,user_ids:[...selected]}));U.closeModal();await after()}catch(err){U.toast(U.errorText(err),'error')}finally{U.setBusy(e.target,false)}};await search();

}

async function sendGroupAttachment(g,file,duration=0,caption=""){

 if(!g.allow_member_messaging&&!can('groups.manage')&&g.created_by!==S.user.id)throw new Error('Messaging is closed in this group.');

 if(!file.size||file.size>10485760)throw new Error('Choose a file under 10 MB.');

 const types={pdf:'application/pdf',doc:'application/msword',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',ppt:'application/vnd.ms-powerpoint',pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',xls:'application/vnd.ms-excel',xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',zip:'application/zip',txt:'text/plain',csv:'text/csv'};

 const mime=types[file.name.split('.').pop().toLowerCase()]||attachmentMime(file);

 const path=`${g.id}/${U.uuid()}/${U.safeName(file.name)}`;must(await sb.storage.from('group-files').upload(path,file,{contentType:mime}));let meta;

 try{meta=must(await sb.from('group_files').insert({group_id:g.id,uploaded_by:S.user.id,name:U.safeName(file.name),object_path:path,size_bytes:file.size,mime_type:mime}).select().single());must(await sb.from('group_messages').insert({group_id:g.id,sender_id:S.user.id,body:caption||(mime.startsWith('audio/')?'Voice message':'Shared a file'),file_id:meta.id,duration_ms:duration}));}catch(e){await sb.storage.from('group-files').remove([path]);if(meta)await sb.from('group_files').delete().eq('id',meta.id);throw e}

}

const reactionEmoji={like:'👍',love:'❤️',care:'🥰',haha:'😂',wow:'😮',sad:'😢',angry:'😡'};

async function hydrateSocial(root){

 U.qa('[data-forum-image]',root).forEach(img=>{const wrap=document.createElement('div');wrap.innerHTML=mediaMarkup('forum-images',img.dataset.forumImage,'','Shared media');img.replaceWith(wrap)});await hydrateMedia(root);

 await Promise.all(U.qa('[data-reactions]',root).map(hydrateReaction));

}

async function hydrateReaction(bar){

 try{let result=await sb.rpc('forum_reaction_summary',{post_input:bar.dataset.reactions}),summary;

 if(['PGRST202','42883'].includes(result.error?.code)){summary={counts:{},mine:null};for(let offset=0;;offset+=500){const rows=must(await sb.from('forum_reactions').select('user_id,reaction').eq('post_id',bar.dataset.reactions).order('user_id').range(offset,offset+499))||[];for(const row of rows){summary.counts[row.reaction]=(summary.counts[row.reaction]||0)+1;if(row.user_id===S.user.id)summary.mine=row.reaction}if(rows.length<500)break}}else summary=must(result);

 summary=summary||{counts:{},mine:null};bar.innerHTML=Object.entries(reactionEmoji).map(([key,emoji])=>`<button class="reaction ${summary.mine===key?'active':''}" data-reaction="${key}" title="${key}" aria-pressed="${summary.mine===key}">${emoji} <span>${summary.counts?.[key]||0}</span></button>`).join('');

 U.qa('[data-reaction]',bar).forEach(b=>b.onclick=async()=>{U.qa('button',bar).forEach(x=>x.disabled=true);try{if(summary.mine===b.dataset.reaction)must(await sb.from('forum_reactions').delete().eq('post_id',bar.dataset.reactions).eq('user_id',S.user.id));else must(await sb.from('forum_reactions').upsert({post_id:bar.dataset.reactions,user_id:S.user.id,reaction:b.dataset.reaction}));await hydrateReaction(bar)}catch(e){U.toast(U.errorText(e),'error');U.qa('button',bar).forEach(x=>x.disabled=false)}});

 }catch(e){bar.textContent='Reactions unavailable: '+U.errorText(e)}

}



async function renderPeople(){

 S.page='people';U.qa('[data-nav]',app()).forEach(x=>x.classList.toggle('active',x.dataset.nav==='people'));chatLayout();

 cleanupChannel();S.group=null;S.direct=null;

 const box=U.q('#page');box.innerHTML=pageHead('Chats','Find a registered Edu Chat Pro user and start a conversation.','<button class="btn ghost" id="return-groups">Groups</button>')+'<div class="card card-pad"><input class="input" id="people-query" placeholder="Search by name" autocomplete="off"><div class="list" id="people-results"></div><button class="btn ghost" id="people-more">Load more</button></div>';

 U.q('#return-groups').onclick=()=>navigate('groups');let offset=0,generation=0,timer;

 async function load(append=false){const input=U.q('#people-query');if(!input)return;const gen=++generation;try{const q=input.value.trim();let query=sb.from('profiles').select('id,full_name,avatar_path').eq('status','active').neq('id',S.user.id).order('full_name').order('id').range(offset,offset+29);if(q)query=query.ilike('full_name',`%${q.replace(/[%_]/g,'')}%`);const rows=must(await query);if(gen!==generation||!U.q('#people-query'))return;const list=U.q('#people-results');if(!append)list.innerHTML='';list.insertAdjacentHTML('beforeend',rows.map(p=>`<div class="list-item">${avatarHtml(p)}<div class="body"><h3>${U.esc(p.full_name)}</h3></div><button class="btn primary small" data-dm-user="${p.id}">${U.icon('chat')} Message</button></div>`).join(''));if(!offset&&!rows.length)list.innerHTML='<p class="empty">No matching users.</p>';U.q('#people-more').hidden=rows.length<30;U.qa('[data-dm-user]',list).forEach(b=>b.onclick=()=>openDirectChat(b.dataset.dmUser));await hydrateAvatars(list)}catch(e){U.toast(U.errorText(e),'error')}}

 U.q('#people-query').oninput=()=>{generation++;clearTimeout(timer);offset=0;timer=setTimeout(()=>load(),250)};U.q('#people-more').onclick=()=>{offset+=30;load(true)};await load();

}

async function renderDirectConversation(id){

 try{

 cleanupChannel();S.page='people';U.qa('[data-nav]',app()).forEach(x=>x.classList.toggle('active',x.dataset.nav==='people'));S.group=null;S.direct=id;

 let person=must(await sb.from('profiles').select('id,full_name,avatar_path').eq('id',id).single());

 chatLayout('direct');const box=U.q('#page');box.innerHTML=`<div class="direct-heading row"><button class="btn ghost" id="dm-back">←</button>${avatarHtml(person)}<div class="body"><h2>${U.esc(person.full_name)}</h2><span class="muted">Private conversation</span></div><div class="spacer"></div><button class="btn ghost" id="dm-audio" title="Audio call">${U.icon('phone')}</button><button class="btn ghost" id="dm-video" title="Video call">${U.icon('camera')}</button></div><div class="card card-pad chat-panel"><button type="button" class="btn ghost small" id="dm-older">Load older messages</button><div class="chat-log" id="dm-log"></div><form class="composer" id="dm-form"><div class="row"><button type="button" class="btn attach-button" id="dm-attach" aria-label="Attach file">+</button><input type="file" hidden id="dm-file"><input class="input" id="dm-text" maxlength="4000" placeholder="Write a message…" required><button class="btn primary">${U.icon('send')} Send</button></div></form></div>`;

 U.q('#dm-back').onclick=()=>navigate('chats');hydrateAvatars(box);

 let dmLimit=30,dmLoadGeneration=0,dmSignature='';const load=async()=>{const generation=++dmLoadGeneration;const rows=must(await sb.from('direct_messages').select('*').or(`and(sender_id.eq.${S.user.id},recipient_id.eq.${id}),and(sender_id.eq.${id},recipient_id.eq.${S.user.id})`).order('created_at',{ascending:false}).limit(dmLimit));if(generation!==dmLoadGeneration||S.direct!==id||!U.q('#dm-log'))return;const updatedPerson=await namesFor([id]);person=updatedPerson[id]||person;const log=U.q('#dm-log');if(!log||S.direct!==id)return;const signature=JSON.stringify([rows,person]);if(signature===dmSignature){hydrateChatReactions(log,'direct');return}dmSignature=signature;const nearBottom=log.scrollHeight-log.scrollTop-log.clientHeight<100;syncMessages(log,rows.length?[...rows].reverse().map(m=>`<div data-message-id="${m.id}" data-created="${m.created_at}" data-stamp="${U.attr(JSON.stringify([m,person]))}" class="message-row ${m.sender_id===S.user.id?'mine':''}">${avatarHtml(m.sender_id===S.user.id?S.profile:person)}<div class="message ${m.sender_id===S.user.id?'mine':''}"><div class="meta">${messageMeta(person.full_name,m.created_at,m.sender_id===S.user.id)}</div><div class="bodytext">${U.esc(m.body)}</div>${m.attachment_path?mediaMarkup('direct-files',m.attachment_path,m.mime_type,m.file_name):''}${m.sender_id===S.user.id?`<button class="text-btn danger-text" data-dm-delete="${m.id}">Delete</button>`:''}</div></div>`).join(''):'<div class="empty chat-empty"><div class="chat-art">•••</div><h2>No messages yet</h2><p>Say hello and start a conversation.</p></div>');const older=U.q('#dm-older');if(older)older.hidden=rows.length<dmLimit;await hydrateAvatars(log);await hydrateMedia(log);linkGroupInvites(log);addDayMarkers(log);hydrateChatReactions(log,S.group?'group':'direct');if(nearBottom)log.scrollTop=log.scrollHeight;U.qa('[data-dm-delete]',log).forEach(b=>b.onclick=async()=>{if(!await U.confirmBox('Delete message','Delete your message?','Delete'))return;try{must(await sb.from('direct_messages').delete().eq('id',b.dataset.dmDelete).eq('sender_id',S.user.id));await load()}catch(e){U.toast(U.errorText(e),'error')}})};

 U.q('#dm-older').onclick=()=>{dmLimit+=30;load().catch(e=>U.toast(U.errorText(e),'error'))};

 U.q('#dm-attach').onclick=()=>U.q('#dm-file').click();U.q('#dm-file').onchange=async e=>{const file=e.target.files?.[0];if(!file)return;const b=U.q('#dm-attach');b.disabled=true;try{await sendDirectAttachment(id,file);await load()}catch(err){U.toast(U.errorText(err),'error')}finally{b.disabled=false;e.target.value=''}};installVoice(U.q('#dm-form'),async(file,duration)=>{await sendDirectAttachment(id,file,duration);await load()});S.pageRefresh=load;

 U.q('#dm-form').onsubmit=async e=>{e.preventDefault();const input=U.q('#dm-text'),body=input.value.trim(),button=e.submitter;if(!body)return;U.setBusy(button,true);try{must(await sb.rpc('send_direct_message',{other:id,message:body}));input.value='';await load();const log=U.q('#dm-log');if(log)log.scrollTop=log.scrollHeight}catch(e){U.toast(U.errorText(e),'error')}finally{U.setBusy(button,false)}};

 for(const [selector,video]of [['#dm-audio',false],['#dm-video',true]])U.q(selector).onclick=async e=>{const button=e.currentTarget;U.setBusy(button,true);try{const meeting=must(await sb.rpc('start_direct_call',{target:id,video}));await openMeeting(must(await sb.from('meetings').select('*').eq('id',meeting).single()),{autoJoin:true})}catch(e){U.toast(U.errorText(e),'error')}finally{U.setBusy(button,false)}};

 await load();const log=U.q('#dm-log');if(log)log.scrollTop=log.scrollHeight;

 S.channel=sb.channel(`dm-${S.user.id}-${id}`).on('postgres_changes',{event:'*',schema:'public',table:'direct_messages',filter:`recipient_id=eq.${S.user.id}`},()=>load().catch(()=>{})).on('postgres_changes',{event:'*',schema:'public',table:'direct_messages',filter:`sender_id=eq.${S.user.id}`},()=>load().catch(()=>{})).on('postgres_changes',{event:'*',schema:'public',table:'message_reactions'},()=>{const log=U.q('#dm-log');if(log)hydrateChatReactions(log,'direct')}).subscribe();

 }catch(e){U.toast(U.errorText(e),'error')}

}

async function receiveDirectCall(n){

 if(S.incoming||S.incomingLoading||document.querySelector('.meeting-shell'))return;

 const age=Date.now()-Date.parse(n.created_at);if(Number.isFinite(age)&&age>60000)return;

 S.incomingLoading=true;

 try{const meeting=must(await sb.from('meetings').select('*').eq('id',n.resource_id).single());if(meeting.ended_at||S.cancelledCalls?.has(n.id)||!S.user)return;

 const dialog=document.createElement('dialog'),group=n.kind==='group_call';dialog.className='incoming-call';dialog.innerHTML=`<div class="call-ring">${U.icon('phone')}</div><h2>${group?'Incoming group meeting':n.kind==='direct_call_video'?'Incoming video call':'Incoming audio call'}</h2><p>${U.esc(n.title)}</p><div class="row center"><button class="btn danger" data-decline>${group?'Dismiss':'Decline'}</button><button class="btn primary" data-answer>${group?'Join':'Answer'}</button></div>`;document.body.appendChild(dialog);dialog.showModal();let timeout;

 const close=()=>{clearTimeout(timeout);if(dialog.open)dialog.close();dialog.remove();if(S.incoming?.id===n.id)S.incoming=null;window.EduPush.dismiss(n.id)};

 S.incoming={id:n.id,close};dialog.oncancel=e=>{e.preventDefault();dialog.querySelector('[data-decline]').click()};timeout=setTimeout(close,Math.max(1000,60000-(Number.isFinite(age)?age:0)));

 dialog.querySelector('[data-decline]').onclick=async()=>{close();if(group)return;try{must(await sb.rpc('decline_direct_call',{meeting:meeting.id}))}catch(e){U.toast(U.errorText(e),'error')}};

 dialog.querySelector('[data-answer]').onclick=async()=>{close();try{const current=must(await sb.from('meetings').select('*').eq('id',meeting.id).single());await openMeeting(current,{autoJoin:true});must(await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('id',n.id))}catch(e){U.toast(U.errorText(e),'error')}};

 }catch(e){U.toast(U.errorText(e),'error')}finally{S.incomingLoading=false}

}



async function openNotification(n){

 try{

 if(n.target_kind==='group'){await openGroup(n.target_id);}
 else if(n.target_kind==='direct'){window.EduWorkspace.pending={kind:'direct',id:n.target_id};await navigate('people');}
 else if(n.target_kind==='forum'){window.EduWorkspace.pendingPost=n.target_id;await navigate('forum');}
 else if(['direct_call_audio','direct_call_video','group_call','missed_call'].includes(n.kind)){const m=must(await sb.from('meetings').select('*').eq('id',n.resource_id).maybeSingle());if(m&&!m.ended_at)await openMeeting(m);else U.toast('This call has ended.');}

 else if(n.kind==='meetings'){const m=must(await sb.from('meetings').select('*').eq('id',n.resource_id).maybeSingle());if(m)await openMeeting(m,{autoJoin:false});else await openGroup(n.resource_id,'meetings');}

 else if(n.kind==='direct_message'){const m=must(await sb.from('direct_messages').select('sender_id,recipient_id').eq('id',n.resource_id).single());await openDirectChat(m.sender_id===S.user.id?m.recipient_id:m.sender_id);}

 else if(n.kind==='group_invite'||n.kind==='group_files'||n.kind==='group_messages'||n.kind==='group_message'||n.kind==='announcement'){await openGroup(n.resource_id,n.kind==='group_files'?'files':'chat');}

 else if(['forum','forum_post','forum_reaction'].includes(n.kind)){await openPost(must(await sb.from('forum_posts').select('*').eq('id',n.resource_id).single()));}

 else await navigate('notifications');

 must(await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('id',n.id));

 }catch(e){U.toast(U.errorText(e),'error')}

}



document.addEventListener('visibilitychange',()=>{if(!document.hidden){railRefresh?.();S.meetingRefresh?.();Promise.resolve(S.pageRefresh?.()).catch(()=>{})}});

window.addEventListener('online',()=>{railRefresh?.();S.meetingRefresh?.();Promise.resolve(S.pageRefresh?.()).catch(()=>{})});

window.addEventListener('edu-alerts-updated',()=>S.alertsRefresh?.());

navigator.serviceWorker?.addEventListener('message',async e=>{if(e.data?.type!=='edu-open-notification'||!S.user)return;try{const n=must(await sb.from('notifications').select('*').eq('id',e.data.id).eq('user_id',S.user.id).maybeSingle());if(n){if(document.querySelector('.meeting-shell')){U.toast(n.title||'Notification');return}await openNotification(n)}}catch(err){U.toast(U.errorText(err),'error')}});

// Shared web/mobile attachment schema. Signed URLs are cached only in memory.

const mediaUrls=new Map();

async function mediaUrl(bucket,path,download=false){

 const key=bucket+'/'+path,hit=mediaUrls.get(key);

 if(!download&&hit&&hit.until>Date.now())return hit.url;

 const data=must(await sb.storage.from(bucket).createSignedUrl(path,3600,download?{download:U.safeName(path.split('/').pop())}:{}));

 if(!download){if(mediaUrls.size>300)mediaUrls.delete(mediaUrls.keys().next().value);mediaUrls.set(key,{url:data.signedUrl,until:Date.now()+3300000})}return data.signedUrl;

}

function mediaMarkup(bucket,path,mime='',name='Attachment'){

 return `<div class="media-attachment" data-media-bucket="${U.attr(bucket)}" data-media-path="${U.attr(path)}" data-media-mime="${U.attr(mime)}"><div class="media-content"></div><div class="row wrap"><span>${U.esc(name)}</span><button type="button" class="btn ghost small" data-media-open>Open</button><button type="button" class="btn ghost small" data-media-download>Download</button></div></div>`;

}

async function hydrateMedia(root){

 await Promise.all(U.qa('[data-media-path]',root).map(async el=>{

 if(el.dataset.ready)return;el.dataset.ready='1';

 const bucket=el.dataset.mediaBucket,path=el.dataset.mediaPath,mime=el.dataset.mediaMime;

 const kind=mime.startsWith('image/')||/\.(jpg|jpeg|png|webp)$/i.test(path)?'img':mime.startsWith('video/')||/\.(mp4|mov|webm)$/i.test(path)&&!mime.startsWith('audio/')?'video':mime.startsWith('audio/')?'audio':null;

 try{

 const url=kind==='img'?await window.EduPhotos.get(sb,S.user.id,bucket,path):await mediaUrl(bucket,path);if(!el.isConnected)return;

 const open=()=>{if(!kind){window.open(url,'_blank','noopener');return}const d=document.createElement('dialog');d.className='media-viewer';const close=document.createElement('button');close.textContent='Close';close.className='btn';const content=document.createElement(kind);content.src=url;if(kind!=='img'){content.controls=true;content.autoplay=true;content.playsInline=true}else content.alt='Shared image';d.append(close,content);document.body.append(d);const done=()=>{if(kind!=='img')content.pause();d.remove()};close.onclick=()=>d.close();d.onclose=done;d.showModal()};

 el.querySelector('[data-media-open]').onclick=open;

 el.querySelector('[data-media-download]').onclick=async()=>{try{const link=document.createElement('a');link.href=await mediaUrl(bucket,path,true);link.download=U.safeName(path.split('/').pop());link.target='_blank';link.rel='noopener';link.click()}catch(e){U.toast(U.errorText(e),'error')}};

 if(kind){const node=document.createElement(kind);node.src=url;if(kind==='img'){node.alt='Shared image';node.loading='lazy';node.decoding='async';node.onclick=open;node.tabIndex=0;node.onkeydown=e=>{if(e.key==='Enter')open()}}else{node.controls=true;node.preload='metadata';node.playsInline=true}el.querySelector('.media-content').append(node)}

 }catch(e){el.dataset.ready='';el.querySelector('.media-content').textContent='Preview unavailable. Reopen this conversation to retry.'}

 }));

}

function attachmentMime(file){const ext=file.name.split('.').pop().toLowerCase();return ({mp4:'video/mp4',mov:'video/quicktime',webm:file.type.startsWith('audio/')?'audio/webm':'video/webm',m4a:'audio/mp4',mp3:'audio/mpeg',ogg:'audio/ogg',wav:'audio/wav',aac:'audio/aac'})[ext]||file.type||'application/octet-stream'}

async function sendDirectAttachment(other,file,duration=0,caption=""){

 if(!file.size||file.size>10485760)throw new Error('Choose a file under 10 MB.');const mime=attachmentMime(file),path=`${S.user.id}/${other}/${U.uuid()}/${U.safeName(file.name)}`;

 must(await sb.storage.from('direct-files').upload(path,file,{contentType:mime}));try{must(await sb.rpc('send_direct_attachment',{other,path_input:path,name_input:U.safeName(file.name),mime_input:mime,size_input:file.size,duration_input:duration}))}catch(e){await sb.storage.from('direct-files').remove([path]);throw e}if(caption){const result=await sb.rpc('send_direct_message',{other,message:caption});if(result.error)U.toast('Attachment sent, but caption failed: '+U.errorText(result.error),'error');}

}

function installVoice(form,send){

 if(!window.MediaRecorder||!navigator.mediaDevices?.getUserMedia)return;

 const button=document.createElement('button');button.type='button';button.className='btn ghost voice-button';button.title='Record voice message';button.textContent='🎙';form.querySelector('.row').append(button);

 button.onclick=async()=>{let stream,recorder,timer,cancelled=false;button.disabled=true;

 try{stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}});const mime=['audio/mp4','audio/webm;codecs=opus','audio/ogg;codecs=opus'].find(t=>MediaRecorder.isTypeSupported(t));if(!mime)throw new Error('Voice recording is not supported by this browser.');recorder=new MediaRecorder(stream,{mimeType:mime});const chunks=[],start=Date.now();

 const d=document.createElement('dialog');d.className='voice-dialog';d.innerHTML='<h2>Recording voice message</h2><p>Maximum 2 minutes</p><button class="btn ghost" data-cancel>Cancel</button> <button class="btn primary" data-send>Stop & send</button>';document.body.append(d);d.showModal();

 const stop=()=>{clearTimeout(timer);if(recorder.state!=='inactive')recorder.stop();stream.getTracks().forEach(t=>t.stop());d.remove()};

 d.querySelector('[data-cancel]').onclick=()=>{cancelled=true;stop()};d.oncancel=e=>{e.preventDefault();cancelled=true;stop()};d.querySelector('[data-send]').onclick=stop;

 recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};

 recorder.onstop=async()=>{try{if(!cancelled&&form.isConnected){const type=mime.split(';')[0],ext=type==='audio/mp4'?'m4a':type==='audio/ogg'?'ogg':'webm';await send(new File(chunks,'voice.'+ext,{type}),Math.min(120000,Date.now()-start))}}catch(e){U.toast(U.errorText(e),'error')}finally{button.disabled=false}};

 recorder.start();timer=setTimeout(stop,120000);

 }catch(e){stream?.getTracks().forEach(t=>t.stop());button.disabled=false;U.toast(U.errorText(e),'error')}

 };

}

async function uploadForumMedia(file){

 if(!file.size||file.size>10485760)throw new Error('Choose a photo or video under 10 MB.');const video=file.type.startsWith('video/'),mime=video?attachmentMime(file):'image/jpeg';if(video&&!['video/mp4','video/webm','video/quicktime'].includes(mime))throw new Error('Choose MP4, WebM or MOV video.');

 const path=`${U.uuid()}/${U.uuid()}.${video?(mime==='video/mp4'?'mp4':mime==='video/webm'?'webm':'mov'):'jpg'}`;must(await sb.storage.from('forum-images').upload(path,video?file:await compressAvatar(file),{contentType:mime}));return path;

}

function offerWebPermissions(){

 if(localStorage.getItem('ecp-web-permissions-v1'))return;

 const banner=document.createElement('section');banner.className='permission-banner card';banner.innerHTML='<strong>Enable calls & notifications</strong><p>Allow camera, microphone and browser notifications. You can change these in site settings.</p><button class="btn primary" data-enable>Enable</button> <button class="btn ghost" data-later>Later</button>';

 document.body.append(banner);banner.querySelector('[data-later]').onclick=()=>{localStorage.setItem('ecp-web-permissions-v1','later');banner.remove()};

 banner.querySelector('[data-enable]').onclick=async e=>{e.target.disabled=true;try{await enableWebAlerts();try{const stream=await navigator.mediaDevices.getUserMedia({audio:true,video:true});stream.getTracks().forEach(t=>t.stop())}catch{U.toast('Camera or microphone was not enabled. You can allow it when joining a call.')}localStorage.setItem('ecp-web-permissions-v1','done')}finally{banner.remove()}};

}

async function oldRenderChatThreads(){

 chatLayout();cleanupChannel();S.group=null;S.direct=null;S.page='groups';

 const box=U.q('#page');box.innerHTML=pageHead('Chats','Your groups and personal conversations.','<button class="btn ghost" id="new-private">New message</button>'+(can('groups.manage')?'<button class="btn primary" id="create-thread-group">+ New group</button>':''))+'<input class="input" id="thread-search" placeholder="Search loaded conversations…"><div id="thread-list" class="list thread-list"></div><button class="btn ghost" id="thread-more">Load more</button>';

 U.q('#new-private').onclick=renderPeople;U.q('#create-thread-group')?.addEventListener('click',async()=>{const v=await U.promptBox({title:'Create group',fields:[{label:'Group name',max:120},{label:'Description',type:'textarea',required:false,max:2000}],submit:'Create'});if(!v)return;try{const g=must(await sb.from('groups').insert({name:v[0],description:v[1],created_by:S.user.id}).select().single());await openGroup(g.id)}catch(e){U.toast(U.errorText(e),'error')}});

 let rows=[],loading=false,offset=0,limit=30,timer;

 const paint=()=>{if(!box.isConnected||!U.q('#thread-list'))return;const query=U.q('#thread-search').value.toLowerCase(),list=U.q('#thread-list');list.innerHTML=rows.filter(t=>(t.name+' '+t.preview).toLowerCase().includes(query)).map(t=>`<article class="list-item thread-row"><button class="thread-open" data-kind="${t.thread_kind}" data-thread="${t.thread_id}">${t.thread_kind==='group'?`<span class="avatar">${groupImage({image_path:t.avatar_path})}</span>`:avatarHtml({full_name:t.name,avatar_path:t.avatar_path})}<span class="thread-copy"><strong>${U.esc(t.name)}</strong><span class="muted">${U.esc(t.preview||'Start a conversation')}</span><small>${t.thread_kind==='group'?'Group':'Private'} · ${U.fmtDate(t.updated_at)}</small></span></button><button class="btn ghost small" data-pin="${t.thread_id}" data-kind="${t.thread_kind}" aria-pressed="${t.pinned}" title="${t.pinned?'Unpin':'Pin'}">${t.pinned?'★ Unpin':'☆ Pin'}</button></article>`).join('')||'<p class="empty">No conversations yet.</p>';hydrateAvatars(list);hydrateGroupImages(list);

 U.qa('[data-thread]',list).forEach(b=>b.onclick=()=>b.dataset.kind==='group'?openGroup(b.dataset.thread):openDirectChat(b.dataset.thread));U.qa('[data-pin]',list).forEach(b=>b.onclick=async()=>{b.disabled=true;try{const t=rows.find(t=>t.thread_id===b.dataset.pin&&t.thread_kind===b.dataset.kind),key={user_id:S.user.id,thread_kind:t.thread_kind,thread_id:t.thread_id};must(t.pinned?await sb.from('chat_pins').delete().match(key):await sb.from('chat_pins').upsert(key));await load(true)}catch(e){U.toast(U.errorText(e),'error')}finally{b.disabled=false}})};

 const load=async(reset=false)=>{if(loading)return;loading=true;try{const found=[];if(reset)offset=0;const pages=reset?Math.ceil(limit/30):1;for(let i=0;i<pages;i++){const part=must(await sb.rpc('mobile_chat_threads',{page_offset:offset+found.length}));found.push(...part);if(part.length<30)break}if(S.page!=='groups'||!U.q('#thread-list'))return;rows=reset?found:[...rows,...found];offset=rows.length;limit=Math.max(30,offset);U.q('#thread-more').hidden=found.length<pages*30;paint()}catch(e){U.toast(U.errorText(e),'error')}finally{loading=false}};

 U.q('#thread-search').oninput=paint;U.q('#thread-more').onclick=()=>load();S.pageRefresh=()=>load(true);await load();

 const refresh=()=>{clearTimeout(timer);timer=setTimeout(()=>{if(S.page==='groups'&&U.q('#thread-list'))load(true)},250)};

 S.channel=sb.channel('chat-thread-updates');for(const table of ['chat_pins','group_messages','direct_messages','group_members','groups'])S.channel.on('postgres_changes',{event:'*',schema:'public',table},refresh);S.channel.subscribe();

}



async function renderGroups(){return renderChatThreads()}

function linkGroupInvites(root){U.qa('.bodytext,.ws-message-body,.message>div:not(.meta)',root).forEach(el=>{if(el.children.length)return;const matches=el.textContent.match(/https:\/\/[^\s<>]+/g)||[];for(const value of matches){try{const url=new URL(value),code=url.searchParams.get('group_invite');if(url.origin!==location.origin||!U.isUuid(code))continue;const button=document.createElement('button');button.className='btn small';button.textContent='Join group';button.onclick=()=>acceptGroupInvite(code);el.append(document.createElement('br'),button)}catch{}}})}



function messageTime(value){return new Date(value).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}

function messageMeta(name,date,mine=false){return `<strong>${U.esc(mine?'You':name)}</strong><time title="${U.attr(U.fmtDate(date))}">${U.esc(messageTime(date))}</time>`}

function syncMessages(log,html){

 const template=document.createElement('template');template.innerHTML=html;const old=new Map([...log.children].filter(n=>n.dataset.messageId).map(n=>[n.dataset.messageId,n]));let cursor=log.firstElementChild;const keep=new Set();

 for(let node of [...template.content.children]){const prev=old.get(node.dataset.messageId);if(prev&&prev.dataset.stamp===node.dataset.stamp)node=prev;keep.add(node);if(node!==cursor)log.insertBefore(node,cursor);cursor=node.nextElementSibling}

 for(const node of [...log.children])if(!keep.has(node))node.remove();

}

function addDayMarkers(log){let previous='';for(const row of U.qa('[data-created]',log)){const date=new Date(row.dataset.created).toLocaleDateString([],{year:'numeric',month:'short',day:'numeric'});if(date!==previous){row.dataset.day=date;row.classList.add('new-day')}else{delete row.dataset.day;row.classList.remove('new-day')}previous=date}}

let designRailChannel=null,railRefresh=null;

function stopDesignRail(){if(designRailChannel)sb.removeChannel(designRailChannel).catch(()=>{});designRailChannel=null;railRefresh=null;document.querySelector('.shell')?.classList.remove('messenger-shell')}

async function renderChatThreads(){

 chatLayout();cleanupChannel();stopDesignRail();S.group=null;S.direct=null;S.page='groups';

 const box=U.q('#page');box.classList.add('messenger-page');document.querySelector('.shell')?.classList.add('messenger-shell');box.innerHTML='<div class="messenger-layout"><aside id="conversation-rail"></aside><section id="conversation-pane"><div class="choose-conversation"><img src="ecp-logo.png" alt="Edu Chat Pro"><h1>Your conversations</h1><p>Choose a chat, or start a new conversation.</p></div></section></div>';

 await mountConversationRail();

}

async function mountConversationRail(){

 const rail=U.q('#conversation-rail');if(!rail)return;

 rail.innerHTML='<div class="rail-title"><h1>Chats</h1><button class="btn icon-btn" id="rail-new" aria-label="New conversation">+</button></div><div class="chat-filters">'+['All','Groups','Unread','Favorites'].map(t=>`<button class="${t==='All'?'selected':''}" data-chat-filter="${t}">${t}</button>`).join('')+'</div><label class="rail-search"><span>⌕</span><input id="rail-query" type="search" placeholder="Search chats, groups, people…"></label><div id="conversation-rows"></div><button class="btn ghost small" id="rail-load-more">More conversations</button>';

 let rows=[],filter='All',query='',loading=false,queued=false,offset=0,more=true,unread=new Map(),timer;

 const draw=()=>{if(!rail.isConnected)return;const list=U.q('#conversation-rows',rail);const shown=rows.filter(t=>(filter!=='Groups'||t.thread_kind==='group')&&(filter!=='Favorites'||t.pinned)&&(filter!=='Unread'||unread.has(t.thread_kind+'/'+t.thread_id))&&t.name.toLowerCase().includes(query));

 list.innerHTML=shown.map(t=>`<article class="conversation ${S.direct===t.thread_id?'selected':''}"><button class="conversation-main" data-open-kind="${t.thread_kind}" data-open-id="${t.thread_id}">${t.thread_kind==='group'?`<span class="avatar">${groupImage({image_path:t.avatar_path})}</span>`:avatarHtml({full_name:t.name,avatar_path:t.avatar_path})}<span class="conversation-copy"><strong>${U.esc(t.name)}</strong><span>${U.esc(t.preview||'Start a conversation')}</span></span><span class="conversation-end"><time>${U.esc(messageTime(t.updated_at))}</time>${unread.has(t.thread_kind+'/'+t.thread_id)?'<span class="unread-dot" aria-label="Unread messages"></span>':''}</span></button><button class="conversation-pin ${t.pinned?'pinned':''}" data-pin-id="${t.thread_id}" data-pin-kind="${t.thread_kind}" aria-label="${t.pinned?'Unpin':'Pin'} conversation">${t.pinned?'◆':'◇'}</button></article>`).join('')||'<div class="rail-empty">No matching conversations.<br><button class="text-btn" id="find-person">Find a person</button></div>';

 hydrateAvatars(list);hydrateGroupImages(list);U.q('#find-person',list)?.addEventListener('click',renderPeople);

 U.qa('[data-open-id]',list).forEach(b=>b.onclick=()=>{const t=rows.find(r=>r.thread_id===b.dataset.openId&&r.thread_kind===b.dataset.openKind);markThreadRead(t).catch(()=>{});b.dataset.openKind==='group'?openGroup(b.dataset.openId):openDirectChat(b.dataset.openId)});

 U.qa('[data-pin-id]',list).forEach(b=>b.onclick=async()=>{b.disabled=true;try{const t=rows.find(t=>t.thread_id===b.dataset.pinId&&t.thread_kind===b.dataset.pinKind),key={user_id:S.user.id,thread_kind:t.thread_kind,thread_id:t.thread_id};must(t.pinned?await sb.from('chat_pins').delete().match(key):await sb.from('chat_pins').upsert(key));await load(true)}catch(e){U.toast(U.errorText(e),'error')}finally{b.disabled=false}});

 };

 const load=async(reset=false)=>{if(loading){queued=true;return}loading=true;try{let fresh=[];const target=reset?Math.max(30,offset):30;while(fresh.length<target){const part=must(await sb.rpc('mobile_chat_threads',{page_offset:(reset?0:offset)+fresh.length}));fresh.push(...part);more=part.length===30;if(!more)break}if(!rail.isConnected)return;rows=reset?fresh:[...rows,...fresh];offset=rows.length;const r=await sb.rpc('web_unread_threads');if(!r.error)unread=new Map((r.data||[]).map(x=>[x.thread_kind+'/'+x.thread_id,true]));draw();U.q('#rail-load-more',rail).hidden=!more}catch(e){U.toast(U.errorText(e),'error')}finally{loading=false;if(queued&&rail.isConnected){queued=false;load(true)}}};

 railRefresh=()=>load(true);U.q('#rail-load-more',rail).onclick=()=>load();U.q('#rail-query',rail).oninput=e=>{query=e.target.value.trim().toLowerCase();draw()};U.qa('[data-chat-filter]',rail).forEach(b=>b.onclick=()=>{filter=b.dataset.chatFilter;U.qa('[data-chat-filter]',rail).forEach(x=>x.classList.toggle('selected',x===b));draw()});

 U.q('#rail-new',rail).onclick=()=>{const r=U.modal({title:'Start a conversation',body:'<button class="btn primary" id="new-person-design">Find a person</button>'+(can('groups.manage')?'<button class="btn" id="new-group-design">Create group</button>':'')});U.q('#new-person-design',r).onclick=()=>{U.closeModal();renderPeople()};U.q('#new-group-design',r)?.addEventListener('click',async()=>{const values=await U.promptBox({title:'Create group',fields:[{label:'Group name',max:120},{label:'Description',type:'textarea',required:false}],submit:'Create'});if(!values)return;try{const g=must(await sb.from('groups').insert({name:values[0],description:values[1],created_by:S.user.id}).select().single());await openGroup(g.id)}catch(e){U.toast(U.errorText(e),'error')}})};

 await load();if(!rail.isConnected)return;

 designRailChannel=sb.channel('web-conversation-rail-'+Date.now());for(const table of ['groups','group_messages','direct_messages','chat_pins','notifications','profiles'])designRailChannel.on('postgres_changes',{event:'*',schema:'public',table},()=>{clearTimeout(timer);timer=setTimeout(()=>{if(rail.isConnected)load(true)},250)});designRailChannel.subscribe();

}

async function markThreadRead(t){if(!t)return;const query=sb.from('notifications').update({read_at:new Date().toISOString()}).eq('user_id',S.user.id).is('read_at',null);if(t.thread_kind==='group')await query.eq('resource_id',t.thread_id).in('kind',['group_message','group_messages','announcement']);else{const messages=must(await sb.from('direct_messages').select('id').eq('sender_id',t.thread_id).eq('recipient_id',S.user.id).order('created_at',{ascending:false}).limit(200));if(messages.length)await query.eq('kind','direct_message').in('resource_id',messages.map(m=>m.id))}}

async function oldOpenDirectChat(id){

 let rail=U.q('#conversation-rail');if(rail)rail.remove();else stopDesignRail();

 await renderDirectConversation(id);

 if(S.direct!==id)return;const page=U.q('#page'),pane=document.createElement('section');pane.id='conversation-pane';while(page.firstChild)pane.append(page.firstChild);

 const layout=document.createElement('div');layout.className='messenger-layout';if(!rail){rail=document.createElement('aside');rail.id='conversation-rail'}layout.append(rail,pane);page.append(layout);page.classList.add('messenger-page');document.querySelector('.shell')?.classList.add('messenger-shell');if(!rail.children.length)await mountConversationRail();else railRefresh?.();

 U.q('#dm-back')?.addEventListener('click',()=>navigate('chats'));const text=U.q('#dm-text');text.placeholder='Type a message…';

 const emoji=document.createElement('button');emoji.type='button';emoji.className='btn ghost emoji-toggle';emoji.textContent='☺';emoji.setAttribute('aria-label','Choose emoji');emoji.onclick=()=>{const r=U.modal({title:'Choose emoji',body:['😊','👍','❤️','🎉','📚','✅','👋','😂'].map(v=>`<button class="btn">${v}</button>`).join('')});U.qa('.modal-body button',r).forEach(b=>b.onclick=()=>{text.value+=b.textContent;U.closeModal();text.focus()})};U.q('#dm-form .row').prepend(emoji);

}

async function installGroupInfo(g){

 const body=U.q('#group-body');if(!body||S.group?.id!==g.id)return;body.classList.add('group-conversation');body.querySelector('.group-info')?.remove();const info=document.createElement('aside');info.className='group-info card';info.innerHTML=`<header><strong>ⓘ &nbsp; Group info</strong><button class="text-btn" id="info-settings" aria-label="Group settings">•••</button></header><div class="group-info-title"><span class="avatar">${groupImage(g)}</span><div><h3>${U.esc(g.name)}</h3><span class="muted">Private group</span></div></div><p>${U.esc(g.description||'Connect, learn and share with your group.')}</p><div id="next-meeting-info"></div><section><div class="info-section-title"><h3>Members</h3><button class="text-btn" id="info-members">See all</button></div><div id="info-member-list"></div></section><section><div class="info-section-title"><h3>Shared media</h3><button class="text-btn" id="info-files">See all</button></div><div id="info-media-list"></div></section>`;body.append(info);const composer=body.querySelector('.chat-panel > .composer');if(composer)body.append(composer);hydrateGroupImages(info);

 U.q('#info-settings',info).onclick=()=>openGroup(g.id,'settings');U.q('#info-members',info).onclick=()=>openGroup(g.id,'members');U.q('#info-files',info).onclick=()=>openGroup(g.id,'files');

 try{const [memberResult,fileResult,meetingResult]=await Promise.all([sb.from('group_members').select('user_id').eq('group_id',g.id).limit(4),sb.from('group_files').select('*').eq('group_id',g.id).order('created_at',{ascending:false}).limit(4),sb.rpc('mobile_meetings',{group_filter:g.id,list_filter:'all',page_offset:0,newest_first:false})]);if(!info.isConnected)return;const members=must(memberResult),profiles=await namesFor(members.map(m=>m.user_id));U.q('#info-member-list',info).innerHTML=members.map(m=>{const p=profiles[m.user_id]||{};return `<div class="info-member">${avatarHtml(p)}<span><strong>${U.esc(p.full_name||'Member')}</strong><small>${m.user_id===g.created_by?'Owner':'Member'}</small></span></div>`}).join('');hydrateAvatars(info);

 const files=must(fileResult);U.q('#info-media-list',info).innerHTML=files.map(f=>`<button class="media-thumb" data-info-file="${f.id}" title="${U.attr(f.name)}">${f.mime_type?.startsWith('image/')?`<img data-info-image="${U.attr(f.object_path)}" alt="${U.attr(f.name)}">`:U.icon('file')}<small>${U.esc(f.name)}</small></button>`).join('')||'<p class="muted">No shared files yet.</p>';U.qa('[data-info-image]',info).forEach(img=>window.EduPhotos.get(sb,S.user.id,'group-files',img.dataset.infoImage).then(url=>{if(img.isConnected)img.src=url}).catch(()=>{}));U.qa('[data-info-file]',info).forEach(b=>b.onclick=()=>{const f=files.find(x=>x.id===b.dataset.infoFile),r=U.modal({title:f.name,body:mediaMarkup('group-files',f.object_path,f.mime_type,f.name)});hydrateMedia(r)});

 const meeting=(meetingResult.data||[]).find(m=>!m.ended_at);if(meeting){U.q('#next-meeting-info',info).innerHTML=`<div class="next-meeting">${U.icon('calendar')}<span><small>Next meeting</small><strong>${U.esc(meeting.title)}</strong></span><button class="btn small" id="info-join-meeting">Join</button></div>`;U.q('#info-join-meeting',info).onclick=()=>openMeeting(meeting,{autoJoin:true})}

 }catch(e){const target=U.q('#info-member-list',info);if(target)target.textContent='Open Members or Files to retry.'}

}

const chatReactionEmoji={like:'👍',love:'❤️',celebrate:'🎉',thanks:'🙏'};

async function hydrateChatReactions(log,kind){

 const nodes=U.qa('[data-message-id]',log);if(!nodes.length)return;const response=await sb.from('message_reactions').select('message_id,user_id,reaction').eq('thread_kind',kind).in('message_id',nodes.map(n=>n.dataset.messageId));if(response.error)return;

 for(const node of nodes){if(!node.isConnected)continue;let bar=node.querySelector('.chat-reactions');if(!bar){bar=document.createElement('div');bar.className='chat-reactions';node.querySelector('.message').append(bar)}const items=(response.data||[]).filter(r=>r.message_id===node.dataset.messageId),mine=items.find(r=>r.user_id===S.user.id)?.reaction;

 bar.innerHTML=Object.entries(chatReactionEmoji).map(([key,value])=>{const count=items.filter(r=>r.reaction===key).length;return `<button data-message-react="${key}" class="${count?'has-reactions':''} ${mine===key?'selected':''}" title="${key}" aria-pressed="${mine===key}">${value}${count?' '+count:''}</button>`}).join('');U.qa('[data-message-react]',bar).forEach(b=>b.onclick=async()=>{b.disabled=true;try{const key={thread_kind:kind,message_id:node.dataset.messageId,user_id:S.user.id};must(mine===b.dataset.messageReact?await sb.from('message_reactions').delete().match(key):await sb.from('message_reactions').upsert({...key,reaction:b.dataset.messageReact}));await hydrateChatReactions(log,kind)}catch(e){U.toast(U.errorText(e),'error')}finally{b.disabled=false}});

 }

}





async function changeWebGroupPhoto(g,tab='chat'){

 const input=document.createElement('input');input.type='file';input.accept='image/jpeg,image/png,image/webp';input.onchange=async()=>{const file=input.files?.[0];if(!file)return;let path,saved=false;try{const blob=await window.EduCrop(file);if(!blob)return;path=`${g.id}/${U.uuid()}.jpg`;must(await sb.storage.from('group-images').upload(path,blob,{contentType:'image/jpeg'}));must(await sb.from('groups').update({image_path:path}).eq('id',g.id).select('id,image_path').single());saved=true;if(g.image_path&&g.image_path!==path)await sb.storage.from('group-images').remove([g.image_path]);U.toast('Group photo saved.','ok');await openGroup(g.id,tab)}catch(e){if(path&&!saved)await sb.storage.from('group-images').remove([path]);U.toast(U.errorText(e)+' If upload is denied, run the supplied Supabase SQL.','error')}};input.click();

}




async function openGroup(id,tab='chat'){window.EduWorkspace.pending={kind:'group',id};window.EduWorkspace.pendingPanel=({files:'Files',members:'Members',meetings:'Meetings',drive:'Google Drive',settings:'Settings'})[tab]||null;await navigate('groups');}
async function openDirectChat(id){const thread=must(await sb.rpc('start_direct_chat',{other_user:id}));window.EduWorkspace.pending={kind:'direct',id:thread};await navigate('people');}

window.toggleTheme=toggleTheme;

init();

})();

