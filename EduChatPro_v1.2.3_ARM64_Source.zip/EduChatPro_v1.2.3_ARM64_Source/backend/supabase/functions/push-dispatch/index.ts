import { importPKCS8, SignJWT } from 'npm:jose@5.9.6';
import { admin, env, HttpError, response, serve, uuid } from '../_shared/http.ts';
// Retry transient network/FCM failures without logging tokens or private credentials.
async function sendWithRetry(url: string, init: RequestInit): Promise<Response> {
  let failure: unknown;
  for (let attempt=0; attempt<3; attempt++) {
    try {
      const result=await fetch(url,{...init,signal:AbortSignal.timeout(12000)});
      if(result.status!==429&&result.status<500||attempt===2)return result;
      await result.body?.cancel();
    } catch(error) {failure=error;if(attempt===2)throw error;}
    await new Promise(resolve=>setTimeout(resolve,250*Math.pow(3,attempt)));
  }
  throw failure??new Error('Push delivery failed');
}
// Invoke from a Supabase notifications INSERT webhook. Payload contains only an
// ID; authoritative notification and recipients are always reread server-side.
serve(async request => {
  const provided = request.headers.get('x-webhook-secret') ?? '';
  const expected = env('PUSH_WEBHOOK_SECRET');
  const a = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(provided)));
  const b = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(expected)));
  let mismatch = 0; for (let i = 0; i < a.length; i++) mismatch |= a[i] ^ b[i];
  if (mismatch) throw new HttpError('Invalid webhook secret', 401);
  const payload = await request.json();
  const id = uuid(payload.record?.id);
  const service = admin();
  const { data: notification, error } = await service.from('notifications').select('*').eq('id', id).single();
  if (error || !notification) throw new HttpError('Unknown notification', 404);
  const account = await service.from('profiles').select('status').eq('id', notification.user_id).single();
  if (account.data?.status !== 'active') return response({ delivered: 0 });
  const tokens = await service.from('device_tokens').select('token,platform').eq('user_id', notification.user_id).limit(50);
  if(tokens.error)throw new Error('Could not read push registrations');
  if (!tokens.data?.length) return response({ delivered: 0 });
  const isCall = ['direct_call_audio','direct_call_video','group_call'].includes(notification.kind);
  if (isCall) {
    const meeting = await service.from('meetings').select('ended_at').eq('id', notification.resource_id).maybeSingle();
    if (!meeting.data || meeting.data.ended_at || Date.now()-Date.parse(notification.created_at)>60000)
      return response({ delivered:0, skipped:'call ended or expired' });
  }
  const credentials = JSON.parse(env('FIREBASE_SERVICE_ACCOUNT_JSON'));
  const key = await importPKCS8(credentials.private_key, 'RS256');
  const assertion = await new SignJWT({ scope: 'https://www.googleapis.com/auth/firebase.messaging' }).setProtectedHeader({ alg: 'RS256' }).setIssuer(credentials.client_email).setAudience('https://oauth2.googleapis.com/token').setIssuedAt().setExpirationTime('1h').sign(key);
  const oauth = await sendWithRetry('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion }) });
  if (!oauth.ok) throw new Error('Firebase authorization failed');
  const { access_token } = await oauth.json();
  let delivered = 0, failed = 0;
  for (const { token, platform } of tokens.data) {
    const cancel = notification.kind === 'call_cancel';
    const nativeCall = (isCall || cancel) && platform === 'android';
    const nativeAndroid = platform === 'android';
    const data: Record<string,string> = { notification_id: id, kind: notification.kind,
      resource_id: notification.resource_id ?? '', title: String(notification.title || 'New Edu Chat Pro update'),
      target_kind: String(notification.target_kind || ''), target_id: String(notification.target_id || ''),
      expires_at_ms: String(Date.parse(notification.created_at) + 60000) };
    if(cancel) data.call_notification_id=notification.resource_id ?? ''; // meeting/resource id used as Android ringing tag
    const message: Record<string,unknown> = { token, data,
      android: { priority:'high', ttl:isCall||cancel?'60s':'86400s',
        ...(!nativeAndroid ? {notification:{sound:'default',tag:id,channel_id:'educhat_messages',icon:'ic_notification'}} : {}) },
    };
    if(!nativeAndroid){
      message.notification={title:'Edu Chat Pro',body:notification.title};
      message.apns={headers:{'apns-priority':'10'},payload:{aps:{sound:'default'}}};
      message.webpush={headers:{Urgency:'high',TTL:isCall?'60':'86400'},notification:{tag:id}};
    }
    // Cancellation is silent and only meaningful for native ringing devices.
    if(cancel&&!nativeCall)continue;
    const result=await sendWithRetry(`https://fcm.googleapis.com/v1/projects/${env('FIREBASE_PROJECT_ID')}/messages:send`,{
      method:'POST',headers:{Authorization:`Bearer ${access_token}`,'Content-Type':'application/json'},body:JSON.stringify({message})});
    if (result.ok) delivered++;
    else { failed++; const body = await result.json(); if (body.error?.details?.some((d: { errorCode?: string }) => d.errorCode === 'UNREGISTERED')) await service.from('device_tokens').delete().eq('user_id', notification.user_id).eq('token', token); }
  }
  // Exhausted transient retries remain failures; do not report them as successful deliveries.
  return response({ delivered, failed }, failed ? 502 : 200);
});
