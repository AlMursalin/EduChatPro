import { createClient } from 'npm:@supabase/supabase-js@2.116.0';
export const env = (name: string): string => {
  const value = Deno.env.get(name);
  if (!value) throw new Error(`Missing server configuration: ${name}`);
  return value;
};
function corsOrigin(request?: Request): string {
  const origin = request?.headers.get('Origin') ?? '';
  const configured = (Deno.env.get('APP_ORIGINS') ?? Deno.env.get('APP_ORIGIN') ?? '*')
    .split(',').map(v => v.trim()).filter(Boolean);
  if (configured.includes('*')) return '*';
  return origin && configured.includes(origin) ? origin : (configured[0] ?? '*');
}
export function response(body: unknown, status = 200, request?: Request) {
  return new Response(JSON.stringify(body), { status, headers: {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': corsOrigin(request),
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Vary': 'Origin',
  }});
}
export function serve(handler: (request: Request) => Promise<Response>) {
  Deno.serve(async request => {
    if (request.method === 'OPTIONS') return response({}, 200, request);
    if (request.method !== 'POST') return response({ error: 'POST required' }, 405, request);
    try { return await handler(request); }
    catch (error) {
      const status = error instanceof HttpError ? error.status : 500;
      return response({ error: status === 500 ? 'Server configuration or operation failed. Check server setup.' : (error as Error).message }, status, request);
    }
  });
}
export class HttpError extends Error { constructor(message: string, public status = 403) { super(message); } }
export async function caller(request: Request) {
  const authorization = request.headers.get('Authorization');
  if (!authorization?.startsWith('Bearer ')) throw new HttpError('Sign in required', 401);
  const client = createClient(env('SUPABASE_URL'), env('SUPABASE_ANON_KEY'), {
    global: { headers: { Authorization: authorization } }, auth: { persistSession: false },
  });
  const { data, error } = await client.auth.getUser();
  if (error || !data.user) throw new HttpError('Invalid session', 401);
  const active = await client.rpc('is_active');
  if (active.error || active.data !== true) throw new HttpError('Access revoked', 403);
  return { client, user: data.user };
}
export const admin = () => createClient(env('SUPABASE_URL'), env('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false, autoRefreshToken: false } });
export function uuid(value: unknown): string {
  if (typeof value !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) throw new HttpError('Invalid ID', 400);
  return value;
}
