BACKGROUND PUSH SETUP — Edu Chat Pro v1.2.3
Firebase project: edu-chat-585b0
Supabase project ref: xaqctutviuxwjuqjuidx

PURPOSE
The Android APK registers each signed-in phone's FCM token in public.device_tokens. A Supabase database webhook invokes the included push-dispatch Edge Function after a row is inserted into public.notifications. The Edge Function rereads the authoritative notification server-side and sends FCM HTTP v1 high-priority data messages. Android then renders message notifications or incoming-call UI natively, so the WebView/Flutter screen does not need to be open.

1. DEPLOY THE INCLUDED EDGE FUNCTION
From this backend directory:
  supabase functions deploy push-dispatch --project-ref xaqctutviuxwjuqjuidx --no-verify-jwt

The function checks x-webhook-secret itself. It is not intended to be a public arbitrary push sender.

2. SET SERVER-ONLY SECRETS IN SUPABASE
  FIREBASE_PROJECT_ID=edu-chat-585b0
  FIREBASE_SERVICE_ACCOUNT_JSON=<the complete Firebase/Google service-account JSON>
  PUSH_WEBHOOK_SECRET=<a strong private random value>

Supabase supplies SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY to the Edge Function runtime.

SECURITY RULE: FIREBASE_SERVICE_ACCOUNT_JSON and PUSH_WEBHOOK_SECRET must stay server-side. Never place either value in the APK, google-services.json, web assets, Git commits, public files, or client environment variables. google-services.json is client configuration; it is NOT a Firebase Admin credential.

3. RETAIN/CONFIGURE ONE DATABASE WEBHOOK
Table/event:
  public.notifications — INSERT

Destination:
  POST https://xaqctutviuxwjuqjuidx.supabase.co/functions/v1/push-dispatch

Headers:
  Content-Type: application/json
  x-webhook-secret: <the exact PUSH_WEBHOOK_SECRET value>

Use Supabase's standard database webhook payload containing record.id. Update an existing matching webhook instead of creating duplicates.

4. DEVICE SETUP
- Open the Android app and sign in once.
- Approve Android notification permission when prompted.
- For Android 14 full-screen incoming-call UI, allow the app's full-screen call setting when prompted if desired.
- The app upserts/refreshed FCM tokens in public.device_tokens.

DELIVERY BEHAVIOR
- Chat/update messages: native high-importance notification channel, sound + vibration.
- Direct/group calls: native incoming-call channel, ringtone + vibration, Answer/Decline, full-screen UI where Android permits it.
- call_cancel: uses meeting/resource ID as the native call tag so the exact ringing call can be cancelled.
- Calls expire after 60 seconds.
- Force-stopping the app in Android Settings blocks FCM until the user opens it again; this cannot be bypassed.

LIVE VERIFICATION CHECKLIST
A. Confirm an Android user's current FCM token exists in public.device_tokens.
B. Insert/send a normal message that creates a public.notifications row; confirm Edge Function invocation succeeds and phone receives a sound notification with app backgrounded.
C. Start a direct audio/video call; confirm incoming-call ringtone/actions appear with app backgrounded.
D. Cancel/end before answer; confirm call_cancel stops the ringtone/full-screen call promptly.
E. Repeat after swiping the app away from Recents (not Force stop).
F. Test on Android 13+ with notification permission both allowed and denied.

This folder contains the server code and configuration contract. Do not treat source presence alone as proof that live secrets/webhooks have been deployed successfully.
