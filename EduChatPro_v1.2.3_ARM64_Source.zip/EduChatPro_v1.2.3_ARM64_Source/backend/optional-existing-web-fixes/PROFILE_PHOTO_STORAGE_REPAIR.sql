-- Optional storage repair for an EXISTING EduChat database.
-- Use only if upload still reports 'Bucket not found' / storage permission denied.
-- No user, message or existing photo is deleted. RLS stays enabled.
begin;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('avatars','avatars',false,1048576,array['image/jpeg','image/png','image/webp'])
on conflict(id) do update set
 file_size_limit=case when storage.buckets.file_size_limit is null then null else greatest(storage.buckets.file_size_limit,1048576) end,
 allowed_mime_types=case when storage.buckets.allowed_mime_types is null then null else array(select distinct unnest(storage.buckets.allowed_mime_types||array['image/jpeg','image/png','image/webp'])) end;

drop policy if exists ecp_avatar_self_insert_20260930 on storage.objects;
create policy ecp_avatar_self_insert_20260930 on storage.objects for insert to authenticated
with check(bucket_id='avatars' and public.is_active() and (storage.foldername(storage.objects.name))[1]=auth.uid()::text);
drop policy if exists ecp_avatar_active_read_20260930 on storage.objects;
create policy ecp_avatar_active_read_20260930 on storage.objects for select to authenticated
using(bucket_id='avatars' and public.is_active());
drop policy if exists ecp_avatar_self_delete_20260930 on storage.objects;
create policy ecp_avatar_self_delete_20260930 on storage.objects for delete to authenticated
using(bucket_id='avatars' and public.is_active() and (storage.foldername(storage.objects.name))[1]=auth.uid()::text);
grant select(id,avatar_path),update(avatar_path) on public.profiles to authenticated;
drop policy if exists ecp_avatar_profile_self_update_20260930 on public.profiles;
create policy ecp_avatar_profile_self_update_20260930 on public.profiles for update to authenticated
using(id=auth.uid() and public.is_active()) with check(id=auth.uid() and public.is_active());
notify pgrst,'reload schema';
commit;
