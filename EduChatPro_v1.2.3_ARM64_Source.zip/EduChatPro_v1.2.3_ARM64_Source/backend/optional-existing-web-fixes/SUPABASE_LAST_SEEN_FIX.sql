-- Run once in the existing EduChat Supabase SQL Editor.
begin;
alter table public.profiles add column if not exists last_seen_visible boolean not null default true;
alter table public.profiles add column if not exists last_active_at timestamptz;
create table if not exists public.ecp_presence_devices(user_id uuid not null references public.profiles(id) on delete cascade,device_id uuid not null,online boolean not null default false,touched_at timestamptz not null default now(),primary key(user_id,device_id));
alter table public.ecp_presence_devices enable row level security;
revoke all on public.ecp_presence_devices from public,anon,authenticated;
create or replace function public.ecp_presence_heartbeat(device uuid,visible boolean) returns void language plpgsql security definer set search_path=public,pg_temp as $$begin
 if auth.uid() is null or not public.is_active() then raise exception 'Active account required' using errcode='42501';end if;
 if device is null then raise exception 'Device identifier required';end if;
 insert into public.ecp_presence_devices(user_id,device_id,online,touched_at) values(auth.uid(),device,visible,now()) on conflict(user_id,device_id) do update set online=excluded.online,touched_at=excluded.touched_at;
 update public.profiles set last_active_at=now() where id=auth.uid();
 delete from public.ecp_presence_devices where user_id=auth.uid() and touched_at<now()-interval '7 days';
end$$;
create or replace function public.ecp_presence_list(targets uuid[]) returns table(id uuid,full_name text,avatar_path text,last_active_at timestamptz,last_seen_visible boolean,public_id text,role text,active_now boolean)
language sql stable security definer set search_path=public,pg_temp as $$
 select p.id,p.full_name,p.avatar_path,
 case when a.hidden then null else greatest(p.last_active_at,d.latest) end,
 not a.hidden,p.public_id,coalesce(r.role,'student'),
 case when a.hidden then false else coalesce(d.online,false) or ((d.latest is null or p.last_active_at>d.latest+interval '5 seconds') and p.last_active_at>now()-interval '90 seconds') end
 from public.profiles p
 left join lateral(select u.role::text role from public.user_roles u where u.user_id=p.id limit 1) r on true
 cross join lateral(select coalesce(r.role,'student') in('super_admin','assistant_admin') and not p.last_seen_visible hidden) a
 left join lateral(select max(touched_at) latest,bool_or(online and touched_at>now()-interval '75 seconds') online from public.ecp_presence_devices where user_id=p.id) d on true
 where public.is_active() and p.id=any(targets[1:200])
$$;
create or replace function public.set_last_seen_visibility(show_value boolean) returns boolean language plpgsql security definer set search_path=public,pg_temp as $$begin
 if not public.is_active() or not exists(select 1 from public.user_roles where user_id=auth.uid() and role::text in('super_admin','assistant_admin')) then raise exception 'Only admins can change their own last seen' using errcode='42501';end if;
 update public.profiles set last_seen_visible=coalesce(show_value,true) where id=auth.uid();return coalesce(show_value,true);end$$;
create or replace function public.enforce_profile_last_seen_visibility() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$begin
 if not new.last_seen_visible and not exists(select 1 from public.user_roles where user_id=new.id and role::text in('super_admin','assistant_admin')) then new.last_seen_visible:=true;end if;return new;end$$;
drop trigger if exists trg_profile_last_seen_visibility on public.profiles;
create trigger trg_profile_last_seen_visibility before insert or update on public.profiles for each row execute function public.enforce_profile_last_seen_visibility();
update public.profiles p set last_seen_visible=true where not last_seen_visible and not exists(select 1 from public.user_roles r where r.user_id=p.id and r.role::text in('super_admin','assistant_admin'));
revoke all on function public.ecp_presence_heartbeat(uuid,boolean),public.ecp_presence_list(uuid[]),public.set_last_seen_visibility(boolean) from public,anon;
grant execute on function public.ecp_presence_heartbeat(uuid,boolean),public.ecp_presence_list(uuid[]),public.set_last_seen_visibility(boolean) to authenticated;
notify pgrst,'reload schema';
commit;
